from __future__ import annotations

import hashlib
import json
import os
import shutil
import socket
import subprocess
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "update_config.json"
STATE_DIR = APP_DIR / "updates"
STATE_PATH = STATE_DIR / "current_version.json"
DOWNLOAD_DIR = STATE_DIR / "downloads"
BACKUP_DIR = STATE_DIR / "backups"

DEFAULT_CONFIG = {
    "enabled": False,
    "manifest_url": "",
    "current_version": "0.0.0",
    "timeout_seconds": 20,
    "keep_backups": 3,
}

PROTECTED_EXACT = {
    "auth/license_cache.json",
    "data/pdd/product_library.json",
}

PROTECTED_PREFIXES = (
    "data/",
    "pdd_profiles/",
    "pdd_cookies/",
    "pdd_browser_profile/",
    "browser_profile_1688/",
    "chrome_debug_profile/",
    "hf_cache/",
    "supplier_data/",
)

ALLOWED_SUFFIXES = {
    ".py",
    ".pyw",
    ".bat",
    ".cmd",
    ".vbs",
    ".json",
    ".md",
    ".txt",
    ".ini",
    ".cfg",
    ".yaml",
    ".yml",
}


@dataclass
class UpdateResult:
    checked: bool
    updated: bool
    message: str


def get_current_version() -> str:
    config = _load_config()
    return _current_version(config)


def check_and_apply_update(show_ui: bool = False) -> UpdateResult:
    _disable_dead_local_proxy()
    config = _load_config()
    if not config.get("enabled"):
        return UpdateResult(False, False, "Auto update disabled.")

    manifest_url = str(config.get("manifest_url") or "").strip()
    if not manifest_url:
        return UpdateResult(False, False, "Auto update manifest URL is empty.")

    try:
        manifest = _fetch_json(manifest_url, _timeout(config))
        remote_version = str(manifest.get("version") or "").strip()
        package_url = str(manifest.get("package_url") or "").strip()
        package_sha256 = str(manifest.get("sha256") or "").strip().lower()
        if not remote_version or not package_url or not package_sha256:
            return UpdateResult(True, False, "Update manifest is incomplete.")

        current_version = _current_version(config)
        if _version_key(remote_version) <= _version_key(current_version):
            return UpdateResult(True, False, f"Already current: {current_version}.")

        if show_ui:
            _show_info("正在更新", f"发现新版本 {remote_version}，正在下载更新。")

        package_path = _download_package(package_url, remote_version, _timeout(config))
        actual_sha256 = _sha256(package_path)
        if actual_sha256.lower() != package_sha256:
            package_path.unlink(missing_ok=True)
            return UpdateResult(True, False, "Downloaded update checksum mismatch.")

        changed_files = _apply_patch_package(package_path, remote_version)
        if not changed_files:
            return UpdateResult(True, False, "Update package did not contain allowed files.")

        _write_state(remote_version, changed_files)
        _prune_backups(int(config.get("keep_backups") or 3))
        if show_ui:
            _show_info("更新完成", f"已更新到 {remote_version}，即将启动软件。")
        return UpdateResult(True, True, f"Updated to {remote_version}.")
    except Exception as exc:
        _write_error_log(exc)
        if show_ui:
            _show_info("更新跳过", "自动更新失败，本次将继续打开当前版本。")
        return UpdateResult(True, False, f"Auto update failed: {exc}")

def _disable_dead_local_proxy() -> None:
    proxy_keys = ("ALL_PROXY", "HTTPS_PROXY", "HTTP_PROXY", "all_proxy", "https_proxy", "http_proxy")
    for key in proxy_keys:
        value = os.environ.get(key) or ""
        if "127.0.0.1" not in value and "localhost" not in value:
            continue
        host, port = _parse_proxy_host_port(value)
        if not host or not port:
            continue
        try:
            with socket.create_connection((host, port), timeout=0.5):
                continue
        except OSError:
            os.environ.pop(key, None)


def _parse_proxy_host_port(value: str) -> tuple[str, int | None]:
    value = value.strip()
    if "://" in value:
        value = value.split("://", 1)[1]
    value = value.split("/", 1)[0]
    if "@" in value:
        value = value.rsplit("@", 1)[1]
    if ":" not in value:
        return value, None
    host, port_text = value.rsplit(":", 1)
    try:
        return host.strip("[]"), int(port_text)
    except ValueError:
        return host.strip("[]"), None

def _load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return dict(DEFAULT_CONFIG)
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))
    except Exception:
        return dict(DEFAULT_CONFIG)
    config = dict(DEFAULT_CONFIG)
    if isinstance(data, dict):
        config.update(data)
    return config


def _timeout(config: dict[str, Any]) -> int:
    try:
        return max(3, int(config.get("timeout_seconds") or 20))
    except Exception:
        return 20


def _current_version(config: dict[str, Any]) -> str:
    if STATE_PATH.exists():
        try:
            data = json.loads(STATE_PATH.read_text(encoding="utf-8-sig"))
            version = str(data.get("version") or "").strip()
            if version:
                return version
        except Exception:
            pass
    return str(config.get("current_version") or "0.0.0").strip() or "0.0.0"


def _fetch_json(url: str, timeout: int) -> dict[str, Any]:
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "PDDClientUpdater/1.0"})
        with _open_url(request, timeout) as response:
            raw = response.read(1024 * 1024)
    except Exception:
        raw = _download_url_with_powershell(url, timeout)
    data = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("Manifest is not a JSON object.")
    return data


def _download_url_with_powershell(url: str, timeout: int) -> bytes:
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    tmp = DOWNLOAD_DIR / f"http_{int(time.time() * 1000)}.tmp"
    startupinfo = None
    creationflags = 0
    if hasattr(subprocess, "STARTUPINFO"):
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        creationflags = subprocess.CREATE_NO_WINDOW
    try:
        curl = shutil.which("curl.exe") or shutil.which("curl")
        if curl:
            completed = subprocess.run(
                [curl, "-L", "--max-time", str(timeout), "-o", str(tmp), url],
                capture_output=True,
                text=True,
                timeout=max(timeout + 10, 20),
                startupinfo=startupinfo,
                creationflags=creationflags,
            )
            if completed.returncode == 0 and tmp.is_file():
                return tmp.read_bytes()

        safe_url = url.replace("'", "''")
        safe_tmp = str(tmp).replace("'", "''")
        command = (
            "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; "
            f"Invoke-WebRequest -Uri '{safe_url}' "
            f"-OutFile '{safe_tmp}' -UseBasicParsing -TimeoutSec {int(timeout)}"
        )
        completed = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                command,
            ],
            capture_output=True,
            text=True,
            timeout=max(timeout + 10, 20),
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
        if completed.returncode != 0:
            raise RuntimeError((completed.stderr or completed.stdout or "PowerShell download failed").strip())
        if not tmp.is_file():
            raise FileNotFoundError(str(tmp))
        return tmp.read_bytes()
    finally:
        tmp.unlink(missing_ok=True)

def _open_url(request: urllib.request.Request, timeout: int):
    try:
        return urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.URLError:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        return opener.open(request, timeout=timeout)


def _download_package(url: str, version: str, timeout: int) -> Path:
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    target = DOWNLOAD_DIR / f"patch_{_safe_name(version)}.zip"
    tmp = target.with_suffix(".download")
    request = urllib.request.Request(url, headers={"User-Agent": "PDDClientUpdater/1.0"})
    try:
        with _open_url(request, timeout) as response, tmp.open("wb") as fh:
            shutil.copyfileobj(response, fh)
    except Exception:
        tmp.write_bytes(_download_url_with_powershell(url, timeout))
    tmp.replace(target)
    return target

def _apply_patch_package(package_path: Path, version: str) -> list[str]:
    changed: list[str] = []
    backup_root = BACKUP_DIR / f"{time.strftime('%Y%m%d_%H%M%S')}_{_safe_name(version)}"
    planned: list[tuple[zipfile.ZipInfo, str, Path]] = []
    try:
        with zipfile.ZipFile(package_path, "r") as archive:
            for entry in archive.infolist():
                if entry.is_dir():
                    continue
                rel = _clean_zip_name(entry.filename)
                if not rel or _is_protected(rel) or not _is_allowed_update_file(rel):
                    continue
                target = _resolve_app_path(rel)
                planned.append((entry, rel, target))

            for _, rel, target in planned:
                if target.exists():
                    backup_path = backup_root / rel
                    backup_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, backup_path)

            for entry, rel, target in planned:
                target.parent.mkdir(parents=True, exist_ok=True)
                tmp_target = target.with_name(target.name + ".update_tmp")
                with archive.open(entry, "r") as src, tmp_target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
                tmp_target.replace(target)
                changed.append(rel)
    except Exception:
        _restore_backup(backup_root, changed)
        raise

    return changed


def _restore_backup(backup_root: Path, changed_files: Iterable[str]) -> None:
    for rel in reversed(list(changed_files)):
        backup_path = backup_root / rel
        if not backup_path.is_file():
            continue
        target = _resolve_app_path(rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(backup_path, target)


def _clean_zip_name(name: str) -> str:
    rel = name.replace("\\", "/").lstrip("/")
    if rel.startswith("files/"):
        rel = rel[len("files/") :]
    parts = [part for part in rel.split("/") if part not in ("", ".")]
    if any(part == ".." for part in parts):
        return ""
    return "/".join(parts)


def _resolve_app_path(rel: str) -> Path:
    target = (APP_DIR / rel).resolve()
    app = APP_DIR.resolve()
    if target != app and app not in target.parents:
        raise ValueError(f"Refusing path outside app directory: {rel}")
    return target


def _is_protected(rel: str) -> bool:
    rel = rel.replace("\\", "/").lstrip("/")
    if rel in PROTECTED_EXACT:
        return True
    return any(rel.startswith(prefix) for prefix in PROTECTED_PREFIXES)


def _is_allowed_update_file(rel: str) -> bool:
    path = Path(rel)
    if path.name == "update_config.json":
        return False
    return path.suffix.lower() in ALLOWED_SUFFIXES


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _version_key(version: str) -> tuple[int, ...]:
    parts: list[int] = []
    for piece in str(version).replace("-", ".").replace("_", ".").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts or [0])


def _safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in value)[:80]


def _write_state(version: str, changed_files: Iterable[str]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": version,
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "files": list(changed_files),
    }
    STATE_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _prune_backups(keep: int) -> None:
    keep = max(1, keep)
    if not BACKUP_DIR.exists():
        return
    backups = sorted(
        [p for p in BACKUP_DIR.iterdir() if p.is_dir()],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for old in backups[keep:]:
        if old.parent == BACKUP_DIR and old.name:
            shutil.rmtree(old, ignore_errors=True)


def _write_error_log(exc: Exception) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    log_path = STATE_DIR / "update_errors.log"
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {type(exc).__name__}: {exc}\n")


def _show_info(title: str, message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        try:
            messagebox.showinfo(title, message, parent=root)
        finally:
            root.destroy()
    except Exception:
        pass
