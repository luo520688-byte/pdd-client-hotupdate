"""
磁力金牛选品助手 — 桌面客户端 v5
"""
import sys, os, json, subprocess, re, traceback, time
from pathlib import Path
from datetime import datetime, timedelta

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTableWidget, QTableWidgetItem,
    QCheckBox, QSpinBox, QComboBox, QLabel, QPushButton, QLineEdit,
    QPlainTextEdit, QGroupBox, QFrame, QStatusBar,
    QFileDialog, QProgressBar, QAbstractItemView,
    QMessageBox, QTimeEdit, QMenu, QAction,
    QDialog, QDialogButtonBox, QListWidget, QListWidgetItem, QScrollArea,
    QTreeWidget, QTreeWidgetItem, QHeaderView, QTabWidget, QStackedWidget,
    QFormLayout, QDoubleSpinBox, QLayout, QSizePolicy
)
from PyQt5.QtWidgets import QShortcut
import pricing_rules
import product_library
import xuanpin_reco
import pending_publish
import urllib.request
# 下载 opener:必须走 clash(★实测这台机直连国内CDN极慢:一张214KB图直连210秒、走clash 0秒)。
# ★★坑:双击启动客户端会继承系统 all_proxy 环境变量,但 urllib 不认 all_proxy(只认 http/https_proxy)
#   → 默认 opener 以为没代理 → 走直连 → 慢死。所以【直接读注册表里的系统代理(clash)】,并把
#   'all' 补成 http/https,绕开这个坑。clash 没开=注册表空=直连(唯一选择),不影响。
def _make_dl_opener():
    try:
        _px = dict(urllib.request.getproxies_registry())
    except Exception:
        _px = {}
    if not _px.get("http") and not _px.get("https"):
        _px = dict(urllib.request.getproxies())
    _all = _px.get("all")
    if _all:
        _px.setdefault("http", _all)
        _px.setdefault("https", _all)
    return urllib.request.build_opener(urllib.request.ProxyHandler(_px))


_DL_OPENER = _make_dl_opener()
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QUrl, QTimer, QTime, QProcess, QFileSystemWatcher
from PyQt5.QtCore import QRect, QSize, QPoint
from PyQt5.QtGui import QColor, QFont, QPalette, QPixmap, QKeySequence
from PyQt5.QtGui import QDesktopServices


APP_TITLE = "磁力金牛选品助手"
APP_RELEASE_VERSION = "1.0.9"

def _read_app_version() -> str:
    try:
        state_path = Path(__file__).resolve().parent / "updates" / "current_version.json"
        data = json.loads(state_path.read_text(encoding="utf-8-sig"))
        version = str(data.get("version") or "").strip()
        if version:
            return version
    except Exception:
        pass
    return APP_RELEASE_VERSION


class UpdateCheckThread(QThread):
    result_signal = pyqtSignal(object)

    def run(self):
        try:
            from auto_updater import check_and_apply_update
            self.result_signal.emit(check_and_apply_update(show_ui=False))
        except Exception as exc:
            self.result_signal.emit(exc)


class FlowLayout(QLayout):
    """按可用宽度自动换行的布局:窗口宽→排一行,窗口窄→按钮自动折到下一行。
    用于选品区工具栏,让窗口不最大化也能看全(按钮太多时换行而非把窗口顶宽)。"""

    def __init__(self, parent=None, hspacing=8, vspacing=6):
        super().__init__(parent)
        self._hspace = hspacing
        self._vspace = vspacing
        self._items = []

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientations(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        s = QSize()
        for it in self._items:
            s = s.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        s += QSize(m.left() + m.right(), m.top() + m.bottom())
        return s

    def _do(self, rect, test):
        m = self.contentsMargins()
        eff = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y, lineh = eff.x(), eff.y(), 0
        for it in self._items:
            w = it.sizeHint().width()
            h = it.sizeHint().height()
            nx = x + w + self._hspace
            if nx - self._hspace > eff.right() and lineh > 0:
                x = eff.x()
                y = y + lineh + self._vspace
                nx = x + w + self._hspace
                lineh = 0
            if not test:
                it.setGeometry(QRect(QPoint(x, y), it.sizeHint()))
            x = nx
            lineh = max(lineh, h)
        return y + lineh - rect.y() + m.bottom()


# ── 全局异常捕获 + 崩溃落盘 ─────────────────────────────────────────────────
_CRASH_LOG_PATH = Path("D:/files/data/client_crash.log")

def _crash_write(tag: str, msg: str):
    """所有崩溃 / 退出事件都写到 client_crash.log,带时间戳。
    长时间运行的 client 突然消失时,这个文件是唯一证据。
    """
    try:
        from datetime import datetime as _dt
        _CRASH_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(_CRASH_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"\n========== {_dt.now().strftime('%Y-%m-%d %H:%M:%S')}  [{tag}] ==========\n")
            f.write(msg)
            f.write("\n")
    except Exception:
        pass


def _global_exc_handler(exc_type, exc_value, exc_tb):
    msg = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    _crash_write("PYTHON_EXC", msg)  # 先落盘,UI 弹窗失败也保住证据
    try:
        from PyQt5.QtWidgets import QMessageBox, QApplication
        if QApplication.instance():
            QMessageBox.critical(None, "程序异常", msg[:2000])
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)

sys.excepthook = _global_exc_handler

# Qt 消息(QtFatalMsg / QtCriticalMsg 等)钩子:捕获 Qt 层错误
def _qt_message_handler(mode, context, message):
    try:
        from PyQt5.QtCore import QtMsgType
        level_map = {
            QtMsgType.QtDebugMsg: "QtDebug",
            QtMsgType.QtInfoMsg: "QtInfo",
            QtMsgType.QtWarningMsg: "QtWarn",
            QtMsgType.QtCriticalMsg: "QtCritical",
            QtMsgType.QtFatalMsg: "QtFatal",
        }
        tag = level_map.get(mode, "QtMsg")
        # 只落盘 Warning 以上,避免日志泛滥
        if mode in (QtMsgType.QtWarningMsg, QtMsgType.QtCriticalMsg, QtMsgType.QtFatalMsg):
            ctx = f"file={context.file}:{context.line} func={context.function}" if context and context.file else ""
            _crash_write(tag, f"{message}\n{ctx}")
    except Exception:
        pass

try:
    from PyQt5.QtCore import qInstallMessageHandler
    qInstallMessageHandler(_qt_message_handler)
except Exception:
    pass

# Python atexit:正常退出 / SystemExit 都会跑(SIGKILL 不跑)
import atexit
def _on_atexit():
    _crash_write("ATEXIT", "Python interpreter exiting normally")
atexit.register(_on_atexit)

BASE_DIR     = Path("D:/files")
DATA_DIR     = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
TREE_PATH    = DATA_DIR / "category_tree.json"
HISTORY_PATH = DATA_DIR / "scrape_history.json"
COMPARED_PATH = DATA_DIR / "compared_products.json"


def _is_main_product_file(p) -> bool:
    """判断 products_*.json 是否是「主报表」文件(用户可见的批次输出)。
    排除:products_live.json(实时草稿)/ *_cp_latest.json(覆盖式 checkpoint 冷备)
    / *_cpNNN.json(老版本累积 checkpoint,理论上已被新版本淘汰)。
    """
    import re as _re
    name = p.name if hasattr(p, "name") else str(p).rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    if name == "products_live.json":
        return False
    # 排除 _cp_latest.json / _cpNNN.json
    if _re.search(r"_cp(_latest|\d+)\.json$", name):
        return False
    return True

# 已比价独立存储字段（与 products_*.json 解耦）
COMPARED_FIELDS = [
    "cost_ref", "supplier_link", "cost_supplier", "cost_top3_str",
    "pdd_price", "pdd_link", "pdd_shop", "pdd_top3_str",
    "img_search_url",
    # 同款校验相关:cost_image=当前选中供应商封面图(GUI 缩略图);
    # candidates=完整候选列表(供手动比价弹窗);auto_note=自动模式告警
    "cost_image", "candidates", "auto_note",
]


def _load_compared_store() -> dict:
    """加载 compared_products.json（key=prod_id，value=比价字段 dict）"""
    if COMPARED_PATH.exists():
        try:
            with open(COMPARED_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _save_compared_store(store: dict):
    COMPARED_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(COMPARED_PATH, "w", encoding="utf-8") as f:
        json.dump(store, f, ensure_ascii=False, indent=2)


def _merge_compared_into(products: list) -> list:
    """把 compared_products.json 中的比价字段合并到 products 列表（按 prod_id）"""
    store = _load_compared_store()
    if not store:
        return products
    for p in products:
        pid = p.get("prod_id") or p.get("name", "")
        if pid in store:
            for f in COMPARED_FIELDS:
                v = store[pid].get(f)
                if v and not p.get(f):
                    p[f] = v
    return products


def _update_compared_store(prod: dict):
    """把 prod 完整字段（含比价字段）写回独立存储；
    比价字段直接使用原名，其它快照字段统一加 `_` 前缀避免冲突。
    """
    pid = prod.get("prod_id") or prod.get("name", "")
    if not pid:
        return
    store = _load_compared_store()
    entry = store.get(pid, {})
    # 比价字段保留原名
    for f in COMPARED_FIELDS:
        v = prod.get(f, "")
        if v:
            entry[f] = v
    # 其余字段全部保存为 _xxx，确保即使删除 products_*.json 也能完整重建
    SKIP = set(COMPARED_FIELDS) | {"prod_id"}
    for k, v in prod.items():
        if k in SKIP: continue
        if k.startswith("_"): continue   # 避免重复 __
        if v == "" or v is None: continue
        entry[f"_{k}"] = v
    from datetime import datetime as _dt
    entry["_updated"] = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    if any(entry.get(f) for f in ["cost_ref", "supplier_link", "cost_supplier", "pdd_price", "pdd_link"]):
        store[pid] = entry
    elif pid in store:
        del store[pid]
    _save_compared_store(store)


def _compared_store_to_products() -> list:
    """把 compared_products.json 还原成完整 products 列表（独立可显示）"""
    store = _load_compared_store()
    products = []
    for pid, entry in store.items():
        prod = {"prod_id": pid}
        for k, v in entry.items():
            if k == "_updated":
                continue
            if k.startswith("_"):
                prod[k[1:]] = v
            else:
                prod[k] = v   # 比价字段保留原名
        products.append(prod)
    return products
CAT_SEL_PATH = DATA_DIR / "last_cat_selection.json"

L1_FIXED = ["美妆", "个护清洁", "美容护肤"]

def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

# ── 表头列定义 ──────────────────────────────────────────────────────────────
COLUMNS = [
    ("",          "_sel",                 44),   # 勾选列
    ("🎯推荐",     "_reco",               110),   # 选品推荐分+标签(xuanpin_reco 打分)
    ("排名",       "rank",                 60),
    ("商品图片",   "image",                70),
    ("货源图",     "cost_image",           80),   # 货源图:挪到我方图旁,核对是否同款一目了然
    ("商品链接",   "link",                 70),
    ("单品洞察",   "insight_url",          70),
    ("商品名称",   "name",               260),
    ("来源类目",   "category_label",     130),
    ("首次上架",   "first_online",        90),
    ("价格区间",   "price_range",        100),
    ("支付GMV",    "gmv_range",          100),
    ("销量区间",   "sales_range",         90),
    ("GMV环比",    "gmv_mom",             80),
    ("订单环比",   "order_mom",           80),
    ("全站GMV",    "site_cumulative_gmv",100),
    ("直接ROI",    "site_direct_roi",     80),
    ("广告花费",   "ad_spend",            90),
    ("货主店铺",   "store_name",         140),
    ("1688参考成本","cost_ref",           110),
    ("1688供应商",  "cost_supplier",      150),
    ("1688前3价格", "cost_top3_str",      280),
    ("1688供货链接","supplier_link",       90),
    ("供应商资料",  "data_path",           90),
    ("拼多多参考价","pdd_price",           110),
    ("拼多多店铺",  "pdd_shop",            140),
    ("拼多多前3价", "pdd_top3_str",        260),
    ("拼多多链接",  "pdd_link",             90),
]
_URL_COLS = {"link", "insight_url", "supplier_link", "pdd_link"}
IMG_SIZE  = 64

# 不显示筛选箭头的列
_STRIP_SKIP_KEYS = {"_sel", "image", "cost_image", "link", "insight_url", "supplier_link", "data_path", "pdd_link"}
# 数值型列（弹窗提示范围语法）
_STRIP_NUM_KEYS  = {"rank", "price_range", "gmv_range", "sales_range", "gmv_mom",
                    "order_mom", "site_cumulative_gmv", "site_direct_roi",
                    "ad_spend", "cost_ref"}


# ── 数值范围排序辅助 ─────────────────────────────────────────────────────────
def _parse_range_max(s: str) -> float:
    """把 '100-120' / '1.6万-2万' / '10-12' / '1700-2100' 解析为上限数值。
    用于销量区间/价格区间等"数值范围"列按数值排序(不是字符串)。
    """
    if not s or not isinstance(s, str):
        return 0.0
    s = s.strip()
    if not s or s == "-":
        return 0.0
    # 单负数(如 "-38.18%"):首位是 - 且后续无 -,直接整体解析
    if s.startswith("-") and s.count("-") == 1:
        last = s
    else:
        # range 形式:取最后一段(上限)
        parts = s.replace("~", "-").split("-")
        last = parts[-1].strip()
    # 处理"万"/"亿"
    mult = 1.0
    if last.endswith("万"):
        mult = 10000.0
        last = last[:-1]
    elif last.endswith("亿"):
        mult = 100000000.0
        last = last[:-1]
    # 去掉百分号、元、空格
    last = last.replace("%", "").replace("元", "").replace(",", "").strip()
    try:
        return float(last) * mult
    except Exception:
        # 抓 last 中的第一个数字
        import re as _re
        m = _re.search(r"-?\d+(?:\.\d+)?", last)
        return float(m.group(0)) * mult if m else 0.0


class NumericTableWidgetItem(QTableWidgetItem):
    """按数值排序的 QTableWidgetItem。
    显示文本(DisplayRole)保留原样,排序按 UserRole+1 存的数值。
    用于销量区间/价格区间/GMV区间 等"X-Y" 范围字符串列。
    """
    _SORT_ROLE = Qt.UserRole + 1
    def __init__(self, text: str):
        super().__init__(text)
        self.setData(self._SORT_ROLE, _parse_range_max(text))
    def __lt__(self, other):
        try:
            a = self.data(self._SORT_ROLE) or 0.0
            b = other.data(self._SORT_ROLE) or 0.0
            return a < b
        except Exception:
            return super().__lt__(other)


# ── 带 ▼ 筛选箭头的表头 ───────────────────────────────────────────────────────
class ResponsiveAutoPromoTable(QTableWidget):
    """在表格视口尺寸变化后通知外层重新计算列宽。"""
    resized = pyqtSignal()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resized.emit()


class FilterableHeaderView(QHeaderView):
    """每列标题右下角带 ▼ 筛选入口，点击弹出勾选值列表"""
    # 传递选中值集合（set）；空 set 表示清除筛选
    filter_applied = pyqtSignal(str, object)   # (col_key, selected_set_or_empty_set)
    ARROW_W = 18

    def __init__(self, col_keys: list, values_getter, parent=None):
        super().__init__(Qt.Horizontal, parent)
        self._col_keys      = col_keys       # 与 COLUMNS 顺序一致的 key 列表
        self._values_getter = values_getter  # callable(key) -> sorted list of unique vals
        self._filters       = {}             # col_idx(int) → set of selected values
        self.setSectionsClickable(True)
        self.setHighlightSections(False)

    # ── 是否显示筛选箭头 ──────────────────────────────────────────────────────
    def _is_filterable(self, logical: int) -> bool:
        if logical < 0 or logical >= len(self._col_keys):
            return False
        return self._col_keys[logical] not in _STRIP_SKIP_KEYS

    # ── 绘制 ▼ 箭头 ───────────────────────────────────────────────────────────
    def paintSection(self, painter, rect, logical_index):
        if not rect.isValid():
            return
        painter.save()
        super().paintSection(painter, rect, logical_index)
        painter.restore()

        if not self._is_filterable(logical_index):
            return

        active = bool(self._filters.get(logical_index))  # 非空 set = 有筛选
        painter.save()
        painter.setPen(QColor("#F59E0B" if active else "#A5B4FC"))
        painter.setFont(QFont("Arial", 7))
        painter.drawText(
            rect.right() - self.ARROW_W, rect.top(),
            self.ARROW_W, rect.height(),
            Qt.AlignCenter, "▼"
        )
        painter.restore()

    # ── 鼠标点击：判断是否点到箭头区域 ───────────────────────────────────────
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            pos     = event.pos()
            logical = self.logicalIndexAt(pos)
            if self._is_filterable(logical):
                sec_x = self.sectionPosition(logical)
                sec_w = self.sectionSize(logical)
                if pos.x() >= sec_x + sec_w - self.ARROW_W:
                    self._show_filter_popup(logical, event.globalPos())
                    return
        super().mousePressEvent(event)

    # ── 弹出值勾选浮窗 ────────────────────────────────────────────────────────
    def _show_filter_popup(self, col_idx: int, global_pos):
        key      = self._col_keys[col_idx] if col_idx < len(self._col_keys) else ""
        cur_set  = self._filters.get(col_idx)   # set or None

        all_vals = self._values_getter(key) if self._values_getter else []
        if not all_vals:
            return   # 暂无数据，不弹窗

        col_name = ""
        if self.model():
            col_name = str(self.model().headerData(col_idx, Qt.Horizontal) or "")

        popup = QFrame(None, Qt.Popup | Qt.FramelessWindowHint)
        popup.setAttribute(Qt.WA_DeleteOnClose)
        popup.setStyleSheet(
            "QFrame{background:white;border:1px solid #D1D5DB;border-radius:8px;}"
        )
        popup.setFixedWidth(250)

        lay = QVBoxLayout(popup)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(5)

        # 标题
        lbl = QLabel(f"筛选：{col_name}")
        lbl.setStyleSheet(
            "font-size:11px;color:#6B7280;font-weight:bold;"
            "background:transparent;border:none;padding-bottom:2px;")
        lay.addWidget(lbl)

        # 搜索框
        search = QLineEdit()
        search.setPlaceholderText("搜索…")
        search.setStyleSheet(
            "QLineEdit{border:1px solid #D1D5DB;border-radius:4px;"
            "padding:3px 7px;font-size:11px;background:white;}"
            "QLineEdit:focus{border-color:#4F46C8;}")
        lay.addWidget(search)

        # 全选复选框
        cb_all = QCheckBox("全选")
        cb_all.setStyleSheet(
            "QCheckBox{font-size:11px;color:#374151;background:transparent;border:none;}"
            "QCheckBox::indicator{width:13px;height:13px;border:1.5px solid #D1D5DB;"
            "border-radius:3px;background:white;}"
            "QCheckBox::indicator:checked{background:#4F46C8;border-color:#4F46C8;}")
        lay.addWidget(cb_all)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("border:none;border-top:1px solid #E5E7EB;")
        lay.addWidget(sep)

        # 值列表
        lw = QListWidget()
        lw.setStyleSheet(
            "QListWidget{border:none;background:white;outline:none;}"
            "QListWidget::item{padding:2px 4px;border:none;}"
            "QListWidget::item:hover{background:#EEF2FF;border:none;}"
            "QListWidget::indicator{width:13px;height:13px;"
            "border:1.5px solid #D1D5DB;border-radius:3px;background:white;}"
            "QListWidget::indicator:checked{background:#4F46C8;border-color:#4F46C8;}")
        lw.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        lw.setMaximumHeight(200)

        all_items = []
        for entry in all_vals:
            # all_vals 现为 [(值, 数量), ...];兼容老的纯值列表
            if isinstance(entry, tuple):
                val, cnt = entry
                text = f"{val}  ({cnt})"
            else:
                val, text = entry, entry
            it = QListWidgetItem(text)
            it.setData(Qt.UserRole, val)          # 真实筛选值(不含数量)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            # cur_set is None → 全部勾选；否则按已选集合
            checked = (cur_set is None) or (val in cur_set)
            it.setCheckState(Qt.Checked if checked else Qt.Unchecked)
            lw.addItem(it)
            all_items.append(it)

        lay.addWidget(lw)

        # ── 同步全选状态 ──────────────────────────────────────────────────────
        def _sync_all_cb():
            visible = [it for it in all_items if not it.isHidden()]
            if not visible:
                return
            n_checked = sum(1 for it in visible if it.checkState() == Qt.Checked)
            cb_all.blockSignals(True)
            cb_all.setChecked(n_checked == len(visible))
            cb_all.blockSignals(False)

        _sync_all_cb()

        def _on_item_changed(_it):
            _sync_all_cb()

        def _on_all_clicked(checked):
            lw.blockSignals(True)
            s = Qt.Checked if checked else Qt.Unchecked
            for it in all_items:
                if not it.isHidden():
                    it.setCheckState(s)
            lw.blockSignals(False)

        def _on_search(text):
            t = text.strip().lower()
            for it in all_items:
                it.setHidden(bool(t) and t not in it.text().lower())
            _sync_all_cb()

        lw.itemChanged.connect(_on_item_changed)
        cb_all.clicked.connect(_on_all_clicked)
        search.textChanged.connect(_on_search)

        # 按钮行
        btn_row = QHBoxLayout()
        btn_clear = QPushButton("清除筛选")
        btn_clear.setStyleSheet(
            "QPushButton{background:#F3F4F6;border:1px solid #D1D5DB;border-radius:5px;"
            "padding:4px 10px;font-size:11px;color:#374151;}"
            "QPushButton:hover{background:#E5E7EB;}")
        btn_ok = QPushButton("确认")
        btn_ok.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;"
            "border-radius:5px;padding:4px 18px;font-size:11px;font-weight:bold;}"
            "QPushButton:hover{background:#4338CA;}")
        btn_row.addWidget(btn_clear)
        btn_row.addStretch()
        btn_row.addWidget(btn_ok)
        lay.addLayout(btn_row)

        def _apply():
            selected = {it.data(Qt.UserRole) for it in all_items if it.checkState() == Qt.Checked}
            all_set  = {it.data(Qt.UserRole) for it in all_items}
            if selected == all_set or not selected:
                # 全选或全不选 → 清除筛选
                self._filters.pop(col_idx, None)
                self.viewport().update()
                popup.close()
                self.filter_applied.emit(key, set())
            else:
                self._filters[col_idx] = selected
                self.viewport().update()
                popup.close()
                self.filter_applied.emit(key, selected)

        def _clear():
            self._filters.pop(col_idx, None)
            self.viewport().update()
            popup.close()
            self.filter_applied.emit(key, set())

        btn_ok.clicked.connect(_apply)
        btn_clear.clicked.connect(_clear)

        # 弹窗位置
        px = max(0, global_pos.x() - 230)
        py = global_pos.y() + 4
        popup.move(px, py)
        popup.show()
        search.setFocus()

    def clear_all_filters(self):
        self._filters.clear()
        self.viewport().update()


# ── 可点击图片 Label(用于商品库:左键放大预览 / 右键复制图片到剪贴板) ──────────
class ClickableImageLabel(QLabel):
    """商品图缩略图,左键点击弹大图预览,右键弹菜单(复制图片 / 打开本地路径)。
    用 setProperty 存图片源:local_path(优先) / image_url(回落)。
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_context_menu)
        self._product_name = ""
        self._local_path = ""
        self._image_url = ""

    def set_image_source(self, local_path: str = "", image_url: str = "", product_name: str = ""):
        self._local_path = local_path or ""
        self._image_url = image_url or ""
        self._product_name = product_name or ""

    def mousePressEvent(self, event):
        # 表格重渲染时旧 label 的底层 C++ 对象可能已被删除,但仍收到鼠标事件 →
        # 调 _show_preview / super().mousePressEvent 会抛 RuntimeError("wrapped C/C++ object ... deleted"),
        # 整个客户端 crash。这里整体兜住:对象没了就忽略本次事件。
        try:
            if event.button() == Qt.LeftButton:
                self._show_preview()
            super().mousePressEvent(event)
        except RuntimeError:
            pass

    def _resolve_pixmap(self, fetch_original: bool = False) -> "QPixmap | None":
        """优先本地路径/高清缓存；预览时才按需下载原图；列表只依赖当前缩略图。"""
        if self._local_path and Path(self._local_path).exists():
            pix = QPixmap(self._local_path)
            if not pix.isNull():
                return pix
        if self._image_url:
            try:
                import hashlib
                _cd = Path(__file__).parent / "data" / "img_cache"
                _cd.mkdir(parents=True, exist_ok=True)
                _u = self._image_url
                _keys = [_u]
                if _u.startswith("//"):
                    _keys.append("https:" + _u)
                for _k in _keys:
                    _cp = _cd / hashlib.md5(_k.encode("utf-8")).hexdigest()
                    if _cp.exists() and _cp.stat().st_size > 0:
                        pix = QPixmap()
                        if pix.loadFromData(_cp.read_bytes()):
                            return pix
                if fetch_original:
                    _url = "https:" + _u if _u.startswith("//") else _u
                    req = urllib.request.Request(_url, headers={"User-Agent": "Mozilla/5.0"})
                    with _DL_OPENER.open(req, timeout=10) as resp:
                        data = resp.read()
                    if data:
                        try:
                            (_cd / hashlib.md5(_url.encode("utf-8")).hexdigest()).write_bytes(data)
                        except Exception:
                            pass
                        pix = QPixmap()
                        if pix.loadFromData(data):
                            return pix
            except Exception:
                pass
        # 最后回落:当前显示的缩略图(列表小图),不再为了列表同步下载高清原图。
        cur = self.pixmap()
        return cur if (cur is not None and not cur.isNull()) else None
    def _show_preview(self):
        pix = self._resolve_pixmap(fetch_original=True)
        if not pix:
            QMessageBox.information(self, "预览", "无可用图片(图片源已失效)")
            return
        # 适配屏幕(最大 800x800)
        from PyQt5.QtWidgets import QApplication as _QA
        screen = _QA.primaryScreen().availableGeometry()
        max_w = min(900, screen.width() - 100)
        max_h = min(900, screen.height() - 100)
        if pix.width() > max_w or pix.height() > max_h:
            pix = pix.scaled(max_w, max_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        dlg = QDialog(self)
        dlg.setWindowTitle(self._product_name or "图片预览")
        v = QVBoxLayout(dlg)
        lbl = QLabel()
        lbl.setPixmap(pix)
        lbl.setAlignment(Qt.AlignCenter)
        v.addWidget(lbl)
        btn_row = QHBoxLayout()
        _btn_css = ("QPushButton{background:white;color:#111827;border:1px solid #D1D5DB;"
                    "border-radius:4px;padding:5px 14px;}"
                    "QPushButton:hover{background:#EEF2FF;color:#111827;}")
        btn_copy = QPushButton("📋 复制图片")
        btn_copy.setStyleSheet(_btn_css)
        btn_copy.clicked.connect(lambda: (self._copy_to_clipboard(), dlg.accept()))
        btn_close = QPushButton("关闭")
        btn_close.setStyleSheet(_btn_css)
        btn_close.clicked.connect(dlg.accept)
        btn_row.addStretch()
        btn_row.addWidget(btn_copy)
        btn_row.addWidget(btn_close)
        v.addLayout(btn_row)
        dlg.resize(pix.width() + 40, pix.height() + 80)
        dlg.exec_()

    def _copy_to_clipboard(self):
        pix = self._resolve_pixmap(fetch_original=True)
        if not pix:
            QMessageBox.warning(self, "复制失败", "无可用图片")
            return
        from PyQt5.QtWidgets import QApplication as _QA
        _QA.clipboard().setPixmap(pix)

    def _on_context_menu(self, pos):
        menu = QMenu(self)
        # 强制黑字白底,避免系统主题(暗色/灰色)误导以为按钮禁用
        menu.setStyleSheet(
            "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
            "QMenu::item{color:#111827;padding:6px 18px;}"
            "QMenu::item:selected{background:#EEF2FF;color:#111827;}"
        )
        act_copy = menu.addAction("📋 复制图片到剪贴板")
        act_preview = menu.addAction("🔍 放大预览")
        act_open_local = None
        if self._local_path and Path(self._local_path).exists():
            act_open_local = menu.addAction("📁 打开本地图片所在文件夹")
        act = menu.exec_(self.mapToGlobal(pos))
        if act == act_copy:
            self._copy_to_clipboard()
        elif act == act_preview:
            self._show_preview()
        elif act_open_local and act == act_open_local:
            try:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self._local_path).parent)))
            except Exception as e:
                QMessageBox.warning(self, "打开失败", str(e))


# ── 选品导出 Excel 后台线程(导出要逐个下图,放后台防 UI 未响应)──────────────
class ExportExcelThread(QThread):
    progress = pyqtSignal(int, int)   # (已处理, 总数)
    done = pyqtSignal(str)            # 成功:路径
    failed = pyqtSignal(str)          # 失败:错误

    def __init__(self, products, path, parent=None):
        super().__init__(parent)
        self.products = products
        self.path = path

    def run(self):
        try:
            from report import generate_excel
            generate_excel(self.products, Path(self.path),
                           progress=lambda i, n: self.progress.emit(i, n))
            self.done.emit(self.path)
        except Exception as e:
            self.failed.emit(str(e))


# ── 视频已传记录(持久化:哪个商品传了哪些 photo_id)──────────────────────────
_VIDEO_UPLOADS_PATH = Path(r"D:/files/data/pdd/video_uploads.json")


def _video_uploads_load() -> dict:
    """{goods_id: {"photo_ids":[...], "uploaded_at":"..."}}"""
    try:
        return json.loads(_VIDEO_UPLOADS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _video_uploads_record(goods_id, photo_id):
    """记一条已传(成功上传后调),去重存盘。"""
    import time as _t
    data = _video_uploads_load()
    e = data.setdefault(str(goods_id), {"photo_ids": [], "uploaded_at": ""})
    pid = str(photo_id or "")
    if pid and pid not in e["photo_ids"]:
        e["photo_ids"].append(pid)
    e["uploaded_at"] = _t.strftime("%Y-%m-%d %H:%M")
    try:
        _VIDEO_UPLOADS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass


def _store_profile_dir(store):
    """店铺名 → 它的 pdd_profile 目录(多店铺方案A:创作者中心登录也存这里,各店各自登一次)。"""
    try:
        stores = json.loads(Path(r"D:/files/pdd_profiles/stores.json").read_text(encoding="utf-8"))
        prof = stores.get(store)
        if prof:
            return str(Path(r"D:/files/pdd_profiles") / prof)
    except Exception:
        pass
    return None


# ── 生图换主图:已换主图记录(去重,不重复换) ──────────────────────────────────
_PROMO_DONE_PATH = Path(r"D:/files/data/pdd/promo_done.json")


def _promo_done_load() -> dict:
    """{goods_id: {"img":"<推广图路径>", "at":"..."}}"""
    try:
        return json.loads(_PROMO_DONE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _promo_done_record(goods_id, img_path):
    """记一条已换主图(换主图提交成功后调)。"""
    import time as _t
    data = _promo_done_load()
    data[str(goods_id)] = {"img": str(img_path or ""), "at": _t.strftime("%Y-%m-%d %H:%M")}
    try:
        _PROMO_DONE_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass


# ── 生图换图编排线程(gpt-image-2 生成推广图 → 换 PDD 主图) ──────────────────────────
class GenImgThread(QThread):
    """逐商品:下载货品图 → gpt-image-2 API 生成直通车推广主图 → 换成 PDD 主图并提交。
    生成=gpt-image-2 API(不开浏览器);换主图按店铺 profile 逐个开浏览器(复用店铺登录态)。
    jobs: [{"gid","name","store","src_url","detail_url"}]。progress 文本进度,finished_summary 汇总。"""
    progress = pyqtSignal(str)
    finished_summary = pyqtSignal(dict)

    _UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
           "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

    def __init__(self, jobs, mode="full", parent=None):
        super().__init__(parent)
        self.jobs = jobs
        self.mode = mode   # full=生成+换主图 / gen_only=只生图 / change_only=已有AI图只换主图
        self._stop = False

    def stop(self):
        self._stop = True

    def _download(self, url, dst):
        import os, urllib.request, hashlib, shutil
        from pathlib import Path
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if url and os.path.exists(url):
            shutil.copyfile(url, dst)
            return os.path.getsize(dst)
        if url.startswith("//"):
            url = "https:" + url
        # ★ 先用本地图片缓存:表格显示货品图时 ImageBatchLoader 已按 md5(url) 把图下到 data/img_cache。
        #   命中就直接复制、不再联网下载(省时间;梯子开着时也不会卡在下原图)。
        try:
            _cp = Path(__file__).parent / "data" / "img_cache" / hashlib.md5(url.encode("utf-8")).hexdigest()
            if _cp.exists() and _cp.stat().st_size > 0:
                shutil.copyfile(str(_cp), dst)
                return os.path.getsize(dst)
        except Exception:
            pass
        req = urllib.request.Request(url, headers={"User-Agent": self._UA})
        import time as _t
        _t0 = _t.time()
        with _DL_OPENER.open(req, timeout=40) as r, open(dst, "wb") as f:
            f.write(r.read())
        _sz = os.path.getsize(dst); _dt = _t.time() - _t0
        try:
            with open(r"D:/files/data/img_dl_debug.log", "a", encoding="utf-8") as _lf:
                _lf.write(_t.strftime("%H:%M:%S ") + "下原图 %dKB 用 %.1fs = %.2f MB/s  %s\n" % (
                    _sz // 1024, _dt, (_sz / 1048576 / _dt if _dt else 0), os.path.basename(dst)))
        except Exception:
            pass
        return _sz

    def run(self):
        import asyncio, os
        try:
            import pdd_set_main_image
            from playwright.async_api import async_playwright
            from pdd_publish import find_chrome
        except Exception as e:
            self.finished_summary.emit({"error": f"导入失败: {e!r}"})
            return

        summary = {"products": 0, "generated": 0, "gen_fail": [],
                   "changed_ok": 0, "change_fail": [], "skipped": []}
        emit = self.progress.emit
        out_dir = r"D:/files/data/promo"

        async def orchestrate():
            generated = []   # [(gid, name, store, promo_img, detail_url)]
            # ── Phase 1:调 gpt-image-2 API 逐商品生成推广图(不开浏览器、不限流) ──
            import image_gen
            if self.mode == "change_only":
                for job in self.jobs:
                    _gid = str(job.get("gid") or "")
                    _p = os.path.join(out_dir, _gid + ".jpg")
                    if os.path.exists(_p):
                        generated.append((_gid, job.get("name") or "", job.get("store") or "",
                                          _p, job.get("detail_url") or ""))
                        emit("用已有AI图换主图: " + _gid)
                    else:
                        summary["skipped"].append((_gid, "没有已生成的AI图"))
                        emit("跳过(没AI图): " + _gid)
                self.jobs = []
            if self.jobs:
                emit("开始生成推广图(gpt-image-2)…")
            _genjobs = list(self.jobs)
            if _genjobs:
                from concurrent.futures import ThreadPoolExecutor, as_completed
                emit("并行生成 %d 张推广图(同时最多20个)..." % len(_genjobs))
                def _gen_one(job):
                    _g = str(job.get("gid") or "")
                    _su = job.get("src_url") or ""
                    if not _su:
                        return ("skip", _g)
                    _src = os.path.join(out_dir, "_src_" + _g + ".jpg")
                    try:
                        self._download(_su, _src)
                    except Exception as e:
                        return ("dlfail", _g, repr(e))
                    _out = os.path.join(out_dir, _g + ".jpg")
                    try:
                        _res = image_gen.generate_for_product(_src, job.get("name") or "", _out)
                    except Exception as e:
                        _res = {"ok": False, "reason": "exc:" + repr(e)}
                    return ("done", _g, job.get("store") or "", job.get("detail_url") or "", _out, _res)
                _total = len(_genjobs); _did = 0
                with ThreadPoolExecutor(max_workers=20) as _ex:
                    _futs = [_ex.submit(_gen_one, j) for j in _genjobs]
                    for _f in as_completed(_futs):
                        _r = _f.result(); _did += 1
                        if _r[0] == "skip":
                            summary["skipped"].append((_r[1], "无货品图")); emit("跳过(无货品图): " + _r[1])
                        elif _r[0] == "dlfail":
                            summary["gen_fail"].append((_r[1], "货品图下载失败")); emit("货品图下载失败: " + _r[1])
                        else:
                            _, _g, _store, _detail, _out, _res = _r
                            summary["products"] += 1
                            if _res.get("ok"):
                                summary["generated"] += 1
                                generated.append((_g, "", _store, _res.get("out_path") or _out, _detail))
                                emit("已出图 %s (%d/%d)" % (_g, _did, _total))
                            else:
                                # 带上 body/raw(API 400 的真实原因,如内容审核/限流),否则只看到 http-400 没用
                                _full = (str(_res.get("reason") or "")
                                         + "  " + str(_res.get("body") or _res.get("raw") or "")).strip()
                                summary["gen_fail"].append((_g, _full))
                                emit("生成失败 %s: %s" % (_g, _full[:160]))

            if self.mode == "gen_only":
                return summary

            if self._stop or not generated:
                return summary

            # ── Phase 2:按店铺分组,逐店铺切 profile 换主图并提交 ──
            from collections import OrderedDict
            by_store = OrderedDict()
            for gid, name, store, img, detail in generated:
                by_store.setdefault(store or "", []).append((gid, img, detail))
            for store, items in by_store.items():
                if self._stop:
                    break
                profile = _store_profile_dir(store)
                if not profile:
                    for gid, img, detail in items:
                        summary["change_fail"].append((gid, "无店铺登录profile"))
                    emit(f"✗ 店铺「{store}」无登录 profile,跳过换主图")
                    continue
                emit(f"打开店铺「{store or '默认'}」换主图…")
                async with async_playwright() as p:
                    ctx = await p.chromium.launch_persistent_context(
                        user_data_dir=profile, executable_path=find_chrome(), headless=False,
                        args=["--start-maximized", "--disable-blink-features=AutomationControlled"],
                        ignore_default_args=["--enable-automation"], viewport=None)
                    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                    try:
                        for gid, img, detail in items:
                            if self._stop:
                                break
                            emit(f"🖼 {gid} 换主图…")
                            try:
                                r = await pdd_set_main_image.set_main_image_on_page(
                                    page, gid, img, detail_url=detail or None, do_submit=True)
                            except Exception as e:
                                r = {"ok": False, "reason": f"exc:{e!r}"}
                            if r.get("ok"):
                                summary["changed_ok"] += 1
                                _promo_done_record(gid, img)
                                emit(f"  ✓ {gid} 主图已换并提交")
                            else:
                                summary["change_fail"].append((gid, r.get("reason")))
                                emit(f"  ✗ {gid} 换主图失败:{r.get('reason')}")
                    finally:
                        await asyncio.sleep(1)
                        try:
                            await ctx.close()
                        except Exception:
                            pass
            return summary

        try:
            result = asyncio.run(orchestrate())
        except Exception as e:
            result = dict(summary, error=repr(e))
        self.finished_summary.emit(result)


# ── 视频补传编排线程(磁力金牛取视频+下载 → PDD多多视频上传) ──────────────────
class InsightOpenThread(QThread):
    """开磁力金牛「商品洞察」页:持久 profile(jinfu_profile)+ main.auto_login 自动登录
    (首次密码登录,之后 session 复用免登),停在洞察页让人看(载体分析里有推广视频)。
    浏览器开着直到用户手动关。"""
    status = pyqtSignal(str)

    def __init__(self, product_id, parent=None):
        super().__init__(parent)
        self.product_id = str(product_id)

    def run(self):
        import asyncio
        try:
            asyncio.run(self._go())
        except Exception as e:
            self.status.emit(f"商品洞察打开失败: {e!r}")

    async def _go(self):
        from playwright.async_api import async_playwright
        from pdd_publish import find_chrome
        import video_pipe
        from main import auto_login, close_popup, TARGET_URL
        profile_dir = r"D:/files/pdd_profiles/jinfu_profile"
        chrome = find_chrome()
        async with async_playwright() as p:
            ctx = await p.chromium.launch_persistent_context(
                user_data_dir=profile_dir, executable_path=chrome, headless=False,
                args=["--start-maximized", "--disable-blink-features=AutomationControlled"],
                ignore_default_args=["--enable-automation"], viewport=None)
            page = ctx.pages[0] if ctx.pages else await ctx.new_page()
            try:
                self.status.emit("磁力金牛登录检查…")
                await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=45000)
                await auto_login(page)                       # 已登录则跳过,否则自动密码登录
                await page.goto(video_pipe._insight_url(self.product_id),
                                wait_until="domcontentloaded", timeout=45000)
                try:
                    await close_popup(page)
                except Exception:
                    pass
                self.status.emit("已打开商品洞察页(看完手动关浏览器即可)")
                await page.wait_for_event("close", timeout=0)   # 停着,等用户手动关
            finally:
                try:
                    await ctx.close()
                except Exception:
                    pass


class VideoSupplementThread(QThread):
    """逐商品:resolve_product_id → 磁力金牛投流榜取【全部】视频+下载 → PDD创作者中心逐条上传发布。
    两段浏览器:先磁力金牛(取+下),再 PDD live_creator(传)。progress 文本进度,finished_summary 汇总。"""
    progress = pyqtSignal(str)
    finished_summary = pyqtSignal(dict)

    def __init__(self, records, parent=None, show_browser=True):
        super().__init__(parent)
        self.records = records
        self.show_browser = show_browser   # True=浏览器显示(默认);False=屏幕外静默
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        import asyncio, os
        try:
            import video_pipe
            import pdd_video_upload
            from playwright.async_api import async_playwright
            from main import auto_login, close_popup, TARGET_URL
            from pdd_publish import find_chrome
        except Exception as e:
            self.finished_summary.emit({"error": f"导入失败: {e!r}"})
            return

        summary = {"products": 0, "videos_found": 0, "downloaded": 0,
                   "uploaded_ok": 0, "uploaded_fail": 0, "skipped": [], "failures": []}
        emit = self.progress.emit

        async def orchestrate():
            lib_index = video_pipe.load_library_index()
            already = _video_uploads_load()   # 已传记录,用于去重(同 photo_id 不重复传)
            downloaded = []   # [(gid, name, [(photo_id, path), ...])]
            # Phase 1:磁力金牛取视频 + 下载
            emit("打开磁力金牛、登录…")
            async with async_playwright() as p:
                _vwin = (["--start-maximized"] if self.show_browser
                         else ["--window-position=-32000,-32000", "--window-size=1700,1000"])
                browser = await p.chromium.launch(executable_path=find_chrome(), headless=False, args=_vwin)
                ctx = await browser.new_context(viewport=None, user_agent=video_pipe.UA)
                page = await ctx.new_page()
                try:
                    await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
                    await auto_login(page)
                    await close_popup(page)
                    await asyncio.sleep(2)
                    for rec in self.records:
                        if self._stop:
                            break
                        gid = str(rec.get("goods_id") or "")
                        name = rec.get("target_name") or rec.get("name") or ""
                        store = rec.get("store") or ""
                        pid = video_pipe.resolve_product_id(rec, lib_index)
                        if not pid:
                            summary["skipped"].append((gid, "无productId映射"))
                            emit(f"⏭ {gid} 无法映射 productId,跳过")
                            continue
                        summary["products"] += 1
                        try:
                            vids = await video_pipe.get_promo_videos_on_page(page, pid)
                        except Exception as e:
                            summary["skipped"].append((gid, f"取视频异常:{e!r}"))
                            emit(f"✗ {gid} 取视频异常")
                            continue
                        summary["videos_found"] += len(vids)
                        done_ids = set((already.get(gid) or {}).get("photo_ids", []))
                        new_vids = [v for v in vids if str(v.get("photo_id") or "") not in done_ids]
                        skip_n = len(vids) - len(new_vids)
                        emit(f"📹 {gid} 投流榜 {len(vids)} 条(已传 {skip_n} 跳过),下载 {len(new_vids)} 条…")
                        # ★下载丢到独立子进程 video_dl.py 跑:进程内下载会被拖到 0.x MB/s,
                        # 独立子进程实测满速(22-63MB/s,已诊断验证)。文件名按序号预定不冲突(auto-match只认gid前缀)。
                        items = []
                        if new_vids:
                            import json as _json, subprocess as _sp, sys as _sys
                            _tasks = []
                            for _i, _v in enumerate(new_vids):
                                _fn = f"{gid}.mp4" if _i == 0 else f"{gid}({_i}).mp4"
                                _dst = os.path.join(video_pipe.DEFAULT_OUTDIR, _fn)
                                _tasks.append([_v["video_url"], _dst, str(_v.get("photo_id") or "")])
                            os.makedirs(video_pipe.DEFAULT_OUTDIR, exist_ok=True)
                            _tjf = os.path.join(video_pipe.DEFAULT_OUTDIR, f"_tasks_{gid}.json")
                            with open(_tjf, "w", encoding="utf-8") as _f:
                                _json.dump(_tasks, _f)
                            emit(f"  ⬇ {gid} 下载 {len(_tasks)} 条视频(独立进程,满速)…")
                            def _run_dl():
                                _got, _n = [], 0
                                try:
                                    _pr = _sp.Popen([_sys.executable, "video_dl.py", _tjf], cwd=r"D:/files",
                                                    stdout=_sp.PIPE, stderr=_sp.DEVNULL, text=True,
                                                    encoding="utf-8", creationflags=getattr(_sp, "CREATE_NO_WINDOW", 0))
                                    for _line in _pr.stdout:
                                        if self._stop:
                                            try: _pr.kill()
                                            except Exception: pass
                                            break
                                        _ss = (_line or "").strip()
                                        if _ss.startswith("DONE\t"):
                                            _pp = _ss.split("\t")
                                            if len(_pp) >= 3:
                                                _got.append((_pp[1], _pp[2])); _n += 1
                                                emit(f"  ✓ {gid} 已下 {_n}/{len(_tasks)}")
                                        elif _ss.startswith("FAIL\t"):
                                            emit(f"  ✗ {gid} 一条下载失败")
                                    _pr.wait()
                                except Exception as _e:
                                    emit(f"  ✗ 下载子进程异常: {_e!r}")
                                return _got
                            items = await asyncio.to_thread(_run_dl)
                            try: os.remove(_tjf)
                            except Exception: pass
                            summary["downloaded"] += len(items)
                        if items:
                            downloaded.append((gid, name, store, items))
                finally:
                    for closer in (ctx.close, browser.close):
                        try:
                            await closer()
                        except Exception:
                            pass

            if self._stop or not downloaded:
                return summary

            # Phase 2:按【店铺】分组,逐店铺切自己 profile 上传发布(多店铺方案A)
            from collections import OrderedDict
            by_store = OrderedDict()
            for gid, name, store, items in downloaded:
                by_store.setdefault(store or "", []).append((gid, items))
            for store, sitems in by_store.items():
                if self._stop:
                    break
                profile = _store_profile_dir(store) or pdd_video_upload.PROFILE
                emit(f"打开店铺「{store or '默认'}」的多多视频…")
                async with async_playwright() as p:
                    _vwin = (["--start-maximized"] if self.show_browser
                             else ["--window-position=-32000,-32000", "--window-size=1700,1000"])
                    ctx = await p.chromium.launch_persistent_context(
                        user_data_dir=profile, executable_path=find_chrome(), headless=False,
                        args=_vwin + ["--disable-blink-features=AutomationControlled"],
                        ignore_default_args=["--enable-automation"], viewport=None)
                    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                    store_out = False
                    upload_index_for_store = 0
                    try:
                        for gid, items in sitems:
                            if self._stop or store_out:
                                break
                            for photo_id, vp in items:
                                if self._stop:
                                    break
                                upload_index_for_store += 1
                                r = await pdd_video_upload.upload_one_video_on_page(
                                    page, vp, description="", preclose_popups=(upload_index_for_store <= 2))
                                if r.get("ok"):
                                    summary["uploaded_ok"] += 1
                                    _video_uploads_record(gid, photo_id)
                                    emit(f"✓ {store}/{gid} 发布成功 {os.path.basename(vp)}")
                                    try:    # 传完即删本地文件,避免 data/videos 越攒越大
                                        os.remove(vp)
                                    except Exception:
                                        pass
                                else:
                                    summary["uploaded_fail"] += 1
                                    summary["failures"].append(
                                        (gid, os.path.basename(vp), str(r.get("reason")),
                                         " ".join(r.get("toast") or [])[:80]))
                                    emit(f"✗ {store}/{gid} 发布失败({r.get('reason')})")
                                    if r.get("reason") == "creator-not-logged-in":
                                        emit(f"⚠ 店铺「{store}」多多视频未登录,跳过该店")
                                        store_out = True
                                        break
                    finally:
                        try:
                            await ctx.close()
                        except Exception:
                            pass
            return summary

        try:
            result = asyncio.run(orchestrate())
        except Exception as e:
            result = dict(summary, error=repr(e))
        self.finished_summary.emit(result)


# ── 本地/自定义视频上传线程(只传不取磁力金牛)──────────────────────────────
class VideoUploadLocalThread(QThread):
    """把用户选的本地视频文件上传到 PDD 多多视频(跳过磁力金牛取数)。
    jobs = [(goods_id, store, [src_path, ...])];按【店铺】分组,逐店铺切自己的 profile 登录态上传
    (多店铺方案A)。文件按商品id重命名后上传(平台自动匹配商品)。"""
    progress = pyqtSignal(str)
    finished_summary = pyqtSignal(dict)

    def __init__(self, jobs, parent=None, show_browser=True):
        super().__init__(parent)
        self.jobs = jobs
        self.show_browser = show_browser   # True=浏览器显示(默认);False=屏幕外静默
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        import asyncio, os, shutil
        from collections import OrderedDict
        try:
            import pdd_video_upload
            from playwright.async_api import async_playwright
            from pdd_publish import find_chrome
        except Exception as e:
            self.finished_summary.emit({"error": f"导入失败: {e!r}"})
            return

        outdir = r"D:/files/data/videos"
        summary = {"products": 0, "videos_found": 0, "downloaded": 0,
                   "uploaded_ok": 0, "uploaded_fail": 0, "skipped": [], "failures": []}
        emit = self.progress.emit

        async def orchestrate():
            already = _video_uploads_load()
            os.makedirs(outdir, exist_ok=True)
            by_store = OrderedDict()
            for gid, store, srcs in self.jobs:
                by_store.setdefault(store or "", []).append((gid, srcs))
            for store, items in by_store.items():
                if self._stop:
                    break
                profile = _store_profile_dir(store) or pdd_video_upload.PROFILE
                emit(f"打开店铺「{store or '默认'}」的多多视频…")
                async with async_playwright() as p:
                    _vwin = (["--start-maximized"] if self.show_browser
                             else ["--window-position=-32000,-32000", "--window-size=1700,1000"])
                    ctx = await p.chromium.launch_persistent_context(
                        user_data_dir=profile, executable_path=find_chrome(), headless=False,
                        args=_vwin + ["--disable-blink-features=AutomationControlled"],
                        ignore_default_args=["--enable-automation"], viewport=None)
                    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                    store_out = False
                    upload_index_for_store = 0
                    try:
                        for gid, srcs in items:
                            if self._stop or store_out:
                                break
                            summary["products"] += 1
                            base = len((already.get(gid) or {}).get("photo_ids", []))
                            for j, src in enumerate(srcs):
                                if self._stop:
                                    break
                                idx = base + j
                                fn = f"{gid}.mp4" if idx == 0 else f"{gid}({idx}).mp4"
                                dst = os.path.join(outdir, fn)
                                try:
                                    shutil.copyfile(src, dst)
                                except Exception as e:
                                    summary["uploaded_fail"] += 1
                                    summary["failures"].append((gid, os.path.basename(src), "copy-fail", repr(e)[:60]))
                                    continue
                                summary["videos_found"] += 1
                                summary["downloaded"] += 1
                                upload_index_for_store += 1
                                r = await pdd_video_upload.upload_one_video_on_page(
                                    page, dst, description="", preclose_popups=(upload_index_for_store <= 2))
                                if r.get("ok"):
                                    summary["uploaded_ok"] += 1
                                    _video_uploads_record(gid, "local:" + os.path.basename(src))
                                    emit(f"✓ {store}/{gid} 上传成功 {os.path.basename(src)}")
                                    try:    # 传完即删拷贝(用户原文件不动),避免 data/videos 越攒越大
                                        os.remove(dst)
                                    except Exception:
                                        pass
                                else:
                                    summary["uploaded_fail"] += 1
                                    summary["failures"].append(
                                        (gid, os.path.basename(src), str(r.get("reason")),
                                         " ".join(r.get("toast") or [])[:80]))
                                    emit(f"✗ {store}/{gid} 失败({r.get('reason')})")
                                    if r.get("reason") == "creator-not-logged-in":
                                        emit(f"⚠ 店铺「{store}」多多视频未登录,跳过该店(请先登录它的多多视频)")
                                        store_out = True
                                        break
                    finally:
                        try:
                            await ctx.close()
                        except Exception:
                            pass
            return summary

        try:
            result = asyncio.run(orchestrate())
        except Exception as e:
            result = dict(summary, error=repr(e))
        self.finished_summary.emit(result)


# ── 批量自定义视频:给每个商品分别选本地视频(不用改文件名)──────────────────
class VideoLocalAssignDialog(QDialog):
    """products=[(gid, name)];每个商品点「选择视频」挑本地文件,确认后 get_jobs() 返回 [(gid,[paths])]。"""

    def __init__(self, products, parent=None):
        super().__init__(parent)
        self.setWindowTitle("批量自定义视频上传 — 给每个商品选视频")
        self.resize(680, 440)
        self.assignments = {}   # gid -> [paths]
        self._store = {gid: store for gid, store, _ in products}   # gid -> 店铺
        lay = QVBoxLayout(self)
        tip = QLabel("给每个商品点「选择视频」挑本地视频文件(可多选,不用改名)。挑好的会上传到对应商品(按店铺分别登录上传)。")
        tip.setStyleSheet("color:#6B7280;font-size:11px;"); tip.setWordWrap(True)
        lay.addWidget(tip)
        self.tbl = QTableWidget(len(products), 4)
        self.tbl.setHorizontalHeaderLabels(["商品", "店铺", "已选视频", "操作"])
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.verticalHeader().setDefaultSectionSize(30)
        for i, (gid, store, name) in enumerate(products):
            it = QTableWidgetItem(f"{(name or '')[:28]}  ({gid})")
            self.tbl.setItem(i, 0, it)
            self.tbl.setItem(i, 1, QTableWidgetItem(store or ""))
            cnt = QTableWidgetItem("—"); cnt.setTextAlignment(Qt.AlignCenter)
            self.tbl.setItem(i, 2, cnt)
            w = QWidget(); hl = QHBoxLayout(w); hl.setContentsMargins(2, 0, 2, 0)
            b = QPushButton("选择视频"); b.setFixedHeight(24)
            b.clicked.connect(lambda _, g=gid, c=cnt: self._pick(g, c))
            hl.addWidget(b); hl.addStretch(1)
            self.tbl.setCellWidget(i, 3, w)
        lay.addWidget(self.tbl, 1)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("开始上传")
        bb.button(QDialogButtonBox.Cancel).setText("取消")
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _pick(self, gid, cnt_item):
        files, _ = QFileDialog.getOpenFileNames(
            self, "选择视频(可多选)", "", "视频 (*.mp4 *.mov *.avi *.m4v *.wmv);;所有文件 (*.*)")
        if files:
            self.assignments[gid] = files
            cnt_item.setText(f"{len(files)} 个")

    def get_jobs(self):
        return [(g, self._store.get(g, ""), p) for g, p in self.assignments.items() if p]


# ── 店铺登录态批量检查线程 ───────────────────────────────────────────────────
class CheckStoreLoginsThread(QThread):
    """后台 headless 打开每个店铺 profile,看 URL 是不是被 PDD 重定向到登录页。
    progress: (store_name, status, message)  status ∈ {'ok','dropped','error'}
    finished_all: 全部完成后发,带每店结果列表
    """
    progress = pyqtSignal(str, str, str)
    finished_all = pyqtSignal(list)

    TARGET = "https://mms.pinduoduo.com/goods/goods_list/chance"
    LOGIN_KEYWORDS = ("login", "passport", "sso")

    def __init__(self, stores: dict, chrome_exe: str, profile_root: Path):
        super().__init__()
        self.stores = stores
        self.chrome_exe = chrome_exe
        self.profile_root = profile_root
        self._stop = False

    def stop(self, wait_ms: int = 3000):
        self._stop = True
        try:
            if self.isRunning():
                self.wait(wait_ms)
        except RuntimeError:
            pass

    def run(self):
        import asyncio as _asyncio
        try:
            results = _asyncio.run(self._check_all())
        except Exception as e:
            results = [{"store": s, "status": "error", "msg": f"线程异常: {e}"}
                       for s in self.stores]
        self.finished_all.emit(results)

    async def _check_all(self):
        from playwright.async_api import async_playwright
        results = []
        async with async_playwright() as p:
            for name, prof_dirname in self.stores.items():
                if self._stop:
                    break
                profile_dir = self.profile_root / prof_dirname
                if not profile_dir.exists():
                    results.append({"store": name, "status": "error",
                                    "msg": "profile 目录不存在"})
                    self.progress.emit(name, "error", "profile 目录不存在")
                    continue
                ctx = None
                try:
                    ctx = await p.chromium.launch_persistent_context(
                        user_data_dir=str(profile_dir),
                        executable_path=self.chrome_exe,
                        headless=True,
                        args=[
                            "--headless=new",
                            "--window-position=-32000,-32000",
                            "--window-size=1280,900",
                            "--disable-blink-features=AutomationControlled",
                        ],
                        ignore_default_args=["--enable-automation"],
                    )
                    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                    await page.goto(self.TARGET, wait_until="domcontentloaded",
                                    timeout=20000)
                    await _asyncio_sleep_safe(2)
                    url = (page.url or "").lower()
                    if any(k in url for k in self.LOGIN_KEYWORDS):
                        results.append({"store": name, "status": "dropped",
                                        "msg": "已掉线(被重定向到登录页)"})
                        self.progress.emit(name, "dropped", "已掉线")
                    else:
                        results.append({"store": name, "status": "ok",
                                        "msg": "登录态有效"})
                        self.progress.emit(name, "ok", "✓ 登录态有效")
                except Exception as e:
                    results.append({"store": name, "status": "error",
                                    "msg": f"检查异常: {e}"})
                    self.progress.emit(name, "error", f"异常: {e}")
                finally:
                    if ctx:
                        try: await ctx.close()
                        except Exception: pass
        return results


async def _asyncio_sleep_safe(s):
    """asyncio.sleep 别名,放外面避免类内 import"""
    import asyncio as _a
    await _a.sleep(s)


class CheckLicenseThread(QThread):
    """打开各条 1688 链接,抓「是否特殊化妆品 + 批准文号」。
    用**专用持久化 profile(headful)**:1688 风控只对有登录态的真实 profile 渲染属性区,
    空白/headless 抓到 0 属性。未登录时停在 1688 登录页等用户登录(cookies 持久化,下次免登)。

    items: [{"id","name","supplier_link"}, ...]
    progress: (id, status, msg)  status ∈ {'has','none','nolink','error'}
    need_login: () 发出时主线程提示"请在弹出浏览器登录1688"
    finished_all: [{"id","name","is_special","license_no","status","msg"}, ...]
    """
    progress = pyqtSignal(str, str, str)
    need_login = pyqtSignal()
    login_done = pyqtSignal()
    finished_all = pyqtSignal(list)

    LOGIN_COOKIES = ("unb", "lgc", "_nk_", "tracknick")  # 出现任一 = 已登录阿里/1688

    def __init__(self, items: list, chrome_exe: str, profile_dir):
        super().__init__()
        self.items = items
        self.chrome_exe = chrome_exe
        self.profile_dir = str(profile_dir)
        self._stop = False

    def stop(self, wait_ms: int = 3000):
        self._stop = True
        try:
            if self.isRunning():
                self.wait(wait_ms)
        except RuntimeError:
            pass

    def run(self):
        import asyncio as _asyncio, traceback as _tb
        try:
            results = _asyncio.run(self._check_all())
        except Exception as e:
            try:
                from pathlib import Path as _P
                _P(r"D:/files/data/pdd/license_check_error.log").write_text(
                    f"chrome={self.chrome_exe!r}\nprofile={self.profile_dir!r}\n\n{_tb.format_exc()}",
                    encoding="utf-8")
            except Exception:
                pass
            results = [{"id": it.get("id", ""), "name": it.get("name", ""),
                        "is_special": "", "license_no": "",
                        "status": "error", "msg": f"线程异常: {e}"} for it in self.items]
        self.finished_all.emit(results)

    async def _logged_in(self, ctx) -> bool:
        try:
            cookies = await ctx.cookies()
        except Exception:
            return False
        return any(c.get("name") in self.LOGIN_COOKIES for c in cookies)

    async def _check_all(self):
        import sys as _s, asyncio as _a
        if r"D:/files" not in _s.path:
            _s.path.insert(0, r"D:/files")
        from playwright.async_api import async_playwright
        from pdd_publish import scrape_supplier_attrs
        results = []
        async with async_playwright() as p:
            ctx = await p.chromium.launch_persistent_context(
                user_data_dir=self.profile_dir,
                executable_path=self.chrome_exe,
                headless=False,
                args=["--start-maximized", "--disable-blink-features=AutomationControlled"],
                ignore_default_args=["--enable-automation"],
                viewport=None,
            )
            try:
                page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                # 1) 登录态检查
                try:
                    await page.goto("https://www.1688.com", wait_until="domcontentloaded", timeout=30000)
                    await _a.sleep(2)
                except Exception:
                    pass
                if not await self._logged_in(ctx):
                    self.need_login.emit()
                    try:
                        await page.goto("https://login.1688.com", wait_until="domcontentloaded", timeout=30000)
                    except Exception:
                        pass
                    # 等用户登录,最多 240 秒
                    for _ in range(120):
                        if self._stop:
                            break
                        await _a.sleep(2)
                        if await self._logged_in(ctx):
                            break
                    if not await self._logged_in(ctx):
                        return [{"id": it.get("id", ""), "name": it.get("name", ""),
                                 "is_special": "", "license_no": "", "status": "error",
                                 "msg": "未登录 1688(超时/取消)"} for it in self.items]
                    self.login_done.emit()
                # 2) 逐条抓取(复用同一持久化 ctx,抓完关掉多开的页)
                for it in self.items:
                    if self._stop:
                        break
                    rid = it.get("id", "")
                    name = it.get("name", "")
                    url = (it.get("supplier_link", "") or "").strip()
                    if not url or "1688.com" not in url:
                        results.append({"id": rid, "name": name, "is_special": "",
                                        "license_no": "", "status": "nolink", "msg": "无 1688 链接"})
                        self.progress.emit(rid, "nolink", "无链接")
                        continue
                    n0 = len(ctx.pages)
                    try:
                        sup = await scrape_supplier_attrs(ctx, url)
                        lic = (sup.get("license_no", "") or "").strip()
                        isp = (sup.get("is_special", "") or "").strip()
                        st = "has" if lic else "none"
                        results.append({"id": rid, "name": name, "is_special": isp,
                                        "license_no": lic, "status": st,
                                        "msg": lic if lic else "未抓到批准文号",
                                        # ★ 顺手抓的 1688 规格料(自定义SKU路取用);抓不到为 {}
                                        "sku_material": sup.get("sku_material") or {}})
                        self.progress.emit(rid, st, lic or "无")
                    except Exception as e:
                        results.append({"id": rid, "name": name, "is_special": "",
                                        "license_no": "", "status": "error", "msg": f"抓取异常: {e}"})
                        self.progress.emit(rid, "error", f"异常: {e}")
                    finally:
                        # 关掉本次 scrape 多开的页(scrape_supplier_attrs 不自关)
                        for pg in ctx.pages[n0:]:
                            try: await pg.close()
                            except Exception: pass
            finally:
                try: await ctx.close()
                except Exception: pass
        return results


# ── 视觉同款核对线程(调本地 qwen2.5vl,判 我方图 vs 1688供货图 是否同款) ──────────
class CheckSameStyleThread(QThread):
    """对各商品调 match_rank.judge_pair(DINOv2)判同款。纯本地、不开浏览器、不依赖 Ollama。
    items: [{"id","name","my_image","supplier_image"}]
    progress: (id, verdict, reason)
    finished_all: [{"id","name","verdict","reason","ok"}, ...]
    """
    progress = pyqtSignal(str, str, str)
    finished_all = pyqtSignal(list)

    def __init__(self, items: list):
        super().__init__()
        self.items = items
        self._stop = False

    def stop(self, wait_ms: int = 3000):
        self._stop = True
        try:
            if self.isRunning():
                self.wait(wait_ms)
        except RuntimeError:
            pass

    def run(self):
        # ★走子进程跑 DINOv2(复用比价那套有 torch 的 python);GUI 进程不加载 torch,避免"未就绪"。
        import json as _j, os, tempfile, subprocess
        results = []
        todo = []
        name_by_id = {}
        for it in self.items:
            rid = it.get("id", ""); name = it.get("name", "")
            name_by_id[rid] = name
            if not it.get("supplier_image"):
                results.append({"id": rid, "name": name, "verdict": "不确定",
                                "reason": "无 1688 候选图(请先比价)", "ok": False})
            else:
                todo.append(it)
        if todo and not self._stop:
            tmp = os.path.join(tempfile.gettempdir(), f"pdd_samestyle_{os.getpid()}.json")
            by_id = {}
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    _j.dump([{"id": it.get("id", ""), "my": it.get("my_image", ""),
                              "other": it.get("supplier_image", "")} for it in todo], f, ensure_ascii=False)
                env = dict(os.environ); env["PYTHONIOENCODING"] = "utf-8"; env["PYTHONUTF8"] = "1"
                proc = subprocess.run(["python", r"D:/files/match_rank.py", "--pairs-file", tmp],
                                      capture_output=True, text=True, encoding="utf-8",
                                      errors="replace", env=env, timeout=600,
                                      creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                out = (proc.stdout or "").strip()
                if out:
                    data = _j.loads(out.splitlines()[-1])   # 末行=结果JSON(stderr另走,不混入)
                    by_id = {d.get("id"): d for d in data}
            except Exception as e:
                self._err = str(e)
            finally:
                try: os.remove(tmp)
                except Exception: pass
            for it in todo:
                rid = it.get("id", "")
                d = by_id.get(rid)
                if d:
                    results.append({"id": rid, "name": name_by_id.get(rid, ""),
                                    "verdict": d.get("verdict", "不确定"),
                                    "reason": d.get("reason", ""), "ok": bool(d.get("ok"))})
                else:
                    results.append({"id": rid, "name": name_by_id.get(rid, ""), "verdict": "不确定",
                                    "reason": "核对子进程无结果(视觉模型未就绪?)", "ok": False})
        for r in results:
            self.progress.emit(r["id"], r["verdict"], r["reason"])
        self.finished_all.emit(results)


# ── 图片批量加载线程 ─────────────────────────────────────────────────────────
class ImageBatchLoader(QThread):
    image_ready = pyqtSignal(object, bytes)

    def __init__(self, tasks, cache_original: bool = True, cache_dir_name: str = "img_cache"):
        super().__init__()
        self.tasks = tasks
        self.cache_original = cache_original
        self.cache_dir_name = cache_dir_name
        self._stop = False

    def run(self):
        import urllib.request, hashlib, os
        from concurrent.futures import ThreadPoolExecutor
        cache_dir = str(Path(__file__).parent / "data" / self.cache_dir_name)
        try:
            os.makedirs(cache_dir, exist_ok=True)
        except Exception:
            cache_dir = ""

        def _fetch(task):
            label, url = task
            if self._stop or not url:
                return
            if isinstance(url, str) and url.startswith("//"):
                url = "https:" + url
            data = None
            fp = ""
            original_fp = ""
            if cache_dir:
                try:
                    key = hashlib.md5(url.encode("utf-8")).hexdigest()
                    fp = os.path.join(cache_dir, key)
                    original_fp = os.path.join(str(Path(__file__).parent / "data" / "img_cache"), key)
                    if os.path.exists(fp):
                        with open(fp, "rb") as f:
                            data = f.read()
                except Exception:
                    data = None

            def _valid_image(buf):
                if not buf:
                    return False
                try:
                    from PyQt5.QtGui import QImage
                    _img = QImage()
                    return bool(_img.loadFromData(buf)) and _img.width() > 0 and _img.height() > 0
                except Exception:
                    return True

            if data is not None and not _valid_image(data):
                try:
                    if fp and os.path.exists(fp):
                        os.remove(fp)
                except Exception:
                    pass
                data = None

            if data is None and original_fp and original_fp != fp and os.path.exists(original_fp):
                try:
                    with open(original_fp, "rb") as f:
                        data = f.read()
                    if not _valid_image(data):
                        data = None
                except Exception:
                    data = None

            if data is None:
                for _try in range(2):
                    if self._stop:
                        return
                    try:
                        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://yangkeduo.com/"})
                        with _DL_OPENER.open(req, timeout=8) as resp:
                            data = resp.read()
                        if data and _valid_image(data):
                            break
                        data = None
                    except Exception:
                        data = None
                if fp and data and self.cache_original:
                    try:
                        with open(fp, "wb") as f:
                            f.write(data)
                    except Exception:
                        pass
            if self._stop or not data:
                return
            try:
                from PyQt5.QtGui import QImage
                from PyQt5.QtCore import QByteArray, QBuffer, QIODevice
                _img = QImage()
                if _img.loadFromData(data):
                    if _img.width() > 256 or _img.height() > 256:
                        _img = _img.scaled(256, 256, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    _ba = QByteArray(); _bf = QBuffer(_ba); _bf.open(QIODevice.WriteOnly)
                    if _img.save(_bf, "JPG", 82):
                        _bf.close()
                        if _ba.size() > 0:
                            data = bytes(_ba)
                else:
                    return
            except Exception:
                pass
            if fp and data and not self.cache_original:
                try:
                    with open(fp, "wb") as f:
                        f.write(data)
                except Exception:
                    pass
            if self._stop or not data:
                return
            try:
                self.image_ready.emit(label, data)
            except Exception:
                pass
        # 8 线程并行下载;_stop 时各任务快速返回,with 块随即结束。
        try:
            with ThreadPoolExecutor(max_workers=8) as ex:
                list(ex.map(_fetch, list(self.tasks)))
        except Exception:
            pass

    def stop(self, wait_ms: int = 3000):
        """请求线程停止 + 等待退出(最多 wait_ms 毫秒)。
        必须在替换 self.xxx_loader 引用前调用,否则旧线程还在跑就被 GC,
        Qt 触发 fatal: 'QThread: Destroyed while thread is still running' 整个客户端 abort。
        """
        self._stop = True
        try:
            if self.isRunning():
                self.wait(wait_ms)
        except RuntimeError:
            pass


# ── 手动比价候选选择弹窗 ─────────────────────────────────────────────────────
class CandidatePickerDialog(QDialog):
    """手动比价:列出 1688 图搜候选(缩略图+名+价+店铺+揽收率),用户单选确认。

    每行有「✅ 用这个」按钮直接提交并关闭(无须二次确认);可选打开 1688 详情页核对。
    selected() 返回所选 candidate dict;Cancel/关闭返回 None。
    """
    THUMB = 100

    def __init__(self, source_name: str, source_image: str, candidates: list, parent=None,
                 selected_link: str = ""):
        super().__init__(parent)
        self.setWindowTitle("手动比价 — 选择同款供应商")
        self.resize(900, 640)
        self._candidates = candidates or []
        self._selected = None
        self._sys_link = (selected_link or "").strip()   # 系统已选中的供应商链接,用于标注
        self._refetch_requested = False   # 用户点「🔄 重新抓取」时置 True,caller 检查后重跑
        self._refetch_with_image = ""     # 用户点「📤 上传新图重抓」选定的本地图路径(空=用原图)
        self._dlg_loader = None

        root = QVBoxLayout(self)
        root.setContentsMargins(15, 12, 15, 12)
        root.setSpacing(8)

        # 顶部:源商品参考
        head = QHBoxLayout()
        self._src_lbl = QLabel("…")
        self._src_lbl.setFixedSize(self.THUMB, self.THUMB)
        self._src_lbl.setAlignment(Qt.AlignCenter)
        self._src_lbl.setStyleSheet("border:2px solid #4F46C8;border-radius:6px;background:#F9FAFB;")
        head.addWidget(self._src_lbl)
        src_info = QLabel(
            f"<b style='color:#4F46C8;font-size:13px'>源商品(已比价目标)</b><br>"
            f"<span style='font-size:12px'>{source_name[:80]}</span><br>"
            f"<span style='color:#6B7280;font-size:11px'>请在下方候选中选一个同款(按 1688 视觉相似度排序,首条最相似)</span>"
        )
        src_info.setTextFormat(Qt.RichText)
        src_info.setWordWrap(True)
        head.addWidget(src_info, 1)
        root.addLayout(head)

        # 排序栏:相似度(默认 1688 原序)/ 价格↑ / 揽收率↓
        self._orig_candidates = list(self._candidates)   # 原始相似度序
        self._sort_mode = "sim"
        sort_bar = QHBoxLayout()
        sort_bar.addWidget(QLabel("<span style='color:#6B7280;font-size:12px'>排序:</span>"))
        self._sort_btns = {}
        for key, label in [("sim", "相似度"), ("price", "价格 ↑低到高"), ("fulfill", "揽收率 ↓高到低")]:
            b = QPushButton(label)
            b.setCheckable(True)
            b.setChecked(key == "sim")
            b.setStyleSheet(
                "QPushButton{background:white;color:#374151;border:1px solid #D1D5DB;border-radius:4px;"
                "padding:4px 12px;}QPushButton:hover{background:#F5F3FF;}"
                "QPushButton:checked{background:#4F46C8;color:white;border-color:#4F46C8;}")
            b.clicked.connect(lambda _, k=key: self._apply_sort(k))
            self._sort_btns[key] = b
            sort_bar.addWidget(b)
        sort_bar.addStretch()
        root.addLayout(sort_bar)

        # 候选滚动列表
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:1px solid #E5E7EB;border-radius:6px;background:white;}")
        box = QWidget()
        bl = QVBoxLayout(box)
        bl.setContentsMargins(8, 8, 8, 8)
        bl.setSpacing(6)
        self._list_layout = bl
        scroll.setWidget(box)
        root.addWidget(scroll, 1)

        # 源图单独加载一次;候选行 + 缩略图由 _populate 负责(排序时重建)
        if source_image:
            self._src_loader = ImageBatchLoader([(self._src_lbl, source_image)])
            self._src_loader.image_ready.connect(self._set_thumb)
            self._src_loader.start()
        self._populate_candidates(self._candidates)

        # 底部按钮
        btm = QHBoxLayout()
        btn_refetch = QPushButton("🔄 重新抓取 1688")
        btn_refetch.setToolTip("候选都不对时,清空当前候选并重新跑 1688 图搜(用原图)")
        btn_refetch.setStyleSheet(
            "QPushButton{background:white;color:#10B981;border:1px solid #86EFAC;"
            "border-radius:4px;padding:6px 14px;}QPushButton:hover{background:#ECFDF5;}")
        btn_refetch.clicked.connect(self._request_refetch)
        btm.addWidget(btn_refetch)
        btn_reupload = QPushButton("📤 上传新图重抓")
        btn_reupload.setToolTip("1688 识别错(如认成模特衣服)时,选一张本地新图(裁剪过的产品主体)重新跑")
        btn_reupload.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;"
            "border-radius:4px;padding:6px 14px;}QPushButton:hover{background:#EEF2FF;}")
        btn_reupload.clicked.connect(self._request_refetch_with_new_image)
        btm.addWidget(btn_reupload)
        btm.addStretch()
        btn_cancel = QPushButton("取消")
        btn_cancel.setStyleSheet(
            "QPushButton{background:#F3F4F6;color:#374151;border:1px solid #D1D5DB;"
            "border-radius:4px;padding:6px 18px;}QPushButton:hover{background:#E5E7EB;}")
        btn_cancel.clicked.connect(self.reject)
        btm.addWidget(btn_cancel)
        root.addLayout(btm)

    def _populate_candidates(self, cands: list):
        """(重)填候选列表(排序后重建)。候选缩略图重新异步加载。"""
        # 清空旧行
        while self._list_layout.count():
            it = self._list_layout.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()
        img_tasks = []
        if not cands:
            self._list_layout.addWidget(QLabel("⚠ 未抓到候选(可能 1688 图搜失败或被风控)"))
        for i, c in enumerate(cands):
            self._list_layout.addWidget(self._build_row(i, c, img_tasks))
        self._list_layout.addStretch()
        if img_tasks:
            if self._dlg_loader is not None:
                try: self._dlg_loader.stop()
                except Exception: pass
            self._dlg_loader = ImageBatchLoader(img_tasks)
            self._dlg_loader.image_ready.connect(self._set_thumb)
            self._dlg_loader.start()

    def _apply_sort(self, key: str):
        """切换排序:相似度(原序)/ 价格升序 / 揽收率降序。"""
        self._sort_mode = key
        for k, b in self._sort_btns.items():
            b.setChecked(k == key)
        cands = list(self._orig_candidates)
        if key == "price":
            cands.sort(key=lambda c: (float(c.get("total", 0) or 0), -float(c.get("fulfillment", 0) or 0)))
        elif key == "fulfill":
            cands.sort(key=lambda c: (-float(c.get("fulfillment", 0) or 0), float(c.get("total", 0) or 0)))
        # key == "sim" → 保持原序
        self._candidates = cands
        self._populate_candidates(cands)

    def closeEvent(self, event):
        """对话框关闭前停掉图片加载线程,避免 QThread destroyed-while-running fatal。"""
        for ld in (getattr(self, "_dlg_loader", None), getattr(self, "_src_loader", None)):
            if ld is not None:
                try: ld.stop()
                except Exception: pass
        super().closeEvent(event)

    def _build_row(self, idx: int, c: dict, img_tasks: list) -> QWidget:
        # 是不是系统已经选中的那条供应商(按链接匹配)
        is_sys = bool(self._sys_link) and (c.get("link", "") or "").strip() == self._sys_link
        row = QWidget()
        if is_sys:
            # 系统推荐行:绿色粗边框 + 浅绿底,一眼可见
            row.setStyleSheet(
                "QWidget{background:#ECFDF5;border:2px solid #059669;border-radius:6px;}"
                "QWidget:hover{background:#D1FAE5;border-color:#047857;}")
        else:
            row.setStyleSheet(
                "QWidget{background:#F9FAFB;border:1px solid #E5E7EB;border-radius:6px;}"
                "QWidget:hover{background:#EEF2FF;border-color:#4F46C8;}")
        rl = QHBoxLayout(row)
        rl.setContentsMargins(8, 8, 8, 8)

        # 缩略图
        thumb = QLabel("…")
        thumb.setFixedSize(self.THUMB, self.THUMB)
        thumb.setAlignment(Qt.AlignCenter)
        thumb.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:4px;color:#9CA3AF;")
        rl.addWidget(thumb)
        if c.get("image"):
            img_tasks.append((thumb, c["image"]))

        # 信息
        fulfillment = c.get("fulfillment", 0)
        fcolor = "#059669" if fulfillment >= 95 else "#DC2626"
        sys_badge = ("<span style='background:#059669;color:white;font-size:11px;"
                     "font-weight:bold;padding:1px 6px;border-radius:3px;margin-right:6px'>"
                     "🏆 系统推荐</span>") if is_sys else ""
        info = QLabel(
            f"<div style='font-size:12px'>{sys_badge}<b>#{idx+1}</b> {c.get('name','(无名)')[:70]}</div>"
            f"<div style='color:#6B7280;font-size:11px;margin-top:4px'>"
            f"{c.get('shopName','(无店铺)')} · 入驻 {c.get('years',0)} 年</div>"
            f"<div style='margin-top:4px'>"
            f"<span style='color:#DC2626;font-size:15px;font-weight:bold'>¥{c.get('total','-')}</span> "
            f"<span style='color:#9CA3AF;font-size:11px'>(¥{c.get('price','-')} + 运{c.get('shipping',0)})</span> "
            f"<span style='color:{fcolor};font-size:11px;margin-left:8px'>揽收 {fulfillment}%</span>"
            f"{(' · ' + c.get('speed','')) if c.get('speed') else ''}"
            f"</div>"
        )
        info.setTextFormat(Qt.RichText)
        info.setWordWrap(True)
        rl.addWidget(info, 1)

        # 操作按钮
        btns = QVBoxLayout()
        btn_open = QPushButton("🔗 打开")
        btn_open.setFixedWidth(80)
        btn_open.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;"
            "border-radius:4px;padding:5px;}QPushButton:hover{background:#EEF2FF;}")
        link = c.get("link", "")
        if link:
            btn_open.clicked.connect(lambda _, u=link: QDesktopServices.openUrl(QUrl(u)))
        else:
            btn_open.setEnabled(False)
        btns.addWidget(btn_open)
        btn_pick = QPushButton("✅ 用这个")
        btn_pick.setFixedWidth(80)
        btn_pick.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;"
            "border-radius:4px;padding:5px;font-weight:bold;}"
            "QPushButton:hover{background:#4338CA;}")
        btn_pick.clicked.connect(lambda _, cc=c: self._pick(cc))
        btns.addWidget(btn_pick)
        rl.addLayout(btns)
        return row

    def _pick(self, c: dict):
        # 按候选 dict 绑定(不按 idx),排序后仍选对
        self._selected = c
        self.accept()

    def _request_refetch(self):
        """点「🔄 重新抓取」:置 flag + 关闭弹窗。caller 检查 _refetch_requested 后重跑。"""
        self._refetch_requested = True
        self.reject()

    def _request_refetch_with_new_image(self):
        """点「📤 上传新图重抓」:选本地图 → 置 path + flag + 关闭弹窗。caller 用新图重跑。"""
        path, _ = QFileDialog.getOpenFileName(
            self, "选一张产品主体图(避开模特/背景干扰)", "",
            "Images (*.jpg *.jpeg *.png *.webp);;All Files (*)")
        if not path:
            return  # 用户取消文件选择,弹窗保持打开
        self._refetch_with_image = path
        self._refetch_requested = True
        self.reject()

    def _set_thumb(self, lbl, data):
        try:
            pix = QPixmap()
            pix.loadFromData(data)
            pix = pix.scaled(self.THUMB, self.THUMB, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            lbl.setPixmap(pix)
            lbl.setText("")
        except RuntimeError:
            pass

    def selected(self) -> dict | None:
        return self._selected


# ── 类目扫描线程 ─────────────────────────────────────────────────────────────
class DiscoverThread(QThread):
    log_signal   = pyqtSignal(str)
    done_signal  = pyqtSignal(dict)
    error_signal = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._proc = None

    def run(self):
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"]       = "1"
        env["PYTHONUNBUFFERED"] = "1"
        exe = sys.executable.replace("pythonw", "python")
        try:
            self._proc = subprocess.Popen(
                [exe, "-u", str(BASE_DIR / "main.py"), "--discover-only"],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                cwd=str(BASE_DIR), env=env,
                encoding="utf-8", errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            for line in self._proc.stdout:
                self.log_signal.emit(line.rstrip("\n"))
            self._proc.wait()
        except Exception as e:
            self.error_signal.emit(str(e))
            return

        if TREE_PATH.exists():
            try:
                with open(TREE_PATH, encoding="utf-8") as f:
                    tree_data = json.load(f)
                self.done_signal.emit(tree_data)
            except Exception as e:
                self.error_signal.emit(f"读取类目树失败: {e}")
        else:
            self.error_signal.emit("未生成类目树文件，请查看日志")

    def stop(self):
        if self._proc:
            self._proc.terminate()


# ── 抓取线程 ────────────────────────────────────────────────────────────────
class ScraperThread(QThread):
    log_signal   = pyqtSignal(str)
    done_signal  = pyqtSignal(list)
    error_signal = pyqtSignal(str)

    def __init__(self, combos, year, month, period="今天"):
        super().__init__()
        self.combos = combos
        self.year   = year
        self.month  = month
        self.period = period
        self._proc  = None

    def run(self):
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"]       = "1"
        env["PYTHONUNBUFFERED"] = "1"
        env["TEST_MODE"]        = "0"
        env["FILTER_YEAR"]      = str(self.year)
        env["FILTER_MONTH"]     = str(self.month)
        env["STATISTIC_PERIOD"] = self.period
        if self.combos:
            env["SELECTED_COMBOS"] = ",".join(self.combos)

        exe = sys.executable.replace("pythonw", "python")
        # 子进程 stdout 直接重定向到 log 文件,worker 线程**不读 stdout**,主线程**不接收 log 信号**。
        # 主窗口用 QTimer tail log 文件展示给用户(完全解耦,Qt 主线程零中转压力,长时间抓不会崩)。
        log_dir = DATA_DIR / "scrape_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        import time as _t
        log_path = log_dir / f"scrape_{_t.strftime('%Y%m%d_%H%M%S')}.log"
        self.scrape_log_path = str(log_path)
        # 通过 log_signal emit 一行特殊标记,主窗口看到这行知道 log 文件路径,启动 tail
        self.log_signal.emit(f"__SCRAPE_LOG_START__:{log_path}")
        try:
            with open(log_path, "w", encoding="utf-8") as _lf:
                self._proc = subprocess.Popen(
                    [exe, "-u", str(BASE_DIR / "main.py")],
                    stdout=_lf, stderr=subprocess.STDOUT,
                    cwd=str(BASE_DIR), env=env,
                    encoding="utf-8", errors="replace",
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
                self._proc.wait()  # 阻塞等子进程退出,worker 线程不做任何 IO
            try:
                with open(log_path, "a", encoding="utf-8") as _lf:
                    _lf.write(f"\n[log] subprocess exit_code={self._proc.returncode}\n")
            except Exception:
                pass
            # 通知主窗口 tail 停下
            self.log_signal.emit(f"__SCRAPE_LOG_END__:exit_code={self._proc.returncode}")
        except Exception as e:
            self.error_signal.emit(str(e))
            try:
                with open(log_path, "a", encoding="utf-8") as _lf:
                    _lf.write(f"\n[log] ScrapeWorker 异常: {e}\n")
            except Exception:
                pass
            self.log_signal.emit(f"__SCRAPE_LOG_END__:exception={e}")
            return

        files = sorted(
            [f for f in DATA_DIR.glob("products_*.json")
             if _is_main_product_file(f)],
            key=lambda f: f.stat().st_mtime
        )
        if files:
            try:
                with open(files[-1], encoding="utf-8") as f:
                    products = json.load(f)
                self.done_signal.emit(products)
                return
            except Exception as e:
                self.error_signal.emit(f"读取数据失败: {e}")
        self.done_signal.emit([])

    def stop(self):
        if self._proc:
            self._proc.terminate()


# ── 拍立淘(万邦 onebound)Key 配置 ────────────────────────────────────────────
WANBANG_CFG_PATH = str(Path(__file__).parent / "data" / "pdd" / "wanbang_api.json")


def load_wanbang_cfg() -> dict:
    try:
        if os.path.exists(WANBANG_CFG_PATH):
            with open(WANBANG_CFG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def wanbang_has_key() -> bool:
    c = load_wanbang_cfg()
    return bool((c.get("key") or "").strip()) and bool((c.get("secret") or "").strip())


def save_wanbang_cfg(key: str, secret: str):
    cfg = load_wanbang_cfg()
    cfg["key"] = key.strip()
    cfg["secret"] = secret.strip()
    cfg.setdefault("enabled", True)
    cfg.setdefault("sort", "")
    os.makedirs(os.path.dirname(WANBANG_CFG_PATH), exist_ok=True)
    with open(WANBANG_CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def ask_wanbang_key(parent=None) -> bool:
    """弹窗让用户填自己的拍立淘(万邦)Key/Secret,保存到本机配置。返回 True=已配置好。"""
    cur = load_wanbang_cfg()
    dlg = QDialog(parent)
    dlg.setWindowTitle("拍立淘 Key 设置(万邦 onebound)")
    dlg.setMinimumWidth(430)
    v = QVBoxLayout(dlg)
    v.addWidget(QLabel("请输入你自己的万邦拍立淘 API Key 与 Secret\n"
                       "(在 onebound 官网注册获取;不填则万邦不可用,会回退爬网页):"))
    form = QFormLayout()
    ed_key = QLineEdit(cur.get("key", ""))
    ed_key.setPlaceholderText("如 t1234567890")
    ed_sec = QLineEdit(cur.get("secret", ""))
    form.addRow("Key：", ed_key)
    form.addRow("Secret：", ed_sec)
    v.addLayout(form)
    note = QLabel("⚠️ 这是你的私人凭据,只保存在本机,不会外传。")
    note.setStyleSheet("color:#888;font-size:11px;")
    v.addWidget(note)
    bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    bb.accepted.connect(dlg.accept)
    bb.rejected.connect(dlg.reject)
    v.addWidget(bb)
    if dlg.exec_() != QDialog.Accepted:
        return wanbang_has_key()
    key, sec = ed_key.text().strip(), ed_sec.text().strip()
    if not key or not sec:
        QMessageBox.warning(parent, "拍立淘 Key", "Key 和 Secret 都要填,未保存。")
        return wanbang_has_key()
    try:
        save_wanbang_cfg(key, sec)
    except Exception as e:
        QMessageBox.critical(parent, "拍立淘 Key", f"保存失败:{e}")
        return False
    return True


# ── 比价方式选择弹窗 ──────────────────────────────────────────────────────────
def ask_compare_mode(parent=None, title="选择比价方式"):
    """点比价类功能时弹窗,让用户选本次用哪种比价引擎。
    返回 'wanbang' / 'web' / 'plugin';用户取消 → None。"""
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.setMinimumWidth(430)
    v = QVBoxLayout(dlg)
    v.addWidget(QLabel("请选择本次用哪种比价方式:"))
    chosen = {"mode": None}

    def _note(text):
        lb = QLabel(text)
        lb.setWordWrap(True)
        lb.setStyleSheet("color:#888; font-size:11px; margin:0 0 8px 8px;")
        return lb

    def _pick(m):
        # 选万邦但还没配置 Key → 先弹"拍立淘 Key"输入;没填好就不往下走(防止用你的key或空跑)。
        if m == "wanbang" and not wanbang_has_key():
            if not ask_wanbang_key(dlg):
                return
        chosen["mode"] = m
        dlg.accept()

    b1 = QPushButton("①  万邦 API  (推荐 · 全自动 · 零风控)")
    b1.clicked.connect(lambda: _pick("wanbang"))
    v.addWidget(b1)
    v.addWidget(_note("第三方接口:干净图准、不开浏览器、可批量无人值守。"))

    b2 = QPushButton("②  爬网页  (老方式 · 全自动)")
    b2.clicked.connect(lambda: _pick("web"))
    v.addWidget(b2)
    v.addWidget(_note("开浏览器爬 1688,可能被风控,别一次跑太多条。"))

    b3 = QPushButton("③  1688 插件官方图搜  (最准)")
    b3.clicked.connect(lambda: _pick("plugin"))
    v.addWidget(b3)
    v.addWidget(_note("⚠️ 占用鼠标键盘(跑时别碰电脑)· 需登录 1688 · 走代发价 · "
                      "适合少量精准比价 · 失败自动回退爬网页。"))

    bc = QPushButton("取消")
    bc.clicked.connect(dlg.reject)
    v.addWidget(bc)

    dlg.exec_()
    return chosen["mode"]


# ── 1688批量比价线程 ──────────────────────────────────────────────────────────
class BulkPriceCompareThread(QThread):
    item_done  = pyqtSignal(int, dict)    # (prod_idx, result)
    item_error = pyqtSignal(int, str)     # (prod_idx, err_msg)
    progress   = pyqtSignal(int, int, str)  # (done, total, name)
    all_done   = pyqtSignal(int, int)     # (success, fail)

    def __init__(self, tasks, min_delay=12, max_delay=22, show_browser=False, mode="auto"):
        """tasks: [(prod_idx, image_url, image_path, name), ...]; mode: 比价引擎 auto/wanbang/web/plugin"""
        super().__init__()
        self.tasks     = tasks
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.show_browser = show_browser
        self.mode      = mode
        self._stop     = False

    def request_stop(self):
        self._stop = True

    def run(self):
        import time, random as _rnd
        script  = Path(__file__).parent / "price_compare.py"
        success = fail = 0
        n = len(self.tasks)

        for i, (prod_idx, image_url, image_path, name) in enumerate(self.tasks):
            if self._stop:
                break
            self.progress.emit(i + 1, n, name)
            try:
                _cmd = [sys.executable, str(script), "--name", name, "--mode", self.mode]
                if image_path:
                    _cmd += ["--image-path", image_path]
                if image_url:
                    _cmd += ["--image-url", image_url]
                if self.show_browser:
                    _cmd.append("--show-browser")
                proc = subprocess.run(
                    _cmd,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    timeout=300,   # 视觉挑链接对前8条候选逐个判,加了推理时间,放宽
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
                raw = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
                result = None
                for line in reversed(raw.splitlines()):
                    if line.strip().startswith("{"):
                        result = json.loads(line.strip())
                        break
                if result is None:
                    self.item_error.emit(prod_idx, f"输出解析失败: {raw[:120]}")
                    fail += 1
                elif "error" in result:
                    self.item_error.emit(prod_idx, result["error"])
                    fail += 1
                else:
                    self.item_done.emit(prod_idx, result)
                    success += 1
            except subprocess.TimeoutExpired:
                self.item_error.emit(prod_idx, "比价超时（>300s）")
                fail += 1
            except Exception as e:
                self.item_error.emit(prod_idx, str(e))
                fail += 1

            # 随机间隔（最后一条不等待）
            if i < n - 1 and not self._stop:
                delay = _rnd.uniform(self.min_delay, self.max_delay)
                # 分段睡眠，便于 _stop 快速生效
                slept = 0.0
                while slept < delay and not self._stop:
                    time.sleep(0.5)
                    slept += 0.5

        self.all_done.emit(success, fail)



# ── 供应商资料下载线程 ────────────────────────────────────────────────────────
class SupplierDownloadThread(QThread):
    done_signal  = pyqtSignal(int, dict)   # (prod_idx, result)
    error_signal = pyqtSignal(int, str)    # (prod_idx, msg)

    def __init__(self, prod_idx: int, supplier_url: str, name: str):
        super().__init__()
        self.prod_idx     = prod_idx
        self.supplier_url = supplier_url
        self.name         = name

    def run(self):
        script = Path(__file__).parent / "supplier_download.py"
        cmd = [sys.executable, str(script),
               "--url",  self.supplier_url,
               "--name", self.name]
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=300,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            raw = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
            if not raw:
                err = (proc.stderr or b"").decode("utf-8", errors="replace").strip()
                self.error_signal.emit(self.prod_idx, err[:300] or "脚本无输出")
                return
            for line in reversed(raw.splitlines()):
                line = line.strip()
                if line.startswith("{"):
                    result = json.loads(line)
                    self.done_signal.emit(self.prod_idx, result)
                    return
            self.error_signal.emit(self.prod_idx, f"无法解析输出: {raw[:200]}")
        except subprocess.TimeoutExpired:
            self.error_signal.emit(self.prod_idx, "下载超时（>300s）")
        except Exception as e:
            self.error_signal.emit(self.prod_idx, str(e))


# ── 历史多选对话框 ────────────────────────────────────────────────────────────
class HistorySelectDialog(QDialog):
    def __init__(self, history_entries, current_count, parent=None):
        super().__init__(parent)
        self.setWindowTitle("选择历史时间段")
        self.setMinimumWidth(380)
        self.setMinimumHeight(340)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 10)
        lay.setSpacing(8)

        tip = QLabel("✅ 勾选要查看的时间段（可多选，数据自动去重合并）")
        tip.setStyleSheet("color:#4B5563;font-size:11px;")
        lay.addWidget(tip)

        self.lw = QListWidget()
        self.lw.setStyleSheet(
            "QListWidget{border:1px solid #E5E7EB;border-radius:6px;}"
            "QListWidget::item{padding:4px 6px;}"
            "QListWidget::item:selected{background:#EEF2FF;color:#1F2937;}"
        )

        # 当前数据（第一项，默认勾选）
        it = QListWidgetItem(f"📌 当前最新数据  ({current_count}条)")
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Checked)
        it.setData(Qt.UserRole, "__current__")
        self.lw.addItem(it)

        today     = datetime.now().strftime("%Y-%m-%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        for entry in reversed(history_entries):
            ts  = entry.get("timestamp", "")
            cnt = entry.get("count", 0)
            fn  = entry.get("filename", "")
            day = ts[:10]
            tag = "今天" if day == today else ("昨天" if day == yesterday else day)
            label = f"🕐 {tag} {ts[11:16]}  ({cnt}条)"
            it2 = QListWidgetItem(label)
            it2.setFlags(it2.flags() | Qt.ItemIsUserCheckable)
            it2.setCheckState(Qt.Unchecked)
            it2.setData(Qt.UserRole, fn)
            self.lw.addItem(it2)

        lay.addWidget(self.lw)

        # 全选 / 全不选
        row = QHBoxLayout()
        for txt, state in [("全选", Qt.Checked), ("全不选", Qt.Unchecked)]:
            b = QPushButton(txt)
            b.setFixedHeight(24)
            b.setStyleSheet("QPushButton{background:#F3F4F6;border-radius:4px;"
                            "font-size:11px;border:1px solid #D1D5DB;padding:0 10px;}"
                            "QPushButton:hover{background:#E5E7EB;}")
            b.clicked.connect(lambda _, s=state: self._set_all(s))
            row.addWidget(b)
        row.addStretch()
        lay.addLayout(row)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("确认查看")
        btns.button(QDialogButtonBox.Cancel).setText("取消")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    def _set_all(self, state):
        for i in range(self.lw.count()):
            self.lw.item(i).setCheckState(state)

    def selected_keys(self):
        """返回选中项的 UserRole 值列表（'__current__' 或文件名）"""
        result = []
        for i in range(self.lw.count()):
            it = self.lw.item(i)
            if it.checkState() == Qt.Checked:
                result.append(it.data(Qt.UserRole))
        return result


# ── 1688比价线程 ────────────────────────────────────────────────────────────
class PriceCompareThread(QThread):
    done_signal  = pyqtSignal(int, dict)   # (prod_idx, result)
    error_signal = pyqtSignal(str)

    def __init__(self, prod_idx: int, image_url: str, name: str, image_path: str = "",
                 show_browser: bool = False, mode: str = "auto"):
        super().__init__()
        self.prod_idx   = prod_idx
        self.image_url  = image_url
        self.name       = name
        self.image_path = image_path  # 本地图路径(可选,有则优先 set_input_files)
        self.show_browser = show_browser  # True=浏览器显示(调试);False=屏幕外静默
        self.mode       = mode        # 比价引擎 auto/wanbang/web/plugin
        self._proc      = None
        self._stopped   = False

    def stop(self):
        """用户点停止 → 杀掉比价子进程(含其拉起的 Chrome),立即中断。"""
        self._stopped = True
        try:
            if self._proc and self._proc.poll() is None:
                self._proc.kill()
        except Exception:
            pass

    def run(self):
        script = Path(__file__).parent / "price_compare.py"
        cmd = [sys.executable, str(script), "--name", self.name, "--mode", self.mode]
        # 本地路径优先(set_input_files 路径,不受 fetch/CORS 限制);
        # 没本地路径才传 URL 走老 fetch 注入
        if self.image_path:
            cmd += ["--image-path", self.image_path]
        if self.image_url:
            cmd += ["--image-url", self.image_url]
        if self.show_browser:
            cmd.append("--show-browser")
        try:
            # 用 Popen 持有句柄,stop() 能 kill;communicate 带超时
            self._proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW)
            try:
                out_b, err_b = self._proc.communicate(timeout=240)
            except subprocess.TimeoutExpired:
                try: self._proc.kill()
                except Exception: pass
                if not self._stopped:
                    self.error_signal.emit("比价超时（>240s）")
                return
            if self._stopped:   # 被用户停止 → 不发任何信号
                return
            raw = (out_b or b"").decode("utf-8", errors="replace").strip()
            err = (err_b or b"").decode("utf-8", errors="replace").strip()
            if not raw:
                self.error_signal.emit(err[:300] if err else "比价脚本无输出")
                return
            for line in reversed(raw.splitlines()):
                line = line.strip()
                if line.startswith("{"):
                    result = json.loads(line)
                    self.done_signal.emit(self.prod_idx, result)
                    return
            self.error_signal.emit(f"无法解析输出: {raw[:200]}")
        except Exception as e:
            if not self._stopped:
                self.error_signal.emit(str(e))


# ── 拼多多比价线程 ────────────────────────────────────────────────────────────
class PddCompareThread(QThread):
    done_signal  = pyqtSignal(int, dict)   # (prod_idx, result)
    error_signal = pyqtSignal(str)

    def __init__(self, prod_idx: int, image_url: str, name: str = ""):
        super().__init__()
        self.prod_idx  = prod_idx
        self.image_url = image_url
        self.name      = name

    def run(self):
        script = Path(__file__).parent / "pdd_compare.py"
        cmd = [sys.executable, str(script),
               "--image-url", self.image_url,
               "--name",      self.name,
               "--detail"]
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=180,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            raw = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
            err = (proc.stderr or b"").decode("utf-8", errors="replace").strip()
            if not raw:
                self.error_signal.emit(err[:300] if err else "拼多多比价脚本无输出")
                return
            for line in reversed(raw.splitlines()):
                line = line.strip()
                if line.startswith("{"):
                    result = json.loads(line)
                    self.done_signal.emit(self.prod_idx, result)
                    return
            self.error_signal.emit(f"无法解析输出: {raw[:200]}")
        except subprocess.TimeoutExpired:
            self.error_signal.emit("拼多多比价超时（>180s）")
        except Exception as e:
            self.error_signal.emit(str(e))


# ── 主窗口 ─────────────────────────────────────────────────────────────────
class MainWindow(QMainWindow):
    def closeEvent(self, event):
        """记录"用户主动关闭"事件。如果 client_crash.log 末尾没有这条,
        而是直接 PYTHON_EXC / ATEXIT,说明上次是异常退出。
        """
        _crash_write("USER_CLOSE", "MainWindow.closeEvent — 用户点了关闭按钮")
        super().closeEvent(event)

    def _cleanup_old_logs(self, retention_days: int = 7):
        """清理 retention_days 天前的 scrape 日志文件,避免日志无限累积。
        只清 data/scrape_logs/*.log,不动 data/pdd/publish_logs/(发布相关的留着核查)。
        """
        import time
        log_dir = DATA_DIR / "scrape_logs"
        if not log_dir.exists():
            return
        cutoff = time.time() - retention_days * 86400
        deleted = 0
        kept = 0
        for f in log_dir.glob("scrape_*.log"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
                    deleted += 1
                else:
                    kept += 1
            except Exception:
                pass
        if deleted > 0:
            print(f"[log-cleanup] 清理 {deleted} 个 {retention_days}+ 天前的 scrape log(保留 {kept} 个)")

    def __init__(self):
        super().__init__()
        _crash_write("STARTUP", "MainWindow.__init__ 启动")
        # 启动时清理 7 天前的 scrape_logs(防止积累占空间,不影响发布日志)
        try:
            self._cleanup_old_logs(retention_days=7)
        except Exception as _e:
            _crash_write("LOG_CLEANUP_ERR", str(_e))
        self.app_version = _read_app_version()
        self.setWindowTitle(f"{APP_TITLE} v{self.app_version}")
        self.resize(1380, 880)
        self.thread        = None
        self.products      = []       # 当前表格显示的数据
        self._all_prods    = []       # 当前加载文件的全量数据
        self._img_loader   = None
        self._tree_data    : dict = {}
        self._compared_only  = False  # 已比价筛选模式
        self._editing_cell   = False  # 防止 itemChanged 递归
        self._cat_filter_key = ""     # "" = 全部，"美妆" / "美妆>彩妆" / "美妆>彩妆>口红"
        self._strip_filters  = {}     # key → 文字/范围筛选字符串
        self._name_search    = ""     # 商品名称搜索关键词
        self._hide_in_library = False  # True=隐藏已入商品库(已处理过)的品,避免重复选
        self._checkbox_undo_stack = []  # Ctrl+Z 撤销最近一次 Shift 批量勾选
        self._checkbox_undo_shortcut = QShortcut(QKeySequence("Ctrl+Z"), self)
        self._checkbox_undo_shortcut.activated.connect(self._undo_last_checkbox_range)
        # 上次抓取参数（用于写历史）
        self._last_combos = []
        self._last_year   = 2026
        self._last_month  = 5
        self._build_ui()
        self._try_load_category_tree()
        self._reload_history_combo()
        self._setup_scheduler()
        self._pdd_load_stores()   # 轻量:店铺下拉数据,待发布渲染要用,保持同步
        # 重活(渲染 ~1600 行选品表 + PDD 待发布/已发布列表)延迟到窗口显示后再做,
        # 避免启动时主线程同步建上万个控件 → 白屏卡顿。先让空窗口画出来。
        self.status.showMessage("正在加载数据…")
        QTimer.singleShot(0, self._deferred_initial_load)
        # 检测上次抓取是否未完成(scrape_progress.json 还在 → 崩溃了)→ 弹窗提示
        # 延后 200ms 等 UI 显示完再弹(QTimer 已在模块顶部导入,勿在此函数内再 import,否则
        # QTimer 会被当作局部变量,上面 1872 行的用法会触发 UnboundLocalError)
        QTimer.singleShot(500, self._check_unfinished_scrape)

    # ── 构建界面 ─────────────────────────────────────────────────────────
    def _build_ui(self):
        QApplication.setFont(QFont("Microsoft YaHei", 9))
        # 顶层 QTabWidget：[选品]、[PDD自动上架]
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.tabs.addTab(self._build_xuanpin_tab(), "🔍 选品")
        self.tabs.addTab(self._build_pdd_publish_tab(), "🛒 PDD自动上架")
        # PDD 表延迟渲染:首次切到 PDD 标签页才渲染它的表(不拖慢启动)
        self._pdd_tab_loaded = False
        self.tabs.currentChanged.connect(self._on_main_tab_changed)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("就绪")
        self._apply_styles()

    def _build_xuanpin_tab(self) -> QWidget:
        """原有选品界面，包装为 tab1"""
        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_sidebar())

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(12, 12, 12, 8)
        rl.setSpacing(6)
        rl.addWidget(self._build_toolbar())
        rl.addWidget(self._build_filter_bar())

        splitter = QSplitter(Qt.Vertical)
        splitter.setHandleWidth(4)

        self.table = self._build_table()
        splitter.addWidget(self.table)
        splitter.addWidget(self._build_log())
        splitter.setSizes([540, 200])
        rl.addWidget(splitter)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(4)
        self.progress.setTextVisible(False)
        self.progress.setStyleSheet(
            "QProgressBar{border:none;background:#E5E7EB}"
            "QProgressBar::chunk{background:#4F46C8}")
        rl.addWidget(self.progress)
        root.addWidget(right, 1)
        return central

    def _build_pdd_publish_tab(self) -> QWidget:
        """PDD 自动上架闭环 - 左侧导航 + 右侧 QStackedWidget"""
        page = QWidget()
        root = QHBoxLayout(page)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── 左侧导航 ──
        sidebar = QWidget()
        sidebar.setFixedWidth(200)
        sidebar.setStyleSheet("QWidget{background:white;border-right:1px solid #E5E7EB;}")
        sl = QVBoxLayout(sidebar)
        sl.setContentsMargins(13, 14, 13, 12)
        sl.setSpacing(2)

        title = QLabel("🛒 PDD 上架")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;padding:4px 0;")
        sl.addWidget(title)
        sl.addWidget(self._hline())

        # 导航列表
        self.pdd_nav = QListWidget()
        self.pdd_nav.setFrameShape(QFrame.NoFrame)
        self.pdd_nav.setStyleSheet("""
            QListWidget{background:white;border:none;font-size:13px;outline:none;}
            QListWidget::item{padding:9px 12px;border-radius:5px;color:#374151;margin:1px 0;}
            QListWidget::item:hover{background:#F3F4F6;}
            QListWidget::item:selected{background:#EEF2FF;color:#4F46C8;font-weight:bold;}
        """)
        self.pdd_nav_items = [
            ("📚  商品库", ""),
            ("📦  待发布", "0"),
            ("📊  已发布", "0"),
            ("📉  店铺监控下架", ""),
            ("🎬  视频", ""),
            ("🎨  生图换图", ""),
            ("🗑  回收站", "0"),
            ("💎  定价规则", ""),
            ("🏪  店铺管理", ""),
            ("📋  实时日志", ""),
            ("🧭  任务中心", ""),
            ("🚗  自动推广", ""),
            ("🔑  API管理", ""),
            # ("⚙   配置", ""),  # 隐藏:全局配置已在定价规则维护,此页是空占位
        ]
        for label, _ in self.pdd_nav_items:
            QListWidgetItem(label, self.pdd_nav)
        self.pdd_nav.setCurrentRow(0)
        self.pdd_nav.currentRowChanged.connect(self._on_pdd_nav_changed)
        sl.addWidget(self.pdd_nav, 1)

        # 注:旧的"当前模式"卡片已移除(Phase 4 后每条待发布带独立规则快照,行内可下拉切换,
        #     侧边显示"当前默认规则"反而误导)。如要管理规则,从导航点「💎 定价规则」即可。
        root.addWidget(sidebar)

        # ── 右侧 QStackedWidget ──
        # 顺序必须与上方 pdd_nav_items 一致。启动时只放占位页，避免隐藏页面同步读盘/渲染表格。
        self.pdd_stack = QStackedWidget()
        self._pdd_page_builders = [
            self._build_pdd_page_library,     # idx 0 商品库
            self._build_pdd_page_pending,     # idx 1 待发布
            self._build_pdd_page_published,   # idx 2 已发布
            self._build_pdd_page_zero_sales_monitor,  # idx 3 店铺监控下架
            self._build_pdd_page_video,       # idx 4 视频
            self._build_pdd_page_genimg,      # idx 5 生图换图
            self._build_pdd_page_recycle,     # idx 6 回收站
            self._build_pdd_page_pricing,     # idx 7 定价规则
            self._build_pdd_page_stores,      # idx 8 店铺管理
            self._build_pdd_page_log,         # idx 9 实时日志
            self._build_pdd_page_tasks,       # idx 10 任务中心
            self._build_pdd_page_autopromo,   # idx 11 自动推广
            self._build_pdd_page_apikeys,     # idx 12 API管理
        ]
        self._pdd_pages_built = [False] * len(self._pdd_page_builders)
        for label, _ in self.pdd_nav_items:
            self.pdd_stack.addWidget(self._build_pdd_lazy_placeholder(label))
        # 配置页已隐藏(空占位)。_build_pdd_page_config 保留备用,不加入导航/堆栈。
        root.addWidget(self.pdd_stack, 1)
        return page

    def _build_pdd_lazy_placeholder(self, title: str) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(24, 24, 24, 24)
        lay.addStretch(1)
        lbl = QLabel(f"{title.strip()}\n\n首次打开时加载")
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet("color:#6B7280;font-size:14px;line-height:1.6;")
        lay.addWidget(lbl)
        lay.addStretch(1)
        return page

    def _ensure_pdd_page_built(self, i: int) -> bool:
        if i < 0 or i >= len(getattr(self, "_pdd_page_builders", [])):
            return False
        if self._pdd_pages_built[i]:
            return False
        old = self.pdd_stack.widget(i)
        page = self._pdd_page_builders[i]()
        self.pdd_stack.removeWidget(old)
        old.deleteLater()
        self.pdd_stack.insertWidget(i, page)
        self._pdd_pages_built[i] = True
        return True

    def _pdd_schedule_initial_page_load(self, i: int):
        """页面先显示出来，再异步触发首次数据加载，避免点击导航时白屏卡住。"""
        def _run():
            try:
                if i == 0 and hasattr(self, "pdd_lib_table"):
                    self._pdd_library_reload()
                elif i == 1 and hasattr(self, "pdd_pending_table"):
                    self._pdd_pending_reload()
                elif i in (2, 6) and hasattr(self, "pdd_pub_table"):
                    self._pdd_load_published()
                elif i == 3 and hasattr(self, "pdd_zs_store"):
                    self._pdd_zs_load_result()
                    self._pdd_zs_refresh_stores()
                elif i == 4 and hasattr(self, "pdd_video_table"):
                    self._pdd_video_reload_table()
                elif i == 5 and hasattr(self, "pdd_genimg_table"):
                    self._pdd_genimg_reload_table()
                elif i == 8 and hasattr(self, "pdd_store_table"):
                    self._pdd_store_reload_table()
                elif i == 9 and hasattr(self, "pdd_log_files"):
                    self._pdd_log_refresh_files()
                elif i == 10 and hasattr(self, "pdd_task_table"):
                    self._task_center_refresh()
                elif i == 11 and hasattr(self, "pdd_ap_table"):
                    self._pdd_ap_reload_table()
                    if getattr(self, "pdd_ap_auto_mon", None) and self.pdd_ap_auto_mon.isChecked():
                        self._pdd_ap_toggle_automon(True)
            except Exception as _e:
                print(f"[PDD首次加载] idx={i} 异常: {_e}")
        QTimer.singleShot(80, _run)
    # ════════════════════════════════════════════════════════════════════════
    #  📚 商品库子页(Phase 2)
    # ════════════════════════════════════════════════════════════════════════

    def _build_pdd_page_library(self) -> QWidget:
        """商品库子页:已比价数据/Excel 导入/手动入库的商品池。

        商品库与上游已比价数据解耦,删 compared_products.json 不影响商品库。
        只有商品库内"提交到待发布"的商品才会进入发布队列。
        """
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(15, 12, 15, 12)
        lay.setSpacing(8)

        # ── 顶部条 ──
        top = QWidget()
        top.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:6px;")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(15, 10, 15, 10)
        title = QLabel("📚 商品库")
        title.setStyleSheet("font-size:14px;font-weight:bold;color:#4F46C8;background:transparent;border:none;")
        tl.addWidget(title)
        desc = QLabel("待提交商品池。从已比价同步 / Excel 导入 / 手动入库;独立存储,删上游不影响。"
                      "选中商品「📤 提交到待发布」后才进入发布队列。")
        desc.setStyleSheet("color:#6B7280;background:transparent;border:none;font-size:11px;")
        desc.setWordWrap(True)
        tl.addWidget(desc)

        # 按钮行
        btn_row = QHBoxLayout()
        btn_sync = QPushButton("🔄 同步已比价")
        btn_sync.setToolTip("把 compared_products.json 里所有已比价商品同步到商品库(去重)")
        btn_sync.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#4338CA;}")
        btn_sync.clicked.connect(self._pdd_library_sync_from_compared)
        btn_row.addWidget(btn_sync)

        btn_refresh = QPushButton("🔄 刷新")
        btn_refresh.setToolTip("重读 product_library.json,刷新表格(用于核对待发布删除后的提交状态)")
        btn_refresh.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#EEF2FF;}")
        btn_refresh.clicked.connect(self._pdd_library_reload)
        btn_row.addWidget(btn_refresh)

        btn_import = QPushButton("📋 导入 Excel")
        btn_import.setToolTip("导入选品导出的 .xlsx 到商品库(自动提取嵌入图保存到本地;未比价字段空,可后续跑 1688 补全)")
        btn_import.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#EEF2FF;}")
        btn_import.clicked.connect(self._pdd_library_import_excel)
        btn_row.addWidget(btn_import)

        btn_template = QPushButton("📄 下载 Excel 模板")
        btn_template.setToolTip("生成一份空白模板(26 列,与导入格式一致)给客户填,弹窗选保存位置")
        btn_template.setStyleSheet(
            "QPushButton{background:white;color:#6B7280;border:1px solid #D1D5DB;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#F3F4F6;}")
        btn_template.clicked.connect(self._pdd_library_download_template)
        btn_row.addWidget(btn_template)

        btn_wbkey = QPushButton("🔑 拍立淘 Key")
        btn_wbkey.setToolTip("设置/更换你自己的万邦拍立淘 API Key 与 Secret(走「万邦」比价时用)。\n"
                             "凭据只存本机,不进交付版。")
        btn_wbkey.setStyleSheet(
            "QPushButton{background:white;color:#6B7280;border:1px solid #D1D5DB;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#F3F4F6;}")
        btn_wbkey.clicked.connect(lambda: self._open_wanbang_key_dialog())
        btn_row.addWidget(btn_wbkey)

        btn_compare = QPushButton("💰 跑 1688 比价")
        btn_compare.setToolTip("对选中的未比价商品跑 1688 图搜补全 supplier_link/cost_ref/候选(每条约 30s)")
        btn_compare.setStyleSheet(
            "QPushButton{background:white;color:#10B981;border:1px solid #86EFAC;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#ECFDF5;}")
        btn_compare.clicked.connect(self._pdd_library_compare_selected)
        btn_row.addWidget(btn_compare)

        self.pdd_lib_btn_stop_compare = QPushButton("⏹ 停止比价")
        self.pdd_lib_btn_stop_compare.setToolTip("立即停止正在跑的 1688 比价队列(杀掉当前子进程)")
        self.pdd_lib_btn_stop_compare.setStyleSheet(
            "QPushButton{background:white;color:#DC2626;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#FEF2F2;}")
        self.pdd_lib_btn_stop_compare.clicked.connect(self._pdd_library_compare_stop)
        self.pdd_lib_btn_stop_compare.setEnabled(False)
        btn_row.addWidget(self.pdd_lib_btn_stop_compare)

        # 显示比价浏览器(调试用):默认勾选，方便直接查看比价执行过程。
        self.pdd_lib_chk_show_browser = QCheckBox("显示比价浏览器(调试)")
        self.pdd_lib_chk_show_browser.setToolTip(
            "默认勾选:比价浏览器会显示，方便查看执行过程。\n"
            "取消勾选:比价浏览器在屏幕外静默运行，不挡桌面。")
        self.pdd_lib_chk_show_browser.setChecked(True)
        btn_row.addWidget(self.pdd_lib_chk_show_browser)

        btn_manual = QPushButton("🖱 手动比价")
        btn_manual.setToolTip("对选中的单条商品打开候选弹窗手动挑同款(自动比价识错时用)")
        btn_manual.setStyleSheet(
            "QPushButton{background:white;color:#F59E0B;border:1px solid #FDE68A;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#FFFBEB;}")
        btn_manual.clicked.connect(self._pdd_library_manual_compare)
        btn_row.addWidget(btn_manual)

        # 「📅 计划提交」已隐藏(占位功能,暂无实际用途)

        btn_row.addStretch()

        btn_check_lic = QPushButton("🔬 核对批准文号")
        btn_check_lic.setToolTip("对勾选商品后台打开 1688 链接,抓「是否特殊化妆品+批准文号」并记录;\n"
                                 "发布时直接用,免得每次开 1688 重抓。无批准文号会提示换链接重抓。")
        btn_check_lic.setStyleSheet(
            "QPushButton{background:white;color:#7C3AED;border:1px solid #C4B5FD;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#F5F3FF;}")
        btn_check_lic.clicked.connect(lambda: self._pdd_library_check_license())
        btn_row.addWidget(btn_check_lic)

        btn_check_same = QPushButton("🔍 核对同款")
        btn_check_same.setToolTip("用本地 DINOv2(和比价同一个视觉模型,不依赖 Ollama)比对「我的商品图」vs「1688供货图」相似度。\n"
                                  "🚨不一致/不确定 = 这条停下来用眼睛看一下(可能比价选错链接,也可能花纹细微差异)。\n"
                                  "守住「面膜配成精华」这种差距巨大的错配;仅标记,不自动改链接。")
        btn_check_same.setStyleSheet(
            "QPushButton{background:white;color:#0E7490;border:1px solid #67E8F9;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#ECFEFF;}")
        btn_check_same.clicked.connect(self._pdd_library_check_same_style)
        btn_row.addWidget(btn_check_same)

        btn_oneclick = QPushButton("🚀 一键跑品")
        btn_oneclick.setToolTip(
            "对勾选商品全自动:比价 → 货品核对(不一致/不确定的拦下不发) → "
            "自动发布(批准文号由发布脚本自抓)。开跑前选店铺+定价规则+份数。")
        btn_oneclick.setStyleSheet(
            "QPushButton{background:#7C3AED;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;font-weight:bold;}QPushButton:hover{background:#6D28D9;}"
            "QPushButton:disabled{background:#D1D5DB;}")
        # 注意:clicked 会传 checked=False,不能直接连 _pdd_oneclick_start(否则 records=False → 误判没选商品)
        btn_oneclick.clicked.connect(lambda: self._pdd_oneclick_start())
        self.pdd_lib_btn_oneclick = btn_oneclick
        btn_row.addWidget(btn_oneclick)

        self.pdd_lib_btn_oneclick_stop = QPushButton("⏹ 停止跑品")
        self.pdd_lib_btn_oneclick_stop.setToolTip("停止一键跑品:杀掉当前比价子进程,不再处理后续。\n"
                                                  "已过闸提交到待发布的商品不受影响(可在待发布页单独停)。")
        self.pdd_lib_btn_oneclick_stop.setStyleSheet(
            "QPushButton{background:white;color:#DC2626;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#FEF2F2;}"
            "QPushButton:disabled{color:#9CA3AF;border-color:#E5E7EB;background:#F9FAFB;}")
        self.pdd_lib_btn_oneclick_stop.clicked.connect(self._pdd_oneclick_stop)
        self.pdd_lib_btn_oneclick_stop.setEnabled(False)
        btn_row.addWidget(self.pdd_lib_btn_oneclick_stop)

        btn_wh = QPushButton("📦 已入仓")
        btn_wh.setToolTip("把勾选商品标记为已入仓;只写商品库本地状态,不影响发布队列")
        btn_wh.setStyleSheet(
            "QPushButton{background:white;color:#047857;border:1px solid #86EFAC;border-radius:4px;"
            "padding:6px 12px;font-weight:bold;}QPushButton:hover{background:#ECFDF5;}")
        btn_wh.clicked.connect(lambda: self._pdd_library_mark_warehoused(True))
        btn_row.addWidget(btn_wh)

        btn_unwh = QPushButton("↩ 取消入仓")
        btn_unwh.setToolTip("取消勾选商品的已入仓标记;只写商品库本地状态")
        btn_unwh.setStyleSheet(
            "QPushButton{background:white;color:#6B7280;border:1px solid #D1D5DB;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#F3F4F6;}")
        btn_unwh.clicked.connect(lambda: self._pdd_library_mark_warehoused(False))
        btn_row.addWidget(btn_unwh)
        btn_submit = QPushButton("📤 提交到待发布")
        btn_submit.setStyleSheet(
            "QPushButton{background:#10B981;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;font-weight:bold;}QPushButton:hover{background:#059669;}")
        btn_submit.clicked.connect(self._pdd_library_submit_to_pending)
        btn_row.addWidget(btn_submit)

        btn_del = QPushButton("🗑 删除选中")
        btn_del.setStyleSheet(
            "QPushButton{background:#FEE2E2;color:#B91C1C;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#FECACA;}")
        btn_del.clicked.connect(self._pdd_library_delete_selected)
        btn_row.addWidget(btn_del)

        tl.addLayout(btn_row)

        # 搜索行
        srch_row = QHBoxLayout()
        srch_lbl = QLabel("搜索：")
        srch_lbl.setStyleSheet("color:#6B7280;background:transparent;border:none;")
        srch_row.addWidget(srch_lbl)
        self.pdd_lib_search = QLineEdit()
        self.pdd_lib_search.setPlaceholderText("商品名 / 类目 关键词…")
        self.pdd_lib_search.textChanged.connect(self._pdd_library_apply_filter)
        srch_row.addWidget(self.pdd_lib_search)
        # 状态筛选(全部 / 已提交 / 未提交 / 已入仓 / 未入仓)
        srch_row.addSpacing(10)
        fl = QLabel("筛选：")
        fl.setStyleSheet("color:#6B7280;background:transparent;border:none;")
        srch_row.addWidget(fl)
        self._pdd_lib_filter_state = "all"  # all / submitted / unsubmitted / warehoused / unwarehoused
        from PyQt5.QtWidgets import QButtonGroup
        self.pdd_lib_filter_group = QButtonGroup(self)
        def _mk(label, key, color_on, color_off):
            b = QPushButton(label)
            b.setCheckable(True)
            b.setStyleSheet(
                f"QPushButton{{background:white;color:{color_off};border:1px solid #D1D5DB;"
                f"border-radius:4px;padding:5px 12px;}}"
                f"QPushButton:checked{{background:{color_on};color:white;border-color:{color_on};font-weight:bold;}}"
                f"QPushButton:hover{{border-color:{color_on};}}")
            b.clicked.connect(lambda _, k=key: self._pdd_library_set_filter(k))
            self.pdd_lib_filter_group.addButton(b)
            srch_row.addWidget(b)
            return b
        self.pdd_lib_btn_all   = _mk("全部",   "all",         "#4F46C8", "#374151")
        self.pdd_lib_btn_sub   = _mk("已提交", "submitted",   "#10B981", "#374151")
        self.pdd_lib_btn_unsub = _mk("未提交", "unsubmitted", "#F59E0B", "#374151")
        self.pdd_lib_btn_wh    = _mk("已入仓", "warehoused", "#047857", "#374151")
        self.pdd_lib_btn_unwh  = _mk("未入仓", "unwarehoused", "#6B7280", "#374151")
        self.pdd_lib_btn_all.setChecked(True)
        srch_row.addStretch()
        tl.addLayout(srch_row)

        lay.addWidget(top)

        # ── 表格 ──
        self.pdd_lib_table = QTableWidget()
        self.pdd_lib_table.setColumnCount(13)
        self.pdd_lib_table.setHorizontalHeaderLabels(
            ["全选", "图(我方/货源)", "商品名", "类目", "售价区间", "供货价", "1688供应商", "入库时间", "来源", "状态", "批准文号", "货品核对", "操作"])
        self.pdd_lib_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.pdd_lib_table.setColumnWidth(0, 45)
        self.pdd_lib_table.setColumnWidth(1, 100)   # 图:我方图+货源图 并排
        self.pdd_lib_table.setColumnWidth(3, 130)
        self.pdd_lib_table.setColumnWidth(4, 90)
        self.pdd_lib_table.setColumnWidth(5, 110)
        self.pdd_lib_table.setColumnWidth(6, 130)
        self.pdd_lib_table.setColumnWidth(7, 130)
        self.pdd_lib_table.setColumnWidth(8, 60)
        self.pdd_lib_table.setColumnWidth(9, 95)
        self.pdd_lib_table.setColumnWidth(10, 175)   # 批准文号(是否特殊 + 文号)
        self.pdd_lib_table.setColumnWidth(11, 90)    # 同款
        self.pdd_lib_table.setColumnWidth(12, 110)   # 操作
        self.pdd_lib_table.setAlternatingRowColors(True)
        self.pdd_lib_table.verticalHeader().setVisible(False)
        self.pdd_lib_table.verticalHeader().setDefaultSectionSize(50)
        self.pdd_lib_table.horizontalHeader().sectionClicked.connect(self._pdd_library_toggle_all)
        # 单元格编辑监听:商品名/类目/售价区间/供货价可编辑(其它列在 render 里 setFlags 去掉 IsEditable)
        self.pdd_lib_table.itemChanged.connect(self._pdd_library_on_item_changed)
        # 双击:批准文号(col10)弹输入框改、货品核对(col11)弹菜单改
        self.pdd_lib_table.cellDoubleClicked.connect(self._pdd_library_cell_dblclick)
        lay.addWidget(self.pdd_lib_table, 1)

        # ── 底部状态 ──
        bot = QHBoxLayout()
        self.pdd_lib_status = QLabel("(未加载)")
        self.pdd_lib_status.setStyleSheet("color:#6B7280;")
        bot.addWidget(self.pdd_lib_status)
        bot.addStretch()
        lay.addLayout(bot)

        # 初始状态
        self._pdd_lib_records = []  # 完整记录列表
        self._pdd_lib_sort_added_desc = True   # ★默认按入库时间倒序(最新入库在前);点表头第7列可切换
        _hdr7 = self.pdd_lib_table.horizontalHeaderItem(7)
        if _hdr7:
            _hdr7.setText("入库时间 ↓")
        self._pdd_library_reload()
        return page

    # ── 商品库:数据加载 / 渲染 ──────────────────────────────────────────────
    def _pdd_library_reload(self):
        """从 product_library.json 重新读取并渲染表格。"""
        if not hasattr(self, "pdd_lib_table"):
            return
        try:
            self._pdd_lib_records = product_library.load_library()
        except Exception as e:
            QMessageBox.critical(self, "加载失败", f"读取商品库失败:\n{e}")
            self._pdd_lib_records = []
        self._pdd_library_apply_filter()

    def _pdd_library_set_filter(self, state: str):
        """切换状态筛选(all / submitted / unsubmitted) 并重渲染。"""
        self._pdd_lib_filter_state = state
        self._pdd_library_apply_filter()

    def _pdd_library_apply_filter(self):
        """按搜索关键词 + 状态(已/未提交)过滤后渲染表格。"""
        kw = self.pdd_lib_search.text().strip().lower() if hasattr(self, "pdd_lib_search") else ""
        records = self._pdd_lib_records
        # 状态筛选
        state = getattr(self, "_pdd_lib_filter_state", "all")
        if state == "submitted":
            records = [r for r in records if r.get("submitted")]
        elif state == "unsubmitted":
            records = [r for r in records if not r.get("submitted")]
        elif state == "warehoused":
            records = [r for r in records if r.get("warehoused")]
        elif state == "unwarehoused":
            records = [r for r in records if not r.get("warehoused")]
        # 批准文号筛选(点表头第 10 列触发)
        lf = getattr(self, "_pdd_lib_filter_license", None)
        if lf == "checked":
            records = [r for r in records if r.get("license_checked") and (r.get("license_no") or "").strip()]
        elif lf == "none":
            records = [r for r in records if r.get("license_checked") and not (r.get("license_no") or "").strip()]
        elif lf == "unchecked":
            records = [r for r in records if not r.get("license_checked")]
        # 货品核对筛选(点表头第 11 列触发)
        sf = getattr(self, "_pdd_lib_filter_samestyle", None)
        if sf == "unchecked":
            records = [r for r in records if not (r.get("same_style") or "").strip()]
        elif sf in ("一致", "不一致", "不确定"):
            records = [r for r in records if (r.get("same_style") or "").strip() == sf]
        # 关键词搜索
        if kw:
            kws = kw.split()
            records = [r for r in records if all(
                k in (r.get("name", "") + " " + r.get("category", "")).lower() for k in kws)]
        # 入库时间排序(点表头第 7 列触发)
        sort_dir = getattr(self, "_pdd_lib_sort_added_desc", None)
        if sort_dir is not None:
            records = sorted(records, key=lambda r: r.get("added_time", ""),
                             reverse=bool(sort_dir))
        self._pdd_library_render(records)

    @staticmethod
    def _pdd_source_image(prod: dict) -> str:
        """取 1688 货源图:按 supplier_link 在 candidates 里匹配选中那条的图;
        匹配不到则退回首个候选图;都没有返回 ''。"""
        link = (prod.get("supplier_link", "") or "").strip()
        cands = prod.get("candidates") or []
        if link:
            for c in cands:
                if (c.get("link", "") or "").strip() == link and c.get("image"):
                    return c["image"]
        for c in cands:
            if c.get("image"):
                return c["image"]
        return prod.get("cost_image", "") or ""

    def _pdd_publish_use_source(self) -> bool:
        """发布用图开关:True=用货源图发布(默认),False=用选品图。
        一键跑品无人值守发布优先读本次弹窗选择;手动发布读待发布工具栏下拉。"""
        oc_src = getattr(self, "_oc_publish_image_source", None)
        if getattr(self, "_oc_unattended", False) and oc_src in ("source", "xuanpin"):
            return oc_src == "source"
        c = getattr(self, "pdd_pub_image_combo", None)
        return (c.currentIndex() == 1) if c is not None else True   # 无下拉时也默认货源图

    def _pdd_smart_sku_on(self) -> bool:
        """🤖智能SKU:已默认常开 —— 发布子进程恒带 --smart-sku(云端判份数,判不准照1688真料重建SKU)。
        不再靠勾选框开关。"""
        return True

    @staticmethod
    def _alicdn_original(url: str) -> str:
        """去掉 alicdn 图片 URL 的尺寸后缀取原图(.220x220 / _220x220 / .jpg_.webp)。
        1688 搜索返回的货源图是 220x220 缩略图,传 PDD「包装标签图」(要求宽高均≥480px)会被拒;
        去掉后缀即原图(实测多为 800x800 / 1200x1200)。非 alicdn 缩略图模式的 URL 原样返回。"""
        import re
        u = (url or "").strip()
        if not u:
            return u
        u = re.sub(r'_\.webp$', '', u, flags=re.I)                          # 去 webp 变体标记
        # 去 _460x460 / .220x220 及其后跟的 q100(质量)/xz 等处理参数(可能出现在扩展名前或 .jpg 之后)
        u = re.sub(r'[._]\d+x\d+(?:[a-z]\d+|[a-z]+)*', '', u, flags=re.I)
        # 折叠重复扩展名(如去掉中段后剩 .jpg.jpg → .jpg)
        u = re.sub(r'(\.(?:jpg|jpeg|png|webp))(?:\.(?:jpg|jpeg|png|webp))+$', r'\1', u, flags=re.I)
        return u

    def _pdd_source_image_for_publish(self, d: dict) -> str:
        """发布用的货源图 URL:先看记录自带 candidates(_pdd_source_image),
        否则按 library_id / prod_id 回查 product_library。取不到/无效返回 ''(调用方回退选品图)。
        返回前转成原图大小(_alicdn_original),避免 220x220 缩略图被 PDD 包装标签图拒。"""
        def _pub(u):
            u = (u or "").strip()
            if not u or u.lower() == "none":
                return ""
            return self._alicdn_original(u)
        si = _pub(self._pdd_source_image(d))
        if si:
            return si
        lib = getattr(self, "_pdd_lib_records", None)
        if not lib:
            try:
                lib = product_library.load_library()
            except Exception:
                lib = []
        lid = str(d.get("library_id") or ""); pid = str(d.get("prod_id") or "")
        for r in (lib or []):
            if (lid and str(r.get("id")) == lid) or (pid and str(r.get("prod_id")) == pid):
                return _pub(self._pdd_source_image(r))
        return ""

    def _pdd_library_render(self, records: list[dict]):
        """渲染表格。records 是过滤后的子集。图片异步加载。"""
        tbl = self.pdd_lib_table
        tbl.blockSignals(True)  # 屏蔽 setItem 触发的 itemChanged
        tbl.setRowCount(0)
        img_tasks = []  # [(QLabel, url), ...] 给 ImageBatchLoader
        for prod in records:
            row = tbl.rowCount()
            tbl.insertRow(row)
            # 复选框:控件式(同选品,稳且不漂);id 仍存 item 的 UserRole(控件覆盖在上面)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsEnabled)            # 不参与 item 勾选/选中/编辑
            chk.setData(Qt.UserRole, prod.get("id", ""))  # 存 library id
            tbl.setItem(row, 0, chk)
            tbl.setCellWidget(row, 0, self._make_check_widget())
            # 「图」列:我方图 + 货源图 并排(人工核对一眼对比"我方 vs 1688货源")
            img_cell = QWidget()
            img_cell.setStyleSheet("background:transparent;")
            _cl = QHBoxLayout(img_cell)
            _cl.setContentsMargins(2, 2, 2, 2)
            _cl.setSpacing(3)
            # ── 我方图(左)──
            img_lbl = ClickableImageLabel()
            img_lbl.setText("…")
            img_lbl.setAlignment(Qt.AlignCenter)
            img_lbl.setFixedSize(42, 42)
            img_lbl.setToolTip("我方商品图")
            img_lbl.setStyleSheet("color:#9CA3AF;background:white;border:1px solid #E5E7EB;border-radius:3px;")
            _cl.addWidget(img_lbl)
            img_url = (prod.get("image", "") or "").strip()
            img_local = (prod.get("image_local", "") or "").strip()
            if img_url and not img_local and Path(img_url).exists():
                img_local, img_url = img_url, ""
            img_lbl.set_image_source(img_local, img_url, prod.get("name", ""))
            if img_local and Path(img_local).exists():
                try:
                    pix = QPixmap(img_local)
                    if not pix.isNull():
                        pix = pix.scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                        img_lbl.setPixmap(pix); img_lbl.setText("")
                except Exception as e:
                    print(f"[lib-render] 本地图加载失败 {img_local}: {e}")
                    img_lbl.setText("📷")
            elif img_url and img_url.startswith(("http://", "https://", "//")):
                if img_url.startswith("//"):
                    img_url = "https:" + img_url
                img_tasks.append((img_lbl, img_url))
            else:
                img_lbl.setText("📷")
            # ── 货源图(右,1688比价选中的供货图)──
            src_img = self._pdd_source_image(prod)
            src_lbl = ClickableImageLabel()
            src_lbl.setAlignment(Qt.AlignCenter)
            src_lbl.setFixedSize(42, 42)
            src_lbl.setToolTip("1688 货源图(比价选中)")
            src_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #FDE68A;border-radius:3px;")
            if src_img:
                src_lbl.set_image_source("", src_img, prod.get("name", ""))
                if src_img.startswith("//"):
                    src_img = "https:" + src_img
                src_lbl.setText("…")
                img_tasks.append((src_lbl, src_img))
            else:
                src_lbl.setText("—")
            _cl.addWidget(src_lbl)
            tbl.setCellWidget(row, 1, img_cell)
            # 商品名
            tbl.setItem(row, 2, QTableWidgetItem(prod.get("name", "")))
            # 类目
            tbl.setItem(row, 3, QTableWidgetItem(prod.get("category", "")))
            # 售价区间
            tbl.setItem(row, 4, QTableWidgetItem(prod.get("price_range", "")))
            # 供货价:可手动输入数字,也可由 1688 比价补全
            cost_str = prod.get("cost_ref", "") or ""
            cost_it = QTableWidgetItem(cost_str)
            cost_it.setToolTip("可直接输入供货价,如 12.5 或 ¥12.5;留空表示未填写")
            if not prod.get("cost_ref"):
                cost_it.setForeground(QColor("#9CA3AF"))
            tbl.setItem(row, 5, cost_it)
            # 1688 供应商(非编辑)
            supp = prod.get("cost_supplier", "") or "—"
            supp_it = QTableWidgetItem(supp)
            supp_it.setFlags(supp_it.flags() & ~Qt.ItemIsEditable)
            if not prod.get("cost_supplier"):
                supp_it.setForeground(QColor("#9CA3AF"))
            tbl.setItem(row, 6, supp_it)
            # 入库时间(非编辑)
            t_it = QTableWidgetItem(prod.get("added_time", ""))
            t_it.setFlags(t_it.flags() & ~Qt.ItemIsEditable)
            tbl.setItem(row, 7, t_it)
            # 来源(非编辑)
            source_map = {"auto": "自动", "manual": "手动", "excel": "Excel"}
            src_it = QTableWidgetItem(source_map.get(prod.get("source", ""), prod.get("source", "")))
            src_it.setFlags(src_it.flags() & ~Qt.ItemIsEditable)
            src_it.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(row, 8, src_it)
            # 状态(非编辑):提交到待发布 + 入仓标记互不影响
            status_parts = []
            if prod.get("warehoused"):
                status_parts.append("📦 已入仓")
            status_parts.append("✅ 已提交" if prod.get("submitted") else "○ 未提交")
            stt_it = QTableWidgetItem("\n".join(status_parts))
            stt_it.setForeground(QColor("#047857") if prod.get("warehoused") else (
                QColor("#10B981") if prod.get("submitted") else QColor("#6B7280")))
            if prod.get("warehouse_time"):
                stt_it.setToolTip("入仓时间: " + str(prod.get("warehouse_time") or ""))
            stt_it.setFlags(stt_it.flags() & ~Qt.ItemIsEditable)
            stt_it.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(row, 9, stt_it)
            # 批准文号(非编辑):核对结果落到表格,不用再记弹窗
            #   未核对 → 灰「— 未核对」;已核对有文号 → 「(非)特 · 文号」;已核对无文号 → 橙「⚠ 无批准文号」
            checked = bool(prod.get("license_checked"))
            lic = (prod.get("license_no", "") or "").strip()
            isp = (prod.get("is_special", "") or "").strip()
            if not checked:
                lic_it = QTableWidgetItem("— 未核对")
                lic_it.setForeground(QColor("#9CA3AF"))
            elif lic:
                sp = {"是": "特殊", "否": "非特"}.get(isp, "")
                lic_it = QTableWidgetItem(f"{sp} · {lic}" if sp else lic)
                lic_it.setForeground(QColor("#DC2626") if isp == "是" else QColor("#047857"))
                lic_it.setToolTip(f"是否特殊化妆品: {isp or '未知'}\n批准文号: {lic}")
            else:
                lic_it = QTableWidgetItem("⚠ 无批准文号")
                lic_it.setForeground(QColor("#D97706"))
                lic_it.setToolTip("已核对但未抓到批准文号 → 建议换 1688 链接重抓")
            lic_it.setFlags(lic_it.flags() & ~Qt.ItemIsEditable)
            tbl.setItem(row, 10, lic_it)
            # 货品核对(非编辑):视觉判品类+包装是否一致。未核对→灰「—」;一致→绿✅;不一致→红🚨;不确定→橙❓
            ss = (prod.get("same_style", "") or "").strip()
            ss_reason = (prod.get("same_style_reason", "") or "").strip()
            if ss == "一致":
                ss_it = QTableWidgetItem("✅ 一致"); ss_it.setForeground(QColor("#047857"))
            elif ss == "不一致":
                ss_it = QTableWidgetItem("🚨 不一致"); ss_it.setForeground(QColor("#DC2626"))
            elif ss == "不确定":
                ss_it = QTableWidgetItem("❓ 不确定"); ss_it.setForeground(QColor("#D97706"))
            else:
                ss_it = QTableWidgetItem("—"); ss_it.setForeground(QColor("#9CA3AF"))
            if ss_reason:
                ss_it.setToolTip(ss_reason)
            ss_it.setTextAlignment(Qt.AlignCenter)
            ss_it.setFlags(ss_it.flags() & ~Qt.ItemIsEditable)
            tbl.setItem(row, 11, ss_it)
            # 操作:🔗 打开 1688 供应商链接 + ✏ 手动编辑链接
            supplier_link = prod.get("supplier_link", "")
            rid = prod.get("id", "")
            op_widget = QWidget()
            op_lay = QHBoxLayout(op_widget)
            op_lay.setContentsMargins(2, 2, 2, 2)
            op_lay.setSpacing(3)
            if supplier_link:
                btn_open = QPushButton("🔗")
                btn_open.setToolTip(f"打开 1688:\n{supplier_link}")
                btn_open.setStyleSheet(
                    "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;"
                    "border-radius:4px;padding:2px 6px;}QPushButton:hover{background:#EEF2FF;}")
                btn_open.clicked.connect(lambda _, u=supplier_link: QDesktopServices.openUrl(QUrl(u)))
                op_lay.addWidget(btn_open)
            btn_edit = QPushButton("✏")
            btn_edit.setToolTip("手动设置/修改 1688 供货链接\n(自动+手动比价都拿不到正确链接时用这个)")
            btn_edit.setStyleSheet(
                "QPushButton{background:white;color:#D97706;border:1px solid #FCD34D;"
                "border-radius:4px;padding:2px 6px;}QPushButton:hover{background:#FEF3C7;}")
            btn_edit.clicked.connect(lambda _, _id=rid: self._pdd_library_edit_supplier_link(_id))
            op_lay.addWidget(btn_edit)
            op_lay.addStretch()
            tbl.setCellWidget(row, 12, op_widget)

        # 底部状态文案
        total = len(self._pdd_lib_records)
        shown = len(records)
        uncompared = sum(1 for r in self._pdd_lib_records if not r.get("supplier_link"))
        submitted = sum(1 for r in self._pdd_lib_records if r.get("submitted"))
        warehoused = sum(1 for r in self._pdd_lib_records if r.get("warehoused"))
        self.pdd_lib_status.setText(
            f"共 {total} 条  ·  显示 {shown} 条  ·  未比价 {uncompared}  ·  已提交 {submitted}  ·  已入仓 {warehoused}")

        tbl.blockSignals(False)  # 恢复 itemChanged 监听

        # 启动异步图片加载(先停旧的避免 QThread destroyed-while-running fatal)
        if img_tasks:
            old = getattr(self, "_pdd_lib_img_loader", None)
            if old is not None:
                try: old.stop()
                except Exception: pass
            self._pdd_lib_img_loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_lib_thumb_cache")
            self._pdd_lib_img_loader.image_ready.connect(self._pdd_library_set_thumb)
            self._pdd_lib_img_loader.start()

    def _pdd_library_on_item_changed(self, item):
        """商品库表格单元格被编辑 → 保存到 product_library.json。
        可编辑列:商品名/类目/售价区间/供货价。
        """
        if not item:
            return
        col = item.column()
        field = {2: "name", 3: "category", 4: "price_range"}.get(col)
        if not field and col != 5:
            return  # 不在可编辑列
        row = item.row()
        chk_it = self.pdd_lib_table.item(row, 0)
        rid = chk_it.data(Qt.UserRole) if chk_it else ""
        if not rid:
            return
        target = next((r for r in self._pdd_lib_records if r.get("id") == rid), None)
        if not target:
            return
        new_val = item.text().strip()
        changed = False
        saved_label = ""
        if col == 5:
            cleaned = new_val.replace("￥", "¥").replace(",", "").strip()
            cleaned = re.sub(r"^(?:¥|RMB|CNY)\s*", "", cleaned, flags=re.I).strip()
            if not cleaned:
                if target.get("cost_ref") or float(target.get("supplier_cost", 0) or 0):
                    target["cost_ref"] = ""
                    target["supplier_cost"] = 0.0
                    changed = True
                saved_label = "供货价=空"
            else:
                try:
                    cost = float(cleaned)
                except ValueError:
                    self.pdd_lib_table.blockSignals(True)
                    item.setText(target.get("cost_ref", "") or "")
                    self.pdd_lib_table.blockSignals(False)
                    QMessageBox.warning(self, "供货价格式不正确", "请输入数字供货价，例如 12.5 或 ¥12.5")
                    return
                if cost < 0:
                    self.pdd_lib_table.blockSignals(True)
                    item.setText(target.get("cost_ref", "") or "")
                    self.pdd_lib_table.blockSignals(False)
                    QMessageBox.warning(self, "供货价格式不正确", "供货价不能小于 0")
                    return
                cost_ref = f"¥{cost:.2f}"
                if target.get("cost_ref") != cost_ref or float(target.get("supplier_cost", 0) or 0) != cost:
                    target["cost_ref"] = cost_ref
                    target["supplier_cost"] = cost
                    changed = True
                self.pdd_lib_table.blockSignals(True)
                item.setText(cost_ref)
                self.pdd_lib_table.blockSignals(False)
                saved_label = f"供货价={cost_ref}"
        else:
            if target.get(field, "") != new_val:
                target[field] = new_val
                changed = True
            saved_label = f"{field}={new_val[:30] or '空'}"
        if not changed:
            return
        try:
            product_library.save_library(self._pdd_lib_records)
            self.pdd_lib_status.setText(f"✓ 已保存 ({saved_label})")
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))

    def _pdd_library_edit_supplier_link(self, rid: str):
        """手动设置/修改 1688 供货链接(自动+手动比价拿不到对的时候用)。
        rid = product_library record id。
        """
        if not rid:
            return
        from PyQt5.QtWidgets import QInputDialog
        # 找当前记录
        target = next((r for r in self._pdd_lib_records if r.get("id") == rid), None)
        if not target:
            QMessageBox.warning(self, "找不到记录", f"id={rid} 不在商品库")
            return
        cur_link = target.get("supplier_link", "") or ""
        cur_supplier = target.get("cost_supplier", "") or ""
        new_link, ok = QInputDialog.getText(
            self,
            f"编辑 1688 链接 — {(target.get('name') or '')[:30]}",
            f"当前供应商:{cur_supplier or '(无)'}\n"
            "在下面填入 1688 商品页 URL(留空可清空当前链接):",
            QLineEdit.Normal,
            cur_link,
        )
        if not ok:
            return
        new_link = new_link.strip()
        # 简单校验:非空时必须看起来像 1688 链接
        if new_link and ("1688.com" not in new_link):
            ret = QMessageBox.question(
                self, "链接不像 1688",
                f"输入的链接不含 '1688.com':\n{new_link}\n\n仍然保存吗?",
                QMessageBox.Yes | QMessageBox.No)
            if ret != QMessageBox.Yes:
                return
        # 链接变了 → 旧的批准文号核对结果失效,清空(A方案:显示未核对,需重新核对)
        if new_link != cur_link:
            target["is_special"] = ""
            target["license_no"] = ""
            target["license_checked"] = False
        target["supplier_link"] = new_link
        # 如果新链接非空且 cost_supplier 为空,标个"手动"占位(让用户能识别)
        if new_link and not target.get("cost_supplier"):
            target["cost_supplier"] = "(手动指定)"
        try:
            product_library.save_library(self._pdd_lib_records)
            self.pdd_lib_status.setText(f"✓ 已保存 1688 链接")
            self._pdd_library_apply_filter()  # 重新渲染让 🔗 按钮出现/消失
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))

    def _pdd_library_set_thumb(self, label, data: bytes):
        """ImageBatchLoader 回调:把下载到的图片塞进对应 QLabel。"""
        try:
            pix = QPixmap()
            pix.loadFromData(data)
            pix = pix.scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            label.setPixmap(pix)
            label.setText("")
        except RuntimeError:
            # label 已被销毁(表格重渲染)
            pass

    def _pdd_library_toggle_all(self, col_idx: int):
        """点表头第 0 列切换全选;第 7 列(入库时间)切换排序;第 9 列(状态)弹菜单筛选。"""
        if col_idx == 7:
            # 切换排序方向:None → True(新→旧) → False(旧→新) → True ...
            cur = getattr(self, "_pdd_lib_sort_added_desc", None)
            self._pdd_lib_sort_added_desc = True if cur is None else (not cur)
            # 更新表头文字加箭头
            arrow = " ↓" if self._pdd_lib_sort_added_desc else " ↑"
            hdr_item = self.pdd_lib_table.horizontalHeaderItem(7)
            if hdr_item:
                hdr_item.setText("入库时间" + arrow)
            self._pdd_library_apply_filter()
            return
        if col_idx == 9:
            # 状态筛选(全部 / 已提交 / 未提交 / 已入仓 / 未入仓)弹菜单
            cur = getattr(self, "_pdd_lib_filter_state", "all")
            menu = QMenu(self)
            menu.setStyleSheet(
                "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
                "QMenu::item{color:#111827;padding:6px 18px;}"
                "QMenu::item:selected{background:#EEF2FF;color:#111827;}"
            )
            options = [("all", "全部"), ("submitted", "已提交"), ("unsubmitted", "未提交"), ("warehoused", "已入仓"), ("unwarehoused", "未入仓")]
            act_map = {}
            for key, label in options:
                act = menu.addAction(("● " if cur == key else "  ") + label)
                act_map[act] = key
            from PyQt5.QtCore import QPoint
            hdr = self.pdd_lib_table.horizontalHeader()
            section_x = hdr.sectionPosition(9)
            menu_pos = hdr.mapToGlobal(QPoint(section_x, hdr.height()))
            chosen = menu.exec_(menu_pos)
            if not chosen:
                return
            new_state = act_map[chosen]
            self._pdd_library_set_filter(new_state)
            # 同步顶部按钮组的勾选状态
            btn_map = {
                "all": getattr(self, "pdd_lib_btn_all", None),
                "submitted": getattr(self, "pdd_lib_btn_sub", None),
                "unsubmitted": getattr(self, "pdd_lib_btn_unsub", None),
                "warehoused": getattr(self, "pdd_lib_btn_wh", None),
                "unwarehoused": getattr(self, "pdd_lib_btn_unwh", None),
            }
            btn = btn_map.get(new_state)
            if btn:
                btn.setChecked(True)
            # 更新表头文字
            mark = "" if new_state == "all" else f" ({dict(options)[new_state]})"
            h = self.pdd_lib_table.horizontalHeaderItem(9)
            if h: h.setText("状态" + mark)
            return
        if col_idx == 10:
            # 批准文号筛选
            opts = [(None, "全部"), ("checked", "已核对有文号"), ("none", "⚠ 无文号"), ("unchecked", "未核对")]
            ok, key = self._pdd_lib_header_filter_menu(10, getattr(self, "_pdd_lib_filter_license", None), opts)
            if not ok:
                return
            self._pdd_lib_filter_license = key
            mark = "" if key is None else f" ({dict(opts)[key]})"
            h = self.pdd_lib_table.horizontalHeaderItem(10)
            if h: h.setText("批准文号" + mark)
            self._pdd_library_apply_filter()
            return
        if col_idx == 11:
            # 货品核对筛选
            opts = [(None, "全部"), ("一致", "✅ 一致"), ("不一致", "🚨 不一致"),
                    ("不确定", "❓ 不确定"), ("unchecked", "未核对")]
            ok, key = self._pdd_lib_header_filter_menu(11, getattr(self, "_pdd_lib_filter_samestyle", None), opts)
            if not ok:
                return
            self._pdd_lib_filter_samestyle = key
            mark = "" if key is None else f" ({dict(opts)[key]})"
            h = self.pdd_lib_table.horizontalHeaderItem(11)
            if h: h.setText("货品核对" + mark)
            self._pdd_library_apply_filter()
            return
        if col_idx != 0:
            return
        cbs = [self._cell_checkbox(self.pdd_lib_table, r)
               for r in range(self.pdd_lib_table.rowCount())]
        cbs = [c for c in cbs if c]
        all_checked = all(c.isChecked() for c in cbs) if cbs else False
        for c in cbs:
            c.setChecked(not all_checked)

    # ── PDD 表格控件式勾选框(替代会漂的 item checkState,统一样式,同选品)──────
    def _make_check_widget(self, checked: bool = False, gid=None) -> QWidget:
        """造一个居中的控件式勾选框(返回 wrapper),放进表格 col 0 的 setCellWidget。
        gid:可选,把记录id(已发布表用 goods_id)存进勾选框 property,操作时直接读id,
        避免靠行号 shown[r] 对齐(顺序/筛选一不一致就下错商品)。不传则行为不变。"""
        cb = QCheckBox()
        cb.setChecked(checked)
        if gid is not None:
            cb.setProperty("rec_id", str(gid))
        cb.setStyleSheet(
            "QCheckBox::indicator{width:16px;height:16px;border:2px solid #C7D2FE;"
            "border-radius:4px;background:white;}"
            "QCheckBox::indicator:hover{border-color:#4F46C8;}"
            "QCheckBox::indicator:checked{background:#4F46C8;border-color:#4F46C8;image:none;}"
            "QCheckBox::indicator:checked:hover{background:#4338CA;}")
        wrap = QWidget()
        wl = QHBoxLayout(wrap)
        wl.setContentsMargins(0, 0, 0, 0)
        wl.setAlignment(Qt.AlignCenter)
        wl.addWidget(cb)
        cb.clicked.connect(lambda checked, c=cb: self._on_table_checkbox_clicked(c, checked))
        wrap.setStyleSheet("background:transparent;")
        return wrap

    def _find_checkbox_location(self, cb):
        """返回 (table, row)；用于 Shift 批量勾选控件式复选框。"""
        for obj in self.findChildren(QTableWidget):
            try:
                for r in range(obj.rowCount()):
                    if self._cell_checkbox(obj, r) is cb:
                        return obj, r
            except Exception:
                continue
        return None, -1

    def _on_table_checkbox_clicked(self, cb, checked: bool):
        table, row = self._find_checkbox_location(cb)
        if table is None or row < 0:
            return
        mods = QApplication.keyboardModifiers()
        last = getattr(self, "_last_table_checkbox_pos", None)
        if mods & Qt.ShiftModifier and last and last[0] is table:
            a, b = sorted((int(last[1]), row))
            changes = []
            for r in range(a, b + 1):
                c = self._cell_checkbox(table, r)
                if c is not None:
                    old_state = (not bool(checked)) if r == row else c.isChecked()
                    changes.append((table, r, old_state))
            for _, r, _old_state in changes:
                c = self._cell_checkbox(table, r)
                if c is not None:
                    c.setChecked(bool(checked))
            if changes:
                stack = getattr(self, "_checkbox_undo_stack", [])
                stack.append(changes)
                self._checkbox_undo_stack = stack[-10:]
        self._last_table_checkbox_pos = (table, row)
    def _undo_last_checkbox_range(self):
        stack = getattr(self, "_checkbox_undo_stack", [])
        if not stack:
            return
        changes = stack.pop()
        self._checkbox_undo_stack = stack
        for table, row, old_state in reversed(changes):
            try:
                c = self._cell_checkbox(table, row)
                if c is not None:
                    c.setChecked(bool(old_state))
            except Exception:
                pass
    def _cell_checkbox(self, table, row: int):
        """取某表 col 0 cellWidget 里的 QCheckBox(没有返回 None)。"""
        w = table.cellWidget(row, 0)
        if w is None:
            return None
        return w if isinstance(w, QCheckBox) else w.findChild(QCheckBox)

    def _pdd_library_get_selected_records(self) -> list[dict]:
        """从表格选中行回查完整 record。"""
        sel_ids = []
        for r in range(self.pdd_lib_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_lib_table, r)
            it = self.pdd_lib_table.item(r, 0)
            if cb and cb.isChecked() and it:
                sel_ids.append(it.data(Qt.UserRole))
        return [r for r in self._pdd_lib_records if r.get("id") in sel_ids]

    def _pdd_lib_header_filter_menu(self, col: int, cur, opts: list):
        """通用:点表头某列弹筛选菜单。opts=[(key,label),...]。返回 (ok, key)。"""
        from PyQt5.QtCore import QPoint
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
            "QMenu::item{color:#111827;padding:6px 18px;}"
            "QMenu::item:selected{background:#EEF2FF;color:#111827;}")
        acts = []
        for key, label in opts:
            act = menu.addAction(("● " if cur == key else "  ") + label)
            acts.append((act, key))
        hdr = self.pdd_lib_table.horizontalHeader()
        pos = hdr.mapToGlobal(QPoint(hdr.sectionPosition(col), hdr.height()))
        chosen = menu.exec_(pos)
        if not chosen:
            return (False, None)
        for act, key in acts:
            if chosen == act:
                return (True, key)
        return (False, None)

    def _pdd_library_cell_dblclick(self, row: int, col: int):
        """双击:批准文号(col10)弹输入框改、货品核对(col11)弹菜单改。"""
        if col not in (10, 11):
            return
        it0 = self.pdd_lib_table.item(row, 0)
        rid = it0.data(Qt.UserRole) if it0 else ""
        if not rid:
            return
        if col == 10:
            self._pdd_lib_edit_license(rid)
        else:
            self._pdd_lib_edit_samestyle(rid)

    def _pdd_lib_edit_license(self, rid: str):
        """双击批准文号 → 弹框手填:是否特殊 + 批准文号(人工填=已核对)。"""
        rec = next((r for r in self._pdd_lib_records if r.get("id") == rid), None)
        if not rec:
            return
        from PyQt5.QtWidgets import QComboBox, QDialogButtonBox
        dlg = QDialog(self); dlg.setWindowTitle("编辑批准文号"); dlg.resize(440, 190)
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel(f"商品:{rec.get('name','')[:34]}"))
        r1 = QHBoxLayout(); r1.addWidget(QLabel("是否特殊用途化妆品:"))
        cb = QComboBox(); cb.addItems(["否", "是", "未知"])
        cb.setCurrentText(rec.get("is_special", "") if rec.get("is_special", "") in ("是", "否") else "未知")
        r1.addWidget(cb); r1.addStretch(); v.addLayout(r1)
        r2 = QHBoxLayout(); r2.addWidget(QLabel("批准文号/备案号:"))
        le = QLineEdit(rec.get("license_no", "")); le.setMinimumWidth(250); r2.addWidget(le); v.addLayout(r2)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject); v.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return
        sp = cb.currentText()
        rec["is_special"] = "" if sp == "未知" else sp
        rec["license_no"] = le.text().strip()
        rec["license_checked"] = True   # 人工填过就算已核对
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e)); return
        self._pdd_library_apply_filter()
        self.pdd_lib_status.setText("✓ 已更新批准文号")

    def _pdd_lib_edit_samestyle(self, rid: str):
        """双击货品核对 → 弹菜单人工设:一致 / 不一致 / 不确定 / 清除(治模型误杀)。"""
        rec = next((r for r in self._pdd_lib_records if r.get("id") == rid), None)
        if not rec:
            return
        from PyQt5.QtGui import QCursor
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
            "QMenu::item{color:#111827;padding:6px 18px;}"
            "QMenu::item:selected{background:#EEF2FF;color:#111827;}")
        a1 = menu.addAction("✅ 一致"); a2 = menu.addAction("🚨 不一致"); a3 = menu.addAction("❓ 不确定")
        menu.addSeparator(); a0 = menu.addAction("清除(未核对)")
        chosen = menu.exec_(QCursor.pos())
        if not chosen:
            return
        val = {a1: "一致", a2: "不一致", a3: "不确定", a0: ""}.get(chosen)
        if val is None:
            return
        import time as _t
        rec["same_style"] = val
        rec["same_style_reason"] = "人工标记" if val else ""
        rec["same_style_time"] = _t.strftime("%Y-%m-%d %H:%M:%S") if val else ""
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e)); return
        self._pdd_library_apply_filter()
        self.pdd_lib_status.setText(f"✓ 货品核对已设为 {val or '未核对'}")

    # ── 发布前预检:备案号(化妆品)辅助 ───────────────────────────────────
    _PDD_COSMETIC_TOP_CATS = ("美妆", "美容护肤", "个护清洁")

    def _pdd_cat_is_cosmetic(self, rec) -> bool:
        """按商品库 category 顶级类目判断是否「需要备案号的化妆品」。类目为空 → 不算(不拦)。"""
        cat = (rec.get("category") or "").strip()
        if not cat:
            return False
        top = cat.split(">")[0].strip()
        return top in self._PDD_COSMETIC_TOP_CATS

    def _pdd_lib_rec_for(self, rec):
        """按 library_id 优先、prod_id 兜底,从内存商品库取记录;查不到返回 None。"""
        libs = getattr(self, "_pdd_lib_records", None) or []
        lib_id = rec.get("library_id"); pid = rec.get("prod_id")
        by_pid = None
        for r in libs:
            if lib_id and r.get("id") == lib_id:
                return r
            if pid and r.get("prod_id") and r.get("prod_id") == pid:
                by_pid = r
        return by_pid

    def _pdd_license_status_for(self, rec):
        """取最新备案号核对状态:优先内存商品库,查不到用记录冻结值兜底。
        返回 (checked: bool, is_special: str, license_no: str)。"""
        lib = self._pdd_lib_rec_for(rec)
        if lib is not None:
            return (bool(lib.get("license_checked")),
                    (lib.get("is_special") or ""),
                    (lib.get("license_no") or "").strip())
        fz = (rec.get("license_no") or "").strip()
        return (bool(fz), (rec.get("is_special") or ""), fz)

    def _pdd_license_gate_ok(self, targets, auto=False) -> bool:
        """发布前预检:targets(待发布记录)里若有「未核对备案号的化妆品」→ 弹窗硬拦,返回 False。
        发布时现抓 1688 备案号常撞验证码失败(占发布失败约 9 成),故开跑前强制先核对。
        全部已核对(或非化妆品)→ 返回 True 放行。"""
        unchecked = []
        for rec in targets:
            if not self._pdd_cat_is_cosmetic(rec):
                continue
            checked, _isp, _lic = self._pdd_license_status_for(rec)
            if not checked:
                unchecked.append(rec)
        if not unchecked:
            return True
        # 分:能回查到商品库的(可一键核对) / 查不到库的(已删库,只能手填)
        resolvable, orphan = [], []
        for rec in unchecked:
            lib = self._pdd_lib_rec_for(rec)
            (resolvable if lib is not None else orphan).append((rec, lib))
        # ★全自动:不弹拦截框,自动去核对(只做一次,防死循环);核对完自动续发。
        if auto:
            _seen, _uniq = set(), []
            for _r, _lib in resolvable:
                if id(_lib) not in _seen:
                    _seen.add(id(_lib)); _uniq.append(_lib)
            if _uniq and not getattr(self, "_auto_license_tried", False):
                self._auto_license_tried = True
                self._auto_resume_publish = True
                print(f"[无人值守] 备案号预检:{len(_uniq)} 个化妆品未核对 → 静默自动核对,完后自动续发…")
                self._pdd_library_check_license(recs=_uniq, silent=True)
                return False           # 核对线程跑完会自动重启发布队列
            print("[无人值守] 备案号:已核对过/无可核对项 → 放行(剩余没号的发布时会跳过,不卡)")
            return True
        names = "\n".join(f"  • {r.get('name','')[:32]}" for r, _ in resolvable[:12])
        extra = f"\n  …还有 {len(resolvable) - 12} 条" if len(resolvable) > 12 else ""
        body = (f"本批有 {len(unchecked)} 个化妆品还没核对备案号。\n"
                f"发布时现抓 1688 备案号常撞验证码失败(占发布失败约 9 成),\n"
                f"请先核对(验证码当场点过),结果会存进商品库,发布时直接用。\n\n"
                f"{names}{extra}")
        if orphan:
            on = "\n".join(f"  • {r.get('name','')[:32]}" for r, _ in orphan[:6])
            body += (f"\n\n⚠ 另有 {len(orphan)} 条在商品库已找不到原品(无法一键核对),\n"
                     f"请手填备案号或从待发布移除:\n{on}")
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("发布前预检:备案号未核对")
        box.setText(body)
        btn_check = box.addButton("🔬 立即核对这些品", QMessageBox.AcceptRole)
        box.addButton("取消发布", QMessageBox.RejectRole)
        box.exec_()
        if box.clickedButton() is btn_check and resolvable:
            # 去重(多条待发布可能指向同一库品),把商品库记录传给现成核对流程
            seen, uniq = set(), []
            for _r, lib in resolvable:
                if id(lib) in seen:
                    continue
                seen.add(id(lib)); uniq.append(lib)
            self._pdd_library_check_license(recs=uniq)
        return False

    # ── 商品库:核对批准文号(发布前预检 + 记录,免发布时重抓) ──────────────
    def _pdd_library_check_license(self, recs=None, silent=False):
        """对勾选商品(或传入的记录列表)后台抓 1688 的「是否特殊化妆品+批准文号」,记录到 product_library。
        recs:发布前预检「立即核对」传入的商品库记录列表;None=用库表勾选。
        silent=True(无人值守自动核对):不建进度框、不弹完成框,后台静默跑,完后自动续发。
        无批准文号 → 提示去手动比价换链接重抓。"""
        sel = recs if recs is not None else self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "核对批准文号", "请先勾选要核对的商品")
            return
        try:
            import sys as _s
            if r"D:/files" not in _s.path:
                _s.path.insert(0, r"D:/files")
            from pdd_publish import find_chrome as _fc
            chrome_exe = _fc()
        except Exception as e:
            QMessageBox.critical(self, "环境异常", f"找 Chrome 失败:\n{e}")
            return
        if not chrome_exe or not Path(chrome_exe).exists():
            QMessageBox.critical(self, "环境异常",
                f"没找到 Chrome 可执行文件(得到: {chrome_exe!r})。\n请确认本机装了 Chrome。")
            return
        if getattr(self, "_pdd_lic_check_running", False):
            QMessageBox.information(self, "核对批准文号", "已有核对任务进行中")
            return
        items = [{"id": r.get("id", ""), "name": r.get("name", ""),
                  "supplier_link": r.get("supplier_link", "")} for r in sel]
        # 进度对话框(无人值守 silent=True → 不建框,后台静默跑)
        dlg = info = lw = None
        id_to_idx = {}
        if not silent:
            dlg = QDialog(self)
            dlg.setWindowTitle("核对批准文号")
            dlg.resize(620, 440)
            v = QVBoxLayout(dlg)
            info = QLabel(f"打开 1688 链接抓「是否特殊化妆品 + 批准文号」。共 {len(items)} 条。\n"
                          f"(首次需在弹出的浏览器里登录 1688,登录后自动继续,下次免登)")
            info.setStyleSheet("color:#374151;")
            info.setWordWrap(True)
            v.addWidget(info)
            lw = QListWidget()
            lw.setStyleSheet("QListWidget{border:1px solid #E5E7EB;border-radius:6px;}"
                             "QListWidget::item{padding:6px 8px;color:#111827;}")
            for i, it in enumerate(items):
                id_to_idx[it["id"]] = i
                lw.addItem(QListWidgetItem(f"⏳ {it['name'][:30]}  …等待"))
            v.addWidget(lw)
            btn_close = QPushButton("关闭")
            btn_close.setStyleSheet("QPushButton{background:white;color:#111827;border:1px solid #D1D5DB;"
                                    "border-radius:4px;padding:5px 14px;}QPushButton:hover{background:#F5F3FF;}")
            btn_close.clicked.connect(dlg.reject)
            v.addWidget(btn_close)
        else:
            for i, it in enumerate(items):
                id_to_idx[it["id"]] = i

        # 专用 1688 登录 profile(与 PDD 店铺 profile 解耦,cookies 持久化)
        lic_profile = Path(r"D:/files/pdd_profiles/license_1688")
        lic_profile.mkdir(parents=True, exist_ok=True)
        t = CheckLicenseThread(items, chrome_exe, lic_profile)
        self._pdd_lic_check_thread = t
        self._pdd_lic_check_running = True
        name_by_id = {it["id"]: it["name"] for it in items}

        def _on_need_login():
            if info is None:
                return
            info.setText("⚠ 请在弹出的 Chrome 里登录 1688(扫码/账号都行),登录后会自动开始核对…")
            info.setStyleSheet("color:#B45309;font-weight:bold;")

        def _on_login_done():
            if info is None:
                return
            info.setText("✅ 已登录 1688,开始核对…")
            info.setStyleSheet("color:#059669;")
        t.need_login.connect(_on_need_login)
        t.login_done.connect(_on_login_done)

        def _on_prog(rid, status, msg):
            if lw is None:
                return
            i = id_to_idx.get(rid)
            if i is None or i >= lw.count():
                return
            icon = {"has": "✅", "none": "⚠", "nolink": "🔗", "error": "❌"}.get(status, "•")
            tail = {"has": f"有: {msg}", "none": "无批准文号 → 换链接重抓",
                    "nolink": "无 1688 链接", "error": msg}.get(status, msg)
            lw.item(i).setText(f"{icon} {name_by_id.get(rid,'')[:30]}  {tail}")

        def _on_done(results):
            self._pdd_lic_check_running = False
            # 若有 error,把首条原因也弹出来(方便排查,不再只显示"其它 N 条")
            _errs = [r for r in results if r["status"] == "error"]
            # 写回 product_library
            by_id = {r["id"]: r for r in results}
            for rec in self._pdd_lib_records:
                res = by_id.get(rec.get("id"))
                if not res or res["status"] in ("nolink", "error"):
                    continue
                rec["is_special"] = res["is_special"]
                rec["license_no"] = res["license_no"]
                rec["license_checked"] = True
                # ★ 存 1688 规格料(供自定义SKU路);有料才写,无料不覆盖旧料
                _mat = res.get("sku_material") or {}
                if _mat:
                    import time as _t
                    rec["sku_material"] = _mat
                    rec["sku_material_at"] = _t.strftime("%Y-%m-%d %H:%M:%S")
            try:
                product_library.save_library(self._pdd_lib_records)
            except Exception as e:
                QMessageBox.warning(self, "保存失败", f"写 product_library 失败:\n{e}")
            self._pdd_library_reload()
            has = sum(1 for r in results if r["status"] == "has")
            none_n = sum(1 for r in results if r["status"] == "none")
            other = len(results) - has - none_n
            mat_n = sum(1 for r in results if r.get("sku_material"))  # 抓到规格料的条数
            none_names = "\n".join(f"  • {r['name'][:30]}" for r in results if r["status"] == "none")
            msg = (f"核对完成：✅ 有 {has} 条 · ⚠ 无 {none_n} 条 · 其它 {other} 条\n"
                   f"📦 含1688规格料 {mat_n} 条(供自定义SKU)\n")
            if none_n:
                msg += (f"\n以下 {none_n} 条未抓到批准文号,请到「手动比价」换一条链接重新抓：\n{none_names}")
            if _errs:
                msg += (f"\n\n❌ {len(_errs)} 条出错:\n" +
                        "\n".join(f"  • {r['name'][:20]}: {r.get('msg','')[:60]}" for r in _errs[:5]))
                msg += "\n(详情见 data/pdd/license_check_error.log)"
            if getattr(self, "_auto_resume_publish", False):
                # 无人值守:不弹完成框,自动关进度框(若有),1.2s 后自动重启发布队列(续发)
                self._auto_resume_publish = False
                if dlg is not None:
                    try:
                        dlg.accept()
                    except Exception:
                        pass
                from PyQt5.QtCore import QTimer as _QT
                _QT.singleShot(1200, lambda: self._pdd_pending_start_queue(
                    preset_copies=getattr(self, "_auto_resume_copies", None)))
            elif not silent:
                QMessageBox.information(self, "核对批准文号", msg)

        t.progress.connect(_on_prog)
        t.finished_all.connect(_on_done)
        t.start()
        if dlg is not None:
            dlg.exec_()

    # ── 商品库:核对同款(视觉,我方图 vs 1688供货图) ──────────────────────────
    def _pdd_library_check_same_style(self):
        """🔍 核对同款:对勾选商品,用本地视觉模型比对我方商品图 vs 1688 供货图。
        纯建议性:只把结果写回商品库 + 标列,不自动改 supplier_link。"""
        sel = self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "核对同款", "请先勾选要核对的商品")
            return
        import sys as _s
        if r"D:/files" not in _s.path:
            _s.path.insert(0, r"D:/files")
        # 不在 GUI 进程加载 torch/DINOv2(会"未就绪");核对走子进程,可用性由子进程结果体现。
        if getattr(self, "_pdd_same_check_running", False):
            QMessageBox.information(self, "核对同款", "已有核对任务进行中")
            return

        def _supplier_img(rec):
            link = (rec.get("supplier_link", "") or "").strip()
            cands = rec.get("candidates") or []
            if link:
                for c in cands:
                    if (c.get("link", "") or "").strip() == link and c.get("image"):
                        return c["image"]
            for c in cands:
                if c.get("image"):
                    return c["image"]
            return ""

        def _my_img(rec):
            il = rec.get("image_local", "") or ""
            if il and Path(il).exists():
                return il
            return rec.get("image", "") or ""

        items = [{"id": r.get("id", ""), "name": r.get("name", ""),
                  "my_image": _my_img(r), "supplier_image": _supplier_img(r)} for r in sel]

        dlg = QDialog(self); dlg.setWindowTitle("核对同款"); dlg.resize(640, 460)
        v = QVBoxLayout(dlg)
        info = QLabel(f"用本地视觉模型(qwen2.5vl)比对「我的商品图」vs「1688供货图」。共 {len(items)} 条。\n"
                      f"仅标记结果,不会自动修改任何链接。")
        info.setStyleSheet("color:#374151;"); info.setWordWrap(True); v.addWidget(info)
        lw = QListWidget()
        lw.setStyleSheet("QListWidget{border:1px solid #E5E7EB;border-radius:6px;}"
                         "QListWidget::item{padding:6px 8px;color:#111827;}")
        id_to_idx = {}
        for i, it in enumerate(items):
            id_to_idx[it["id"]] = i
            lw.addItem(QListWidgetItem(f"⏳ {it['name'][:30]}  …等待"))
        v.addWidget(lw)
        btn_close = QPushButton("关闭")
        btn_close.setStyleSheet("QPushButton{background:white;color:#111827;border:1px solid #D1D5DB;"
                                "border-radius:4px;padding:5px 14px;}QPushButton:hover{background:#ECFEFF;}")
        btn_close.clicked.connect(dlg.reject); v.addWidget(btn_close)

        t = CheckSameStyleThread(items)
        self._pdd_same_check_thread = t
        self._pdd_same_check_running = True
        name_by_id = {it["id"]: it["name"] for it in items}

        def _on_prog(rid, verdict, reason):
            i = id_to_idx.get(rid)
            if i is None or i >= lw.count():
                return
            icon = {"一致": "✅", "不一致": "🚨", "不确定": "❓"}.get(verdict, "•")
            lw.item(i).setText(f"{icon} {name_by_id.get(rid, '')[:26]}  {verdict} — {reason[:42]}")

        def _on_done(results):
            self._pdd_same_check_running = False
            import time as _t
            now = _t.strftime("%Y-%m-%d %H:%M:%S")
            by_id = {r["id"]: r for r in results}
            for rec in self._pdd_lib_records:
                res = by_id.get(rec.get("id"))
                if not res:
                    continue
                rec["same_style"] = res["verdict"]
                rec["same_style_reason"] = res["reason"]
                rec["same_style_time"] = now
            try:
                product_library.save_library(self._pdd_lib_records)
            except Exception as e:
                QMessageBox.warning(self, "保存失败", f"写 product_library 失败:\n{e}")
            self._pdd_library_reload()
            same = sum(1 for r in results if r["verdict"] == "一致")
            diff = sum(1 for r in results if r["verdict"] == "不一致")
            unsure = len(results) - same - diff
            diff_names = "\n".join(f"  • {r['name'][:28]}: {r['reason'][:60]}"
                                   for r in results if r["verdict"] == "不一致")
            msg = f"核对完成:✅ 一致 {same} · 🚨 不一致 {diff} · ❓ 不确定 {unsure}"
            if diff:
                msg += (f"\n\n🚨 以下 {diff} 条品类/包装不一致(买家收到可能不对板),"
                        f"务必人工看候选图、换链接后再上架:\n{diff_names}")
            QMessageBox.information(dlg, "核对同款", msg)

        t.progress.connect(_on_prog)
        t.finished_all.connect(_on_done)
        t.start()
        dlg.exec_()

    # ── 商品库:同步已比价 ────────────────────────────────────────────────
    def _pdd_library_sync_from_compared(self):
        """从 compared_products.json 同步所有已比价商品到商品库。
        去重逻辑在 product_library.bulk_add(merge=True):按 prod_id 合并非空字段。
        """
        try:
            compared = _compared_store_to_products()
        except Exception as e:
            QMessageBox.critical(self, "同步失败", f"读取 compared_products.json 失败:\n{e}")
            return
        if not compared:
            QMessageBox.information(self, "同步", "compared_products.json 没有已比价数据")
            return

        # 只同步已比价的(有 supplier_link 才视为已比价)。未比价的不进商品库。
        compared_only = [p for p in compared if p.get("supplier_link")]
        skipped_uncompared = len(compared) - len(compared_only)
        if not compared_only:
            QMessageBox.information(self, "同步",
                f"compared_products.json 共 {len(compared)} 条,但都未比价(无 supplier_link),无需同步")
            return

        # 转换 compared 记录为商品库 record 格式
        # 字段映射:_compared_store_to_products 已去掉 _ 前缀,
        # 实际字段名:name/image/link/category_label/price_range/store_name/first_online
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        new_recs = []
        for p in compared_only:
            new_recs.append({
                "prod_id":       str(p.get("prod_id") or p.get("ID") or ""),
                "name":          p.get("name", ""),
                "image":         p.get("image", ""),
                "price_range":   p.get("price_range", ""),
                "category":      p.get("category_label") or p.get("category") or "",
                "shop_name":     p.get("store_name") or p.get("shop_name") or "",
                "shop_id":       str(p.get("shop_id") or ""),
                "pdd_link":      p.get("link", ""),
                "first_listed":  p.get("first_online") or p.get("first_listed") or "",
                # 1688 字段
                "supplier_link": p.get("supplier_link", ""),
                "supplier_cost": float(p.get("supplier_cost", 0) or 0),
                "cost_ref":      p.get("cost_ref", ""),
                "cost_supplier": p.get("cost_supplier", ""),
                "cost_top3_str": p.get("cost_top3_str", ""),
                "candidates":    p.get("candidates", []) or [],
                "auto_note":     p.get("auto_note", "") or "自动比价",
                # 比价时视觉同款结论,带进商品库 → 免再人工核对
                "same_style":        p.get("same_style", ""),
                "same_style_reason": p.get("same_style_reason", ""),
                "same_style_time":   p.get("same_style_time", ""),
                "source":        "auto",
                "added_time":    now,
            })
        try:
            self._pdd_lib_records, added, merged = product_library.bulk_add(
                self._pdd_lib_records, new_recs, merge=True)
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "同步失败", f"写入商品库失败:\n{e}")
            return
        self._pdd_library_apply_filter()
        msg = (f"已比价 {len(compared_only)} 条 → 新增 {added} 条,更新 {merged} 条")
        if skipped_uncompared:
            msg += f"\n(跳过 {skipped_uncompared} 条未比价)"
        QMessageBox.information(self, "同步完成", msg)

    def _pdd_library_mark_warehoused(self, flag: bool = True):
        """把勾选商品标记/取消标记为已入仓。只写商品库本地状态。"""
        sel = self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "已入仓", "请先勾选商品。")
            return
        import time as _t
        ids = {r.get("id") for r in sel}
        now = _t.strftime("%Y-%m-%d %H:%M:%S")
        changed = 0
        for rec in self._pdd_lib_records:
            if rec.get("id") not in ids:
                continue
            if bool(rec.get("warehoused")) == bool(flag):
                continue
            rec["warehoused"] = bool(flag)
            rec["warehouse_time"] = now if flag else ""
            changed += 1
        if not changed:
            self.pdd_lib_status.setText("✓ 入仓状态未变化")
            return
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", f"写 product_library 失败:\n{e}")
            return
        self.pdd_lib_status.setText(("✓ 已标记入仓 " if flag else "✓ 已取消入仓 ") + f"{changed} 条")
        self._pdd_library_apply_filter()
    # ── 商品库:删除 ────────────────────────────────────────────────────────
    def _pdd_library_delete_selected(self):
        sel = self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "删除", "请先勾选要删除的商品")
            return
        if QMessageBox.question(self, "确认删除",
                                f"将从商品库永久删除 {len(sel)} 条记录。\n此操作只影响商品库,不影响已比价数据。\n继续?",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        ids = [r["id"] for r in sel]
        try:
            self._pdd_lib_records, n = product_library.delete_by_ids(self._pdd_lib_records, ids)
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "删除失败", str(e))
            return
        self._pdd_library_apply_filter()
        QMessageBox.information(self, "删除完成", f"已删除 {n} 条")

    # ── 商品库:提交到待发布 ───────────────────────────────────────────────
    def _pdd_library_submit_to_pending(self):
        """对选中商品弹"选店铺 + 选规则"对话框,确认后批量提交到 pending_publish.json。"""
        sel = self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "提交", "请先勾选要提交的商品")
            return
        # 过滤掉缺关键字段的(图片字段:image URL 或 image_local 本地路径任一即可)
        def _has_image(r):
            il = r.get("image_local", "")
            return bool(r.get("image")) or (il and Path(il).exists())
        invalid = [r for r in sel if not r.get("supplier_link") or not _has_image(r)]
        valid = [r for r in sel if r.get("supplier_link") and _has_image(r)]
        if not valid:
            QMessageBox.warning(self, "提交失败",
                "选中商品都缺少 supplier_link 或图片(URL/本地),无法发布。\n请先跑 1688 比价补全或检查图片路径。")
            return

        # 选店铺 + 选规则
        rules = pricing_rules.load_rules()
        default_rule = pricing_rules.get_default_rule(rules) if rules else None
        stores = self._pdd_get_store_list()
        stores = [s for s in stores if s and "无已登录" not in s]
        if not stores:
            QMessageBox.warning(self, "提交失败", "未找到已登录店铺,请先在「🏪 店铺管理」添加")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle("提交到待发布")
        dlg.resize(420, 220)
        dl = QVBoxLayout(dlg)
        info = QLabel(f"将提交 <b>{len(valid)}</b> 条商品到待发布"
                      + (f"<br><span style='color:#DC2626'>跳过 {len(invalid)} 条(缺图/供应商链接)</span>" if invalid else ""))
        info.setTextFormat(Qt.RichText)
        dl.addWidget(info)
        form = QFormLayout()
        cb_store = QComboBox()
        for s in stores:
            cb_store.addItem(s)
        form.addRow("发布店铺：", cb_store)
        cb_rule = QComboBox()
        for r in rules:
            mark = " ★" if r.get("is_default") else ""
            cb_rule.addItem(f"{r.get('name','(未命名)')}{mark}", r)
        def _select_rule_for_store():
            cb_rule.setCurrentIndex(self._pricing_rule_index_for_store(rules, cb_store.currentText()))
        cb_store.currentIndexChanged.connect(lambda _i: _select_rule_for_store())
        _select_rule_for_store()
        form.addRow("定价规则：", cb_rule)
        dl.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        dl.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return

        store = cb_store.currentText()
        rule = cb_rule.currentData()
        if not isinstance(rule, dict):
            QMessageBox.warning(self, "提交失败", "未选定价规则")
            return

        # 构造提交项 + 批量入库
        new_pendings = [pending_publish.build_from_library(r, store=store, pricing_rule=rule)
                        for r in valid]
        try:
            existing = pending_publish.load_pending()
            new_list, added, skipped = pending_publish.bulk_submit(existing, new_pendings, dedupe=True)
            pending_publish.save_pending(new_list)
        except Exception as e:
            QMessageBox.critical(self, "提交失败", f"写入待发布失败:\n{e}")
            return

        # 标记商品库中已提交
        try:
            ids = [r["id"] for r in valid]
            self._pdd_lib_records = product_library.mark_submitted(self._pdd_lib_records, ids, True)
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            print(f"[!] 标记 submitted 失败(不阻断): {e}")

        self._pdd_library_apply_filter()
        QMessageBox.information(self, "提交完成",
            f"已提交 {added} 条到待发布  ·  跳过 {skipped} 条(已存在)"
            + (f"  ·  另跳过 {len(invalid)} 条(缺图/供应商)" if invalid else ""))

    # ── 商品库:下载 Excel 模板 ────────────────────────────────────────────
    def _pdd_library_download_template(self):
        """生成一份空白 Excel 模板给客户填,字段顺序/列名必须与 _parse_selection_excel 一致。
        默认保存到桌面,可在文件对话框里改路径/文件名。
        """
        # 默认桌面 + 时间戳文件名
        desktop = Path(os.path.expanduser("~")) / "Desktop"
        if not desktop.exists():
            desktop = Path(os.path.expanduser("~"))
        default_name = f"PDD商品库导入模板_{time.strftime('%Y%m%d')}.xlsx"
        default_path = str(desktop / default_name)

        path, _ = QFileDialog.getSaveFileName(
            self, "保存 Excel 模板", default_path,
            "Excel Files (*.xlsx);;All Files (*)")
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"

        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.comments import Comment
            wb = Workbook()
            ws = wb.active
            ws.title = "商品库导入"

            # 表头(必须与 _parse_selection_excel 字段映射一致,共 26 列)。
            # 必填列含 ★ 前缀;col 3 商品图片用换行额外标注"请在此嵌入"。
            headers = [
                "排名",
                "★ 商品ID",
                "★ 商品图片\n(请在此嵌入产品图)",
                "★ 商品名称",
                "单品洞察",
                "商品链接",
                "货主店铺名称", "货主ID", "首次上架时间", "货主常驻城市", "价格区间",
                "支付GMV区间", "订单量区间", "销量区间", "支付GMV环比", "支付订单量环比",
                "全站-当日累计GMV区间", "全站-当日累计订单量区间", "全站-直接ROI区间",
                "全站-当日累计ROI区间", "广告花费区间", "来源类目",
                "1688图搜", "1688参考成本", "1688供应商", "1688前3价格"
            ]
            # 关键列必填注释(导入会用到的字段,其它可空)
            critical_notes = {
                2:  "★ 必填:商品ID(用于去重,如 PDD goods_id)",
                3:  "★ 必填:在此单元格直接粘贴/嵌入产品主体图\n导入时自动提取到本地,后续 1688 比价用",
                4:  "★ 必填:商品名称",
                6:  "可选:商品 PDD 链接",
                7:  "可选:货主店铺名(可含 ID,如 '某某店\\nID: 12345')",
                9:  "可选:首次上架时间",
                11: "可选:价格区间(如 '19.90-39.90')",
                22: "可选:来源类目(如 '美容护肤>底妆>遮瑕')",
            }

            # 样式
            header_font = Font(bold=True, color="FFFFFF", size=11)
            # 必填列:红字加粗(白底突出,改用白底以让红色可读)
            required_font = Font(bold=True, color="DC2626", size=12)
            header_fill = PatternFill(start_color="4F46C8", end_color="4F46C8", fill_type="solid")
            required_fill = PatternFill(start_color="FEF2F2", end_color="FEF2F2", fill_type="solid")  # 浅红底
            center = Alignment(horizontal="center", vertical="center", wrap_text=True)
            # 必填字段:商品ID + 商品图片 + 商品名称
            required_cols = {2, 3, 4}

            for col, h in enumerate(headers, start=1):
                cell = ws.cell(row=1, column=col, value=h)
                if col in required_cols:
                    cell.font = required_font
                    cell.fill = required_fill
                else:
                    cell.font = header_font
                    cell.fill = header_fill
                cell.alignment = center
                if col in critical_notes:
                    cell.comment = Comment(critical_notes[col], "PDD自动上架")

            # 列宽
            col_widths = {1: 6, 2: 18, 3: 14, 4: 32, 5: 12, 6: 24, 7: 22, 8: 12, 9: 14,
                          10: 12, 11: 14, 22: 20, 23: 12, 24: 14, 25: 22, 26: 24}
            for col_idx, w in col_widths.items():
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = w
            ws.row_dimensions[1].height = 44  # 加高让 col 3 两行文字显示完整

            # 第 2 行:示例行(灰色提示,客户可删)
            sample = [
                "1", "26397456283425", "(嵌入图片)", "示例商品名称",
                "", "https://mobile.yangkeduo.com/goods.html?goods_id=xxx",
                "示例店铺\nID: 12345", "12345", "2026-05-01", "广州",
                "19.90-39.90", "", "", "", "", "", "", "", "", "", "",
                "美容护肤>底妆>遮瑕", "(点击图搜)", "", "", ""
            ]
            sample_font = Font(color="9CA3AF", italic=True)
            for col, v in enumerate(sample, start=1):
                if v:
                    cell = ws.cell(row=2, column=col, value=v)
                    cell.font = sample_font

            # 第 3 行起:留 20 行空白让客户填
            wb.save(path)
        except Exception as e:
            QMessageBox.critical(self, "生成模板失败", f"{e}\n\n{traceback.format_exc()[:500]}")
            return

        # 成功提示 + 询问是否打开
        ans = QMessageBox.question(self, "模板已生成",
            f"模板已保存到:\n{path}\n\n是否打开所在文件夹?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if ans == QMessageBox.Yes:
            try:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(path).parent)))
            except Exception:
                pass

    # ── 商品库:Excel 导入 ──────────────────────────────────────────────────
    def _pdd_library_import_excel(self):
        """导入选品导出的 .xlsx 到商品库。
        - 解析 26 列字段(prod_id/name/category/price_range/store/pdd_link...)
        - 提取嵌入图,按 prod_id 保存到 data/pdd/library_images/<prod_id>.jpg
        - source 标记为 'excel',supplier_link 字段空(后续 💰 跑 1688 比价补全)
        """
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 Excel 文件", "", "Excel Files (*.xlsx);;All Files (*)")
        if not path:
            return
        try:
            new_recs, n_images = self._parse_selection_excel(path)
        except Exception as e:
            QMessageBox.critical(self, "导入失败", f"解析 Excel 失败:\n{e}\n\n{traceback.format_exc()[:500]}")
            return
        if not new_recs:
            QMessageBox.warning(self, "导入失败", "未解析出任何商品记录,请确认是选品导出的 Excel")
            return

        # 入库
        try:
            self._pdd_lib_records, added, merged = product_library.bulk_add(
                self._pdd_lib_records, new_recs, merge=True)
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "导入失败", f"写入商品库失败:\n{e}")
            return
        self._pdd_library_apply_filter()
        QMessageBox.information(self, "导入完成",
            f"解析 {len(new_recs)} 条 → 新增 {added} · 更新 {merged}\n提取嵌入图 {n_images} 张")

    def _parse_selection_excel(self, xlsx_path: str) -> tuple[list[dict], int]:
        """解析选品导出 Excel,返回 (records, images_count)。
        字段位置参考选品导出格式(26 列):
          col2=商品ID  col3=图片(嵌入)  col4=商品名称  col6=商品链接  col7=货主店铺
          col9=首次上架  col11=价格区间  col22=来源类目
        """
        from openpyxl import load_workbook
        wb = load_workbook(xlsx_path, data_only=True)
        ws = wb.active

        # 1) 提取嵌入图:按 anchor 行号 → 图片 bytes
        image_dir = Path(r"D:/files/data/pdd/library_images")
        image_dir.mkdir(parents=True, exist_ok=True)
        row_to_img_bytes: dict[int, bytes] = {}
        for img in (getattr(ws, "_images", None) or []):
            try:
                anchor = img.anchor
                # OneCellAnchor / TwoCellAnchor 都有 from_/_from 属性
                from_attr = getattr(anchor, "from_", None) or getattr(anchor, "_from", None)
                row_idx = getattr(from_attr, "row", None)  # 0-based
                if row_idx is None:
                    continue
                # 取图片字节:openpyxl _data() 或 ref 兼容
                data = None
                if hasattr(img, "_data") and callable(img._data):
                    data = img._data()
                elif hasattr(img, "ref"):
                    ref = img.ref
                    if isinstance(ref, bytes):
                        data = ref
                    elif hasattr(ref, "read"):
                        data = ref.read()
                if data:
                    row_to_img_bytes[row_idx] = data
            except Exception as e:
                print(f"[excel-import] 图片提取失败 row={row_idx}: {e}")

        # WPS/金山的单元格图片会保存为 DISPIMG 公式 + xl/cellimages.xml, openpyxl._images 读不到。
        try:
            import posixpath, zipfile
            import xml.etree.ElementTree as ET
            sheet_xml = f"xl/worksheets/sheet{wb.worksheets.index(ws) + 1}.xml"
            with zipfile.ZipFile(xlsx_path) as zf:
                names = set(zf.namelist())
                if {"xl/cellimages.xml", "xl/_rels/cellimages.xml.rels", sheet_xml}.issubset(names):
                    rel_root = ET.fromstring(zf.read("xl/_rels/cellimages.xml.rels"))
                    rels = {}
                    for rel in rel_root:
                        rid = rel.attrib.get("Id")
                        target = rel.attrib.get("Target") or ""
                        if rid and target:
                            rels[rid] = posixpath.normpath(posixpath.join("xl", target))

                    cell_img_root = ET.fromstring(zf.read("xl/cellimages.xml"))
                    id_to_media = {}
                    for pic in cell_img_root.iter():
                        if not pic.tag.endswith("}pic"):
                            continue
                        pic_id = ""
                        rid = ""
                        for node in pic.iter():
                            if node.tag.endswith("}cNvPr"):
                                pic_id = node.attrib.get("name") or ""
                            elif node.tag.endswith("}blip"):
                                rid = (node.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
                                       or node.attrib.get("r:embed") or "")
                        media_path = rels.get(rid)
                        if pic_id and media_path and media_path in names:
                            id_to_media[pic_id] = media_path

                    sheet_root = ET.fromstring(zf.read(sheet_xml))
                    for cell in sheet_root.iter():
                        if not cell.tag.endswith("}c"):
                            continue
                        ref = cell.attrib.get("r") or ""
                        if not ref.startswith("C"):
                            continue
                        text = "".join(cell.itertext())
                        m_img = re.search(r'DISPIMG\("([^"]+)"', text)
                        if not m_img:
                            continue
                        m_row = re.search(r"\d+", ref)
                        media_path = id_to_media.get(m_img.group(1))
                        if m_row and media_path:
                            row_to_img_bytes.setdefault(int(m_row.group(0)) - 1, zf.read(media_path))
        except Exception as e:
            print(f"[excel-import] WPS单元格图片提取失败: {e}")

        # 2) 遍历数据行(从 row 2 起,openpyxl row 是 1-based;_images.anchor.row 是 0-based)
        recs = []
        images_saved = 0
        for r_idx in range(2, ws.max_row + 1):
            row = [ws.cell(r_idx, c).value for c in range(1, ws.max_column + 1)]
            # 容错:行数不足 26 列也允许
            def get(i):  # 1-based 列号
                return row[i-1] if i-1 < len(row) else None

            prod_id = str(get(2) or "").strip()
            name = str(get(4) or "").strip()
            if not prod_id and not name:
                continue  # 空行跳过

            # 店铺信息可能形如 "店名\nID: 123456"
            shop_raw = str(get(7) or "")
            shop_name = shop_raw.split("\n")[0].strip()
            shop_id = ""
            m_sid = re.search(r"ID[:：]\s*(\d+)", shop_raw)
            if m_sid:
                shop_id = m_sid.group(1)

            # 保存嵌入图到本地(anchor.row 是 0-based,数据 row=2 对应 anchor.row=1)
            image_local = ""
            img_bytes = row_to_img_bytes.get(r_idx - 1)
            if img_bytes:
                # 检测图片格式(JPEG/PNG 头)
                ext = ".jpg"
                if img_bytes[:2] == b"\x89P" or img_bytes[:8].startswith(b"\x89PNG"):
                    ext = ".png"
                import hashlib
                img_key = prod_id or f"excel_row_{r_idx}_{hashlib.md5(name.encode('utf-8')).hexdigest()[:8]}"
                img_key = re.sub(r"[^0-9A-Za-z_\-]+", "_", img_key).strip("_") or f"excel_row_{r_idx}"
                local_path = image_dir / f"{img_key}{ext}"
                try:
                    with open(local_path, "wb") as f:
                        f.write(img_bytes)
                    image_local = str(local_path)
                    images_saved += 1
                except Exception as e:
                    print(f"[excel-import] 保存图片失败 row={r_idx} prod_id={prod_id}: {e}")

            recs.append({
                "prod_id":       prod_id,
                "name":          name,
                "image":         "",  # Excel 没有 URL
                "image_local":   image_local,
                "price_range":   str(get(11) or ""),
                "category":      str(get(22) or ""),
                "shop_name":     shop_name,
                "shop_id":       shop_id,
                "pdd_link":      str(get(6) or ""),
                "first_listed":  str(get(9) or ""),
                # 1688 字段空(待比价补全)
                "supplier_link": "",
                "cost_ref":      "",
                "cost_supplier": "",
                "cost_top3_str": "",
                "candidates":    [],
                "auto_note":     "未比价",
                "source":        "excel",
                "added_time":    time.strftime("%Y-%m-%d %H:%M:%S"),
                "raw_excel_row": {f"col{i+1}": (str(v) if v is not None else "") for i, v in enumerate(row)},
            })
        return recs, images_saved

    # ── 商品库:跑 1688 比价补全 ────────────────────────────────────────────
    def _pdd_library_compare_selected(self):
        """对选中的未比价商品逐条跑 1688 图搜,补全 supplier_link / cost_ref / candidates。

        策略:
          - 仅处理 supplier_link 为空的记录(已比价的跳过)
          - 串行跑(避免 1688 风控);每条约 30s
          - 进度在状态栏 + 标题更新
        """
        sel = self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "1688 比价", "请先勾选要比价的商品")
            return
        # 过滤已比价的
        targets = [r for r in sel if not r.get("supplier_link")]
        n_compared = len(sel) - len(targets)
        if not targets:
            # 全部已比价 → 问是否强制重比(重跑 1688 图搜 + 视觉同款,覆盖原结果)
            ans = QMessageBox.question(self, "1688 比价",
                f"选中 {len(sel)} 条都已比价过。\n是否【强制重新比价】?\n\n"
                f"会重新跑 1688 图搜 + 视觉同款标注,覆盖原供货链接 / 候选 / 同款结论。",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans != QMessageBox.Yes:
                return
            targets = list(sel)   # 强制重比:选中的全部重跑
        elif n_compared:
            # 混合:有未比价也有已比价 → 问要不要把已比价的也一起重比
            ans = QMessageBox.question(self, "1688 比价",
                f"选中 {len(targets)} 条未比价、{n_compared} 条已比价。\n\n"
                f"「是」= 全部 {len(sel)} 条重新比价(已比价的会覆盖供货链接/候选/同款)\n"
                f"「否」= 只比未比价的 {len(targets)} 条",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans == QMessageBox.Yes:
                targets = list(sel)
        already = len(sel) - len(targets)   # 实际会跳过的已比价数(供下方提示)
        # 必须有图(URL 或本地)
        need_img = [r for r in targets if not (r.get("image") or r.get("image_local"))]
        usable = [r for r in targets if r.get("image") or r.get("image_local")]
        if not usable:
            QMessageBox.warning(self, "1688 比价",
                "选中未比价商品都缺图,无法以图搜款")
            return

        # 直接弹"选比价方式"(它即作为确认);取消则不跑。数量/跳过信息放状态栏,不再单独弹确认窗。
        mode = ask_compare_mode(self, "商品库批量比价 — 选择比价方式")
        if not mode:
            return
        self._compare_mode = mode
        _tip = f"将对 {len(usable)} 条跑 1688 比价"
        if already:
            _tip += f"(跳过 {already} 条已比价)"
        if need_img:
            _tip += f"(跳过 {len(need_img)} 条缺图)"
        self.pdd_lib_status.setText(_tip + "…")

        # 队列串行处理
        self._pdd_lib_compare_queue = list(usable)
        self._pdd_lib_compare_total = len(usable)
        self._pdd_lib_compare_done = 0
        self._pdd_lib_compare_stop = False
        self.pdd_lib_btn_stop_compare.setEnabled(True)
        self._pdd_library_compare_next()

    def _pdd_browser_args(self) -> list:
        """返回 PDD 子进程的浏览器显隐参数:勾了「显示浏览器(调试)」→ ['--show-browser'],
        否则 [](默认静默,屏幕外跑)。所有 pdd_*.py 操作子进程统一用它。
        状态存共享 flag,待发布页/已发布页两个勾选框都同步它。"""
        return ["--show-browser"] if getattr(self, "_pdd_show_browser_flag", False) else []

    def _pdd_task_center_show_browser_on(self) -> bool:
        return bool(getattr(self, "_pdd_task_show_browser_flag", True))

    def _pdd_set_task_center_show_browser(self, checked: bool):
        """任务中心浏览器显隐总控:同步 PDD 操作、视频、自动推广、店铺监控页。"""
        checked = bool(checked)
        self._pdd_task_show_browser_flag = checked
        self._pdd_syncing_task_show_browser = True
        try:
            self._pdd_on_show_browser_toggled(checked)
        finally:
            self._pdd_syncing_task_show_browser = False
        for name in ("pdd_video_chk_show_browser", "pdd_ap_show_browser", "pdd_zs_show_browser"):
            c = getattr(self, name, None)
            if c is not None and c.isChecked() != checked:
                c.blockSignals(True)
                c.setChecked(checked)
                c.blockSignals(False)
        c = getattr(self, "pdd_task_show_browser", None)
        if c is not None and c.isChecked() != checked:
            c.blockSignals(True)
            c.setChecked(checked)
            c.blockSignals(False)
    def _pdd_make_show_browser_chk(self) -> QCheckBox:
        """造一个「显示浏览器(调试)」勾选框,登记到列表,勾选状态全局同步。
        待发布页/已发布页各放一个,勾任一个两个都跟着变。"""
        if not hasattr(self, "_pdd_show_browser_chks"):
            self._pdd_show_browser_chks = []
            self._pdd_show_browser_flag = True
        chk = QCheckBox("显示浏览器(调试)")
        chk.setToolTip(
            "默认勾选:发布/核查/下架等所有 PDD 操作都会显示浏览器,方便查看执行过程。\n"
            "取消勾选:浏览器在屏幕外静默运行,不挡桌面。\n"
            "(店铺扫码登录不受此影响,始终显示。)")
        chk.setChecked(self._pdd_show_browser_flag)
        chk.toggled.connect(self._pdd_on_show_browser_toggled)
        self._pdd_show_browser_chks.append(chk)
        return chk

    def _pdd_on_show_browser_toggled(self, checked: bool):
        """任一「显示浏览器」勾选框变化 → 更新共享 flag + 同步其它勾选框(防递归)。"""
        self._pdd_show_browser_flag = bool(checked)
        if not getattr(self, "_pdd_syncing_task_show_browser", False):
            self._pdd_task_show_browser_flag = bool(checked)
            c_task = getattr(self, "pdd_task_show_browser", None)
            if c_task is not None and c_task.isChecked() != checked:
                c_task.blockSignals(True)
                c_task.setChecked(checked)
                c_task.blockSignals(False)
        for c in getattr(self, "_pdd_show_browser_chks", []):
            if c.isChecked() != checked:
                c.blockSignals(True)
                c.setChecked(checked)
                c.blockSignals(False)

    def _pdd_close_compare_browser(self):
        """比价队列全部结束后,关掉比价用的 debug Chrome(端口 9222 那个),
        不残留在屏幕外/后台。只关比价专用的独立 profile 进程,不动用户其它 Chrome。
        下次比价 price_compare.py 会自动重新拉起。"""
        try:
            # 按"命令行含 chrome_debug_profile"精准杀,只关比价专用 Chrome,
            # 绝不误杀用户日常 Chrome(它们命令行不含这个 profile 路径)。
            # 用 PowerShell CIM 取进程(wmic 在新版 Windows 已弃用,不依赖它)。
            ps = (
                "Get-CimInstance Win32_Process -Filter \"name='chrome.exe'\" "
                "| Where-Object { $_.CommandLine -like '*chrome_debug_profile*' } "
                "| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
            )
            subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
        except Exception as e:
            print(f"[比价] 关闭比价浏览器失败(不影响结果): {e}")

    def _close_browser_if_plugin(self):
        """单条比价结束后:若本次用的是 1688 插件模式,关掉那个可见的调试 Chrome,
        不残留挡桌面。web/auto 模式的屏幕外浏览器保留复用,不动。"""
        if getattr(self, "_compare_mode", "auto") == "plugin":
            self._pdd_close_compare_browser()

    def _open_wanbang_key_dialog(self):
        """点「🔑 拍立淘 Key」:弹窗设置/更换万邦 Key/Secret。"""
        before = wanbang_has_key()
        ok = ask_wanbang_key(self)
        if ok and wanbang_has_key():
            self.status.showMessage("✅ 拍立淘 Key 已保存(走「万邦」比价时生效)")
        elif before and not wanbang_has_key():
            self.status.showMessage("拍立淘 Key 已清空")

    def _pdd_library_compare_stop(self):
        """立即停止比价队列:杀当前子进程 + 清空队列。"""
        self._pdd_lib_compare_stop = True
        self._pdd_lib_compare_queue = []
        t = getattr(self, "_pdd_lib_compare_thread", None)
        if t is not None:
            try: t.stop()
            except Exception: pass
        self.pdd_lib_btn_stop_compare.setEnabled(False)
        self.pdd_lib_status.setText(
            f"⏹ 已停止比价(已完成 {getattr(self, '_pdd_lib_compare_done', 0)} 条)")
        self._pdd_library_apply_filter()
        self._pdd_close_compare_browser()

    def _pdd_library_compare_next(self):
        """从队列取下一条跑比价。"""
        if getattr(self, "_pdd_lib_compare_stop", False):
            return  # 已停止,不再取新条
        if not self._pdd_lib_compare_queue:
            self.pdd_lib_btn_stop_compare.setEnabled(False)
            self.pdd_lib_status.setText(
                f"✅ 1688 比价完成: {self._pdd_lib_compare_done}/{self._pdd_lib_compare_total}")
            self._pdd_library_apply_filter()
            self._pdd_close_compare_browser()   # 全部跑完 → 关掉比价浏览器,不残留
            QMessageBox.information(self, "1688 比价完成",
                f"共处理 {self._pdd_lib_compare_done} 条")
            return
        prod = self._pdd_lib_compare_queue.pop(0)
        # 图片源:优先本地路径 image_local(走 set_input_files,最稳);其次 URL image
        image_url = prod.get("image") or ""
        image_path = ""
        img_local = prod.get("image_local") or ""
        if img_local and Path(img_local).exists():
            image_path = img_local
        if not image_url and not image_path:
            print(f"[1688比价] 跳过 {prod.get('name','')[:30]} (无图)")
            self._pdd_lib_compare_done += 1
            self._pdd_library_compare_next()
            return
        name = prod.get("name", "")
        self.pdd_lib_status.setText(
            f"🔍 跑 1688 比价 {self._pdd_lib_compare_done + 1}/{self._pdd_lib_compare_total}: {name[:40]}…")

        # 借用 PriceCompareThread:prod_idx 用 -1 占位,result 回调用闭包持有 record
        _show = self.pdd_lib_chk_show_browser.isChecked() if hasattr(self, "pdd_lib_chk_show_browser") else False
        t = PriceCompareThread(-1, image_url, name, image_path=image_path, show_browser=_show,
                               mode=getattr(self, "_compare_mode", "auto"))
        t.done_signal.connect(lambda _idx, result, p=prod: self._pdd_library_compare_done_one(p, result))
        t.error_signal.connect(lambda msg, p=prod: self._pdd_library_compare_done_one(p, {"error": msg}))
        self._pdd_lib_compare_thread = t   # 持有引用防 GC
        t.start()

    def _ensure_image_server_url(self, local_path: str) -> str:
        """把本地图片路径转成 http://127.0.0.1:<port>/<filename> URL。
        首次调用时启动 HTTP server(daemon 线程,GUI 退出自动关);后续复用同一端口。
        服务根目录 = data/pdd/library_images/,只暴露这一个目录的文件。
        """
        if not hasattr(self, "_pdd_image_server_port") or not self._pdd_image_server_port:
            import http.server, socketserver, threading
            img_root = str(Path(r"D:/files/data/pdd/library_images").resolve())

            class ImgHandler(http.server.SimpleHTTPRequestHandler):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, directory=img_root, **kwargs)
                def log_message(self, *a, **k):
                    pass  # 静默

            # 端口 0 让 OS 分配空闲端口
            try:
                httpd = socketserver.TCPServer(("127.0.0.1", 0), ImgHandler)
                port = httpd.server_address[1]
                t = threading.Thread(target=httpd.serve_forever, daemon=True)
                t.start()
                self._pdd_image_server = httpd
                self._pdd_image_server_port = port
                print(f"[image-server] 启动 http://127.0.0.1:{port}/  (root={img_root})")
            except Exception as e:
                print(f"[image-server] 启动失败: {e}")
                return ""

        try:
            filename = Path(local_path).name
            return f"http://127.0.0.1:{self._pdd_image_server_port}/{filename}"
        except Exception:
            return ""

    # ── 商品库:手动比价(单条选择) ────────────────────────────────────────
    def _pdd_library_manual_compare(self):
        """对单条选中商品打开手动比价弹窗。
        - 若已有 candidates → 直接弹窗
        - 否则跑 1688 图搜抓 candidates → 弹窗
        - 用户选中后写回 supplier_link/cost_ref/cost_supplier + auto_note='✋ 手动比价'
        """
        sel = self._pdd_library_get_selected_records()
        if len(sel) != 1:
            QMessageBox.information(self, "手动比价", "请只勾选 1 条商品(手动比价为单条操作)")
            return
        prod = sel[0]
        cands = prod.get("candidates") or []
        if cands:
            # 已有候选,直接弹窗
            self._pdd_library_open_candidate_picker(prod, cands)
            return
        # 无候选 → 跑一次抓
        image_url = prod.get("image") or ""
        image_path = ""
        img_local = prod.get("image_local") or ""
        if img_local and Path(img_local).exists():
            image_path = img_local
        if not image_url and not image_path:
            QMessageBox.warning(self, "手动比价", "该商品缺图(URL 和本地图都没有),无法以图搜款")
            return
        mode = ask_compare_mode(self, "手动比价 — 选择比价方式")
        if not mode:
            return
        self._compare_mode = mode
        self.pdd_lib_status.setText(f"🔍 手动比价:抓取候选 {prod.get('name','')[:30]}…")
        _show = self.pdd_lib_chk_show_browser.isChecked() if hasattr(self, "pdd_lib_chk_show_browser") else False
        t = PriceCompareThread(-1, image_url, prod.get("name", ""), image_path=image_path, show_browser=_show,
                               mode=mode)
        t.done_signal.connect(lambda _idx, result, p=prod: self._pdd_library_manual_compare_fetched(p, result))
        t.error_signal.connect(lambda msg, p=prod: self._pdd_library_manual_compare_fetched(p, {"error": msg}))
        self._pdd_lib_manual_thread = t  # 防 GC
        t.start()

    def _pdd_library_manual_compare_fetched(self, prod: dict, result: dict):
        """抓完候选回调:把 candidates 存到库 + 打开弹窗。"""
        self.pdd_lib_status.setText("")
        self._close_browser_if_plugin()   # 插件模式跑完关掉可见浏览器
        if "error" in result or not result.get("ok"):
            err = result.get("error") or "未抓到候选"
            QMessageBox.warning(self, "手动比价", f"抓取失败:{err}")
            return
        cands = result.get("candidates", []) or []
        # 缓存到库(即使用户不选,下次手动比价直接弹窗)
        self._pdd_lib_records = product_library.update_fields(
            self._pdd_lib_records, prod["id"], {"candidates": cands})
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception:
            pass
        if not cands:
            QMessageBox.information(self, "手动比价", "未抓到任何候选")
            return
        # 取最新 record(含 candidates)再打开弹窗
        prod = product_library.get_by_id(self._pdd_lib_records, prod["id"]) or prod
        self._pdd_library_open_candidate_picker(prod, cands)

    def _pdd_library_open_candidate_picker(self, prod: dict, candidates: list):
        """复用 CandidatePickerDialog 弹窗。用户选中后写回字段。"""
        # 源图:优先 URL,否则本地路径(QPixmap 加载本地直接 work,但 dialog 用 ImageBatchLoader 走 URL;
        # 本地图传 file:/// URL 也可,但为简化:本地图传空字符串,dialog 就不显示源图)
        src_img = prod.get("image") or ""
        if not src_img and prod.get("image_local"):
            # 本地图直接 file:// URL,ImageBatchLoader 用 urllib 能处理 file:///
            src_img = "file:///" + str(prod["image_local"]).replace("\\", "/")
        dlg = CandidatePickerDialog(
            source_name=prod.get("name", ""),
            source_image=src_img,
            candidates=candidates,
            parent=self,
            selected_link=prod.get("supplier_link", ""),
        )
        dlg.exec_()
        # 用户点了「🔄 重新抓取」或「📤 上传新图重抓」:清空候选 + 重跑 1688
        if getattr(dlg, "_refetch_requested", False):
            mode = ask_compare_mode(self, "重新抓取 1688 — 选择比价方式")
            if not mode:
                return
            self._compare_mode = mode
            new_image_path = getattr(dlg, "_refetch_with_image", "") or ""
            self._pdd_lib_records = product_library.update_fields(
                self._pdd_lib_records, prod["id"],
                {"candidates": [], "supplier_link": "", "cost_ref": "", "cost_supplier": "",
                 "cost_top3_str": "", "supplier_cost": 0.0, "auto_note": "重新抓取中…",
                 "is_special": "", "license_no": "", "license_checked": False})
            try:
                product_library.save_library(self._pdd_lib_records)
            except Exception:
                pass
            self._pdd_library_apply_filter()
            fresh = product_library.get_by_id(self._pdd_lib_records, prod["id"])
            if fresh:
                # 优先级:用户上传的新图 > 原 image_local > 原 image URL
                if new_image_path and Path(new_image_path).exists():
                    image_path = new_image_path
                    image_url = ""
                    self.pdd_lib_status.setText(
                        f"🔍 用新图重抓 1688: {Path(new_image_path).name}…")
                else:
                    image_url = fresh.get("image") or ""
                    image_path = ""
                    img_local = fresh.get("image_local") or ""
                    if img_local and Path(img_local).exists():
                        image_path = img_local
                    if not image_url and not image_path:
                        QMessageBox.warning(self, "手动比价", "该商品缺图,无法重新抓取")
                        return
                    self.pdd_lib_status.setText(f"🔍 重新抓取 1688: {fresh.get('name','')[:30]}…")
                _show = self.pdd_lib_chk_show_browser.isChecked() if hasattr(self, "pdd_lib_chk_show_browser") else False
                t = PriceCompareThread(-1, image_url, fresh.get("name", ""), image_path=image_path, show_browser=_show,
                                       mode=getattr(self, "_compare_mode", "auto"))
                t.done_signal.connect(lambda _idx, result, p=fresh: self._pdd_library_manual_compare_fetched(p, result))
                t.error_signal.connect(lambda msg, p=fresh: self._pdd_library_manual_compare_fetched(p, {"error": msg}))
                self._pdd_lib_manual_thread = t
                t.start()
            return
        if not dlg._selected:
            self.pdd_lib_status.setText("手动比价已取消")
            return
        picked = dlg._selected
        # 写回字段
        total = picked.get("total", 0) or 0
        price = picked.get("price", 0) or 0
        shipping = picked.get("shipping", 0) or 0
        patch = {
            "supplier_link": picked.get("link", ""),
            "cost_ref":      f"¥{total} (¥{price}+运{shipping})" if total else "",
            "cost_supplier": picked.get("shopName", ""),
            "cost_top3_str": f"✋ {picked.get('shopName','')} ¥{total}({picked.get('fulfillment',0)}%)",
            "supplier_cost": float(total) if total else 0.0,
            "auto_note":     "✋ 手动比价",
            "last_compared_time": time.strftime("%Y-%m-%d %H:%M:%S"),
            # 换了链接 → 旧批准文号核对作废(A方案),需重新核对
            "is_special": "", "license_no": "", "license_checked": False,
        }
        self._pdd_lib_records = product_library.update_fields(
            self._pdd_lib_records, prod["id"], patch)
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pdd_library_apply_filter()
        self.pdd_lib_status.setText(
            f"✋ 手动比价已确认 — {picked.get('shopName','')}  ¥{total}")

    def _pdd_library_compare_done_one(self, prod: dict, result: dict):
        """单条比价完成回调:写回字段 + 推进队列。"""
        self._pdd_lib_compare_done += 1
        if "error" in result or not result.get("ok"):
            err = result.get("error") or "未抓到候选"
            print(f"[1688比价] {prod.get('name','')[:30]} 失败: {err}")
            # 仍标记 last_compared_time,避免反复重试
            self._pdd_lib_records = product_library.update_fields(
                self._pdd_lib_records, prod["id"],
                {"auto_note": f"比价失败: {err[:50]}", "last_compared_time": time.strftime("%Y-%m-%d %H:%M:%S")})
        else:
            self._pdd_lib_records = product_library.mark_compared(
                self._pdd_lib_records, prod["id"], result)
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            print(f"[1688比价] 保存失败(不阻断队列): {e}")
        # 推进
        self._pdd_library_apply_filter()
        self._pdd_library_compare_next()

    # ════════════════════════════════════════════════════════════════════════
    #  🚀 一键跑品(编排器):比价 → 货品核对闸门 → 批准文号 → 自动发布
    #  安全闸门:货品核对「不一致/不确定」、批准文号抓不到 → 拦下不发,留商品库标原因。
    #  出错(比价/发布失败)→ 跳过记原因继续。全部跑完弹汇总。
    # ════════════════════════════════════════════════════════════════════════
    def _pdd_oneclick_start(self, records=None):
        """点【🚀 一键跑品】:弹窗选店铺+定价规则,确认后逐条全自动跑。
        records=None → 从商品库勾选取(商品库按钮);
        records=[...] → 跑外部传入的这批商品库记录(选品区一键跑品先同步进库再传入)。"""
        # 多店顺序队列:在跑也不拒绝 —— 收集好这单设置后入队,前面跑完自动开跑(入队逻辑见本函数末尾)
        sel = records if records is not None else self._pdd_library_get_selected_records()
        if not sel:
            QMessageBox.information(self, "一键跑品", "请先勾选要跑的商品")
            return

        def _has_image(r):
            il = r.get("image_local", "")
            return bool(r.get("image")) or (il and Path(il).exists())
        usable = [r for r in sel if _has_image(r)]
        no_img = len(sel) - len(usable)
        if not usable:
            QMessageBox.warning(self, "一键跑品", "选中商品都缺图(URL/本地),无法以图搜款比价。")
            return

        # 选店铺 + 选规则(沿用提交到待发布的弹窗式样)
        rules = pricing_rules.load_rules()
        stores = [s for s in self._pdd_get_store_list() if s and "无已登录" not in s]
        if not stores:
            QMessageBox.warning(self, "一键跑品", "未找到已登录店铺,请先在「🏪 店铺管理」添加")
            return
        if not rules:
            QMessageBox.warning(self, "一键跑品", "未找到定价规则,请先在「💎 定价规则」添加")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle("🚀 一键跑品 — 开跑设置")
        dlg.resize(640, 520)
        dl = QVBoxLayout(dlg)
        info = QLabel(
            f"将对 <b>{len(usable)}</b> 条商品按下面勾选的步骤跑。<br>"
            f"<span style='color:#DC2626'>勾了货品核对时,不一致/不确定的会被拦下不发,留商品库待人工。</span>"
            + (f"<br><span style='color:#DC2626'>跳过 {no_img} 条缺图</span>" if no_img else ""))
        info.setTextFormat(Qt.RichText)
        info.setWordWrap(True)
        dl.addWidget(info)
        form = QFormLayout()
        default_idx = 0
        for i, r in enumerate(rules):
            if r.get("is_default"):
                default_idx = i

        tbl_stores = QTableWidget(len(stores), 4)
        tbl_stores.setHorizontalHeaderLabels(["全选/反选", "店铺", "定价规则", "每品发几条"])
        tbl_stores.verticalHeader().setVisible(False)
        tbl_stores.verticalHeader().setDefaultSectionSize(34)
        tbl_stores.setSelectionMode(QAbstractItemView.NoSelection)
        tbl_stores.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl_stores.setAlternatingRowColors(True)
        tbl_stores.setFixedHeight(min(244, 38 + len(stores) * 34))
        tbl_stores.setStyleSheet(
            "QTableWidget{gridline-color:#E5E7EB;alternate-background-color:#F9FAFB;}"
            "QHeaderView::section{background:#4F46C8;color:white;border:none;padding:6px 8px;font-weight:bold;}"
            "QComboBox,QSpinBox{min-height:26px;border:1px solid #CBD5E1;border-radius:4px;padding:0 6px;background:white;}"
            "QSpinBox{padding-right:16px;}")
        hdr = tbl_stores.horizontalHeader()
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(0, QHeaderView.Fixed)
        hdr.setSectionResizeMode(1, QHeaderView.Fixed)
        hdr.setSectionResizeMode(2, QHeaderView.Stretch)
        hdr.setSectionResizeMode(3, QHeaderView.Fixed)
        tbl_stores.setColumnWidth(0, 44)
        tbl_stores.setColumnWidth(1, 190)
        tbl_stores.setColumnWidth(3, 92)
        store_search = QLineEdit()
        store_search.setPlaceholderText("搜索店铺名，过滤后再勾选…")
        store_search.setFixedHeight(28)
        store_search.setStyleSheet(
            "QLineEdit{border:1px solid #CBD5E1;border-radius:4px;padding:0 8px;background:white;}"
            "QLineEdit:focus{border-color:#4F46C8;}")

        bulk_bar = QWidget()
        bulk_lay = QHBoxLayout(bulk_bar)
        bulk_lay.setContentsMargins(0, 0, 0, 0)
        bulk_lay.setSpacing(6)
        bulk_lay.addWidget(QLabel("批量规则:"))
        bulk_rule = QComboBox()
        bulk_rule.setMinimumWidth(210)
        for r in rules:
            mark = " ★" if r.get("is_default") else ""
            bulk_rule.addItem(f"{r.get('name','(未命名)')}{mark}", r)
        bulk_lay.addWidget(bulk_rule, 1)
        bulk_rule_checked = QPushButton("规则→已勾选")
        bulk_rule_checked.setFixedHeight(28)
        bulk_rule_visible = QPushButton("规则→可见")
        bulk_rule_visible.setFixedHeight(28)
        bulk_lay.addWidget(bulk_rule_checked)
        bulk_lay.addWidget(bulk_rule_visible)
        bulk_lay.addSpacing(8)
        bulk_lay.addWidget(QLabel("批量条数:"))
        bulk_copies = QSpinBox()
        bulk_copies.setRange(1, 20)
        bulk_copies.setAlignment(Qt.AlignCenter)
        bulk_copies.setFixedWidth(66)
        bulk_lay.addWidget(bulk_copies)
        bulk_copies_checked = QPushButton("条数→已勾选")
        bulk_copies_checked.setFixedHeight(28)
        bulk_copies_visible = QPushButton("条数→可见")
        bulk_copies_visible.setFixedHeight(28)
        bulk_lay.addWidget(bulk_copies_checked)
        bulk_lay.addWidget(bulk_copies_visible)

        store_rows = []
        for row, store_name in enumerate(stores):
            cb_on = QCheckBox()
            cb_on.setChecked(row == 0)
            w_on = QWidget(); l_on = QHBoxLayout(w_on); l_on.setContentsMargins(0, 0, 0, 0)
            l_on.addStretch(1); l_on.addWidget(cb_on); l_on.addStretch(1)
            tbl_stores.setCellWidget(row, 0, w_on)
            store_item = QTableWidgetItem(store_name)
            store_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            tbl_stores.setItem(row, 1, store_item)
            cb_rule_row = QComboBox()
            cb_rule_row.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            cb_rule_row.setMinimumContentsLength(18)
            for r in rules:
                mark = " ★" if r.get("is_default") else ""
                cb_rule_row.addItem(f"{r.get('name','(未命名)')}{mark}", r)
            cb_rule_row.setCurrentIndex(self._pricing_rule_index_for_store(rules, store_name))
            tbl_stores.setCellWidget(row, 2, cb_rule_row)
            sp_copy_row = QSpinBox()
            sp_copy_row.setRange(1, 20)
            sp_copy_row.setAlignment(Qt.AlignCenter)
            sp_copy_row.setMinimumWidth(72)
            sp_copy_row.setValue(1)
            sp_copy_row.setToolTip("同一商品发多条时,自动错开主图(轮播图第2/3…张拖成主图),避免被 PDD 判重复铺货。\n1 = 每个商品只发 1 条。")
            tbl_stores.setCellWidget(row, 3, sp_copy_row)
            store_rows.append({"store": store_name, "check": cb_on, "rule": cb_rule_row, "copies": sp_copy_row})
        def _visible_store_rows():
            return [(i, r) for i, r in enumerate(store_rows) if not tbl_stores.isRowHidden(i)]

        def _apply_store_search(text=""):
            q = (text or "").strip().lower()
            for i, row in enumerate(store_rows):
                tbl_stores.setRowHidden(i, bool(q) and q not in row["store"].lower())
            _refresh_plan_summary()

        def _toggle_visible_store_checks(section):
            if section != 0:
                return
            visible = _visible_store_rows()
            if not visible:
                return
            all_checked = all(r["check"].isChecked() for _, r in visible)
            for _, r in visible:
                r["check"].setChecked(not all_checked)
            _refresh_plan_summary()

        def _checked_visible_store_rows():
            return [(i, r) for i, r in _visible_store_rows() if r["check"].isChecked()]

        def _apply_bulk_rule_to_rows(rows):
            rule = bulk_rule.currentData()
            if not isinstance(rule, dict):
                return
            for _, r in rows:
                idx = r["rule"].findData(rule)
                if idx >= 0:
                    r["rule"].setCurrentIndex(idx)

        def _apply_bulk_copies_to_rows(rows):
            copies = bulk_copies.value()
            for _, r in rows:
                r["copies"].setValue(copies)
            _refresh_plan_summary()

        tbl_stores.horizontalHeader().sectionClicked.connect(_toggle_visible_store_checks)
        bulk_rule_checked.clicked.connect(lambda: _apply_bulk_rule_to_rows(_checked_visible_store_rows()))
        bulk_rule_visible.clicked.connect(lambda: _apply_bulk_rule_to_rows(_visible_store_rows()))
        bulk_copies_checked.clicked.connect(lambda: _apply_bulk_copies_to_rows(_checked_visible_store_rows()))
        bulk_copies_visible.clicked.connect(lambda: _apply_bulk_copies_to_rows(_visible_store_rows()))

        dl.addWidget(QLabel("发布店铺 / 定价规则:"))
        dl.addWidget(store_search)
        dl.addWidget(bulk_bar)
        dl.addWidget(tbl_stores)
        store_search.textChanged.connect(_apply_store_search)

        cb_dist = QComboBox()
        cb_dist.addItem("按顺序均匀分配商品", "split")
        cb_dist.addItem("每个店都跑同一批商品", "repeat")
        cb_dist.setToolTip("均匀分配:第1个商品给第1个店、第2个给第2个店,轮流发牌。\n每店同批:每个勾选店铺都跑完整这批商品。")
        form.addRow("多店跑法：", cb_dist)
        cb_pub_img = QComboBox()
        cb_pub_img.addItem("货品图(1688货源图，默认)", "source")
        cb_pub_img.addItem("选品图(快手/商品库图)", "xuanpin")
        cb_pub_img.setCurrentIndex(0 if self._pdd_publish_use_source() else 1)
        cb_pub_img.setToolTip("选择本次一键跑品发布时用于 PDD 搜同款建链接的图片。货品图取比价选中的 1688 图;取不到时仍会自动回退选品图。")
        form.addRow("发布用图：", cb_pub_img)
        dl.addLayout(form)

        summary = QLabel()
        summary.setWordWrap(True)
        summary.setStyleSheet("color:#4B5563;font-size:12px;")
        dl.addWidget(summary)

        def _selected_store_rows():
            return [r for r in store_rows if r["check"].isChecked()]

        def _plan_counts(selected, mode_key):
            counts = []
            for i, r in enumerate(selected):
                product_count = len(usable) if mode_key == "repeat" else len(usable[i::len(selected)])
                copies = r["copies"].value()
                counts.append((r["store"], product_count, copies, product_count * copies))
            return counts

        def _refresh_plan_summary():
            selected = _selected_store_rows()
            if not selected:
                cb_dist.setEnabled(False)
                summary.setText("<span style='color:#DC2626'>请至少勾选 1 个店铺。</span>")
                return
            cb_dist.setEnabled(len(selected) > 1)
            mode_key = cb_dist.currentData()
            counts = _plan_counts(selected, mode_key)
            total_tasks = sum(product_count for _, product_count, _, _ in counts)
            total_publish = sum(publish_count for _, _, _, publish_count in counts)
            if len(selected) == 1:
                mode_text = "单店模式"
            else:
                mode_text = "每店都跑同一批" if mode_key == "repeat" else "按顺序均匀分配"
            parts = []
            for store, product_count, copies, publish_count in counts:
                if product_count:
                    parts.append(f"{store}:{product_count}个商品×{copies}条={publish_count}条")
            summary.setText(f"本次计划:{len(usable)} 个商品 · {len(selected)} 个店 · {mode_text} · "
                            f"共 {total_tasks} 个商品任务，预计发布 {total_publish} 条。 " + "；".join(parts))
        for r in store_rows:
            r["check"].toggled.connect(lambda _v: _refresh_plan_summary())
            r["copies"].valueChanged.connect(lambda _v: _refresh_plan_summary())
        cb_dist.currentIndexChanged.connect(lambda _i: _refresh_plan_summary())
        _refresh_plan_summary()
        # ── 跑哪几步(记住上次勾选)──
        #    ①比价 ②核对 ③发布 可单独勾;没勾③发布则④⑤自动变灰;⑥开车占位(阶段3开放)。
        _steps0 = self._oc_load_steps()
        dl.addWidget(QLabel("跑哪几步:"))
        oc_cb_compare = QCheckBox("① 比价(1688找货算成本)"); oc_cb_compare.setChecked(_steps0["compare"])
        oc_cb_check   = QCheckBox("② 货品核对(拦下发错的)"); oc_cb_check.setChecked(_steps0["check"])
        oc_cb_publish = QCheckBox("③ 发布上架"); oc_cb_publish.setChecked(_steps0["publish"])
        oc_cb_mainimg = QCheckBox("④ 发布后换主图"); oc_cb_mainimg.setChecked(_steps0["main_img"])
        oc_cb_video   = QCheckBox("⑤ 发布后补视频"); oc_cb_video.setChecked(_steps0["video"])
        oc_cb_promote = QCheckBox("⑥ 自动推广开车"); oc_cb_promote.setChecked(_steps0["promote"])
        oc_cb_compare.setToolTip("不勾=用商品库里已有的比价数据,不重新比价")
        oc_cb_check.setToolTip("不勾=不做图像核对、不拦截(风险自负)")
        oc_cb_publish.setToolTip("不勾=只比价/核对,不发布(把货备在商品库)")
        oc_cb_promote.setToolTip("发布成功后给新品自动开车:弹一次确认 → 真开(真花钱);老链接锁投产/亏本自动跳过")
        # 依赖:没勾③发布 → ④⑤⑥ 无意义 → 变灰并取消
        def _oc_sync_dep():
            on = oc_cb_publish.isChecked()
            cb_pub_img.setEnabled(on)
            for _c in (oc_cb_mainimg, oc_cb_video, oc_cb_promote):
                if not on:
                    _c.setChecked(False)
                _c.setEnabled(on)
        oc_cb_publish.toggled.connect(lambda _v: _oc_sync_dep())
        _oc_sync_dep()
        for _c in (oc_cb_compare, oc_cb_check, oc_cb_publish, oc_cb_mainimg, oc_cb_video, oc_cb_promote):
            _c.setStyleSheet("font-size:12px;")
            dl.addWidget(_c)
        # 浏览器显隐:一键跑品默认【全程显示】,可取消=屏幕外静默跑
        oc_cb_browser = QCheckBox("显示浏览器(全程盯着看;取消=屏幕外静默跑)")
        oc_cb_browser.setChecked(True)
        oc_cb_browser.setStyleSheet("font-size:12px;color:#4F46C8;")
        dl.addWidget(oc_cb_browser)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("🚀 开始")
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        dl.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return
        selected_rows = _selected_store_rows()
        if not selected_rows:
            QMessageBox.information(self, "一键跑品", "请至少勾选 1 个发布店铺")
            return
        # 本次步骤配置(开车占位关)+ 记住;④⑤需③发布开才生效
        _pub = oc_cb_publish.isChecked()
        steps = {"compare": oc_cb_compare.isChecked(), "check": oc_cb_check.isChecked(),
                 "publish": _pub,
                 "main_img": oc_cb_mainimg.isChecked() and _pub,
                 "video": oc_cb_video.isChecked() and _pub,
                 "promote": oc_cb_promote.isChecked() and _pub}
        if not steps["compare"] and not steps["publish"]:
            QMessageBox.information(self, "一键跑品", "至少要勾「比价」或「发布」其中一个,否则没什么可跑的。")
            return
        publish_image_source = cb_pub_img.currentData() or "source"
        publish_image_label = "货品图" if publish_image_source == "source" else "选品图"
        self._oc_save_steps(steps)          # 记住勾选,作下次默认
        dist_mode = cb_dist.currentData()
        counts = _plan_counts(selected_rows, dist_mode)
        total_tasks = sum(product_count for _, product_count, _, _ in counts)
        total_publish = sum(publish_count for _, _, _, publish_count in counts)
        plan_lines = [
            f"本次将处理 {len(usable)} 个商品,勾选 {len(selected_rows)} 个店铺。",
            f"跑法:{'单店模式' if len(selected_rows) == 1 else ('每个店都跑同一批商品' if dist_mode == 'repeat' else '按顺序均匀分配商品')}",
            f"商品任务合计:{total_tasks} 个，预计发布:{total_publish} 条。",
            f"发布用图:{publish_image_label}。",
        ]
        if len(selected_rows) > 1 and dist_mode == "repeat" and steps["compare"]:
            plan_lines.append("同批多店:只在第一个店执行比价,后续店复用商品库比价结果。")
        plan_lines.append("")
        plan_lines += [f"  • {s}: {product_count} 个商品 × 每品 {copies} 条 = 发布 {publish_count} 条"
                       for s, product_count, copies, publish_count in counts if product_count]
        if QMessageBox.question(self, "确认一键跑品计划", "\n".join(plan_lines),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 比价方式:多店一次性设置时只弹一次,所有店复用同一方式。
        mode = None
        if steps["compare"]:
            mode = ask_compare_mode(self, "一键跑品 — 选择比价方式")
            if not mode:
                return
        showb = oc_cb_browser.isChecked()

        # ── 生成 job:每个勾选店铺一单,按表格顺序排队跑 ──
        if not hasattr(self, "_oc_job_queue"):
            self._oc_job_queue = []
        added_jobs = 0
        for i, row in enumerate(selected_rows):
            rule = row["rule"].currentData()
            if not isinstance(rule, dict):
                QMessageBox.warning(self, "一键跑品", f"店铺「{row['store']}」未选定价规则")
                return
            recs = list(usable) if dist_mode == "repeat" else list(usable[i::len(selected_rows)])
            if not recs:
                continue
            job_steps = dict(steps)
            # 同一批商品跑多店时,第一店完成比价后会写回商品库;后续店直接复用,避免重复图搜。
            if dist_mode == "repeat" and i > 0:
                job_steps["compare"] = False
            self._oc_job_queue.append({
                "store": row["store"], "rule": rule, "copies": row["copies"].value(), "steps": job_steps,
                "publish_image_source": publish_image_source,
                "mode": mode if job_steps.get("compare") else None, "show_browser": showb, "records": recs})
            added_jobs += 1
        if not added_jobs:
            QMessageBox.information(self, "一键跑品", "本次分配后没有可跑商品")
            return
        self._oc_batch_target = 0
        self._oc_batch_mode = None
        self._oc_queue_ensure_timer()
        if added_jobs > 1:
            self.pdd_lib_status.setText(f"🚀 已加入 {added_jobs} 个店铺跑品队列,将按表格顺序依次跑…")
        elif getattr(self, "_oc_running", False) or not self._oc_system_idle():
            j = self._oc_job_queue[-1]
            self.pdd_lib_status.setText(
                f"🚀 已加入跑品队列:店铺「{j['store']}」{len(j['records'])} 个商品，预计发布 {len(j['records']) * j.get('copies', 1)} 条(前面跑完自动开跑)")
        else:
            j = self._oc_job_queue[-1]
            self.pdd_lib_status.setText(
                f"🚀 已加入跑品队列:店铺「{j['store']}」{len(j['records'])} 个商品，预计发布 {len(j['records']) * j.get('copies', 1)} 条,即将开跑…")
    def _pdd_oneclick_stop(self):
        """停止一键跑品:清空多店队列 + 停队列轮询 + 置停止标志 + 杀当前比价子进程 + 主动收尾。
        注意:PriceCompareThread 被 stop() 后不发任何信号(见其 run),所以这里必须
        主动调 _oc_finish 收尾,否则流程会挂住。已过闸提交到待发布的不受影响。"""
        # 先清空待跑队列 + 批量设置目标 + 停轮询(无论当前是否在跑都清,免得停了又自动开下一单)
        self._oc_job_queue = []
        self._oc_batch_target = 0
        self._oc_batch_mode = None
        self._oc_idle_streak = 0
        if hasattr(self, "_oc_queue_timer"):
            self._oc_queue_timer.stop()
        if not getattr(self, "_oc_running", False):
            self.pdd_lib_status.setText("⏹ 已清空跑品队列")
            if hasattr(self, "pdd_lib_btn_oneclick_stop"):
                self.pdd_lib_btn_oneclick_stop.setEnabled(False)
            return
        self._oc_stop = True
        self._oc_queue = []   # 清空当前单剩余商品
        t = getattr(self, "_oc_thread", None)
        if t is not None:
            try:
                t.stop()      # 杀比价子进程(PriceCompareThread.stop,之后不发信号)
            except Exception:
                pass
        if hasattr(self, "pdd_lib_btn_oneclick_stop"):
            self.pdd_lib_btn_oneclick_stop.setEnabled(False)
        self.pdd_lib_status.setText("⏹ 已停止一键跑品(含队列)")
        # 主动收尾(比价线程被杀后不会回调,需手动进 finish)
        self._oc_finish(stopped=True)

    # ── 多店顺序队列:空闲门 + 去抖 + 逐单启动 ────────────────────────────────
    def _oc_launch_job(self, job: dict):
        """按 job 设置启动一单一键跑品(从队列取出后调用)。各单顺序跑,互不抢全局状态。"""
        steps = job["steps"]; rule = job["rule"]
        self._oc_steps = steps
        self._oc_publish_image_source = job.get("publish_image_source", "source")
        self._auto_full = steps["main_img"] or steps["video"]   # 触发发布后链路的总开关
        # 浏览器显隐:同步全局开关(比价/发布/换图/视频子进程)+ 开车那边的开关
        _showb = job.get("show_browser", True)
        try:
            self._pdd_on_show_browser_toggled(_showb)
        except Exception:
            self._pdd_show_browser_flag = _showb
        if hasattr(self, "pdd_ap_show_browser"):
            try:
                self.pdd_ap_show_browser.setChecked(_showb)
            except Exception:
                pass
        if job.get("mode"):
            self._compare_mode = job["mode"]
        usable = job["records"]
        # 初始化本单调度状态
        self._oc_running = True
        self._oc_stop = False
        self._oc_store = job["store"]
        self._oc_rule = rule
        self._oc_copies = job["copies"]
        self._oc_queue = list(usable)
        self._oc_total = len(usable)
        self._oc_done = 0
        self._oc_passed = []
        self._oc_published = []
        self._oc_blocked = []
        self._oc_failed = []
        self._oc_summary_extra = ""
        if hasattr(self, "pdd_lib_btn_oneclick_stop"):
            self.pdd_lib_btn_oneclick_stop.setEnabled(True)
        _left = len(getattr(self, "_oc_job_queue", []))
        self.pdd_lib_status.setText(
            f"🚀 一键跑品开始:{self._oc_total} 条 → 店铺「{job['store']}」规则「{rule.get('name','')}」"
            + (f"(队列还剩 {_left} 个)" if _left else ""))
        self._oc_next()

    def _oc_system_idle(self) -> bool:
        """整条跑品链(比价→核对→发布→换图→视频→开车)是否彻底空闲——用于队列放行下一单。
        任一阶段在跑(含别的浏览器任务)都算忙,避免抢同一 profile / 全局状态串台。"""
        if getattr(self, "_oc_running", False):          # 比价/核对阶段
            return False
        if getattr(self, "_pdd_qrun_active", False):     # 待发布队列在发
            return False
        if getattr(self, "_auto_in_video_chain", False): # 换图/视频链
            return False
        if getattr(self, "_oc_promote_pending", None):   # 待开车(发布汇总后、开车启动前的过渡)
            return False
        busy, _ = self._pdd_browser_busy()               # 比价/视频/开车/发布等任何浏览器子进程/线程
        return not busy

    def _oc_queue_ensure_timer(self):
        """确保多店队列轮询定时器在跑(1.5s 一次;队列空且空闲时自停)。"""
        if not hasattr(self, "_oc_queue_timer"):
            self._oc_queue_timer = QTimer(self)
            self._oc_queue_timer.timeout.connect(self._oc_queue_tick)
        if not self._oc_queue_timer.isActive():
            self._oc_idle_streak = 0
            self._oc_queue_timer.start(1500)

    def _oc_queue_tick(self):
        """轮询:队列里有待跑单 + 系统【连续两次】空闲(去抖,躲阶段切换的毫秒空隙)→ 取下一单开跑。"""
        q = getattr(self, "_oc_job_queue", None)
        if not q:
            self._oc_idle_streak = 0
            if hasattr(self, "_oc_queue_timer"):
                self._oc_queue_timer.stop()
            return
        if self._oc_system_idle():
            self._oc_idle_streak = getattr(self, "_oc_idle_streak", 0) + 1
        else:
            self._oc_idle_streak = 0
        if self._oc_idle_streak >= 2:
            self._oc_idle_streak = 0
            job = self._oc_job_queue.pop(0)
            self._oc_launch_job(job)

    def _oc_next(self):
        """取下一条:先比价。比价完成回调里走货品核对闸门。"""
        if self._oc_stop:
            self._oc_finish(stopped=True)
            return
        if not self._oc_queue:
            self._oc_finish()
            return
        prod = self._oc_queue.pop(0)
        self._oc_cur = prod
        n = self._oc_done + 1
        name = prod.get("name", "")
        # 没勾①比价 → 用商品库已有比价数据直接走闸门(不重新比价)
        if not self._oc_step("compare"):
            self.pdd_lib_status.setText(f"🚀 一键跑品 [{n}/{self._oc_total}] 用已有比价数据:{name[:34]}…")
            self._oc_use_existing(prod)
            return
        self.pdd_lib_status.setText(f"🚀 一键跑品 [{n}/{self._oc_total}] 比价中:{name[:34]}…")
        # 图片源
        image_url = prod.get("image") or ""
        image_path = ""
        img_local = prod.get("image_local") or ""
        if img_local and Path(img_local).exists():
            image_path = img_local
        _show = getattr(self, "_pdd_show_browser_flag", False)
        t = PriceCompareThread(-1, image_url, name, image_path=image_path, show_browser=_show,
                               mode=getattr(self, "_compare_mode", "auto"))
        t.done_signal.connect(lambda _idx, result, p=prod: self._oc_after_compare(p, result))
        t.error_signal.connect(lambda msg, p=prod: self._oc_after_compare(p, {"error": msg}))
        self._oc_thread = t   # 持有防 GC
        t.start()

    def _oc_after_compare(self, prod: dict, result: dict):
        """比价完成 → 写回商品库 → 货品核对闸门:
        一致 → 过闸进发布阶段;不一致/不确定/缺供应商 → 拦下,留商品库标原因。"""
        # 已停止/已收尾 → 忽略迟到的回调,防重复收尾
        if not getattr(self, "_oc_running", False) or getattr(self, "_oc_stop", False):
            return
        self._oc_done += 1
        name = prod.get("name", "")
        # 比价本身失败 → 出错跳过
        if "error" in result or not result.get("ok"):
            err = result.get("error") or "未抓到候选"
            # 把比价的黑话错误翻成大白话 + 怎么办,免得客户看不懂失败原因
            el = err.lower()
            if ("验证" in err) or any(k in el for k in ("punish", "verify", "captcha", "blocked", "login", "passport")):
                friendly = ("比价失败:1688图搜被风控验证拦截 → 改用「万邦API」比价方式,"
                            "或比价时勾「显示浏览器」手动过验证码;或本批先不勾「①比价」用商品库已有数据")
            elif "未加载" in err:
                friendly = "比价失败:1688图搜页没加载出来(网络慢/被风控)→ 重试,或改用「万邦API」比价"
            elif ("未抓到候选" in err) or ("候选" in err):
                friendly = "比价失败:图搜没找到相似货源(图片不清晰或确无同款)"
            else:
                friendly = f"比价失败: {err[:60]}"
            self._oc_failed.append((name, friendly))
            self._pdd_lib_records = product_library.update_fields(
                self._pdd_lib_records, prod["id"],
                {"auto_note": friendly[:90], "last_compared_time": time.strftime("%Y-%m-%d %H:%M:%S")})
            self._oc_save_and_next()
            return
        # 比价成功 → 落库
        self._pdd_lib_records = product_library.mark_compared(
            self._pdd_lib_records, prod["id"], result)
        # 取最新记录(含写回的 supplier_link / same_style)
        fresh = product_library.get_by_id(self._pdd_lib_records, prod["id"]) or prod

        verdict = (result.get("same_style", "") or "").strip()
        # ── 货品核对闸门(没勾②核对则不拦,直接放行)──
        if self._oc_step("check") and verdict != "一致":
            why = {"不一致": "🚨 货品核对不一致", "不确定": "❓ 货品核对不确定/低置信"}.get(
                verdict, f"货品核对未通过({verdict or '无结论'})")
            self._oc_blocked.append((name, why + ",留商品库待人工"))
            self._oc_save_and_next()
            return
        # 一致但没拿到供应商链接(理论上少见)→ 也拦
        if not (fresh.get("supplier_link") or "").strip():
            self._oc_blocked.append((name, "比价一致但无供应商链接,留商品库待人工"))
            self._oc_save_and_next()
            return
        # ✅ 过闸 → 进发布阶段
        self._oc_to_publish(fresh)

    def _oc_use_existing(self, prod: dict):
        """没勾①比价时:用商品库里已有的比价数据走闸门/发布,不重新比价。"""
        if not getattr(self, "_oc_running", False) or getattr(self, "_oc_stop", False):
            return
        self._oc_done += 1
        name = prod.get("name", "")
        fresh = product_library.get_by_id(self._pdd_lib_records, prod["id"]) or prod
        verdict = (fresh.get("same_style", "") or "").strip()
        # 没勾②核对则不拦;勾了核对但库里结论不是"一致" → 拦下
        if self._oc_step("check") and verdict != "一致":
            why = {"不一致": "🚨 货品核对不一致", "不确定": "❓ 货品核对不确定/低置信"}.get(
                verdict, f"货品核对未通过({verdict or '未核对'})")
            self._oc_blocked.append((name, why + ",留商品库待人工"))
            self._oc_save_and_next()
            return
        # 没有比价数据(无供应商链接)→ 发不了,拦下
        if not (fresh.get("supplier_link") or "").strip():
            self._oc_blocked.append((name, "跳过比价,但商品库无比价数据(无供应商链接),发不了,留待人工"))
            self._oc_save_and_next()
            return
        self._oc_to_publish(fresh)

    def _oc_save_and_next(self):
        """保存商品库 + 刷新 + 推进下一条。"""
        try:
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            print(f"[一键跑品] 保存失败(不阻断): {e}")
        self._pdd_library_apply_filter()
        self._oc_next()

    def _oc_to_publish(self, prod: dict):
        """过闸商品 → 攒进 _oc_passed(全部比价完后统一提交到待发布并自动开跑)。
        批准文号不在此拦(按用户决定):发布脚本 pdd_publish 内部自己抓,抓不到也照发。"""
        self._oc_passed.append(prod)
        self._oc_save_and_next()

    def _oc_finish(self, stopped: bool = False):
        """全部比价+闸门跑完(或被停)→ 把过闸商品提交待发布并自动开跑 → 弹汇总,复位状态。"""
        self._oc_running = False
        if hasattr(self, "pdd_lib_btn_oneclick"):
            self.pdd_lib_btn_oneclick.setEnabled(True)
        if hasattr(self, "pdd_lib_btn_oneclick_stop"):
            # 队列还有待跑单 → 停止按钮保持可用(可随时清队列);否则关掉
            self.pdd_lib_btn_oneclick_stop.setEnabled(bool(getattr(self, "_oc_job_queue", None)))
        # 比价阶段结束 → 关掉比价 debug Chrome(避免和后续发布浏览器堆叠/残留)
        try:
            self._pdd_close_compare_browser()
        except Exception as e:
            print(f"[一键跑品] 关闭比价浏览器失败(不影响发布): {e}")

        # ── 过闸商品 → 提交待发布 + 自动开跑发布(复用成熟的待发布队列)──
        submitted = 0
        if self._oc_passed and self._oc_step("publish"):
            try:
                new_pendings = [
                    pending_publish.build_from_library(r, store=self._oc_store, pricing_rule=self._oc_rule)
                    for r in self._oc_passed]
                existing = pending_publish.load_pending()
                new_list, submitted, _skip = pending_publish.bulk_submit(
                    existing, new_pendings, dedupe=True, dedupe_scope="prod_store")
                pending_publish.save_pending(new_list)
                # 标记商品库已提交
                ids = [r["id"] for r in self._oc_passed]
                self._pdd_lib_records = product_library.mark_submitted(self._pdd_lib_records, ids, True)
                product_library.save_library(self._pdd_lib_records)
                self._pdd_library_apply_filter()
            except Exception as e:
                QMessageBox.critical(self, "一键跑品", f"过闸商品提交待发布失败:\n{e}")
                submitted = 0

        # 勾了⑥开车 且 有成功提交发布 → 记一次性标记,等本批发布完(链尾)再预演+确认开车
        if self._oc_step("promote") and submitted:
            self._oc_promote_after_publish = True
            self._oc_promote_store = self._oc_store
        else:
            self._oc_promote_after_publish = False

        # 一键跑品的「比价阶段」结果(拦下/出错)暂存,挂到发布批量汇总里一起显示,
        # 避免比价完先弹一个阻塞框(不点 OK 就不往下发布)。
        oc_lines = [f"🚫 货品核对拦下 {len(self._oc_blocked)} · ❌ 比价出错 {len(self._oc_failed)}"]
        if self._oc_blocked:
            oc_lines.append("【拦下(留商品库待人工)】")
            oc_lines += [f"  • {n} — {why}" for n, why in self._oc_blocked[:20]]
        if self._oc_failed:
            oc_lines.append("【比价出错跳过】")
            oc_lines += [f"  • {n} — {why}" for n, why in self._oc_failed[:20]]
        self._oc_summary_extra = "\n".join(oc_lines)

        self.pdd_lib_status.setText(
            f"🚀 一键跑品:过闸 {submitted} · 拦下 {len(self._oc_blocked)} · 出错 {len(self._oc_failed)}")

        if submitted:
            # 有过闸商品 → 切到待发布页并自动开跑发布(不弹阻塞框);
            # 发布全部跑完后由 _pdd_show_batch_summary 一次性弹总汇总(含上面拦下/出错)。
            try:
                self._pdd_pending_records = pending_publish.load_pending()
                self._pdd_pending_apply_filter()
                if hasattr(self, "pdd_stack"):
                    self.pdd_stack.setCurrentIndex(1)
                if hasattr(self, "pdd_nav") and self.pdd_nav.count() > 1:
                    self.pdd_nav.setCurrentRow(1)
                _copies = getattr(self, "_oc_copies", 1)
                QTimer.singleShot(500, lambda c=_copies: self._pdd_pending_start_queue(preset_copies=c))
            except Exception as e:
                print(f"[一键跑品] 自动开跑发布失败(可手动到待发布页开始队列): {e}")
        else:
            # 没提交发布(只比价/核对 或 无可发布)→ 结果。
            # ★多店队列:后面还有店要跑时【不弹阻塞框】(否则卡住要手点OK才下一个店),
            #   状态栏提示并自动继续;结果累积,等最后一单(队列空)才弹一次合并汇总。
            if not stopped and not self._oc_step("publish") and self._oc_passed:
                line = f"店铺「{self._oc_store}」过闸 {len(self._oc_passed)} 条留库(只比价/核对,未发布)"
            elif stopped:
                line = f"⏹ 店铺「{self._oc_store}」已停止(已处理 {self._oc_done}/{self._oc_total})"
            else:
                line = f"店铺「{self._oc_store}」完成(无可发布商品,已处理 {self._oc_done}/{self._oc_total})"
            if not hasattr(self, "_oc_multi_results"):
                self._oc_multi_results = []
            _block = (f"{line}\n{self._oc_summary_extra}" if self._oc_summary_extra else line)
            self._oc_multi_results.append(_block)
            self._oc_summary_extra = ""
            if getattr(self, "_oc_job_queue", None):
                # 后面还有店 → 不弹框,状态栏提示,空闲门会自动开下一个店
                self.pdd_lib_status.setText(f"✅ {line};继续下一个店铺…(队列还剩 {len(self._oc_job_queue)} 个)")
            else:
                # 最后一单(或单店) → 弹一次合并汇总,然后清空
                results = self._oc_multi_results
                self._oc_multi_results = []
                head = "一键跑品完成" + (f"(共 {len(results)} 个店铺)" if len(results) > 1 else "")
                QMessageBox.information(self, head, head + "\n\n" + "\n\n".join(results))

    # ════════════════════════════════════════════════════════════════════════
    #  📦 待发布队列子页(Phase 4 重写)
    # ════════════════════════════════════════════════════════════════════════

    def _build_pdd_page_pending(self) -> QWidget:
        """待发布队列。数据源:pending_publish.json(持久化,刷新不丢)。

        每条已绑定店铺 + 定价规则快照,无需顶部下拉。
        状态机:pending(灰) / running(蓝) / failed(红+原因)。
        成功 → 自动转入已发布历史 + 从此页删除。
        """
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(15, 12, 15, 12)
        lay.setSpacing(8)

        # ── 顶部条 ──
        top = QWidget()
        top.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:6px;")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(15, 10, 15, 10)
        title = QLabel("📦 待发布队列")
        title.setStyleSheet("font-size:14px;font-weight:bold;color:#4F46C8;background:transparent;border:none;")
        tl.addWidget(title)
        desc = QLabel("从商品库提交进队列的商品。每条带店铺 + 定价规则快照。状态持久化,刷新不重置。"
                      "成功的自动转入「📊 已发布」,失败的留此处并保留失败原因。")
        desc.setStyleSheet("color:#6B7280;background:transparent;border:none;font-size:11px;")
        desc.setWordWrap(True)
        tl.addWidget(desc)

        # 按钮行
        btn_row = QHBoxLayout()
        self.pdd_pending_btn_start = QPushButton("▶ 开始队列")
        self.pdd_pending_btn_start.setStyleSheet(
            "QPushButton{background:#10B981;color:white;border:none;border-radius:4px;"
            "padding:6px 14px;font-weight:bold;}QPushButton:hover{background:#059669;}"
            "QPushButton:disabled{background:#D1D5DB;}")
        # ⚠ 必须 lambda:直连会把 clicked 的 checked=False 当 preset_copies 传入(§30),
        #   导致 `preset_copies is not None` 成立 → 跳过「发布几条」弹窗。lambda 保证 preset_copies=None。
        self.pdd_pending_btn_start.clicked.connect(lambda: self._pdd_pending_start_queue())
        btn_row.addWidget(self.pdd_pending_btn_start)
        # 全自动开关:勾上=这批发布成功后,自动对上架成功的商品 换主图→补视频(默认关=老行为)
        self.pdd_pending_chk_auto = QCheckBox("全自动(发布后自动换主图+补视频)")
        self.pdd_pending_chk_auto.setToolTip("勾上:本批发布成功后,自动对上架成功的商品 生图换主图→补视频,无人值守")
        self.pdd_pending_chk_auto.toggled.connect(self._oc_set_auto_full)
        btn_row.addWidget(self.pdd_pending_chk_auto)
        self.pdd_pending_btn_pause = QPushButton("⏸ 暂停")
        self.pdd_pending_btn_pause.setToolTip("当前商品跑完后停止处理后续(不打断当前)")
        self.pdd_pending_btn_pause.setStyleSheet(
            "QPushButton{background:white;color:#F59E0B;border:1px solid #FDE68A;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#FFFBEB;}"
            "QPushButton:disabled{color:#9CA3AF;border-color:#E5E7EB;background:#F9FAFB;}")
        self.pdd_pending_btn_pause.clicked.connect(self._pdd_pending_pause_queue)
        self.pdd_pending_btn_pause.setEnabled(False)
        btn_row.addWidget(self.pdd_pending_btn_pause)
        self.pdd_pending_btn_stop = QPushButton("⏹ 停止")
        self.pdd_pending_btn_stop.setToolTip("立即杀掉当前发布子进程(PDD 可能留半成品)")
        self.pdd_pending_btn_stop.setStyleSheet(
            "QPushButton{background:white;color:#DC2626;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#FEF2F2;}"
            "QPushButton:disabled{color:#9CA3AF;border-color:#E5E7EB;background:#F9FAFB;}")
        self.pdd_pending_btn_stop.clicked.connect(self._pdd_pending_stop_queue)
        self.pdd_pending_btn_stop.setEnabled(False)
        btn_row.addWidget(self.pdd_pending_btn_stop)
        # 人工强发:对勾选的「无同款」失败品,无视VLM,按相似度+热度强制发布(发出标🟢绿旗)
        self.pdd_pending_btn_force = QPushButton("🟢 人工强发")
        self.pdd_pending_btn_force.setToolTip("对勾选的商品(通常是标「无同款」的失败项)无视AI同款核对,"
                                              "在前7候选里按【相似度+热度最高】强制发布;发出的商品标🟢绿旗待人工复核")
        self.pdd_pending_btn_force.setStyleSheet(
            "QPushButton{background:white;color:#059669;border:1px solid #6EE7B7;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#ECFDF5;}")
        self.pdd_pending_btn_force.clicked.connect(self._pdd_pending_force_publish)
        btn_row.addWidget(self.pdd_pending_btn_force)
        # 模式选择:串行 / 多店铺并发
        mode_lbl = QLabel("模式:")
        mode_lbl.setStyleSheet("color:#374151;background:transparent;padding-left:8px;")
        btn_row.addWidget(mode_lbl)
        self.pdd_pending_mode = QComboBox()
        self.pdd_pending_mode.addItem("🐢 单条排队")
        self.pdd_pending_mode.addItem("🚀 多店铺并发(max=3)")
        self.pdd_pending_mode.setToolTip("单条排队:一次只跑 1 个子进程,稳\n"
                                         "多店铺并发:不同店铺最多同时跑 3 个,同店铺串行(避免 profile 锁)")
        self.pdd_pending_mode.setStyleSheet(
            "QComboBox{background:white;color:#111827;border:1px solid #D1D5DB;"
            "border-radius:4px;padding:4px 10px;}"
            "QComboBox:hover{background:#EEF2FF;}")
        btn_row.addWidget(self.pdd_pending_mode)
        # 发布用图:选品图(默认)/ 货源图。货源图=比价选定的 1688 主图,搜同款更贴近真实进货
        pubimg_lbl = QLabel("发布用图:")
        pubimg_lbl.setStyleSheet("color:#374151;background:transparent;padding-left:8px;")
        btn_row.addWidget(pubimg_lbl)
        self.pdd_pub_image_combo = QComboBox()
        self.pdd_pub_image_combo.addItem("🖼 选品图")
        self.pdd_pub_image_combo.addItem("📦 货源图(默认)")
        self.pdd_pub_image_combo.setCurrentIndex(1)   # ★默认货源图:更干净、搜同款更贴近真实进货
        self.pdd_pub_image_combo.setToolTip(
            "选品图:用快手选品图去 PDD 搜同款建链接(老策略)\n"
            "货源图:用比价选定的 1688 货源主图搜同款,模板更贴近真实进货\n"
            "(货源图查不到时自动回退选品图;商品库/待发布都生效)")
        self.pdd_pub_image_combo.setStyleSheet(
            "QComboBox{background:white;color:#111827;border:1px solid #D1D5DB;"
            "border-radius:4px;padding:4px 10px;}"
            "QComboBox:hover{background:#EEF2FF;}")
        btn_row.addWidget(self.pdd_pub_image_combo)
        # 🤖智能SKU:已默认常开(发布时云端判份数,判不准照1688真料重建SKU);锁定为开,不再切换。
        self.pdd_smart_sku_chk = QCheckBox("🤖智能SKU(默认开)")
        self.pdd_smart_sku_chk.setChecked(True)
        self.pdd_smart_sku_chk.setEnabled(False)
        self.pdd_smart_sku_chk.setToolTip(
            "已默认常开:发布时用云端模型判每个SKU份数;判不准的清掉、照1688真料重建SKU(多色/1瓶2瓶3瓶)。")
        self.pdd_smart_sku_chk.setStyleSheet("color:#374151;background:transparent;padding-left:8px;")
        btn_row.addWidget(self.pdd_smart_sku_chk)
        # 显示浏览器(调试)开关:与已发布页那个同步,管所有 PDD 操作的浏览器显隐
        btn_row.addWidget(self._pdd_make_show_browser_chk())
        btn_row.addStretch()
        btn_batch_store = QPushButton("🏪 批量改店铺")
        btn_batch_store.setToolTip("对选中条目批量切换发布店铺(仅 待发布/失败 状态生效)")
        btn_batch_store.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#EEF2FF;}")
        btn_batch_store.clicked.connect(self._pdd_pending_batch_change_store)
        btn_row.addWidget(btn_batch_store)
        btn_batch_rule = QPushButton("💎 批量改规则")
        btn_batch_rule.setToolTip("对选中条目批量切换定价规则(规则全字段快照重写,即时重算预计拼单价)")
        btn_batch_rule.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#EEF2FF;}")
        btn_batch_rule.clicked.connect(self._pdd_pending_batch_change_rule)
        btn_row.addWidget(btn_batch_rule)
        btn_batch_retry = QPushButton("↻ 批量重试")
        btn_batch_retry.setToolTip("把选中的失败条目重置为待发布,可直接选择是否立即启动队列")
        btn_batch_retry.setStyleSheet(
            "QPushButton{background:white;color:#92400E;border:1px solid #FDE68A;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#FFFBEB;}")
        btn_batch_retry.clicked.connect(self._pdd_pending_batch_retry)
        btn_row.addWidget(btn_batch_retry)
        btn_refresh = QPushButton("🔄 刷新")
        btn_refresh.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#EEF2FF;}")
        btn_refresh.clicked.connect(self._pdd_pending_reload)
        btn_row.addWidget(btn_refresh)
        btn_del = QPushButton("🗑 删除选中")
        btn_del.setStyleSheet(
            "QPushButton{background:#FEE2E2;color:#B91C1C;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:6px 14px;}QPushButton:hover{background:#FECACA;}")
        btn_del.clicked.connect(self._pdd_pending_delete_selected)
        btn_row.addWidget(btn_del)
        tl.addLayout(btn_row)

        # 搜索
        srch_row = QHBoxLayout()
        srch_lbl = QLabel("搜索：")
        srch_lbl.setStyleSheet("color:#6B7280;background:transparent;border:none;")
        srch_row.addWidget(srch_lbl)
        self.pdd_pending_search = QLineEdit()
        self.pdd_pending_search.setPlaceholderText("商品名 / 店铺 / 失败原因 关键词…")
        self.pdd_pending_search.textChanged.connect(self._pdd_pending_apply_filter)
        srch_row.addWidget(self.pdd_pending_search)
        srch_row.addStretch()
        tl.addLayout(srch_row)

        lay.addWidget(top)

        # ── 表格 ──
        self.pdd_pending_table = QTableWidget()
        self.pdd_pending_table.setColumnCount(12)
        self.pdd_pending_table.setHorizontalHeaderLabels(
            ["全选", "图(我方/货源)", "商品名", "类目", "店铺", "规则", "供货价", "预计拼单价",
             "状态", "失败原因", "提交时间", "操作"])
        self.pdd_pending_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.pdd_pending_table.setColumnWidth(0, 45)
        self.pdd_pending_table.setColumnWidth(1, 100)   # 图:我方图+货源图 并排
        self.pdd_pending_table.setColumnWidth(3, 130)   # 类目
        self.pdd_pending_table.setColumnWidth(4, 130)   # 店铺
        self.pdd_pending_table.setColumnWidth(5, 140)   # 规则
        self.pdd_pending_table.setColumnWidth(6, 110)   # 供货价
        self.pdd_pending_table.setColumnWidth(7, 100)   # 预计拼单价
        self.pdd_pending_table.setColumnWidth(8, 90)    # 状态
        self.pdd_pending_table.setColumnWidth(9, 200)   # 失败原因
        self.pdd_pending_table.setColumnWidth(10, 140)  # 提交时间
        self.pdd_pending_table.setColumnWidth(11, 130)  # 操作
        self.pdd_pending_table.setAlternatingRowColors(True)
        self.pdd_pending_table.verticalHeader().setVisible(False)
        self.pdd_pending_table.verticalHeader().setDefaultSectionSize(50)
        self.pdd_pending_table.horizontalHeader().sectionClicked.connect(self._pdd_pending_toggle_all)
        lay.addWidget(self.pdd_pending_table, 1)

        # ── 底部 ──
        bot = QHBoxLayout()
        self.pdd_pending_status = QLabel("(未加载)")
        self.pdd_pending_status.setStyleSheet("color:#6B7280;")
        bot.addWidget(self.pdd_pending_status)
        bot.addStretch()
        lay.addLayout(bot)

        # 队列运行时状态
        self._pdd_pending_records = []
        self._pdd_qrun_active = False
        self._pdd_qrun_paused = False
        self._pdd_qrun_stop_requested = False
        self._pdd_qrun_current_id = ""
        self._pdd_qrun_proc = None
        self._pdd_qrun_tmp_path = ""
        # 并发模式专用状态(单条模式下不用):{rid: {"store","proc","tmp_path","log_file","log_path","start_iso"}}
        self._pdd_qrun_active_jobs = {}
        self._pdd_qrun_max_concurrent = 3
        # 本次队列只跑这些 rid(None = 跑全部待发布);由"开始队列"时勾选决定
        self._pdd_qrun_selected_ids = None

        self._pdd_pending_reload()
        return page

    # ── 待发布:数据加载 / 渲染 ───────────────────────────────────────────
    def _pdd_pending_reload(self):
        """从 pending_publish.json 读 + 首次自动恢复(running→pending) + 渲染。"""
        try:
            if not getattr(self, "_pdd_pending_recovered", False):
                self._pdd_pending_records = pending_publish.recover_on_startup()
                self._pdd_pending_recovered = True
            else:
                self._pdd_pending_records = pending_publish.load_pending()
        except Exception as e:
            QMessageBox.critical(self, "加载失败", f"读取待发布失败:\n{e}")
            self._pdd_pending_records = []
        self._pdd_pending_apply_filter()

    def _pdd_pending_apply_filter(self):
        kw = self.pdd_pending_search.text().strip().lower() if hasattr(self, "pdd_pending_search") else ""
        records = self._pdd_pending_records
        if kw:
            kws = kw.split()
            def _match(r):
                blob = (r.get("name", "") + " " + r.get("shop_name", "") + " " + r.get("store", "")
                        + " " + r.get("fail_reason", "")).lower()
                return all(k in blob for k in kws)
            records = [r for r in records if _match(r)]
        self._pdd_pending_render(records)

    def _pdd_pending_render(self, records: list):
        tbl = self.pdd_pending_table
        tbl.setRowCount(0)
        img_tasks = []
        # 一次性加载下拉数据(店铺 / 规则);仅 pending 状态行允许编辑
        try:
            _rules_list = pricing_rules.load_rules()
        except Exception:
            _rules_list = []
        _stores_list = self._pdd_get_store_list()
        # 货源图回查表:待发布记录本身没存货源图,按 library_id / prod_id 映射回 product_library。
        # 优先用已加载的 _pdd_lib_records(商品库已打开过),否则现读一次文件(~10ms)。
        _lib = getattr(self, "_pdd_lib_records", None)
        if not _lib:
            try:
                _lib = product_library.load_library()
            except Exception:
                _lib = []
        _lib_by_id   = {str(r.get("id")): r for r in _lib if r.get("id")}
        _lib_by_prod = {str(r.get("prod_id")): r for r in _lib if r.get("prod_id")}
        for rec in records:
            row = tbl.rowCount()
            tbl.insertRow(row)
            # 复选框:纯控件式(item 设 Enabled 不画原生框;UserRole 存 id 供读取);读取改读控件
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsEnabled)
            chk.setData(Qt.UserRole, rec.get("id", ""))
            tbl.setItem(row, 0, chk)
            tbl.setCellWidget(row, 0, self._make_check_widget())
            # 图:我方图 + 货源图 并排(一眼对比是否同款)
            img_cell = QWidget()
            img_cell.setStyleSheet("background:transparent;")
            _cl = QHBoxLayout(img_cell)
            _cl.setContentsMargins(2, 2, 2, 2)
            _cl.setSpacing(3)
            # ── 我方图(左)──
            img_lbl = ClickableImageLabel()
            img_lbl.setText("…")
            img_lbl.setAlignment(Qt.AlignCenter)
            img_lbl.setFixedSize(42, 42)
            img_lbl.setToolTip("我方商品图")
            img_lbl.setStyleSheet("color:#9CA3AF;background:white;border:1px solid #E5E7EB;border-radius:3px;")
            _cl.addWidget(img_lbl)
            img_local = rec.get("image_local") or ""
            img_url = rec.get("image", "") or ""
            img_lbl.set_image_source(img_local, img_url, rec.get("name", ""))
            if img_local and Path(img_local).exists():
                try:
                    pix = QPixmap(img_local)
                    if not pix.isNull():
                        pix = pix.scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                        img_lbl.setPixmap(pix); img_lbl.setText("")
                except Exception:
                    img_lbl.setText("📷")
            elif img_url and img_url.startswith(("http://", "https://", "//")):
                if img_url.startswith("//"): img_url = "https:" + img_url
                img_tasks.append((img_lbl, img_url))
            else:
                img_lbl.setText("📷")
            # ── 货源图(右):回查 product_library(library_id / prod_id)──
            _lr = (_lib_by_id.get(str(rec.get("library_id") or ""))
                   or _lib_by_prod.get(str(rec.get("prod_id") or "")))
            src_img = self._pdd_source_image(_lr) if _lr else ""
            src_lbl = ClickableImageLabel()
            src_lbl.setAlignment(Qt.AlignCenter)
            src_lbl.setFixedSize(42, 42)
            src_lbl.setToolTip("1688 货源图(比价选中)")
            src_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #FDE68A;border-radius:3px;")
            if src_img:
                src_lbl.set_image_source("", src_img, rec.get("name", ""))
                if src_img.startswith("//"): src_img = "https:" + src_img
                src_lbl.setText("…")
                img_tasks.append((src_lbl, src_img))
            else:
                src_lbl.setText("—")
            _cl.addWidget(src_lbl)
            tbl.setCellWidget(row, 1, img_cell)
            # 商品名
            tbl.setItem(row, 2, QTableWidgetItem(rec.get("name", "")))
            # 类目
            cat = rec.get("category", "") or "—"
            cat_it = QTableWidgetItem(cat)
            if not rec.get("category"):
                cat_it.setForeground(QColor("#9CA3AF"))
            tbl.setItem(row, 3, cat_it)
            # 店铺 + 规则:status=pending 时用 ComboBox 允许编辑;其它状态用只读文本
            _status_now = rec.get("publish_status", pending_publish.STATUS_PENDING)
            if _status_now == pending_publish.STATUS_PENDING:
                # ── 店铺下拉 ──
                store_combo = QComboBox()
                store_combo.setStyleSheet(
                    "QComboBox{border:1px solid #E5E7EB;border-radius:3px;padding:2px 4px;"
                    "background:white;}QComboBox:hover{border-color:#4F46C8;}")
                store_combo.blockSignals(True)
                for s in _stores_list:
                    store_combo.addItem(s)
                cur_store = rec.get("store", "")
                if cur_store and cur_store not in _stores_list:
                    store_combo.addItem(cur_store)  # 兜底显示旧值
                store_combo.setCurrentText(cur_store)
                store_combo.blockSignals(False)
                store_combo.currentTextChanged.connect(
                    lambda txt, rid=rec["id"]: self._pdd_pending_change_store(rid, txt))
                tbl.setCellWidget(row, 4, store_combo)
                # ── 规则下拉 ──
                rule_combo = QComboBox()
                rule_combo.setStyleSheet(
                    "QComboBox{border:1px solid #E5E7EB;border-radius:3px;padding:2px 4px;"
                    "background:white;}QComboBox:hover{border-color:#4F46C8;}")
                rule_combo.blockSignals(True)
                cur_rule_id = rec.get("pricing_rule_id", "")
                cur_rule_idx = 0
                for i, ru in enumerate(_rules_list):
                    rn = ru.get("name", "")
                    rm = float(ru.get("margin", 0)) * 100
                    rule_combo.addItem(f"{rn} ({rm:.0f}%)", ru)
                    if ru.get("id") == cur_rule_id:
                        cur_rule_idx = i
                # 兜底:若规则被删,显示快照名
                if not _rules_list or (cur_rule_id and not any(ru.get("id") == cur_rule_id for ru in _rules_list)):
                    rule_combo.addItem(f"⚠ {rec.get('pricing_rule_name','(规则已删)')} (快照)", None)
                    cur_rule_idx = rule_combo.count() - 1
                rule_combo.setCurrentIndex(cur_rule_idx)
                rule_combo.blockSignals(False)
                rule_combo.currentIndexChanged.connect(
                    lambda _i, rid=rec["id"], c=rule_combo: self._pdd_pending_change_rule(rid, c.currentData()))
                tbl.setCellWidget(row, 5, rule_combo)
            else:
                tbl.setItem(row, 4, QTableWidgetItem(rec.get("store", "")))
                margin_pct = float(rec.get("rule_margin", 0)) * 100
                tbl.setItem(row, 5, QTableWidgetItem(
                    f"{rec.get('pricing_rule_name', '')} ({margin_pct:.0f}%)"))
            # 供货价
            cost_str = rec.get("cost_ref", "") or "—"
            cost_it = QTableWidgetItem(cost_str)
            if not rec.get("cost_ref"):
                cost_it.setForeground(QColor("#9CA3AF"))
            tbl.setItem(row, 6, cost_it)
            # 预计拼单价(supplier_cost 字段为 0 时,从 cost_ref "¥xx (¥xx+运xx)" 提首数字兜底)
            ship = float(rec.get("rule_shipping", 4.0))
            mar = float(rec.get("rule_margin", 0.9))
            scost = float(rec.get("supplier_cost", 0) or 0)
            if not scost and rec.get("cost_ref"):
                m = re.search(r"(\d+\.?\d*)", rec["cost_ref"])
                if m:
                    try:
                        scost = float(m.group(1))
                    except ValueError:
                        pass
            est = round((scost + ship) / (1 - mar), 2) if scost and mar < 0.99 else 0
            est_it = QTableWidgetItem(f"¥{est:.2f}" if est else "—")
            est_it.setTextAlignment(Qt.AlignCenter)
            est_it.setForeground(QColor("#10B981") if est else QColor("#9CA3AF"))
            tbl.setItem(row, 7, est_it)
            # 状态色
            status = rec.get("publish_status", pending_publish.STATUS_PENDING)
            status_map = {
                pending_publish.STATUS_PENDING: ("⚪ 待发布",   "#6B7280"),
                pending_publish.STATUS_RUNNING: ("🔵 发布中…", "#3B82F6"),
                pending_publish.STATUS_FAILED:  ("❌ 失败",    "#DC2626"),
            }
            stt_txt, stt_color = status_map.get(status, (status, "#6B7280"))
            stt_it = QTableWidgetItem(stt_txt)
            stt_it.setForeground(QColor(stt_color))
            stt_it.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(row, 8, stt_it)
            # 失败原因(tooltip 显示完整)
            reason = rec.get("fail_reason", "")
            reason_short = (reason[:60] + "…") if len(reason) > 60 else reason
            reason_it = QTableWidgetItem(reason_short or "—")
            if reason:
                reason_it.setToolTip(reason)
                reason_it.setForeground(QColor("#DC2626"))
            else:
                reason_it.setForeground(QColor("#9CA3AF"))
            tbl.setItem(row, 9, reason_it)
            # 提交时间
            tbl.setItem(row, 10, QTableWidgetItem(rec.get("submit_time", "")))
            # 操作:重试(仅 failed) + 删除
            op_widget = QWidget()
            ol = QHBoxLayout(op_widget)
            ol.setContentsMargins(2, 2, 2, 2)
            ol.setSpacing(3)
            if status == pending_publish.STATUS_FAILED:
                btn_retry = QPushButton("↻ 重试")
                btn_retry.setStyleSheet(
                    "QPushButton{background:#FEF3C7;color:#92400E;border:1px solid #FDE68A;"
                    "border-radius:3px;padding:3px 6px;font-size:10px;}"
                    "QPushButton:hover{background:#FDE68A;}")
                btn_retry.clicked.connect(lambda _, rid=rec["id"]: self._pdd_pending_retry(rid))
                ol.addWidget(btn_retry)
            btn_del_one = QPushButton("🗑")
            btn_del_one.setFixedWidth(28)
            btn_del_one.setStyleSheet(
                "QPushButton{background:#FEE2E2;color:#B91C1C;border:1px solid #FCA5A5;"
                "border-radius:3px;padding:3px;font-size:10px;}"
                "QPushButton:hover{background:#FECACA;}")
            btn_del_one.clicked.connect(lambda _, rid=rec["id"]: self._pdd_pending_delete_one(rid))
            ol.addWidget(btn_del_one)
            tbl.setCellWidget(row, 11, op_widget)

        # 底部统计
        stats = pending_publish.count_by_status(self._pdd_pending_records)
        self.pdd_pending_status.setText(
            f"共 {len(self._pdd_pending_records)} 条  ·  "
            f"待发布 {stats[pending_publish.STATUS_PENDING]}  ·  "
            f"发布中 {stats[pending_publish.STATUS_RUNNING]}  ·  "
            f"失败 {stats[pending_publish.STATUS_FAILED]}"
        )
        # 异步图(先停旧 loader 避免 QThread destroyed-while-running fatal)
        if img_tasks:
            old = getattr(self, "_pdd_pending_img_loader", None)
            if old is not None:
                try: old.stop()
                except Exception: pass
            self._pdd_pending_img_loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_pending_thumb_cache")
            self._pdd_pending_img_loader.image_ready.connect(self._pdd_pending_set_thumb)
            self._pdd_pending_img_loader.start()

    def _pdd_pending_set_thumb(self, label, data):
        try:
            pix = QPixmap()
            pix.loadFromData(data)
            pix = pix.scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            label.setPixmap(pix); label.setText("")
        except RuntimeError:
            pass

    def _pdd_pending_toggle_all(self, col_idx: int):
        if col_idx != 0:
            return
        cbs = [self._cell_checkbox(self.pdd_pending_table, r)
               for r in range(self.pdd_pending_table.rowCount())]
        cbs = [c for c in cbs if c]
        all_checked = all(c.isChecked() for c in cbs) if cbs else False
        for c in cbs:
            c.setChecked(not all_checked)

    def _pdd_pending_get_selected_ids(self) -> list:
        ids = []
        for r in range(self.pdd_pending_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_pending_table, r)
            it = self.pdd_pending_table.item(r, 0)
            if cb and cb.isChecked() and it:
                ids.append(it.data(Qt.UserRole))
        return ids

    # ── 待发布:批量发布完成后的汇总弹窗 ────────────────────────────────
    def _pdd_show_batch_summary(self, batch: dict):
        """队列跑完一次,弹一个汇总弹窗。
        - 成功:列名+店铺+规则+goods_id
        - 失败:列名+原因(含 log 文件名)
        """
        succ = batch.get("success", [])
        fail = batch.get("failed", [])
        total = len(succ) + len(fail)
        lines = [f"批量发布完成,共 {total} 条:"]
        lines.append(f"  ✅ 成功 {len(succ)}  ·  ❌ 失败 {len(fail)}")
        if succ:
            lines.append("")
            lines.append("【成功】")
            for s in succ[:20]:
                tag = "ok" if s.get("status") == "ok" else f"⚠{s.get('status','')}"
                lines.append(f"  • {s['name'][:40]}  [{tag}]  goods_id={s.get('goods_id','-')}")
            if len(succ) > 20:
                lines.append(f"  …还有 {len(succ)-20} 条")
        if fail:
            lines.append("")
            lines.append("【失败】")
            for f in fail[:20]:
                lines.append(f"  • {f['name'][:40]}")
                lines.append(f"      {f['reason'][:100]}")
            if len(fail) > 20:
                lines.append(f"  …还有 {len(fail)-20} 条")
        # 一键跑品场景:把比价阶段的「拦下/出错」一并显示(只这一次总汇总),然后清空
        oc_extra = getattr(self, "_oc_summary_extra", "")
        if oc_extra:
            lines.append("")
            lines.append("═══ 一键跑品·比价阶段 ═══")
            lines.append(oc_extra)
            self._oc_summary_extra = ""
        # 用 QMessageBox detailedText 适配长文本
        started_followup = False
        try:
            mb = QMessageBox(self)
            mb.setIcon(QMessageBox.Information if not fail else QMessageBox.Warning)
            mb.setWindowTitle("批量发布完成")
            mb.setText(f"批量发布完成: ✅ 成功 {len(succ)} · ❌ 失败 {len(fail)} (共 {total} 条)")
            mb.setDetailedText("\n".join(lines))
            # 一键跑品勾了⑥开车:本批发布成功 → 记下待开车(店铺+gids),链尾再预演+确认+真开
            if getattr(self, "_oc_promote_after_publish", False):
                self._oc_promote_after_publish = False
                _pg = [str(s.get("goods_id")) for s in succ
                       if s.get("goods_id") and str(s.get("goods_id")) != "-"]
                _ps = getattr(self, "_oc_promote_store", "") or getattr(self, "_oc_store", "")
                if _pg and _ps:
                    self._oc_promote_pending = (_ps, _pg)
            # 人工发布 → 弹完成框;无人值守/任务中心自动续跑 → 不弹,直接往下
            if (not getattr(self, "_oc_unattended", False)
                    and not self._task_center_should_defer_dialog()):
                mb.exec_()
            # 要不要接发布后链:勾了④换图 或 ⑤补视频 才接
            _do_chain = bool(succ) and (self._oc_step("main_img") or self._oc_step("video"))
            if _do_chain:
                try:
                    self._auto_after_publish(succ)   # 换主图→补视频→(链尾)开车
                    started_followup = True
                except Exception as _e:
                    print(f"[链] 后续阶段触发失败: {_e}")
                    started_followup = self._oc_maybe_promote()
            else:
                started_followup = self._oc_maybe_promote()  # 没换图/视频 → 直接进开车环节(若勾了⑥)
        except Exception:
            if self._task_center_should_defer_dialog():
                self._task_center_update_current_detail("\n".join(lines))
            else:
                QMessageBox.information(self, "批量发布完成", "\n".join(lines))
        if self._task_center_should_defer_dialog():
            self._task_center_update_current_detail("\n".join(lines))
        return started_followup

    # ── 一键跑品步骤配置(比价/核对/发布/换主图/补视频/开车),记忆上次勾选 ──
    _OC_STEPS_PATH = r"D:/files/data/pdd/oneclick_steps.json"

    def _oc_load_steps(self) -> dict:
        """读上次勾的步骤;缺省=比价/核对/发布开,换主图/补视频/开车看上次(默认关)。"""
        import json as _j
        d = {}
        try:
            p = Path(self._OC_STEPS_PATH)
            if p.exists():
                d = _j.loads(p.read_text(encoding="utf-8-sig")) or {}
        except Exception:
            d = {}
        return {
            "compare":  bool(d.get("compare", True)),
            "check":    bool(d.get("check", True)),
            "publish":  bool(d.get("publish", True)),
            "main_img": bool(d.get("main_img", False)),
            "video":    bool(d.get("video", False)),
            "promote":  bool(d.get("promote", False)),
        }

    def _oc_save_steps(self, steps: dict):
        import json as _j
        try:
            p = Path(self._OC_STEPS_PATH)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(_j.dumps(steps, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _oc_step(self, key: str) -> bool:
        """当前这次跑的某步是否开。未单独设置时:换主图/补视频跟随 _auto_full,其余默认开。"""
        steps = getattr(self, "_oc_steps", None)
        if isinstance(steps, dict) and key in steps:
            return bool(steps[key])
        if key in ("main_img", "video"):
            return bool(getattr(self, "_auto_full", False))
        return True

    def _oc_set_auto_full(self, v):
        """选品区/待发布页那两个「全自动」勾选框用:开=换主图+补视频都做(与一键跑品步骤配置保持一致)。"""
        v = bool(v)
        self._auto_full = v
        st = dict(getattr(self, "_oc_steps", None) or {})
        st.update({"main_img": v, "video": v})
        st.setdefault("compare", True); st.setdefault("check", True)
        st.setdefault("publish", True); st.setdefault("promote", False)
        self._oc_steps = st

    def _auto_after_publish(self, succ):
        """全自动:本批上架成功的商品 → 自动 生图换主图 →(完成后)补视频。无人值守。
        默认关,勾「全自动」才会被 _pdd_show_batch_summary 调到。"""
        gids = {str(s.get("goods_id")) for s in succ
                if s.get("goods_id") and str(s.get("goods_id")) != "-"}
        if not gids:
            return
        try:
            pub = [r for r in self._pdd_video_published_records()
                   if str(r.get("goods_id")) in gids]
        except Exception:
            pub = []
        if not pub:
            print("[全自动] 没找到本批上架商品记录,跳过换主图/补视频")
            return
        self._auto_pub_recs = pub
        if self._oc_step("main_img"):
            print(f"[全自动] 本批上架 {len(pub)} 个 → 自动换主图…")
            self._pdd_genimg_generate_selected(recs=pub, mode="full", no_confirm=True)
        else:
            self._auto_chain_video()   # 没勾换主图 → 直接进补视频环节

    def _auto_chain_video(self):
        """换主图跑完 → 自动接视频补传(全自动链第二棒);没勾补视频则跳过,直接进开车环节。"""
        recs = getattr(self, "_auto_pub_recs", None)
        self._auto_pub_recs = None
        if recs and self._oc_step("video"):
            self._auto_in_video_chain = True   # 标记:补视频完成框静默 + 完后接开车
            print(f"[链] → 自动补视频 {len(recs)} 个…")
            try:
                self._pdd_video_supplement_selected(recs=recs, no_confirm=True)
            except Exception as _e:
                self._auto_in_video_chain = False
                print(f"[链] 补视频触发失败: {_e}")
                self._oc_maybe_promote()   # 补视频触发失败也别卡住开车
        else:
            self._oc_maybe_promote()       # 没补视频 → 直接进开车(若勾了⑥)

    def _oc_maybe_promote(self):
        """一键跑品链尾:勾了⑥开车且本批有成功发布的品 → 先预演(不花钱),
        预演跑完在 _pdd_ap_run_done 里弹确认 → 真开车。只在有待开车记录时才动。"""
        pend = getattr(self, "_oc_promote_pending", None)
        self._oc_promote_pending = None
        if not pend:
            return False
        store, gids = pend
        gids = [str(g) for g in gids if g]
        if not store or not gids:
            return False
        recs = [{"goods_id": g, "store": store} for g in gids]
        try:
            self.pdd_ap_status.setText(f"🚗 一键跑品·开车:店铺「{store}」{len(gids)} 条…")
        except Exception:
            pass
        try:
            self.pdd_ap_tier.setCurrentText("20%盈利")
        except Exception:
            pass
        # 无人值守:直接真开,不弹任何确认框(老链接锁/已推广/亏本由 roas_auto 自动跳过)
        self._pdd_ap_run_selected(recs=recs, confirm=True, skip_ask=True)
        return True

    # ── 待发布:批量编辑(店铺/规则) ─────────────────────────────────────
    def _pdd_pending_batch_change_store(self):
        """对选中条目批量改店铺。"""
        ids = self._pdd_pending_get_selected_ids()
        if not ids:
            QMessageBox.information(self, "批量改店铺", "请先勾选条目")
            return
        # 过滤掉 running
        targets = [r for r in self._pdd_pending_records
                   if r.get("id") in set(ids)
                   and r.get("publish_status") != pending_publish.STATUS_RUNNING]
        skipped = len(ids) - len(targets)
        if not targets:
            QMessageBox.warning(self, "批量改店铺", "选中条目都在发布中,先 ⏹ 停止队列再改")
            return
        stores = [s for s in self._pdd_get_store_list() if s]
        if not stores:
            QMessageBox.warning(self, "批量改店铺", "未找到已登录店铺")
            return
        # 简易选择对话框
        dlg = QDialog(self)
        dlg.setWindowTitle("批量改店铺")
        dlg.resize(360, 140)
        dl = QVBoxLayout(dlg)
        info = QLabel(f"将对 <b>{len(targets)}</b> 条记录切换店铺"
                      + (f"<br><span style='color:#DC2626'>跳过 {skipped} 条(正在发布中)</span>" if skipped else ""))
        info.setTextFormat(Qt.RichText)
        dl.addWidget(info)
        form = QFormLayout()
        cb = QComboBox()
        for s in stores:
            cb.addItem(s)
        form.addRow("新店铺：", cb)
        dl.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        dl.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return
        new_store = cb.currentText()
        if not new_store:
            return
        tids = {r["id"] for r in targets}
        for r in self._pdd_pending_records:
            if r.get("id") in tids:
                r["store"] = new_store
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pdd_pending_apply_filter()
        QMessageBox.information(self, "批量改店铺",
            f"已更新 {len(targets)} 条 → 店铺={new_store}"
            + (f"\n跳过 {skipped} 条(正在发布中)" if skipped else ""))

    def _pdd_pending_batch_change_rule(self):
        """对选中条目批量改定价规则(全字段快照重写)。"""
        ids = self._pdd_pending_get_selected_ids()
        if not ids:
            QMessageBox.information(self, "批量改规则", "请先勾选条目")
            return
        targets = [r for r in self._pdd_pending_records
                   if r.get("id") in set(ids)
                   and r.get("publish_status") != pending_publish.STATUS_RUNNING]
        skipped = len(ids) - len(targets)
        if not targets:
            QMessageBox.warning(self, "批量改规则", "选中条目都在发布中,先 ⏹ 停止队列再改")
            return
        try:
            rules = pricing_rules.load_rules()
        except Exception as e:
            QMessageBox.critical(self, "批量改规则", f"读取规则失败: {e}")
            return
        if not rules:
            QMessageBox.warning(self, "批量改规则", "未找到任何定价规则,先到「💎 定价规则」页新建")
            return
        # 对话框
        dlg = QDialog(self)
        dlg.setWindowTitle("批量改定价规则")
        dlg.resize(420, 160)
        dl = QVBoxLayout(dlg)
        info = QLabel(f"将对 <b>{len(targets)}</b> 条记录切换定价规则<br>"
                      f"<span style='color:#6B7280;font-size:11px'>规则字段会以快照形式冻结到 pending,"
                      f"后续规则修改不影响这次提交</span>"
                      + (f"<br><span style='color:#DC2626'>跳过 {skipped} 条(正在发布中)</span>" if skipped else ""))
        info.setTextFormat(Qt.RichText)
        info.setWordWrap(True)
        dl.addWidget(info)
        form = QFormLayout()
        cb = QComboBox()
        default_idx = 0
        for i, ru in enumerate(rules):
            mark = " ★" if ru.get("is_default") else ""
            cb.addItem(f"{ru.get('name','(未命名)')} ({float(ru.get('margin',0))*100:.0f}%){mark}", ru)
            if ru.get("is_default"):
                default_idx = i
        cb.setCurrentIndex(default_idx)
        form.addRow("新规则：", cb)
        dl.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        dl.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return
        new_rule = cb.currentData()
        if not isinstance(new_rule, dict):
            return
        tids = {r["id"] for r in targets}
        for r in self._pdd_pending_records:
            if r.get("id") in tids:
                r["pricing_rule_id"]       = new_rule.get("id", "")
                r["pricing_rule_name"]     = new_rule.get("name", "")
                r["rule_shipping"]         = float(new_rule.get("shipping", 4.0))
                r["rule_margin"]           = float(new_rule.get("margin", 0.9))
                r["rule_single_buy_extra"] = float(new_rule.get("single_buy_extra", 2.0))
                r["rule_spec_suffix"]      = new_rule.get("spec_suffix", "+面膜1片")
                r["rule_stock"]            = int(new_rule.get("stock", 8888))
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pdd_pending_apply_filter()  # 全表重渲染:重算 est + 更新下拉显示
        QMessageBox.information(self, "批量改规则",
            f"已更新 {len(targets)} 条 → 规则={new_rule.get('name','')}"
            + (f"\n跳过 {skipped} 条(正在发布中)" if skipped else ""))

    # ── 待发布:行内编辑(店铺/规则) ────────────────────────────────────
    def _pdd_pending_change_store(self, rid: str, new_store: str):
        """店铺下拉切换 → 更新 pending record 的 store(不影响 est 价格)。"""
        if not new_store:
            return
        changed = False
        for r in self._pdd_pending_records:
            if r.get("id") == rid and r.get("store") != new_store:
                r["store"] = new_store
                changed = True
                break
        if not changed:
            return
        try:
            pending_publish.save_pending(self._pdd_pending_records)
            self.pdd_pending_status.setText(f"✓ 店铺已更新为 {new_store}")
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))

    def _pdd_pending_change_rule(self, rid: str, new_rule):
        """规则下拉切换 → 把所有 rule_* 字段更新到新规则的快照 + 即时重算 est。"""
        if not isinstance(new_rule, dict):
            return  # 选了"快照"占位项
        changed = False
        for r in self._pdd_pending_records:
            if r.get("id") == rid:
                r["pricing_rule_id"]       = new_rule.get("id", "")
                r["pricing_rule_name"]     = new_rule.get("name", "")
                r["rule_shipping"]         = float(new_rule.get("shipping", 4.0))
                r["rule_margin"]           = float(new_rule.get("margin", 0.9))
                r["rule_single_buy_extra"] = float(new_rule.get("single_buy_extra", 2.0))
                r["rule_spec_suffix"]      = new_rule.get("spec_suffix", "+面膜1片")
                r["rule_stock"]            = int(new_rule.get("stock", 8888))
                changed = True
                break
        if not changed:
            return
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        # 即时重算预计拼单价(只改对应行那一格,不重渲染整张表避免破坏 combo 焦点)
        row = self._pdd_pending_find_row(rid)
        if row >= 0:
            self._pdd_pending_recalc_est_cell(rid, row)
        self.pdd_pending_status.setText(f"✓ 规则已切换为 {new_rule.get('name','')}")

    def _pdd_pending_find_row(self, rid: str) -> int:
        """根据 record id 找当前表格中的行号(过滤/排序后仍可定位)。-1 表示找不到。"""
        for r in range(self.pdd_pending_table.rowCount()):
            it = self.pdd_pending_table.item(r, 0)
            if it and it.data(Qt.UserRole) == rid:
                return r
        return -1

    def _pdd_pending_recalc_est_cell(self, rid: str, row: int):
        """重算指定行的「预计拼单价」单元格(col 7)。"""
        rec = pending_publish.get_by_id(self._pdd_pending_records, rid)
        if not rec:
            return
        ship = float(rec.get("rule_shipping", 4.0))
        mar = float(rec.get("rule_margin", 0.9))
        scost = float(rec.get("supplier_cost", 0) or 0)
        if not scost and rec.get("cost_ref"):
            m = re.search(r"(\d+\.?\d*)", rec["cost_ref"])
            if m:
                try:
                    scost = float(m.group(1))
                except ValueError:
                    pass
        est = round((scost + ship) / (1 - mar), 2) if scost and mar < 0.99 else 0
        est_it = QTableWidgetItem(f"¥{est:.2f}" if est else "—")
        est_it.setTextAlignment(Qt.AlignCenter)
        est_it.setForeground(QColor("#10B981") if est else QColor("#9CA3AF"))
        self.pdd_pending_table.setItem(row, 7, est_it)

    # ── 待发布:删除 / 重试 ───────────────────────────────────────────────
    def _pdd_pending_delete_selected(self):
        ids = self._pdd_pending_get_selected_ids()
        if not ids:
            QMessageBox.information(self, "删除", "请先勾选要删除的记录")
            return
        rs = [r for r in self._pdd_pending_records if r.get("id") in set(ids)]
        running = [r for r in rs if r.get("publish_status") == pending_publish.STATUS_RUNNING]
        if running:
            QMessageBox.warning(self, "删除", f"{len(running)} 条正在发布中,先 ⏹ 停止队列再删")
            return
        if QMessageBox.question(self, "确认删除",
                f"将从待发布队列删除 {len(ids)} 条记录,不可撤销。\n继续?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 先收集要删的记录,用于回写商品库 submitted 状态
        deleted = [r for r in self._pdd_pending_records if r.get("id") in set(ids)]
        self._pdd_pending_records, n = pending_publish.delete_by_ids(self._pdd_pending_records, ids)
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pdd_unmark_library_for_deleted(deleted)
        self._pdd_pending_apply_filter()

    def _pdd_pending_delete_one(self, rid: str):
        rec = pending_publish.get_by_id(self._pdd_pending_records, rid)
        if rec and rec.get("publish_status") == pending_publish.STATUS_RUNNING:
            QMessageBox.warning(self, "删除", "该条正在发布中,先 ⏹ 停止队列再删")
            return
        name = rec.get("name", "") if rec else ""
        if QMessageBox.question(self, "确认删除",
                f"删除「{name[:40]}」?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        deleted = [rec] if rec else []
        self._pdd_pending_records, _ = pending_publish.delete_by_ids(self._pdd_pending_records, [rid])
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception:
            pass
        self._pdd_unmark_library_for_deleted(deleted)
        self._pdd_pending_apply_filter()

    def _pdd_unmark_library_for_deleted(self, deleted_records: list):
        """待发布手动删除时,同步把商品库对应 record 的 submitted 标记取消。
        前提:库 record 在剩余的 pending 中也没有引用(防止一条库 record 多次提交时误改)。
        仅手动删除调用,publish 成功后不调用(成功视为"已发布",submitted 保持 True)。
        """
        if not deleted_records:
            return
        deleted_lib_ids = {r.get("library_id") for r in deleted_records if r.get("library_id")}
        if not deleted_lib_ids:
            return
        try:
            remaining = pending_publish.load_pending()
        except Exception:
            remaining = self._pdd_pending_records
        still_used = {r.get("library_id") for r in remaining if r.get("library_id")}
        to_unmark = deleted_lib_ids - still_used
        if not to_unmark:
            return
        try:
            lib_recs = product_library.load_library()
            lib_recs = product_library.mark_submitted(lib_recs, to_unmark, False)
            product_library.save_library(lib_recs)
            # 同步内存中的库 records(若商品库页已加载)
            if hasattr(self, "_pdd_lib_records"):
                self._pdd_lib_records = lib_recs
        except Exception as e:
            print(f"[unmark] 商品库 submitted 同步失败(不阻断): {e}")

    def _pdd_pending_retry(self, rid: str):
        """重置 failed 条目为 pending(等待队列下次处理)。"""
        self._pdd_pending_records = pending_publish.mark_pending(self._pdd_pending_records, rid)
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception:
            pass
        self._pdd_pending_apply_filter()
        self.pdd_pending_status.setText(f"↻ 已重置为待发布,点 ▶ 开始队列 处理")

    def _pdd_pending_batch_retry(self):
        """批量把选中的 failed 条目重置为 pending。可选立即启动队列。"""
        ids = self._pdd_pending_get_selected_ids()
        if not ids:
            QMessageBox.information(self, "批量重试", "请先勾选条目")
            return
        id_set = set(ids)
        # 仅对状态 = failed 的生效;其它跳过
        failed_targets = [r for r in self._pdd_pending_records
                          if r.get("id") in id_set
                          and r.get("publish_status") == pending_publish.STATUS_FAILED]
        skipped = len(ids) - len(failed_targets)
        if not failed_targets:
            QMessageBox.warning(self, "批量重试", "选中条目里没有失败状态的(只对 ❌ 失败 生效)")
            return
        # 询问是否立即启动
        msg = (f"将把 {len(failed_targets)} 条失败记录重置为 ⚪ 待发布"
               + (f"\n(跳过 {skipped} 条非 failed 状态)" if skipped else "")
               + "\n\n重置后立即启动队列?")
        btn = QMessageBox.question(self, "批量重试", msg,
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                QMessageBox.Yes)
        if btn == QMessageBox.Cancel:
            return
        # 重置状态
        for r in self._pdd_pending_records:
            if r.get("id") in {x["id"] for x in failed_targets}:
                r["publish_status"] = pending_publish.STATUS_PENDING
                r["fail_reason"]    = ""
                r["start_time"]     = ""
                r["finish_time"]    = ""
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pdd_pending_apply_filter()
        self.pdd_pending_status.setText(
            f"↻ 已批量重置 {len(failed_targets)} 条为待发布"
            + (f" (跳过 {skipped} 条)" if skipped else ""))
        if btn == QMessageBox.Yes:
            # 立即启动队列
            self._pdd_pending_start_queue()

    # ── 待发布:队列控制 ─────────────────────────────────────────────────
    def _pdd_pending_force_publish(self):
        """人工强发:对勾选的商品打 _force_style 标记(发布时走 --force-style:无视VLM,按相似度+热度挑),
        失败的重置成 pending,再走正常队列。通常用于发布失败、标「无同款·品牌不一致」的商品。"""
        sel = [s for s in self._pdd_pending_get_selected_ids() if s]
        if not sel:
            QMessageBox.information(self, "人工强发",
                                    "请先在表里勾选要强制发布的商品(通常是标「🟡 无同款·品牌不一致」的失败项)。")
            return
        n = len(sel)
        if QMessageBox.question(
                self, "人工强发",
                f"对勾选的 {n} 个商品【人工强发】?\n\n"
                "将【无视 AI 同款核对】,在前 7 候选里按【相似度最高 + 热度最高】强制发布。\n"
                "⚠ 真发布、真花钱;发出来的商品会标 🟢 绿旗,提示人工复核是否对版。\n\n确定继续?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        sel_set = set(sel)
        for r in self._pdd_pending_records:
            if r.get("id") in sel_set:
                r["_force_style"] = True
                if r.get("publish_status") == pending_publish.STATUS_FAILED:
                    r["publish_status"] = pending_publish.STATUS_PENDING
                    r["fail_reason"] = ""
        try:
            pending_publish.save_pending(self._pdd_pending_records)
        except Exception:
            pass
        self._pdd_pending_apply_filter()
        self.pdd_pending_status.setText(f"🟢 人工强发:已标记 {n} 条,开始发布…")
        self._pdd_pending_start_queue()

    def _pdd_pending_start_queue(self, preset_copies: int = None):
        """启动队列(或从暂停恢复)。批量模式累积成功/失败,结束时 1 个汇总弹窗。
        勾选了条目 → 只跑勾选的;一条没勾 → 跑全部待发布。
        preset_copies:有值(一键跑品传入)→ 直接用该份数,跳过"发布几条"交互弹窗。"""
        if getattr(self, "_pdd_qrun_active", False) and not getattr(self, "_pdd_qrun_paused", False):
            sel = [s for s in self._pdd_pending_get_selected_ids() if s]
            detail = f"勾选 {len(sel)} 条" if sel else "当前全部待发布"
            self._task_center_enqueue(
                "待发布队列",
                lambda preset_copies=preset_copies: self._pdd_pending_start_queue(preset_copies),
                f"等待当前待发布队列结束后自动开始 · {detail}")
            self.pdd_pending_status.setText("已加入任务中心，等待当前队列结束后继续")
            return
        # ★「无人值守」总开关:一键跑品(传了 preset_copies)= True → 全程不弹框、自动续;
        #   手动发布 = False → 该弹的框照弹。每次启动队列重设,不留残留。
        #   手动发布时,换图/视频两步按当前「全自动」勾选框定(避免沿用上次一键跑品的步骤)。
        self._oc_unattended = (preset_copies is not None)
        if not self._oc_unattended:
            _v = bool(getattr(self, "pdd_pending_chk_auto", None) and self.pdd_pending_chk_auto.isChecked())
            self._oc_steps = {"compare": True, "check": True, "publish": True,
                              "main_img": _v, "video": _v, "promote": False}
        self._pdd_qrun_paused = False
        self._pdd_qrun_stop_requested = False
        # 批量结果累积(本次队列周期内,每条完成后追加)
        if not getattr(self, "_pdd_qrun_batch", None):
            self._pdd_qrun_batch = {"success": [], "failed": []}
        # 捕获勾选范围(仅在"新启动"时,resume 时沿用上次的)
        if not self._pdd_qrun_active:
            sel = [s for s in self._pdd_pending_get_selected_ids() if s]
            if sel:
                sel_set = set(sel)
                # 勾选里若有"失败"状态的 → 先重置成 pending,这样能被队列跑到
                # (运行中的不动;已是 pending 的保持)
                changed = False
                for r in self._pdd_pending_records:
                    if (r.get("id") in sel_set
                            and r.get("publish_status") == pending_publish.STATUS_FAILED):
                        r["publish_status"] = pending_publish.STATUS_PENDING
                        r["fail_reason"] = ""
                        changed = True
                if changed:
                    try: pending_publish.save_pending(self._pdd_pending_records)
                    except Exception: pass
                    self._pdd_pending_apply_filter()
                self._pdd_qrun_selected_ids = sel_set
                self.pdd_pending_status.setText(f"▶ 只跑勾选的 {len(sel_set)} 条")
            else:
                # 一条没勾 → 跑全部待发布(老行为)
                self._pdd_qrun_selected_ids = None
            # ── 发布前预检:未核对备案号的化妆品 → 硬拦整批 + 一键核对 ──
            _gsel = self._pdd_qrun_selected_ids
            if _gsel:
                _gtargets = [r for r in self._pdd_pending_records
                             if r.get("id") in _gsel
                             and r.get("publish_status") == pending_publish.STATUS_PENDING]
            else:
                _gtargets = [r for r in self._pdd_pending_records
                             if r.get("publish_status") == pending_publish.STATUS_PENDING]
            self._auto_resume_copies = preset_copies   # 全自动:核对完续发要用回这个份数
            if not self._pdd_license_gate_ok(_gtargets, auto=getattr(self, "_oc_unattended", False)):
                # 取消 / 去核对 → 不开跑(无人值守时核对完会自动重启本队列)
                self.pdd_pending_status.setText("⏸ 已暂停:请先核对备案号再发布"
                                                if not getattr(self, "_oc_unattended", False)
                                                else "🤖 无人值守:正在自动核对备案号,完后自动继续发布…")
                return
            # ── 同商品发多条:问 N → 克隆 N-1 份(每份不同 carousel_shift)──
            cur_sel = self._pdd_qrun_selected_ids   # set=只跑勾选 / None=跑全部
            if preset_copies is not None:
                # 一键跑品已在开头问过份数 → 直接用,不再弹窗(否则会卡住自动流程)
                n_copies, ok = int(preset_copies), True
            else:
                from PyQt5.QtWidgets import QInputDialog
                n_copies, ok = QInputDialog.getInt(
                    self, "每个商品发布几条",
                    "同一商品发布多条时,程序会逐条发布并自动错开主图\n"
                    "(把轮播图第 2/3… 张拖成主图),避免被 PDD 判定重复铺货。\n\n"
                    "每个商品发布几条?(1=只发 1 条,维持现状)",
                    1, 1, 20, 1)
            if ok and n_copies >= 2:
                import uuid as _uuid
                recs = pending_publish.load_pending()
                if cur_sel:
                    targets = [r for r in recs if r.get("id") in cur_sel
                               and r.get("publish_status") == pending_publish.STATUS_PENDING]
                else:
                    targets = [r for r in recs
                               if r.get("publish_status") == pending_publish.STATUS_PENDING]
                new_sel = set(cur_sel) if cur_sel else set()
                added = 0
                for t in targets:
                    t["carousel_shift"] = 0           # 原记录 = 第 1 条,主图不动
                    new_sel.add(t.get("id"))
                    for k in range(1, n_copies):
                        clone = dict(t)
                        clone["id"] = _uuid.uuid4().hex[:12]
                        clone["carousel_shift"] = k    # 第 k+1 条 → 第 k 张当主图
                        clone["publish_status"] = pending_publish.STATUS_PENDING
                        clone["fail_reason"] = ""
                        clone["start_time"] = ""
                        clone["finish_time"] = ""
                        clone["submit_time"] = ""      # _normalize 会补当前时间
                        clone["attempt_count"] = 0
                        recs.append(clone)
                        new_sel.add(clone["id"])
                        added += 1
                if targets:
                    try:
                        pending_publish.save_pending(recs)
                    except Exception as _e:
                        QMessageBox.warning(self, "发多条", f"保存克隆记录失败:\n{_e}")
                    self._pdd_pending_records = pending_publish.load_pending()
                    # 扩展后把跑的范围锁定到这些(含克隆),避免误跑到其它 pending
                    self._pdd_qrun_selected_ids = new_sel
                    self._pdd_pending_apply_filter()
                    self.pdd_pending_status.setText(
                        f"▶ 发 {len(targets)} 个商品 × {n_copies} 条(克隆 +{added} 条)")
                else:
                    QMessageBox.information(self, "发多条", "没有可发布的待发布(pending)商品")
            elif ok:
                # 发单条(n_copies=1):清掉记录里可能残留的 carousel_shift,避免之前"发多条"留下的
                # shift 值让单条发布也去重排轮播图(把第N张拖成主图)。只动本次要发的 pending 记录。
                _recs = pending_publish.load_pending()
                _sel = self._pdd_qrun_selected_ids
                _changed = False
                for r in _recs:
                    if r.get("publish_status") != pending_publish.STATUS_PENDING:
                        continue
                    if _sel and r.get("id") not in _sel:
                        continue
                    if r.get("carousel_shift", 0):
                        r["carousel_shift"] = 0
                        _changed = True
                if _changed:
                    try:
                        pending_publish.save_pending(_recs)
                        self._pdd_pending_records = pending_publish.load_pending()
                    except Exception:
                        pass
        if self._pdd_qrun_active:
            # 已暂停后恢复:继续当前队列；运行中点开始会在函数开头进入任务中心预约。
            self.pdd_pending_status.setText("▶ 队列继续")
            self.pdd_pending_btn_pause.setEnabled(True)
            self.pdd_pending_btn_stop.setEnabled(True)
            self.pdd_pending_btn_start.setEnabled(True)
            self.pdd_pending_btn_start.setText("预约队列")
            self._pdd_pending_process_next()
            return
        self._pdd_qrun_active = True
        self.pdd_pending_btn_start.setEnabled(True)
        self.pdd_pending_btn_start.setText("预约队列")
        self.pdd_pending_btn_pause.setEnabled(True)
        self.pdd_pending_btn_stop.setEnabled(True)
        self._pdd_pending_process_next()

    def _pdd_pending_pause_queue(self):
        self._pdd_qrun_paused = True
        self.pdd_pending_status.setText("⏸ 已请求暂停(当前条跑完后停)")
        # 按钮:仅 start(恢复) + stop 可用
        self.pdd_pending_btn_start.setEnabled(True)
        self.pdd_pending_btn_start.setText("▶ 继续")
        self.pdd_pending_btn_pause.setEnabled(False)

    def _pdd_pending_stop_queue(self):
        """杀子进程 + 清队列状态。并发模式下杀所有活跃子进程。"""
        n_active = len(self._pdd_qrun_active_jobs) or (1 if self._pdd_qrun_proc else 0)
        if QMessageBox.question(self, "确认停止",
                f"立即停止队列?\n当前 {n_active} 个发布子进程会被杀(PDD 可能留半成品)",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._pdd_qrun_stop_requested = True
        # 杀单条模式的 proc
        try:
            if self._pdd_qrun_proc and self._pdd_qrun_proc.state() != QProcess.NotRunning:
                self._pdd_qrun_proc.kill()
        except Exception:
            pass
        # 杀并发模式的所有活跃 proc
        for rid, job in list(self._pdd_qrun_active_jobs.items()):
            try:
                p = job.get("proc")
                if p and p.state() != QProcess.NotRunning:
                    p.kill()
            except Exception:
                pass

    def _pdd_pending_process_next(self):
        """从 pending 取下一批处理。模式:单条排队 vs 多店铺并发。"""
        if self._pdd_qrun_paused:
            return  # 暂停期间不取新条
        if self._pdd_qrun_stop_requested:
            self._pdd_qrun_active = False
            self._pdd_qrun_stop_requested = False
            self.pdd_pending_status.setText("⏹ 队列已停止")
            self.pdd_pending_btn_start.setEnabled(True)
            self.pdd_pending_btn_start.setText("▶ 开始队列")
            self.pdd_pending_btn_pause.setEnabled(False)
            self.pdd_pending_btn_stop.setEnabled(False)
            QTimer.singleShot(300, self._task_center_try_start_next)
            return

        # 读模式
        mode_idx = self.pdd_pending_mode.currentIndex() if hasattr(self, "pdd_pending_mode") else 0
        is_concurrent = (mode_idx == 1)

        sel_ids = getattr(self, "_pdd_qrun_selected_ids", None)  # None=跑全部
        # ── 并发模式:循环填满直到 max_concurrent 或没人可启 ──
        if is_concurrent:
            self._pdd_pending_records = pending_publish.load_pending()
            launched_now = 0
            while len(self._pdd_qrun_active_jobs) < self._pdd_qrun_max_concurrent:
                active_stores = {j["store"] for j in self._pdd_qrun_active_jobs.values()}
                # 找下一条 pending 且 store 不在活跃集(且在勾选范围内)
                rec = None
                for r in self._pdd_pending_records:
                    if r.get("publish_status") != pending_publish.STATUS_PENDING:
                        continue
                    if sel_ids is not None and r.get("id") not in sel_ids:
                        continue
                    if (r.get("store") or "") in active_stores:
                        continue
                    rec = r
                    break
                if not rec:
                    break
                if self._pdd_pending_launch_one(rec):
                    launched_now += 1
                # 若 launch_one 内部 mark_failed 了,继续 while 看还有没有别的
            # 重渲染表格
            self._pdd_pending_apply_filter()
            if not self._pdd_qrun_active_jobs:
                # 没在跑也没启起来 → 队列空
                self._pdd_qrun_active = False
                self.pdd_pending_status.setText("✅ 队列空闲(无待发布)")
                self.pdd_pending_btn_start.setEnabled(True)
                self.pdd_pending_btn_start.setText("▶ 开始队列")
                self.pdd_pending_btn_pause.setEnabled(False)
                self.pdd_pending_btn_stop.setEnabled(False)
                batch = getattr(self, "_pdd_qrun_batch", None)
                if batch and (batch["success"] or batch["failed"]):
                    started_followup = self._pdd_show_batch_summary(batch)
                    self._pdd_qrun_batch = {"success": [], "failed": []}
                    if self._task_center_should_defer_dialog() and not started_followup:
                        ok = not bool(batch.get("failed"))
                        detail = f"待发布队列完成:成功 {len(batch.get('success', []))} · 失败 {len(batch.get('failed', []))}"
                        if self._task_center_is_queued_run():
                            self._task_center_finish_current(ok, detail)
                        else:
                            QTimer.singleShot(500, self._task_center_try_start_next)
                elif self._task_center_should_defer_dialog():
                    if self._task_center_is_queued_run():
                        self._task_center_finish_current(True, "待发布队列完成:无待发布记录")
                    else:
                        QTimer.singleShot(500, self._task_center_try_start_next)
                return
            self.pdd_pending_status.setText(
                f"🚀 并发运行中,活跃 {len(self._pdd_qrun_active_jobs)}/{self._pdd_qrun_max_concurrent}"
                + (f" (新启 {launched_now})" if launched_now else ""))
            return

        # ── 单条模式(原逻辑,完全不动)──
        # 若并发模式下还有未完成的 job(用户切模式了),先等清完再走 serial 路径
        if self._pdd_qrun_active_jobs or self._pdd_qrun_proc is not None:
            return
        # 重读最新(用户可能删了)
        self._pdd_pending_records = pending_publish.load_pending()
        # 勾选范围内取下一条 pending;sel_ids=None 时退回原 next_pending(全部)
        if sel_ids is not None:
            rec = next((r for r in self._pdd_pending_records
                        if r.get("publish_status") == pending_publish.STATUS_PENDING
                        and r.get("id") in sel_ids), None)
        else:
            rec = pending_publish.next_pending(self._pdd_pending_records)
        if not rec:
            self._pdd_qrun_active = False
            self.pdd_pending_status.setText("✅ 队列空闲(无待发布)")
            self.pdd_pending_btn_start.setEnabled(True)
            self.pdd_pending_btn_start.setText("▶ 开始队列")
            self.pdd_pending_btn_pause.setEnabled(False)
            self.pdd_pending_btn_stop.setEnabled(False)
            self._pdd_pending_apply_filter()
            # 批量结束 → 汇总弹窗(只在有结果时弹;同时清空累积容器)
            batch = getattr(self, "_pdd_qrun_batch", None)
            if batch and (batch["success"] or batch["failed"]):
                started_followup = self._pdd_show_batch_summary(batch)
                self._pdd_qrun_batch = {"success": [], "failed": []}
                if self._task_center_should_defer_dialog() and not started_followup:
                    ok = not bool(batch.get("failed"))
                    detail = f"待发布队列完成:成功 {len(batch.get('success', []))} · 失败 {len(batch.get('failed', []))}"
                    if self._task_center_is_queued_run():
                        self._task_center_finish_current(ok, detail)
                    else:
                        QTimer.singleShot(500, self._task_center_try_start_next)
            elif self._task_center_should_defer_dialog():
                if self._task_center_is_queued_run():
                    self._task_center_finish_current(True, "待发布队列完成:无待发布记录")
                else:
                    QTimer.singleShot(500, self._task_center_try_start_next)
            return
        # 单条模式启动这一条
        self._pdd_pending_launch_one(rec)
        return

    def _pdd_pending_launch_one(self, rec) -> bool:
        """启动一条 record 的发布子进程(单条/并发模式共用)。
        成功返回 True;图片获取/启动失败已 mark_failed,返回 False。
        并发模式下,会把 job 信息存到 self._pdd_qrun_active_jobs[rec_id]。
        单条模式下,沿用 self._pdd_qrun_proc / _pdd_qrun_current_id 老字段(保持回调兼容)。
        """
        # 准备图片:开关=货源图时优先下载 1688 货源图;否则/查不到 → 选品图(image_local 优先,否则下载 image URL)
        import urllib.request, uuid as _uuid, threading as _thr
        from PyQt5.QtWidgets import QApplication as _QApp
        image_local = rec.get("image_local") or ""
        image_url = rec.get("image") or ""
        tmp_dir = Path(r"D:/files/data/pdd/temp")
        use_src = self._pdd_publish_use_source()
        src_url = self._pdd_source_image_for_publish(rec)   # 货源图(原图):存进记录 + 开关开时当发布图
        tmp_path = ""
        # ★ 下载放后台线程,主线程边等边 processEvents → 界面绝不冻(未响应根因:下图卡在 DNS/连接,
        #   而 urlopen 的 timeout 管不了 DNS 解析)。最多等 25s,超时/失败 → 走下面 except 标失败、跑下一条。
        _dlres = {}
        def _do_dl():
            def _dl(_u, _dst, _to=20):
                import hashlib as _h, shutil as _sh
                # ★ 先用本地缓存(和 ImageBatchLoader 同一套,表格缩略图就是它下的)→ 命中=0网络、秒取
                _cp = Path(r"D:/files/data/img_cache") / _h.md5(_u.encode("utf-8")).hexdigest()
                if _cp.exists() and _cp.stat().st_size > 0:
                    _sh.copyfile(str(_cp), _dst); return
                _req = urllib.request.Request(_u, headers={"User-Agent": "Mozilla/5.0"})
                with _DL_OPENER.open(_req, timeout=_to) as _r, open(_dst, "wb") as _f:
                    _f.write(_r.read())
            try:
                _tp = ""
                if use_src and src_url:                       # ① 货源图模式
                    try:
                        tmp_dir.mkdir(parents=True, exist_ok=True)
                        _p = str(tmp_dir / f"pdd_pub_{_uuid.uuid4().hex[:12]}.jpg")
                        _dl(src_url, _p); _tp = _p
                        print(f"[发布用图] 货源图 {src_url[:70]}", flush=True)
                    except Exception as e:
                        print(f"[发布用图] 货源图下载失败,回退选品图: {e}", flush=True)
                if not _tp:                                   # ② 选品图(默认/回退)
                    if image_local and Path(image_local).exists():
                        _tp = image_local
                    elif image_url:
                        tmp_dir.mkdir(parents=True, exist_ok=True)
                        _p = str(tmp_dir / f"pdd_pub_{_uuid.uuid4().hex[:12]}.jpg")
                        _dl(image_url, _p); _tp = _p
                    else:
                        raise ValueError("缺图片(image 和 image_local 都为空)")
                _dlres["path"] = _tp
            except Exception as e:
                _dlres["err"] = e
        _dt = _thr.Thread(target=_do_dl, daemon=True); _dt.start()
        _waited = 0.0
        while _dt.is_alive() and _waited < 25:
            _QApp.processEvents(); time.sleep(0.05); _waited += 0.05
        try:
            if _dt.is_alive():
                raise TimeoutError("图片下载超时(URL失效/DNS解析卡住),已跳过")
            if _dlres.get("err"):
                raise _dlres["err"]
            tmp_path = _dlres.get("path") or ""
            if not tmp_path:
                raise ValueError("缺图片(image 和 image_local 都为空)")
        except Exception as e:
            self._pdd_pending_records = pending_publish.mark_failed(
                self._pdd_pending_records, rec["id"], f"图片获取失败: {e}")
            try: pending_publish.save_pending(self._pdd_pending_records)
            except Exception: pass
            self._pdd_pending_apply_filter()
            mode_idx = self.pdd_pending_mode.currentIndex() if hasattr(self, "pdd_pending_mode") else 0
            if mode_idx == 0:  # serial
                QTimer.singleShot(400, self._pdd_pending_process_next)
            return False
        # 标记 running
        self._pdd_pending_records = pending_publish.mark_running(self._pdd_pending_records, rec["id"])
        try: pending_publish.save_pending(self._pdd_pending_records)
        except Exception: pass
        # 单条模式沿用老字段(回调依赖)
        self._pdd_qrun_current_id = rec["id"]
        self._pdd_qrun_tmp_path = tmp_path
        self._pdd_pending_apply_filter()
        self.pdd_pending_status.setText(f"🚀 发布中: {rec.get('name','')[:40]}…")

        # 启动 pdd_publish.py 子进程
        # 子进程 stdout 实时落盘到 data/pdd/publish_logs/<id>_<时间>.log,
        # 失败时 fail_reason 附日志文件名,方便人工查
        log_dir = Path(r"D:/files/data/pdd/publish_logs")
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"{rec['id']}_{time.strftime('%Y%m%d_%H%M%S')}.log"
        try:
            log_file = open(log_path, "w", encoding="utf-8")
        except Exception:
            log_file = None
        # 启动时间戳(用于 history 匹配判断成功)
        start_iso = time.strftime("%Y-%m-%d %H:%M:%S")

        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)

        def _on_stdout(p=proc, lf=log_file):
            try:
                chunk = bytes(p.readAllStandardOutput()).decode("utf-8", errors="replace")
                if lf:
                    lf.write(chunk)
                    lf.flush()
            except Exception:
                pass
        proc.readyReadStandardOutput.connect(_on_stdout)

        # log_prefix 不含扩展名,pdd_publish.py 失败时用它做截图文件名前缀
        log_prefix = str(Path(log_path).with_suffix(""))
        # 备案号/是否特殊:优先取商品库最新核对值(发布前预核对的结果),查不到用记录冻结值兜底
        _lchk, _lisp, _lno = self._pdd_license_status_for(rec)
        args = [
            "-u", r"D:/files/pdd_publish.py",
            "--store", rec.get("store", ""),
            "--image", tmp_path,
            "--xuanpin-image-url", image_url or "",      # 选品图URL:平移进 history 供已发布展示
            "--source-image-url",  src_url or "",        # 货源图URL:平移进 history 供已发布展示
            "--supplier-url", rec.get("supplier_link", ""),
            "--supplier-cost", str(rec.get("supplier_cost", 0) or 0),
            # 商品库已核对的批准文号/是否特殊 → 传过去,pdd_publish 直接用,免开 1688 重抓
            "--is-special",   str(_lisp or ""),
            "--license-no",   str(_lno or ""),
            # 同商品发多条:第 2/3… 条把轮播图第 N 张拖成主图,防重复铺货(0=不动)
            "--carousel-shift", str(int(rec.get("carousel_shift", 0) or 0)),
            "--shipping",     str(rec.get("rule_shipping", 4.0)),
            "--margin",       str(rec.get("rule_margin", 0.9)),
            "--single-extra", str(rec.get("rule_single_buy_extra", 2.0)),
            "--suffix",       str(rec.get("rule_spec_suffix", "+面膜1片")),
            "--stock",        str(int(rec.get("rule_stock", 8888))),
            "--rule-name",    str(rec.get("pricing_rule_name", "")),
            "--log-prefix",   log_prefix,
            "--auto-close",
        ]
        if self._pdd_smart_sku_on():
            args.append("--smart-sku")
        # 同款核对闸门:人工强发的记录走 --force-style(无视VLM,相似度+热度挑);其余正常走 --vlm-gate
        if rec.get("_force_style"):
            args.append("--force-style")
        else:
            args.append("--vlm-gate")
        args += self._pdd_browser_args()
        proc.finished.connect(
            lambda code, _s, r=rec, p=tmp_path, lf=log_file, lp=str(log_path), st=start_iso:
                self._pdd_pending_on_finished(code, r, p, lf, lp, st))
        self._pdd_qrun_proc = proc
        # 并发模式:把 job 信息存到字典(以 rec_id 为 key,store 为分组依据)
        self._pdd_qrun_active_jobs[rec["id"]] = {
            "store": rec.get("store", ""),
            "proc": proc,
            "tmp_path": tmp_path,
            "log_file": log_file,
            "log_path": str(log_path),
            "start_iso": start_iso,
            "name": rec.get("name", ""),
        }
        proc.start(sys.executable, args)
        return True

    def _pdd_pending_on_finished(self, exit_code, rec, tmp_path, log_file, log_path, start_iso):
        """子进程完成回调(严格成功判定)。

        成功条件:exit_code in (0, 2) **且** history.json 里有匹配条目
        (匹配 = 同 store + time >= start_iso)。history 没记录 = 没真上架 → 失败。
        失败时 fail_reason 附 log 文件名,方便人工排查。
        """
        # 关 log 文件
        try:
            if log_file:
                log_file.close()
        except Exception:
            pass

        # 清临时图
        try:
            if tmp_path and tmp_path.startswith(str(Path(r"D:/files/data/pdd/temp"))):
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
        except Exception:
            pass

        # 校验 history 是否真新增了本次记录
        matched = None
        try:
            history_path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
            if history_path.exists():
                import json as _json
                hist = _json.load(open(history_path, encoding="utf-8-sig"))
                if isinstance(hist, list):
                    rec_store = rec.get("store", "")
                    for h in reversed(hist):  # 倒序,最近的优先
                        if (h.get("store") == rec_store
                                and h.get("time", "") >= start_iso):
                            matched = h
                            break
        except Exception as e:
            print(f"[on_finished] 校验 history 异常: {e}")

        self._pdd_pending_records = pending_publish.load_pending()

        really_success = (exit_code in (0, 2)) and (matched is not None)

        # 准备批量累积容器
        if not getattr(self, "_pdd_qrun_batch", None):
            self._pdd_qrun_batch = {"success": [], "failed": []}

        if really_success:
            # 真成功 → 从 pending 删
            self._pdd_pending_records, _ = pending_publish.delete_by_ids(
                self._pdd_pending_records, [rec["id"]])
            try: pending_publish.save_pending(self._pdd_pending_records)
            except Exception: pass
            hstatus = matched.get("status", "")
            msg_title = "✅ 发布成功" if hstatus == "ok" else f"⚠ 已上架({hstatus})"
            self.pdd_pending_status.setText(f"{msg_title}: {rec.get('name','')[:30]}")
            # 累积到批量结果(不立即弹窗,队列结束时一次性汇总)
            self._pdd_qrun_batch["success"].append({
                "name":     rec.get("name", ""),
                "store":    rec.get("store", ""),
                "rule":     rec.get("pricing_rule_name", ""),
                "goods_id": matched.get("goods_id", "-"),
                "status":   hstatus,
            })
        else:
            # 失败:exit 看似成功但 history 没记录 / exit 非 0-2 / 用户手动停止
            # 先扫日志看有没有 LOGIN_REQUIRED(店铺掉线特定标记)
            login_dropped = False
            no_same_style = False
            _ltext = ""
            try:
                if log_path and Path(log_path).exists():
                    with open(log_path, encoding="utf-8", errors="ignore") as _lf:
                        _ltext = _lf.read()
                    if "[LOGIN_REQUIRED]" in _ltext:
                        login_dropped = True
                    if "status=no_same_style" in _ltext:
                        no_same_style = True
            except Exception:
                pass
            if self._pdd_qrun_stop_requested:
                reason = "用户手动停止"
            elif login_dropped:
                reason = f"🔑 店铺「{rec.get('store','')}」cookie 已过期,请到「店铺管理 → 重新登录」扫码"
            elif no_same_style:
                reason = "🟡 无同款·品牌不一致(AI核对前7候选都不是同款,未发布)→ 勾选本品点「人工强发」可按相似度+热度强制发布"
            elif exit_code in (0, 2) and matched is None:
                reason = f"子进程 exit={exit_code} 但 history 未记录,实际未上架"
            else:
                reason = f"子进程退出码 {exit_code}"
            try:
                reason += (f" | 日志: {Path(log_path).name}"
                           f"  截图: 同目录 {Path(log_path).stem}_fail_pageN.png")
            except Exception:
                pass
            self._pdd_pending_records = pending_publish.mark_failed(
                self._pdd_pending_records, rec["id"], reason)
            try: pending_publish.save_pending(self._pdd_pending_records)
            except Exception: pass
            self.pdd_pending_status.setText(f"❌ 失败: {rec.get('name','')[:30]} ({reason[:60]})")
            self._pdd_qrun_batch["failed"].append({
                "name":   rec.get("name", ""),
                "store":  rec.get("store", ""),
                "reason": reason,
            })

        self._pdd_qrun_proc = None
        self._pdd_qrun_current_id = ""
        self._pdd_qrun_tmp_path = ""
        # 并发模式:从活跃 jobs 字典移除本条
        self._pdd_qrun_active_jobs.pop(rec.get("id", ""), None)
        self._pdd_pending_apply_filter()
        # 同步刷新已发布页(若该页已加载)
        try:
            if hasattr(self, "_pdd_load_published"):
                self._pdd_load_published()
        except Exception:
            pass
        # 继续推进队列(单条模式取下一条,并发模式补满)
        QTimer.singleShot(800, self._pdd_pending_process_next)

    def _on_pdd_nav_changed(self, i: int):
        """切换 PDD 左侧子导航。首次打开某页时才创建该页，避免启动时预渲染所有表。"""
        created = self._ensure_pdd_page_built(i)
        self.pdd_stack.setCurrentIndex(i)
        if created:
            self._pdd_schedule_initial_page_load(i)
            return
        if i == 0 and hasattr(self, "pdd_lib_table"):
            self._pdd_library_reload()
        elif i == 1 and hasattr(self, "pdd_pending_table"):
            self._pdd_pending_reload()
        elif i == 3 and hasattr(self, "pdd_zs_store"):
            self._pdd_zs_refresh_stores()
    # ════════════════════════════════════════════════════════════════════════
    #  🚗 自动推广子页(承接「已发布·未下架」在架商品 → 表格选品 → 一键开车)
    #  版面对齐「生图换图」:表格(货品图/商品名/店铺/状态/操作)+ 勾选 + 批量;引擎 roas_auto.py
    # ════════════════════════════════════════════════════════════════════════

    # ════════════════════════════════════════════════════════════════════════
    #  📉 店铺监控下架:扫描 30日销量 / 创建时间 → 复用批量下架
    # ════════════════════════════════════════════════════════════════════════

    def _build_pdd_page_zero_sales_monitor(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(6)
        title = QLabel("📉 店铺监控下架")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        tip = QLabel("扫描 PDD 商品列表中的在售商品,按创建时间和30日销量筛选滞销品;立即下架会复用已验证的批量下架流程并回写已发布状态。")
        tip.setStyleSheet("color:#6B7280;font-size:11px;"); tip.setWordWrap(True)
        lay.addWidget(tip)

        top = QHBoxLayout(); top.setSpacing(8)
        top.addWidget(QLabel("店铺"))
        self.pdd_zs_store = QComboBox(); self.pdd_zs_store.setMinimumWidth(180)
        top.addWidget(self.pdd_zs_store)
        top.addWidget(QLabel("上架天数≥"))
        self.pdd_zs_days = QSpinBox(); self.pdd_zs_days.setRange(1, 365); self.pdd_zs_days.setValue(14); self.pdd_zs_days.setSuffix(" 天")
        top.addWidget(self.pdd_zs_days)
        top.addWidget(QLabel("30日销量≤"))
        self.pdd_zs_sales = QSpinBox(); self.pdd_zs_sales.setRange(0, 999999); self.pdd_zs_sales.setValue(0)
        top.addWidget(self.pdd_zs_sales)
        top.addWidget(QLabel("最多页"))
        self.pdd_zs_max_pages = QSpinBox(); self.pdd_zs_max_pages.setRange(1, 100); self.pdd_zs_max_pages.setValue(20)
        top.addWidget(self.pdd_zs_max_pages)
        top.addWidget(QLabel("限制条数"))
        self.pdd_zs_limit = QSpinBox(); self.pdd_zs_limit.setRange(0, 50); self.pdd_zs_limit.setValue(0); self.pdd_zs_limit.setToolTip("0=全部命中;测试真实下架时建议先设为1")
        top.addWidget(self.pdd_zs_limit)
        top.addStretch(1)
        lay.addLayout(top)

        row = QHBoxLayout(); row.setSpacing(8)
        self.pdd_zs_show_browser = QCheckBox("显示浏览器")
        self.pdd_zs_show_browser.setChecked(self._pdd_task_center_show_browser_on())
        self.pdd_zs_show_browser.toggled.connect(self._pdd_set_task_center_show_browser)
        row.addWidget(self.pdd_zs_show_browser)
        self.pdd_zs_keep_open = QCheckBox("执行后保留浏览器")
        self.pdd_zs_keep_open.setChecked(False)
        row.addWidget(self.pdd_zs_keep_open)
        self.pdd_zs_auto_monitor = QCheckBox("自动监控")
        row.addWidget(self.pdd_zs_auto_monitor)
        row.addWidget(QLabel("间隔"))
        self.pdd_zs_interval = QSpinBox(); self.pdd_zs_interval.setRange(1, 24); self.pdd_zs_interval.setValue(1); self.pdd_zs_interval.setSuffix(" 天")
        row.addWidget(self.pdd_zs_interval)
        self.pdd_zs_auto_apply = QCheckBox("命中后自动下架")
        self.pdd_zs_auto_apply.setToolTip("高风险:自动监控命中后会直接执行批量下架;默认关闭")
        row.addWidget(self.pdd_zs_auto_apply)
        row.addStretch(1)
        lay.addLayout(row)

        btns = QHBoxLayout(); btns.setSpacing(8)
        self.pdd_zs_btn_refresh_store = QPushButton("刷新店铺")
        self.pdd_zs_btn_scan = QPushButton("扫描预览")
        self.pdd_zs_btn_apply = QPushButton("立即下架")
        self.pdd_zs_btn_stop = QPushButton("停止")
        self.pdd_zs_btn_clear_done = QPushButton("清除已下架")
        self.pdd_zs_btn_apply.setStyleSheet("QPushButton{background:#EF4444;color:white;border:none;border-radius:4px;padding:6px 12px;}QPushButton:hover{background:#DC2626;}")
        self.pdd_zs_btn_scan.setStyleSheet("QPushButton{background:#2563EB;color:white;border:none;border-radius:4px;padding:6px 12px;}QPushButton:hover{background:#1D4ED8;}")
        self.pdd_zs_btn_refresh_store.clicked.connect(self._pdd_zs_refresh_stores)
        self.pdd_zs_btn_scan.clicked.connect(lambda: self._pdd_zs_launch(apply=False, auto=False))
        self.pdd_zs_btn_apply.clicked.connect(lambda: self._pdd_zs_launch(apply=True, auto=False))
        self.pdd_zs_btn_stop.clicked.connect(self._pdd_zs_stop)
        self.pdd_zs_btn_clear_done.clicked.connect(self._pdd_zs_clear_taken_down_records)
        self.pdd_zs_auto_monitor.toggled.connect(self._pdd_zs_toggle_auto)
        btns.addWidget(self.pdd_zs_btn_refresh_store)
        btns.addWidget(self.pdd_zs_btn_scan)
        btns.addWidget(self.pdd_zs_btn_apply)
        btns.addWidget(self.pdd_zs_btn_stop)
        btns.addWidget(self.pdd_zs_btn_clear_done)
        btns.addStretch(1)
        self.pdd_zs_status = QLabel("等待扫描")
        self.pdd_zs_status.setStyleSheet("color:#6B7280;font-size:11px;")
        btns.addWidget(self.pdd_zs_status)
        lay.addLayout(btns)

        self.pdd_zs_table = QTableWidget()
        self.pdd_zs_table.setColumnCount(7)
        self.pdd_zs_table.setHorizontalHeaderLabels(["店铺", "goods_id", "30日销量", "上架天数", "创建时间", "商品名", "状态"])
        self.pdd_zs_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        self.pdd_zs_table.setColumnWidth(0, 150)
        self.pdd_zs_table.setColumnWidth(1, 135)
        self.pdd_zs_table.setColumnWidth(2, 85)
        self.pdd_zs_table.setColumnWidth(3, 85)
        self.pdd_zs_table.setColumnWidth(4, 140)
        self.pdd_zs_table.setColumnWidth(6, 80)
        self.pdd_zs_table.setAlternatingRowColors(True)
        lay.addWidget(self.pdd_zs_table, 1)

        self.pdd_zs_log = QPlainTextEdit(); self.pdd_zs_log.setReadOnly(True); self.pdd_zs_log.setMaximumHeight(150)
        self.pdd_zs_log.setStyleSheet("font-family:Consolas,monospace;font-size:11px;")
        lay.addWidget(self.pdd_zs_log)

        self.pdd_zs_timer = QTimer(self)
        self.pdd_zs_timer.timeout.connect(self._pdd_zs_auto_tick)
        self._pdd_zs_refresh_stores()
        if self._pdd_zs_out_path().exists():
            self._pdd_zs_load_result()
        return page

    def _pdd_zs_refresh_stores(self):
        stores = self._pdd_get_store_list()
        if not stores:
            stores = sorted({(r.get("store") or "").strip()
                             for r in (getattr(self, "_pdd_pub_all", []) or []) if r.get("store")})
        cur = self.pdd_zs_store.currentText().strip() if hasattr(self, "pdd_zs_store") else ""
        self.pdd_zs_store.blockSignals(True)
        self.pdd_zs_store.clear()
        self.pdd_zs_store.addItem("全部")
        for s in stores:
            if s and s != "全部":
                self.pdd_zs_store.addItem(s)
        idx = self.pdd_zs_store.findText(cur)
        self.pdd_zs_store.setCurrentIndex(idx if idx >= 0 else 0)
        self.pdd_zs_store.blockSignals(False)
        self.pdd_zs_status.setText(f"已加载 {len(stores)} 个店铺" if stores else "没有可选店铺")

    def _pdd_zs_busy(self):
        p = getattr(self, "_pdd_zs_proc", None)
        return bool(p) and p.state() != QProcess.NotRunning

    def _pdd_zs_append_log(self, text):
        if not text:
            return
        self.pdd_zs_log.appendPlainText(text.rstrip())
        self.pdd_zs_log.verticalScrollBar().setValue(self.pdd_zs_log.verticalScrollBar().maximum())

    def _pdd_zs_out_path(self):
        return Path(r"C:/tmp/pdd_zero_sales_full_flow_gui.json")

    def _pdd_zs_launch(self, apply=False, auto=False):
        if self._pdd_zs_busy():
            self.pdd_zs_status.setText("已有监控任务进行中")
            if auto:
                self._pdd_zs_defer_auto("店铺监控任务仍在运行")
            return
        busy, name = self._pdd_browser_busy()
        if busy:
            if auto:
                self._pdd_zs_defer_auto(f"其它浏览器任务在跑:{name}")
            else:
                self.pdd_zs_status.setText(f"浏览器任务忙:{name}")
                QMessageBox.information(self, "店铺监控下架", f"已有浏览器任务进行中:{name}\n请等它结束后再执行。")
            return
        store = self.pdd_zs_store.currentText().strip()
        if not store:
            if not auto:
                QMessageBox.warning(self, "店铺监控下架", "请先选择店铺")
            return
        out_path = self._pdd_zs_out_path()
        input_candidates = None
        if apply:
            existing_rows = []
            if not auto:
                try:
                    import json as _json
                    scan_data = _json.load(open(out_path, encoding="utf-8-sig")) if out_path.exists() else {}
                    existing_rows = scan_data.get("candidates") or []
                    if not existing_rows:
                        QMessageBox.warning(self, "店铺监控下架", "当前没有可下架的扫描结果。请先点『扫描预览』确认命中商品。")
                        return
                    if store != "全部" and (scan_data.get("store") or "") != store:
                        QMessageBox.warning(self, "店铺监控下架", "当前扫描结果的店铺与所选店铺不一致，请重新扫描。")
                        return
                    scan_max_sales = scan_data.get("threshold_max_sales_30d")
                    if int(scan_data.get("threshold_days") or 0) != self.pdd_zs_days.value() or int(scan_max_sales if scan_max_sales is not None else -1) != self.pdd_zs_sales.value():
                        QMessageBox.warning(self, "店铺监控下架", "当前扫描结果与筛选规则不一致，请重新扫描。")
                        return
                    input_candidates = out_path
                except Exception as e:
                    QMessageBox.warning(self, "店铺监控下架", f"读取当前扫描结果失败：{e}")
                    return
            limit = self.pdd_zs_limit.value()
            count_text = len(existing_rows) if existing_rows else (limit if limit else "自动扫描命中")
            msg = (f"将下架店铺「{store}」的命中商品。\n\n"
                   f"规则:上架满 {self.pdd_zs_days.value()} 天且30日销量≤{self.pdd_zs_sales.value()}。\n"
                   f"本次数量:{count_text}\n"
                   f"来源:{'当前扫描结果' if input_candidates else '自动重新扫描'}\n\n此操作会真实下架 PDD 商品,确认执行?")
            if not auto and QMessageBox.question(self, "确认立即下架", msg,
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                return
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        args = [r"D:/files/pdd_zero_sales_monitor.py",
                "--store", store,
                "--days", str(self.pdd_zs_days.value()),
                "--max-sales", str(self.pdd_zs_sales.value()),
                "--pages", "0",
                "--max-pages", str(self.pdd_zs_max_pages.value()),
                "--out", str(out_path)]
        if self.pdd_zs_limit.value() > 0:
            args += ["--limit", str(self.pdd_zs_limit.value())]
        if apply and input_candidates:
            args += ["--input-candidates", str(input_candidates)]
        if self.pdd_zs_show_browser.isChecked():
            args.append("--show-browser")
        if self.pdd_zs_keep_open.isChecked():
            args.append("--keep-open")
        if apply:
            args += ["--apply", "--confirm", "APPLY_TAKEDOWN"]
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        from PyQt5.QtCore import QProcessEnvironment
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONIOENCODING", "utf-8"); env.insert("PYTHONUTF8", "1")
        proc.setProcessEnvironment(env)
        proc.readyReadStandardOutput.connect(lambda p=proc: self._pdd_zs_append_log(bytes(p.readAllStandardOutput()).decode("utf-8", errors="replace")))
        proc.finished.connect(lambda code, _s, ap=apply: self._pdd_zs_done(code, ap))
        self._pdd_zs_proc = proc
        self.pdd_zs_log.clear()
        self.pdd_zs_status.setText(("自动" if auto else "") + ("下架执行中" if apply else "扫描中"))
        proc.start(sys.executable, ["-u"] + args)

    def _pdd_zs_done(self, code, apply):
        self.pdd_zs_status.setText(f"完成 exit={code}")
        self._pdd_zs_load_result()
        if apply:
            try:
                self._pdd_load_published()
            except Exception:
                pass

    def _pdd_zs_taken_down_ids_from_result(self, data):
        taken_down_ids = set()
        apply_results = []
        if isinstance(data.get("apply_result"), dict):
            apply_results.append(data.get("apply_result"))
        for store_result in data.get("store_results") or []:
            if isinstance(store_result.get("apply_result"), dict):
                apply_results.append(store_result.get("apply_result"))
        for apply_result in apply_results:
            for batch in apply_result.get("batches") or []:
                if not batch.get("clicked"):
                    continue
                if int(batch.get("result_count") or 0) <= 0:
                    continue
                taken_down_ids.update(str(gid) for gid in (batch.get("goods_ids") or []) if gid)
        return taken_down_ids

    def _pdd_zs_load_result(self):
        import json as _json
        path = self._pdd_zs_out_path()
        try:
            data = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else {}
        except Exception as e:
            self.pdd_zs_status.setText(f"读取结果失败:{e}")
            return
        rows = data.get("candidates") or []
        taken_down_ids = self._pdd_zs_taken_down_ids_from_result(data)
        self.pdd_zs_table.setRowCount(0)
        taken_down_count = 0
        for rec in rows:
            r = self.pdd_zs_table.rowCount(); self.pdd_zs_table.insertRow(r)
            gid = str(rec.get("goods_id") or "")
            status = "已下架" if gid in taken_down_ids else "命中"
            if status == "已下架":
                taken_down_count += 1
            vals = [rec.get("store", ""), gid, rec.get("sales_30d", ""), rec.get("age_days", ""),
                    rec.get("created_time", ""), rec.get("title", ""), status]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(str(v))
                if c in (1, 2, 3, 4, 6):
                    it.setTextAlignment(Qt.AlignCenter)
                self.pdd_zs_table.setItem(r, c, it)
        if taken_down_count:
            self.pdd_zs_status.setText(f"已下架 {taken_down_count} 条 / 命中 {len(rows)} 条 · 扫描 {data.get('row_count', 0)} 条")
        else:
            self.pdd_zs_status.setText(f"命中 {len(rows)} 条 · 扫描 {data.get('row_count', 0)} 条")

    def _pdd_zs_clear_taken_down_records(self):
        import json as _json
        path = self._pdd_zs_out_path()
        if not path.exists():
            QMessageBox.information(self, "店铺监控下架", "当前没有可清理的扫描结果。")
            return
        try:
            data = _json.load(open(path, encoding="utf-8-sig"))
        except Exception as e:
            QMessageBox.warning(self, "店铺监控下架", f"读取扫描结果失败：{e}")
            return
        rows = data.get("candidates") or []
        if not isinstance(rows, list) or not rows:
            QMessageBox.information(self, "店铺监控下架", "当前扫描结果里没有候选记录。")
            return
        taken_down_ids = self._pdd_zs_taken_down_ids_from_result(data)
        if not taken_down_ids:
            QMessageBox.information(self, "店铺监控下架", "当前结果里没有已下架记录可清除。")
            return
        remaining = [rec for rec in rows if str(rec.get("goods_id") or "") not in taken_down_ids]
        removed = len(rows) - len(remaining)
        if removed <= 0:
            QMessageBox.information(self, "店铺监控下架", "当前表格中没有匹配到已下架记录。")
            return
        if QMessageBox.question(self, "清除已下架记录",
                f"将从当前扫描结果文件中移除 {removed} 条已下架记录。\n\n不会操作 PDD 后台，也不会删除发布历史。确认清除？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        data["candidates"] = remaining
        data["candidate_count"] = len(remaining)
        try:
            path.write_text(_json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.warning(self, "店铺监控下架", f"写入扫描结果失败：{e}")
            return
        self._pdd_zs_load_result()
        QMessageBox.information(self, "店铺监控下架", f"已清除 {removed} 条已下架记录，剩余 {len(remaining)} 条。")

    def _pdd_zs_stop(self):
        p = getattr(self, "_pdd_zs_proc", None)
        if p and p.state() != QProcess.NotRunning:
            p.kill()
            self.pdd_zs_status.setText("已停止")

    def _pdd_zs_defer_auto(self, reason: str):
        if not self.pdd_zs_auto_monitor.isChecked():
            return
        self._pdd_zs_pending_auto = True
        self._pdd_zs_pending_apply = bool(self.pdd_zs_auto_apply.isChecked())
        self.pdd_zs_status.setText(f"自动监控让位排队:{reason}; 持续排队,5分钟后重试")
        self._pdd_zs_append_log(f"[auto-wait] {reason}; retry in 5 minutes")
        if not getattr(self, "_pdd_zs_retry_scheduled", False):
            self._pdd_zs_retry_scheduled = True
            QTimer.singleShot(300000, self._pdd_zs_auto_retry)

    def _pdd_zs_auto_retry(self):
        self._pdd_zs_retry_scheduled = False
        if not self.pdd_zs_auto_monitor.isChecked():
            self._pdd_zs_pending_auto = False
            return
        if not getattr(self, "_pdd_zs_pending_auto", False):
            return
        if self._pdd_zs_busy():
            self._pdd_zs_defer_auto("店铺监控任务仍在运行")
            return
        busy, name = self._pdd_browser_busy()
        if busy:
            self._pdd_zs_defer_auto(f"其它浏览器任务在跑:{name}")
            return
        apply = bool(getattr(self, "_pdd_zs_pending_apply", False))
        self._pdd_zs_pending_auto = False
        self.pdd_zs_status.setText("自动监控排队结束,开始执行")
        self._pdd_zs_launch(apply=apply, auto=True)
    def _pdd_zs_toggle_auto(self, checked):
        if checked:
            if self.pdd_zs_auto_apply.isChecked():
                if QMessageBox.question(self, "自动下架确认",
                    "自动监控已勾选『命中后自动下架』,到点会真实下架命中商品。确认开启?",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                    self.pdd_zs_auto_monitor.setChecked(False)
                    return
            self._pdd_zs_pending_auto = False
            self._pdd_zs_retry_scheduled = False
            self.pdd_zs_timer.start(self.pdd_zs_interval.value() * 24 * 60 * 60 * 1000)
            self.pdd_zs_status.setText(f"自动监控已开:每 {self.pdd_zs_interval.value()} 天")
        else:
            self.pdd_zs_timer.stop()
            self._pdd_zs_pending_auto = False
            self._pdd_zs_retry_scheduled = False
            self.pdd_zs_status.setText("自动监控已关")

    def _pdd_zs_auto_tick(self):
        if not self.pdd_zs_auto_monitor.isChecked():
            return
        self._pdd_zs_launch(apply=self.pdd_zs_auto_apply.isChecked(), auto=True)
    def _build_pdd_page_autopromo(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(6)
        title = QLabel("🚗 自动推广(稳定成本推广)")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        tip = QLabel("承接【已发布、未下架】在架商品 → 算实际保本投产 → 开车(建稳定成本推广计划)。"
                     "「📊抓数据」回传花费/结算投产/成交;「🤖自动调车」按结算投产比 vs 保本止损关车。"
                     "开车/抓数据/关车会开浏览器,期间别碰鼠标键盘。")
        tip.setStyleSheet("color:#9CA3AF;font-size:11px;"); tip.setWordWrap(True)
        lay.addWidget(tip)

        # 行1:刷新 + 搜索 + 状态 + 店铺 + 统计
        bar1 = QHBoxLayout(); bar1.setSpacing(6)
        btn_reload = QPushButton("🔄 刷新"); btn_reload.clicked.connect(self._pdd_ap_reload_table)
        bar1.addWidget(btn_reload)
        bar1.addWidget(QLabel("搜索:"))
        self.pdd_ap_search = QLineEdit(); self.pdd_ap_search.setPlaceholderText("商品名 / goods_id；多个可用空格或逗号分隔"); self.pdd_ap_search.setFixedWidth(240)
        self.pdd_ap_search.textChanged.connect(self._pdd_ap_apply_filter)
        bar1.addWidget(self.pdd_ap_search)
        bar1.addWidget(QLabel("状态:"))
        self.pdd_ap_cat = QComboBox(); self.pdd_ap_cat.addItems(["全部", "未推广", "推广中", "受限", "已暂停"])
        self.pdd_ap_cat.currentIndexChanged.connect(self._pdd_ap_apply_filter)
        bar1.addWidget(self.pdd_ap_cat)
        bar1.addWidget(QLabel("阶段:"))
        self.pdd_ap_stage = QComboBox(); self.pdd_ap_stage.addItems(["全部", "一阶段", "二阶段"])
        self.pdd_ap_stage.currentIndexChanged.connect(self._pdd_ap_apply_filter)
        bar1.addWidget(self.pdd_ap_stage)
        bar1.addWidget(QLabel("店铺:"))
        self.pdd_ap_store = QComboBox(); self.pdd_ap_store.addItem("全部")
        self.pdd_ap_store.currentIndexChanged.connect(self._pdd_ap_apply_filter)
        bar1.addWidget(self.pdd_ap_store)
        btn_promo = QPushButton("🔗 推广中心")
        btn_promo.setToolTip("选店铺 → 用该店登录态打开推广中心列表页")
        btn_promo.setStyleSheet("background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;padding:4px 10px;")
        btn_promo.clicked.connect(self._pdd_ap_open_promo_center)
        bar1.addWidget(btn_promo)
        btn_policy = QPushButton("⚙ 调车设置"); btn_policy.clicked.connect(self._pdd_ap_policy_dialog); bar1.addWidget(btn_policy)
        btn_takedown = QPushButton("🚫 批量下架")
        btn_takedown.setToolTip("对选中的商品执行真下架：沿用已发布页的批量下架流程，按店铺串行并再次确认。")
        btn_takedown.setStyleSheet("background:#EF4444;color:white;border:none;border-radius:4px;padding:4px 10px;")
        btn_takedown.clicked.connect(self._pdd_ap_takedown_selected)
        bar1.addWidget(btn_takedown)
        btn_ignore_suggestion = QPushButton("\u5ffd\u7565\u5efa\u8bae")
        btn_ignore_suggestion.setToolTip("\u5ffd\u7565\u9009\u4e2d\u5546\u54c1\u7684\u6682\u505c\u3001\u4e0b\u67b6\u6216\u6295\u4ea7\u5efa\u8bae\uff1b\u4e0d\u6267\u884c\u4efb\u4f55\u62fc\u591a\u591a\u64cd\u4f5c")
        btn_ignore_suggestion.clicked.connect(lambda: self._pdd_ap_update_suggestions_selected("ignored"))
        bar1.addWidget(btn_ignore_suggestion)
        btn_confirm_suggestion = QPushButton("\u6807\u8bb0\u5df2\u4eba\u5de5\u5904\u7406")
        btn_confirm_suggestion.setToolTip("\u4ec5\u8bb0\u5f55\u9009\u4e2d\u5efa\u8bae\u5df2\u4eba\u5de5\u5904\u7406\uff1b\u4e0d\u4f1a\u6682\u505c\u3001\u4e0b\u67b6\u6216\u8c03\u6574\u6295\u4ea7")
        btn_confirm_suggestion.clicked.connect(lambda: self._pdd_ap_update_suggestions_selected("confirmed_manual"))
        bar1.addWidget(btn_confirm_suggestion)
        bar1.addStretch(1)
        self.pdd_ap_stats = QLabel(""); self.pdd_ap_stats.setStyleSheet("color:#6B7280;font-size:11px;")
        bar1.addWidget(self.pdd_ap_stats)
        lay.addLayout(bar1)

        # 行2:全选 + 档位/预算 + 开车 + 监控/自动调车 + 状态
        bar2 = QHBoxLayout(); bar2.setSpacing(6)
        btn_chk = QPushButton("☑ 全选当前"); btn_chk.clicked.connect(self._pdd_ap_toggle_all)
        bar2.addWidget(btn_chk)
        bar2.addWidget(QLabel("档位:"))
        self.pdd_ap_tier = QComboBox(); self.pdd_ap_tier.addItems(["10%盈利", "20%盈利", "实际保本"])
        self.pdd_ap_tier.setCurrentText("20%盈利")
        bar2.addWidget(self.pdd_ap_tier)
        bar2.addWidget(QLabel("日预算:"))
        self.pdd_ap_budget = QSpinBox(); self.pdd_ap_budget.setRange(200, 100000); self.pdd_ap_budget.setSingleStep(50); self.pdd_ap_budget.setValue(200)
        bar2.addWidget(self.pdd_ap_budget)
        self.pdd_ap_show_browser = QCheckBox("显示浏览器")
        self.pdd_ap_show_browser.setToolTip("勾上(默认)=开车/抓数据/关车/调车/自动调车时浏览器显示在屏幕上(可盯着看);不勾=屏幕外静默")
        self.pdd_ap_show_browser.setChecked(self._pdd_task_center_show_browser_on())
        self.pdd_ap_show_browser.toggled.connect(self._pdd_set_task_center_show_browser)
        bar2.addWidget(self.pdd_ap_show_browser)
        btn_go = QPushButton("🚗 开车(选中)")
        btn_go.setStyleSheet("background:#10B981;color:white;font-weight:bold;border-radius:4px;padding:6px 14px;")
        btn_go.clicked.connect(lambda: self._pdd_ap_run_selected(confirm=True))
        bar2.addWidget(btn_go)
        btn_claim = QPushButton("✅ 加入自动推广(选中)")
        btn_claim.setToolTip("把已在推广中的选中商品认领为本程序管理；不重新开车、不改拼多多后台。加入后自动调车可能调整这些计划。")
        btn_claim.setStyleSheet("background:white;color:#059669;border:1px solid #6EE7B7;border-radius:4px;padding:6px 12px;")
        btn_claim.clicked.connect(self._pdd_ap_claim_selected)
        bar2.addWidget(btn_claim)
        btn_all = QPushButton("🚗 全部未推广")
        btn_all.setStyleSheet("background:#4F46C8;color:white;font-weight:bold;border-radius:4px;padding:6px 12px;")
        btn_all.clicked.connect(self._pdd_ap_run_all_unpromoted)
        bar2.addWidget(btn_all)
        btn_bpause = QPushButton("⏸ 批量暂停")
        btn_bpause.setToolTip("对勾选的多条计划批量暂停(推广中心 搜ID→全选→批量操作→暂停)")
        btn_bpause.setStyleSheet("background:white;color:#D97706;border:1px solid #FCD34D;border-radius:4px;padding:6px 12px;")
        btn_bpause.clicked.connect(lambda: self._pdd_ap_batch_op("pause"))
        bar2.addWidget(btn_bpause)

        btn_bdel = QPushButton("🗑 批量删除")
        btn_bdel.setToolTip("对勾选的多条计划批量删除(逐个 更多→删除→确定;不可逆)")
        btn_bdel.setStyleSheet("background:white;color:#DC2626;border:1px solid #FCA5A5;border-radius:4px;padding:6px 12px;")
        btn_bdel.clicked.connect(lambda: self._pdd_ap_batch_op("delete"))
        bar2.addWidget(btn_bdel)
        btn_mon = QPushButton("📊 抓数据"); btn_mon.setToolTip("从推广后台回传 花费/结算投产/成交,填进表里")
        btn_mon.setStyleSheet("background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;padding:6px 12px;")
        btn_mon.clicked.connect(lambda: self._pdd_ap_monitor_refresh(respect_dropdown=True))  # 手动抓:尊重店铺下拉(选了具体店只抓那店)
        bar2.addWidget(btn_mon)
        btn_auto = QPushButton("🤖 自动调车"); btn_auto.setToolTip("先抓最新数据再判:亏的自动关车止损 · 二阶段调投产 · 达标且预算花光的自动加预算放量")
        btn_auto.setStyleSheet("background:white;color:#DC2626;border:1px solid #FCA5A5;border-radius:4px;padding:6px 12px;")
        btn_auto.clicked.connect(self._pdd_ap_autopilot)
        bar2.addWidget(btn_auto)
        # 自动监控:每 N 分钟自动抓数据(可选抓完自动调车=无人值守闭环)
        self.pdd_ap_auto_mon = QCheckBox("🔄自动监控")
        self.pdd_ap_auto_mon.setToolTip("勾上:每隔设定分钟自动抓数据更新(花费/结算投产等)")
        self.pdd_ap_auto_mon.toggled.connect(self._pdd_ap_toggle_automon)
        bar2.addWidget(self.pdd_ap_auto_mon)
        self.pdd_ap_mon_interval = QSpinBox()
        self.pdd_ap_mon_interval.setRange(1, 1440); self.pdd_ap_mon_interval.setValue(60); self.pdd_ap_mon_interval.setSuffix(" 分")
        self.pdd_ap_mon_interval.setToolTip("自动监控间隔(分钟)")
        self.pdd_ap_mon_interval.valueChanged.connect(self._pdd_ap_automon_reschedule)
        bar2.addWidget(self.pdd_ap_mon_interval)
        self.pdd_ap_auto_adjust = QCheckBox("抓完自动调车")
        self.pdd_ap_auto_adjust.setToolTip("勾上:每次抓完数据后自动跑一次自动调车(止损+二阶段调投产+达标放量),无人值守")
        bar2.addWidget(self.pdd_ap_auto_adjust)
        btn_scope = QPushButton("⚙ 监控店铺")
        btn_scope.setToolTip("设置自动监控抓数据的店铺范围;手动抓数据不受限制")
        btn_scope.clicked.connect(self._pdd_ap_monitor_scope_dialog)
        bar2.addWidget(btn_scope)
        bar2.addStretch(1)
        self.pdd_ap_status = QLabel(""); self.pdd_ap_status.setStyleSheet("color:#9CA3AF;font-size:11px;")
        bar2.addWidget(self.pdd_ap_status)
        lay.addLayout(bar2)

        # ── 汇总数据卡(表格上方):跟「店铺」下拉联动 —— 选某店=该店汇总,选「全部」=多店合计 ──
        #    数据来自推广中心顶部「推广数据」面板(今日口径),由自动监控/抓数据每轮写入 roas_summary.json
        self.pdd_ap_summary_widgets = {}
        sumcard = QWidget(); sumcard.setObjectName("apSumCard"); sumcard.setAttribute(Qt.WA_StyledBackground, True)
        sumcard.setStyleSheet("#apSumCard{background:#FFFFFF;border:1px solid #E5E7EB;border-radius:10px;}")
        outer = QVBoxLayout(sumcard); outer.setContentsMargins(14, 8, 14, 10); outer.setSpacing(6)
        head = QHBoxLayout(); head.setSpacing(8)
        dot = QLabel("📊 推广数据汇总"); dot.setStyleSheet("color:#4F46C8;font-size:13px;font-weight:bold;border:none;background:transparent;")
        head.addWidget(dot)
        self._pdd_ap_summary_scope = QLabel("")
        self._pdd_ap_summary_scope.setStyleSheet("color:#9CA3AF;font-size:11px;border:none;background:transparent;")
        head.addWidget(self._pdd_ap_summary_scope)
        head.addStretch(1)
        self.pdd_ap_summary_range = QComboBox()
        self.pdd_ap_summary_range.addItems(['今日', '昨日', '近7日', '近30日'])
        self.pdd_ap_summary_range.setToolTip("日期口径(同推广中心:今日/昨日/近7日/近30日)——汇总卡 + 表格各产品指标都按这个档显示")
        self.pdd_ap_summary_range.currentIndexChanged.connect(self._pdd_ap_on_range_changed)
        head.addWidget(self.pdd_ap_summary_range)
        btn_sumref = QPushButton("🔄 刷新汇总")
        btn_sumref.setToolTip("重读最新汇总(自动监控/抓数据每轮会更新 roas_summary.json)")
        btn_sumref.setCursor(Qt.PointingHandCursor)
        btn_sumref.setStyleSheet("QPushButton{background:#EEF2FF;color:#4F46C8;border:1px solid #C7D2FE;border-radius:6px;padding:4px 12px;font-size:11px;}"
                                 "QPushButton:hover{background:#E0E7FF;}")
        btn_sumref.clicked.connect(self._pdd_ap_refresh_summary)
        head.addWidget(btn_sumref)
        outer.addLayout(head)
        sumrow = QHBoxLayout(); sumrow.setSpacing(6)
        _METRIC_COLORS = {'结算投产比': '#10B981', '结算交易额': '#10B981',
                          '点击转化率': '#2563EB', '总花费': '#DC2626'}
        for _lab in ['总花费', '曝光量', '点击量', '点击率', '点击转化率',
                     '结算交易额', '结算投产比', '结算成交笔数', '每笔结算成交花费', '交易额结算率']:
            chip = QWidget(); chip.setStyleSheet("border:none;background:transparent;")
            chip.setMinimumWidth(104)
            cv = QVBoxLayout(chip); cv.setContentsMargins(6, 4, 6, 4); cv.setSpacing(3)
            v = QLabel("—"); v.setAlignment(Qt.AlignCenter)
            v.setStyleSheet(f"color:{_METRIC_COLORS.get(_lab, '#111827')};font-size:20px;font-weight:bold;border:none;background:transparent;")
            n = QLabel(_lab); n.setAlignment(Qt.AlignCenter)
            n.setStyleSheet("color:#9CA3AF;font-size:11px;border:none;background:transparent;")
            cv.addWidget(v); cv.addWidget(n)
            self.pdd_ap_summary_widgets[_lab] = v
            sumrow.addWidget(chip, 1)
        outer.addLayout(sumrow)
        lay.addWidget(sumcard)

        self.pdd_ap_table = ResponsiveAutoPromoTable(0, 25)
        self.pdd_ap_table.setHorizontalHeaderLabels(
            ["选", "goods_id", "图", "商品名", "店铺", "上架日期", "成本", "拼单价", "利润率", "实际保本",
             "开车日期", "状态", "阶段", "曝光量", "点击量", "点击率", "转化率", "花费", "结算金额",
             "交易额结算率", "结算投产", "设定投产", "预算", "结算笔数", "操作"])
        h = self.pdd_ap_table.horizontalHeader()
        for c in range(25):
            h.setSectionResizeMode(c, QHeaderView.Fixed)
        h.setSectionsClickable(True)
        h.sectionClicked.connect(self._pdd_ap_sort)   # 自定义排序(重渲染,cellWidget 不错位)
        for c, w in self._PDD_AP_FULL_WIDTHS.items():
            self.pdd_ap_table.setColumnWidth(c, w)
        self.pdd_ap_table.resized.connect(self._pdd_ap_schedule_column_widths)
        self._pdd_ap_width_pending = False
        self.pdd_ap_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pdd_ap_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.pdd_ap_table.verticalHeader().setDefaultSectionSize(48)
        self.pdd_ap_table.cellDoubleClicked.connect(self._pdd_ap_cell_dblclick)   # 双击「开车日期」手填
        lay.addWidget(self.pdd_ap_table, 1)
        self.pdd_ap_status.setText("首次打开，正在加载数据…")
        # ★默认打开:自动监控 + 抓完自动调车(放最后——等 status/interval/adjust 都建好再勾,
        #   避免勾选触发 _pdd_ap_toggle_automon 时引用还没建的控件而崩)。勾自动监控会启动监控定时器。
        self.pdd_ap_auto_adjust.setChecked(True)
        self.pdd_ap_auto_mon.blockSignals(True)
        self.pdd_ap_auto_mon.setChecked(True)
        self.pdd_ap_auto_mon.blockSignals(False)
        QTimer.singleShot(0, self._pdd_ap_schedule_column_widths)
        return page

    _PDD_AP_FULL_WIDTHS = {
        0: 40, 1: 120, 2: 50, 3: 240, 4: 110, 5: 130, 6: 70, 7: 80, 8: 80,
        9: 82, 10: 96, 11: 78, 12: 80, 13: 80, 14: 70, 15: 70, 16: 70,
        17: 80, 18: 90, 19: 92, 20: 82, 21: 82, 22: 70, 23: 78, 24: 150,
    }
    _PDD_AP_COMPACT_WIDTHS = {
        0: 30, 1: 112, 2: 44, 4: 82, 5: 78, 6: 54, 7: 66, 8: 54, 9: 60,
        10: 78, 11: 60, 12: 54, 13: 54, 14: 50, 15: 54, 16: 54, 17: 60,
        18: 68, 19: 68, 20: 62, 21: 62, 22: 64, 23: 56, 24: 130,
    }

    def _pdd_ap_schedule_column_widths(self):
        if getattr(self, "_pdd_ap_width_pending", False):
            return
        self._pdd_ap_width_pending = True
        QTimer.singleShot(0, self._pdd_ap_apply_column_widths)

    def _pdd_ap_apply_column_widths(self):
        self._pdd_ap_width_pending = False
        tbl = getattr(self, "pdd_ap_table", None)
        if tbl is None or tbl.viewport().width() <= 0:
            return
        available = tbl.viewport().width()
        full_total = sum(self._PDD_AP_FULL_WIDTHS.values())
        widths = self._PDD_AP_FULL_WIDTHS if available >= full_total else self._PDD_AP_COMPACT_WIDTHS
        for col, width in widths.items():
            tbl.setColumnWidth(col, width)
        other_total = sum(width for col, width in widths.items() if col != 3)
        tbl.setColumnWidth(3, max(120, available - other_total))

    def _pdd_ap_load_json(self, fname: str) -> dict:
        import json as _j
        p = Path(r"D:/files/data/pdd") / fname
        if p.exists():
            try:
                d = _j.loads(p.read_text(encoding="utf-8-sig"))
                return d if isinstance(d, dict) else {}
            except Exception:
                return {}
        return {}

    def _pdd_ap_done_load(self) -> dict:
        return self._pdd_ap_load_json("roas_promoted.json")

    def _pdd_ap_done_save(self, m: dict):
        import json as _j
        import shutil as _shutil
        p = Path(r"D:/files/data/pdd/roas_promoted.json")
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            if p.exists() and p.stat().st_size > 1:
                bdir = p.parent / "backups"
                bdir.mkdir(exist_ok=True)
                b = bdir / f"roas_promoted_{time.strftime('%Y%m%d_%H%M%S')}.json"
                _shutil.copy2(p, b)
            tmp = p.with_suffix(p.suffix + ".tmp")
            tmp.write_text(_j.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(p)
        except Exception: pass

    def _pdd_ap_cell_dblclick(self, row, col):
        """双击「开车日期」(col 10)手填:自动已记的提示无需填;空的弹框输入,存 roas_open_date.json(只补空、不覆盖自动)。"""
        if col != 10:
            return
        it = self.pdd_ap_table.item(row, 1)
        gid = (it.text().strip() if it else "")
        if not gid:
            return
        auto = (getattr(self, "_pdd_ap_done_map", {}).get(gid) or {}).get("at", "")
        if auto:
            QMessageBox.information(self, "开车日期", f"{gid} 已自动记录开车日期 {auto.split(' ')[0]},无需手填。")
            return
        from PyQt5.QtWidgets import QInputDialog
        by_gid = {str(r.get("goods_id") or ""): r for r in getattr(self, "_pdd_ap_recs", []) or []}
        inferred, _tip = self._pdd_ap_open_date_text(gid, by_gid.get(gid), "推广中")
        cur = (getattr(self, "_pdd_ap_opendate", {}) or {}).get(gid, "") or inferred or time.strftime("%Y-%m-%d")
        txt, ok = QInputDialog.getText(self, "手填开车日期",
                                       f"商品 {gid} 的开车日期(YYYY-MM-DD,留空=清除):", text=cur)
        if not ok:
            return
        txt = (txt or "").strip()
        od = self._pdd_ap_load_json("roas_open_date.json")
        if txt:
            od[gid] = txt
        else:
            od.pop(gid, None)
        try:
            import json as _j
            Path(r"D:/files/data/pdd/roas_open_date.json").write_text(
                _j.dumps(od, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.warning(self, "开车日期", f"保存失败:{e}")
            return
        self._pdd_ap_opendate = od
        if self.pdd_ap_table.item(row, 10):
            self.pdd_ap_table.item(row, 10).setText(txt or "—")

    def _pdd_ap_open_date_text(self, gid: str, rec: dict | None = None, status: str = "") -> tuple[str, str]:
        """自动推广开车日期显示:自动记录 > 手填 > 监控本地字段 > 已推广商品按上架日推断。"""
        gid = str(gid or "")
        rec = rec or {}
        auto = (getattr(self, "_pdd_ap_done_map", {}).get(gid) or {}).get("at", "")
        if auto:
            return auto.split(" ")[0], "本程序自动开车记录"
        manual = (getattr(self, "_pdd_ap_opendate", {}) or {}).get(gid, "")
        if manual:
            return str(manual).split(" ")[0], "人工补录开车日期"
        mon = (getattr(self, "_pdd_ap_monitor", {}) or {}).get(gid) or {}
        for key in ("open_date", "opened_at", "first_seen_at", "created_at"):
            val = str(mon.get(key) or "").strip()
            if val:
                return val.split(" ")[0], f"推广监控记录字段 {key}"
        if status and status != "未推广":
            pub_time = str(rec.get("time") or "").strip()
            if pub_time:
                return pub_time.split(" ")[0], "本地无开车记录；已有推广计划，按上架日期推断"
        return "", "自动开车会自动记日期；这条没记到可双击手填"
    def _pdd_ap_reload_table(self):
        """重读在架记录 + 成本(历史) + 监控(live) + 算账缓存(利润率/保本),刷新店铺下拉,渲染。"""
        self._pdd_ap_recs = self._pdd_video_published_records()   # 在架商品(已排除回收站)
        self._pdd_ap_done_map = self._pdd_ap_done_load()
        try:
            import roas_calc
            self._pdd_ap_cost = roas_calc.load_history_costs()    # {gid: {unit_cost,...}}
        except Exception:
            self._pdd_ap_cost = {}
        self._pdd_ap_monitor = self._pdd_ap_load_json("roas_monitor.json")
        _raw_takedown_review = self._pdd_ap_load_json("roas_takedown_review.json")
        self._pdd_ap_review = {gid: item for gid, item in _raw_takedown_review.items()
                               if isinstance(item, dict) and item.get("kind") == "takedown"}
        self._pdd_ap_target_review = self._pdd_ap_load_json("roas_target_adjust_review.json")
        self._pdd_ap_pause_review = self._pdd_ap_load_json("roas_pause_review.json")
        # 手填的开车日期覆盖:{gid: "YYYY-MM-DD"}。给"程序没记到/非本程序开的"计划双击补填用。
        #   ★独立文件,不写 roas_promoted → 不影响"自动调车只调本程序计划"。
        self._pdd_ap_opendate = self._pdd_ap_load_json("roas_open_date.json")
        # 算账缓存:主用 roas_calc_cache.json(📊抓数据持久化:成本/拼单价/利润率/实际保本/各档/SKU)
        self._pdd_ap_calc = self._pdd_ap_load_json("roas_calc_cache.json")
        # 兼容:并入最近一次开车的 roas_auto_result.json(缓存里没有的才补)
        try:
            import json as _j
            data = _j.loads(Path(r"D:/files/data/pdd/roas_auto_result.json").read_text(encoding="utf-8"))
            for r in (data or []):
                g = str(r.get("goods_id", ""))
                if g and g not in self._pdd_ap_calc:
                    prices = [rw.get("price") for rw in (r.get("rows") or [])
                              if isinstance(rw.get("price"), (int, float))]
                    pr = ""
                    if prices:
                        pr = f"{min(prices):g}" if min(prices) == max(prices) else f"{min(prices):g}~{max(prices):g}"
                    self._pdd_ap_calc[g] = {
                        "margin": (r.get("worst") or {}).get("margin"),
                        "real_breakeven": r.get("real_breakeven_roas"),
                        "price_range": pr,
                    }
        except Exception:
            pass
        cur = self.pdd_ap_store.currentText() if hasattr(self, "pdd_ap_store") else "全部"
        stores = sorted({(r.get("store") or "").strip() for r in self._pdd_ap_recs if r.get("store")})
        self.pdd_ap_store.blockSignals(True)
        self.pdd_ap_store.clear(); self.pdd_ap_store.addItem("全部")
        for s in stores: self.pdd_ap_store.addItem(s)
        idx = self.pdd_ap_store.findText(cur); self.pdd_ap_store.setCurrentIndex(idx if idx >= 0 else 0)
        self.pdd_ap_store.blockSignals(False)
        self._pdd_ap_apply_filter()
        QTimer.singleShot(0, lambda: self.pdd_ap_table.horizontalScrollBar().setValue(0))

    def _pdd_ap_status_of(self, gid: str) -> str:
        """推广状态:以推广中心(监控)为准 —— 监控里有就用监控的真实状态;监控里查无 = 推广中心没这条计划 → 未推广。
        ★即使本地开车记录(roas_promoted.json)里有,只要监控扫不到 live 计划也算「未推广」:
          开车没真成功 / 投产被 PDD 锁死建不出 / 计划已删 等都归到未推广,方便程序归类与重新开车,
          不再卡在"已开车"占位(那是只看本地记录、不看推广中心实情导致的假状态)。"""
        mon = getattr(self, "_pdd_ap_monitor", {}).get(gid)
        if mon:
            s = mon.get("status", "")
            if s and s != "未知":
                return s      # 推广中/已暂停/无可用创意/限制推广/推广受限/审核中… 原样透传
            return "推广中"   # 状态没读准 → 当在投
        return "未推广"       # 监控查无 → 未推广(开车记录里有也算,见上)

    # 可排序列(列号)→ 上架日期/利润率/实际保本/开车日期/各 live 指标/设定投产/预算
    _PDD_AP_SORTABLE = {5, 8, 9, 10, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23}

    def _pdd_ap_sort_key(self, col, t):
        """某列的排序键。t=(rec, gid, name, store, status)。数值列返回 float(空/—→-inf 沉底);日期列返回字符串。"""
        rec, gid = t[0], t[1]
        mon = (getattr(self, "_pdd_ap_monitor", {}).get(gid) or {})
        cc = (getattr(self, "_pdd_ap_calc", {}).get(gid) or {})
        _rng = self.pdd_ap_summary_range.currentText() if hasattr(self, "pdd_ap_summary_range") else "今日"
        mt = (mon.get("metrics_by_range", {}) or {}).get(_rng) or mon.get("metrics", {})
        NEG = float("-inf")
        def num(x):
            try:
                return float(str(x).replace("¥", "").replace("%", "").replace(",", "").strip())
            except (TypeError, ValueError):
                return NEG
        if col == 5:   # 上架日期(ISO 字符串可直接比)
            return str(rec.get("time") or "")
        if col == 10:  # 开车日期
            return self._pdd_ap_open_date_text(gid, rec, t[4])[0]
        if col == 8:
            mg = cc.get("margin"); return mg if isinstance(mg, (int, float)) else NEG
        if col == 9:
            be = cc.get("real_breakeven"); return be if isinstance(be, (int, float)) else NEG
        if col == 13: return num(mt.get("曝光"))
        if col == 14: return num(mt.get("点击"))
        if col == 15: return num(mt.get("点击率"))
        if col == 16: return num(mt.get("点击转化率"))
        if col == 17: return num(mt.get("花费"))
        if col == 18: return num(mt.get("结算交易额"))
        if col == 19: return num(mt.get("交易额结算率"))
        if col == 20: return num(mt.get("结算投产比"))
        if col == 21: return num(mon.get("target_roas"))
        if col == 22:
            b = mon.get("budget")
            return float("inf") if str(b).strip() == "不限" else num(b)
        if col == 23: return num(mt.get("结算成交笔数"))
        return ""

    def _pdd_ap_plan_header_menu(self):
        """Click goods_id header to filter pending recommendation types."""
        from PyQt5.QtWidgets import QMenu
        from PyQt5.QtCore import QPoint
        current = getattr(self, "_pdd_ap_plan_filter", "\u5168\u90e8")
        menu = QMenu(self)
        for option in ("\u5168\u90e8", "\u6682\u505c\u63a8\u5e7f\u5efa\u8bae", "\u4e0b\u67b6\u5efa\u8bae", "\u6295\u4ea7\u5efa\u8bae", "\u6b63\u5e38\u8ba1\u5212"):
            action = menu.addAction(("\u25cf " if option == current else "    ") + option)
            action.triggered.connect(lambda _=False, value=option: self._pdd_ap_set_plan_filter(value))
        header = self.pdd_ap_table.horizontalHeader()
        x = header.sectionViewportPosition(1)
        menu.exec_(header.mapToGlobal(QPoint(x, header.height())))

    def _pdd_ap_set_plan_filter(self, option):
        self._pdd_ap_plan_filter = option
        self._pdd_ap_apply_filter()
    def _pdd_ap_stage_header_menu(self):
        """点「阶段」列头 → 弹菜单选 全部/一阶段/二阶段(同步顶部阶段下拉)。"""
        from PyQt5.QtWidgets import QMenu
        from PyQt5.QtCore import QPoint
        cur = self.pdd_ap_stage.currentText() if hasattr(self, "pdd_ap_stage") else "全部"
        m = QMenu(self)
        for opt in ("全部", "一阶段", "二阶段"):
            act = m.addAction(("● " if opt == cur else "    ") + opt)
            act.triggered.connect(lambda _=False, o=opt: self._pdd_ap_set_stage_filter(o))
        hdr = self.pdd_ap_table.horizontalHeader()
        x = hdr.sectionViewportPosition(12)
        m.exec_(hdr.mapToGlobal(QPoint(x, hdr.height())))

    def _pdd_ap_set_stage_filter(self, opt):
        """设阶段筛选(由列头菜单触发):改顶部下拉值即会重走筛选。"""
        if hasattr(self, "pdd_ap_stage"):
            i = self.pdd_ap_stage.findText(opt)
            if i >= 0:
                self.pdd_ap_stage.setCurrentIndex(i)
                return
        self._pdd_ap_apply_filter()

    def _pdd_ap_sort(self, col):
        """点表头:阶段列(12)弹筛选菜单;其余可排序列排序(同列再点切换升/降),然后重走筛选。"""
        if col == 1:
            self._pdd_ap_plan_header_menu()
            return
        if col == 12:
            self._pdd_ap_stage_header_menu()
            return
        if col not in self._PDD_AP_SORTABLE:
            return
        prev = getattr(self, "_pdd_ap_sort_col", None)
        asc = not (prev == col and getattr(self, "_pdd_ap_sort_asc", True))
        self._pdd_ap_sort_col = col
        self._pdd_ap_sort_asc = asc
        hdr = self.pdd_ap_table.horizontalHeader()
        hdr.setSortIndicatorShown(True)
        hdr.setSortIndicator(col, Qt.AscendingOrder if asc else Qt.DescendingOrder)
        self._pdd_ap_apply_filter()

    def _pdd_ap_apply_filter(self):
        kw = (self.pdd_ap_search.text() or "").strip().lower()
        import re as _re
        tokens = [t for t in _re.split(r"[\s,，、]+", kw) if t]
        cat = self.pdd_ap_cat.currentText(); store = self.pdd_ap_store.currentText()
        review_only = bool(getattr(self, "pdd_ap_review_only", None) and self.pdd_ap_review_only.isChecked())
        stage_sel = self.pdd_ap_stage.currentText() if hasattr(self, "pdd_ap_stage") else "全部"
        plan_filter = getattr(self, "_pdd_ap_plan_filter", "\u5168\u90e8")
        rows = []
        for rec in getattr(self, "_pdd_ap_recs", []):
            gid = str(rec.get("goods_id", ""))
            name = rec.get("target_name") or rec.get("name") or rec.get("title") or ""
            st = rec.get("store") or ""
            status = self._pdd_ap_status_of(gid)
            if tokens and not any(token in gid.lower() or token in name.lower() for token in tokens): continue
            review = (getattr(self, "_pdd_ap_review", {}) or {}).get(gid) or {}
            target_review = (getattr(self, "_pdd_ap_target_review", {}) or {}).get(gid) or {}
            pause_review = (getattr(self, "_pdd_ap_pause_review", {}) or {}).get(gid) or {}
            down_pending = bool(review) and review.get("kind") == "takedown" and review.get("status") == "pending"
            target_pending = bool(target_review) and target_review.get("status") == "pending"
            pause_pending = bool(pause_review) and pause_review.get("status") == "pending"
            if review_only and not down_pending and not target_pending and not pause_pending: continue
            if review_only and not review and not target_review and not pause_review: continue
            if plan_filter == "\u6682\u505c\u63a8\u5e7f\u5efa\u8bae" and not pause_pending: continue
            if plan_filter == "\u4e0b\u67b6\u5efa\u8bae" and not down_pending: continue
            if plan_filter == "\u6295\u4ea7\u5efa\u8bae" and not target_pending: continue
            if plan_filter == "\u6b63\u5e38\u8ba1\u5212" and (down_pending or target_pending or pause_pending): continue
            if store != "全部" and st != store: continue
            if cat == "未推广" and status != "未推广": continue
            if cat == "推广中" and status not in ("推广中", "已开车"): continue   # 只正常在投
            if cat == "受限" and status in ("未推广", "已暂停", "推广中", "已开车", "未知"): continue  # 只异常/受限
            if cat == "已暂停" and status != "已暂停": continue
            if stage_sel != "全部":
                stage = (getattr(self, "_pdd_ap_monitor", {}).get(gid) or {}).get("stage", "")
                if stage != stage_sel: continue
            rows.append((rec, gid, name, st, status))
        col = getattr(self, "_pdd_ap_sort_col", None)
        if col is not None:
            rows.sort(key=lambda t: self._pdd_ap_sort_key(col, t),
                      reverse=not getattr(self, "_pdd_ap_sort_asc", True))
        display_rows = rows
        self._pdd_ap_render(display_rows)
        recs = getattr(self, "_pdd_ap_recs", [])
        total = len(recs)
        def _st(r): return self._pdd_ap_status_of(str(r.get("goods_id")))
        running = sum(1 for r in recs if _st(r) not in ("未推广", "已暂停"))
        restricted = sum(1 for r in recs if _st(r) not in ("未推广", "已暂停", "推广中", "已开车", "未知"))
        note = f"(含受限 {restricted})" if restricted else ""
        cap_note = f" · 当前显示 {len(rows)}"
        self.pdd_ap_stats.setText(f"共 {total} 在架 · 在投 {running}{note} · 其余 {total - running}{cap_note}")
        self._pdd_ap_refresh_summary()

    def _pdd_ap_on_range_changed(self):
        """日期档下拉切换:汇总卡 + 表格各产品指标都按新档刷新(纯重渲染、不重抓,瞬时)。"""
        self._pdd_ap_refresh_summary()
        try:
            self._pdd_ap_apply_filter()
        except Exception:
            pass

    def _pdd_ap_refresh_summary(self):
        """读 roas_summary.json,按「店铺」下拉(单店/多店合计)+「日期档」下拉显示汇总数据。
        新结构 {store:{ranges:{档:{指标}},scraped_at}};兼容旧结构 {store:{metrics,scraped_at}}(当今日)。"""
        if not hasattr(self, "pdd_ap_summary_widgets"):
            return
        rng = self.pdd_ap_summary_range.currentText() if hasattr(self, "pdd_ap_summary_range") else "今日"
        data = self._pdd_ap_load_json("roas_summary.json")
        store_sel = self.pdd_ap_store.currentText() if hasattr(self, "pdd_ap_store") else "全部"

        def _metrics_of(entry):
            if not isinstance(entry, dict):
                return None
            rgs = entry.get("ranges")
            if isinstance(rgs, dict):
                return rgs.get(rng)
            return entry.get("metrics") if rng == "今日" else None   # 兼容旧结构

        if store_sel and store_sel != "全部":
            e = data.get(store_sel)
            entries = [e] if isinstance(e, dict) else []
            scope = store_sel
        else:
            entries = [v for v in data.values() if isinstance(v, dict)]
            scope = f"全部 {len(entries)} 店合计"
        metrics_list = [m for m in (_metrics_of(e) for e in entries) if m]
        try:
            from roas_summary import aggregate_summaries
            agg = aggregate_summaries(metrics_list)
        except Exception:
            agg = {}
        for lab, w in self.pdd_ap_summary_widgets.items():
            w.setText(str(agg.get(lab) or "—"))
        times = [e.get("scraped_at", "") for e in entries if e.get("scraped_at")]
        tstr = max(times) if times else ""
        if metrics_list:
            self._pdd_ap_summary_scope.setText(f"{scope} · {rng} · 抓取 {tstr}")
        else:
            self._pdd_ap_summary_scope.setText(f"{scope} · {rng} · 暂无数据(跑「📊抓数据」或自动监控后更新)")

    def _pdd_ap_render(self, rows):
        tbl = self.pdd_ap_table
        tbl.setUpdatesEnabled(False)
        tbl.setRowCount(len(rows))
        img_tasks = []
        cost_map = getattr(self, "_pdd_ap_cost", {}); calc_map = getattr(self, "_pdd_ap_calc", {})
        mon_map = getattr(self, "_pdd_ap_monitor", {})
        done_map = getattr(self, "_pdd_ap_done_map", {}) or {}
        rng = self.pdd_ap_summary_range.currentText() if hasattr(self, "pdd_ap_summary_range") else "今日"  # 表格指标按这个日期档显示
        promo_done_map = _promo_done_load()
        for r, (rec, gid, name, store, status) in enumerate(rows):
            mon = mon_map.get(gid) or {}; cc = calc_map.get(gid) or {}
            tbl.setCellWidget(r, 0, self._make_check_widget(False, gid=gid))
            review = (getattr(self, "_pdd_ap_review", {}) or {}).get(gid) or {}
            target_review = (getattr(self, "_pdd_ap_target_review", {}) or {}).get(gid) or {}
            pause_review = (getattr(self, "_pdd_ap_pause_review", {}) or {}).get(gid) or {}
            id_item = QTableWidgetItem(("⚠ " + gid) if review else gid)
            if review: id_item.setToolTip("待人工确认下架：" + str(review.get("reason", "")))
            if pause_review:
                id_item.setText(("\u26a0\u23f8 " if review else "\u23f8 ") + gid)
                id_item.setToolTip("\u5f85\u4eba\u5de5\u786e\u8ba4\u6682\u505c\u63a8\u5e7f\uff1a" + str(pause_review.get("reason", "")))
            if target_review.get("status") == "failed":
                id_item.setText(("\u26a0\u274c " if review else "\u274c ") + gid)
                id_item.setToolTip("目标投产调整失败：" + str(target_review.get("failure_note") or target_review.get("reason", "")))
            elif target_review:
                id_item.setText(("\u26a0\U0001F514 " if review else "\U0001F514 ") + gid)
                id_item.setToolTip("\u5f85\u4eba\u5de5\u786e\u8ba4\u76ee\u6807\u6295\u4ea7\uff1a" + str(target_review.get("reason", "")))
            tbl.setItem(r, 1, id_item)
            img_lbl = ClickableImageLabel(); img_lbl.setAlignment(Qt.AlignCenter); img_lbl.setFixedSize(44, 44)
            img_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #E5E7EB;border-radius:3px;")
            ai_src = ""
            done_img = (promo_done_map.get(str(gid)) or {}).get("img", "") if isinstance(promo_done_map, dict) else ""
            if done_img and Path(done_img).exists():
                ai_src = str(done_img)
            else:
                fallback_ai = Path(r"D:/files/data/promo") / f"{gid}.jpg"
                if fallback_ai.exists():
                    ai_src = str(fallback_ai)
            if ai_src:
                img_lbl.setText("")
                img_lbl.set_image_source(local_path=ai_src, product_name=name + " · AI生图")
                try:
                    img_tasks.append((img_lbl, Path(ai_src).resolve().as_uri()))
                except Exception:
                    img_lbl.setText("AI")
            else:
                src = self._pdd_genimg_src_image(rec) or (mon.get("img") or "")   # 没AI图 → 用货品图/推广列表商品主图
                if src:
                    if src.startswith("//"): src = "https:" + src
                    img_lbl.setText(""); img_lbl.set_image_source(image_url=src, product_name=name + " · 商品图")
                    img_tasks.append((img_lbl, src))
                else:
                    img_lbl.setText("无")
            tbl.setCellWidget(r, 2, img_lbl)
            # 商品名:非本程序开的 → 标 🚩 红字。判定:有 live 计划,且【既无本程序开车记录(roas_promoted)
            #   又没手填过开车日期(roas_open_date)】= 真不是自己的。手填过日期=已认领,不标。
            is_foreign = (status != "未推广") and (gid not in done_map) \
                and (gid not in (getattr(self, "_pdd_ap_opendate", {}) or {}))
            it_name = QTableWidgetItem(("🚩 " + name) if is_foreign else name)
            if is_foreign:
                it_name.setForeground(QColor("#DC2626"))
                it_name.setToolTip("🚩 非本程序开的推广计划(本程序无开车记录)——自动调车不会动它")
            tbl.setItem(r, 3, it_name)
            tbl.setItem(r, 4, QTableWidgetItem(store))
            # 上架日期
            t = str(rec.get("time") or ""); tbl.setItem(r, 5, QTableWidgetItem(t.split(" ")[0] if t else "—"))
            # 成本(单件货价)
            uc = float((cost_map.get(gid) or {}).get("unit_cost", 0) or 0)
            tbl.setItem(r, 6, QTableWidgetItem(f"¥{uc:.2f}" if uc else "—"))
            # 拼单价(实际售价):优先算账缓存的【全档区间】(多SKU都算了),否则监控的主SKU价
            gp = cc.get("price_range") or mon.get("group_price") or ""
            it_gp = QTableWidgetItem(f"¥{gp}" if gp else "—")
            _sk = cc.get("skus") or []
            if _sk:
                it_gp.setToolTip("各档拼单价(算实际保本用了全部档):\n" + "\n".join(
                    f"¥{s.get('price')} ×{s.get('units')}件  {str(s.get('name', ''))[:18]}" for s in _sk[:8]))
            tbl.setItem(r, 7, it_gp)
            # 利润率 / 实际保本(算账缓存,开车/抓数据后才有)
            mg = cc.get("margin"); be = cc.get("real_breakeven")
            tbl.setItem(r, 8, QTableWidgetItem(f"{mg*100:.0f}%" if isinstance(mg, (int, float)) else "—"))
            it_be = QTableWidgetItem(f"{be:.2f}" if isinstance(be, (int, float)) else "—")
            skus = cc.get("skus") or []
            if skus:
                it_be.setToolTip("多SKU(取最低毛利档定保本):\n" + "\n".join(
                    f"{s.get('name','')[:22]}  ¥{s.get('price')} ×{s.get('units')}件" for s in skus[:8]))
            tbl.setItem(r, 9, it_be)
            # 开车日期:自动记录 > 手填 > 监控本地字段 > 已推广商品按上架日推断。
            shown, date_tip = self._pdd_ap_open_date_text(gid, rec, status)
            it_dt = QTableWidgetItem(shown or "—")
            it_dt.setToolTip(date_tip + "；双击可手填/修正")
            tbl.setItem(r, 10, it_dt)
            # 状态
            color = {"推广中": "#10B981", "已开车": "#10B981", "已暂停": "#F59E0B", "未推广": "#9CA3AF"}.get(status, "#DC2626")
            it_s = QTableWidgetItem(status); it_s.setForeground(QColor(color))
            if color == "#DC2626":   # 异常/受限(无可用创意/限制推广/审核中…):红字 + 提示去修改
                it_s.setToolTip("该计划受限/无可用创意/审核中,实际投不出去 → 点📊去数据页或PDD后台修改")
            tbl.setItem(r, 11, it_s)
            # 阶段(二阶段标红:提醒按 结算投产+0.1 调投产,防断流)
            stage = mon.get("stage", "")
            it_st = QTableWidgetItem(stage or "—")
            if stage == "二阶段":
                it_st.setForeground(QColor("#DC2626"))
            tbl.setItem(r, 12, it_st)
            # ── 实际数据板块(监控回传),按选中日期档(rng)取;该档没抓到则回退今日。漏斗:曝光→点击→…
            mt = (mon.get("metrics_by_range", {}) or {}).get(rng) or mon.get("metrics", {})
            def _m(k):
                v = mt.get(k, "")
                return str(v) if v not in ("", None) else "—"
            tbl.setItem(r, 13, QTableWidgetItem(_m("曝光")))
            tbl.setItem(r, 14, QTableWidgetItem(_m("点击")))
            tbl.setItem(r, 15, QTableWidgetItem(_m("点击率")))
            tbl.setItem(r, 16, QTableWidgetItem(_m("点击转化率")))
            tbl.setItem(r, 17, QTableWidgetItem(_m("花费")))
            tbl.setItem(r, 18, QTableWidgetItem(_m("结算交易额")))
            tbl.setItem(r, 19, QTableWidgetItem(_m("交易额结算率")))
            it_roi = QTableWidgetItem(_m("结算投产比"))
            try:
                _roi = float(str(mt.get("结算投产比", "")).replace("%", ""))
            except (ValueError, TypeError):
                _roi = None
            tips = []
            if mon.get("target_roas"): tips.append(f"目标投产 {mon.get('target_roas')}")
            if isinstance(be, (int, float)): tips.append(f"实际保本 {be:.2f}")
            if _roi is not None and _roi > 0 and isinstance(be, (int, float)):
                if _roi >= be:
                    it_roi.setForeground(QColor("#10B981")); tips.append("≥保本=赚 ✓")
                else:
                    it_roi.setForeground(QColor("#DC2626")); tips.append("<保本=亏")
            if tips:
                it_roi.setToolTip(" · ".join(tips))
            tbl.setItem(r, 20, it_roi)
            # 设定投产(开车时设的净目标投产比)—— 和左边的"结算投产"并排,一眼看实际 vs 设定的差异
            tgt = mon.get("target_roas", "")
            it_tgt = QTableWidgetItem(str(tgt) if tgt not in ("", None) else "—")
            try:
                _tg = float(str(tgt).replace("%", "")) if tgt not in ("", None) else None
            except (ValueError, TypeError):
                _tg = None
            if _tg and _tg > 0 and _roi is not None and _roi > 0:
                it_tgt.setToolTip(f"设定目标投产 {_tg:g} · 实际结算投产 {_roi:g} · 差 {(_roi - _tg):+.2f}")
            tbl.setItem(r, 21, it_tgt)
            # 预算日限额
            bud = mon.get("budget", "")
            if bud in ("", None):
                bud_txt = "—"
            elif str(bud) == "不限":
                bud_txt = "不限"
            else:
                try:
                    bud_txt = f"¥{float(str(bud).replace(',', '')):.0f}"
                except (TypeError, ValueError):
                    bud_txt = f"¥{bud}"
            tbl.setItem(r, 22, QTableWidgetItem(bud_txt))
            tbl.setItem(r, 23, QTableWidgetItem(_m("结算成交笔数")))
            # 操作:🔗 + 按状态给 开车/关车+调车/重启
            w = QWidget(); hl = QHBoxLayout(w); hl.setContentsMargins(2, 0, 2, 0); hl.setSpacing(3)
            url = rec.get("detail_url") or ""
            if url:
                bl = QPushButton("🔗"); bl.setFixedHeight(24); bl.setToolTip("打开 PDD 商品页")
                bl.clicked.connect(lambda _, u=url, s=store: self._open_in_chrome(u, s)); hl.addWidget(bl)
            ad_id = str(mon.get("ad_id", "") or "")
            if ad_id:
                bd = QPushButton("📊"); bd.setFixedHeight(24); bd.setToolTip("打开这条计划的官方数据页(adId 直达)")
                _du = f"https://yingxiao.pinduoduo.com/goods/promotion/list?adId={ad_id}&drawerTab=unit&msfrom=mms_sidenav"
                bd.clicked.connect(lambda _, u=_du, s=store: self._open_in_chrome(u, s)); hl.addWidget(bd)
            if status not in ("未推广", "已暂停"):   # 在投(含受限/无创意等,开关还ON)→ 可 调/关车
                b1 = QPushButton("调"); b1.setFixedHeight(24); b1.setToolTip("调车:自定义净目标投产比 / 预算日限额(可单独调预算)")
                b1.clicked.connect(lambda _, g=gid, s=store: self._pdd_ap_adjust_dialog(g, s)); hl.addWidget(b1)
                b2 = QPushButton("⏸"); b2.setFixedHeight(24); b2.setToolTip("关车:暂停这条计划")
                b2.clicked.connect(lambda _, g=gid, s=store: self._pdd_ap_adjust_launch(g, s, "pause")); hl.addWidget(b2)
            elif status == "已暂停":
                b3 = QPushButton("▶ 重启"); b3.setFixedHeight(24); b3.setToolTip("重新开启这条计划")
                b3.clicked.connect(lambda _, g=gid, s=store: self._pdd_ap_adjust_launch(g, s, "resume")); hl.addWidget(b3)
            else:
                b = QPushButton("🚗 开车"); b.setFixedHeight(24); b.setToolTip("建稳定成本推广计划(真开车)")
                b.clicked.connect(lambda _, x=rec: self._pdd_ap_run_selected(recs=[x], confirm=True)); hl.addWidget(b)
            if status != "未推广":
                bx = QPushButton("🗑"); bx.setFixedHeight(24); bx.setToolTip("删除这条推广计划")
                bx.clicked.connect(lambda _, g=gid, s=store: self._pdd_ap_adjust_launch(g, s, "delete")); hl.addWidget(bx)
            hl.addStretch(1)
            tbl.setCellWidget(r, 24, w)
            if (r + 1) % 20 == 0:
                QApplication.processEvents()
        tbl.setUpdatesEnabled(True)
        if img_tasks:
            old = getattr(self, "_pdd_ap_img_loader", None)
            if old is not None:
                try: old.stop()
                except Exception: pass
            self._pdd_ap_img_loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_ap_thumb_cache")
            self._pdd_ap_img_loader.image_ready.connect(self._pdd_library_set_thumb)
            self._pdd_ap_img_loader.start()

    def _pdd_ap_busy(self) -> bool:
        p = getattr(self, "_pdd_ap_proc", None)
        return bool(p) and p.state() != QProcess.NotRunning

    def _pdd_browser_busy(self):
        """是否有任何浏览器任务在跑 —— 扫主窗口所有 QProcess/QThread 成员的真实运行状态
        (state()/isRunning() 任务结束自动清零、可靠;自动覆盖现有+将来所有浏览器任务,不用逐个列举)。
        返回 (busy:bool, name:str)。供自动监控让位给前台任务,避免抢同一 profile 开成空白页两个任务一起卡死。"""
        from PyQt5.QtCore import QProcess as _QP, QThread as _QT
        for name, o in list(self.__dict__.items()):
            try:
                if isinstance(o, _QP):
                    if o.state() != _QP.NotRunning:
                        return True, name
                elif isinstance(o, _QT):
                    if o.isRunning():
                        return True, name
            except Exception:
                continue
        return False, ""

    def _pdd_ap_launch(self, args, status_msg, on_done, _from_task_center=False):
        """通用:起一个 python 子进程(roas_monitor/autopilot/adjust),结束回调 on_done(code)。"""
        busy, busy_name = self._task_center_busy()
        if busy and not _from_task_center:
            self._task_center_enqueue(
                "自动推广任务",
                lambda args=list(args), status_msg=status_msg, on_done=on_done: self._pdd_ap_launch(args, status_msg, on_done, _from_task_center=True),
                f"等待 {busy_name} 结束后自动开始 · {status_msg}")
            return
        from PyQt5.QtCore import QProcessEnvironment
        self._task_center_register_running("自动推广任务", status_msg)
        self.pdd_ap_status.setText(status_msg)
        proc = QProcess(self); proc.setProcessChannelMode(QProcess.MergedChannels)
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONIOENCODING", "utf-8"); env.insert("PYTHONUTF8", "1")
        proc.setProcessEnvironment(env)
        buf = []
        def _cap(p=proc):
            try: buf.append(bytes(p.readAllStandardOutput()).decode("utf-8", errors="replace"))
            except Exception: pass
        proc.readyReadStandardOutput.connect(_cap)
        proc.finished.connect(lambda code, _s: (on_done(code, "".join(buf)), self._task_center_finish_current(code == 0)))
        if self._pdd_task_center_show_browser_on():
            args = args + ["--show-browser"]
        self._pdd_ap_proc = proc
        proc.start(sys.executable, ["-u"] + args)

    def _pdd_ap_monitor_save(self, m: dict):
        import json as _j
        p = Path(r"D:/files/data/pdd/roas_monitor.json")
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(_j.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception: pass

    def _pdd_ap_cur_store(self) -> str:
        s = self.pdd_ap_store.currentText().strip()
        if s and s != "全部":
            return s
        stores = sorted({(r.get("store") or "").strip() for r in getattr(self, "_pdd_ap_recs", []) if r.get("store")})
        return stores[0] if stores else ""

    def _pdd_ap_stores_to_run(self) -> list:
        """自动监控/抓数据/调车要扫的店铺 = 所有【有在架商品】的店铺(全自动,与下拉筛选无关)。
        ★逐店去推广中心实扫,任何 live 计划都能发现,绝不漏:不再靠"程序以为有没有车"来筛
        (那样会漏掉记录不全/刚开车的店,导致开了车却不抓——本就是这个优化坑的)。
        某店确实没在推广,扫一遍发现没有即可,无害。"""
        stores, seen = [], set()
        for r in getattr(self, "_pdd_ap_recs", []):
            st = (r.get("store") or "").strip()
            if st and st not in seen:
                seen.add(st); stores.append(st)
        return stores

    def _pdd_ap_monitor_scope_path(self) -> Path:
        return Path(r"D:/files/data/pdd/roas_monitor_scope.json")

    def _pdd_ap_all_scope_stores(self) -> list:
        stores, seen = [], set()
        for st in self._pdd_ap_stores_to_run():
            if st and st not in seen:
                seen.add(st); stores.append(st)
        for st in sorted(self._pdd_stores_read().keys()):
            st = (st or "").strip()
            if st and st not in seen:
                seen.add(st); stores.append(st)
        return stores

    def _pdd_ap_monitor_scope_load(self):
        p = self._pdd_ap_monitor_scope_path()
        if not p.exists():
            return None
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            return {str(x).strip() for x in data.get("enabled_stores", []) if str(x).strip()}
        except Exception:
            return None

    def _pdd_ap_monitor_scope_save(self, enabled_stores: list):
        p = self._pdd_ap_monitor_scope_path()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            data = {"enabled_stores": enabled_stores}
            p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.critical(self, "监控店铺", f"保存失败:\n{e}")

    def _pdd_ap_apply_monitor_scope(self, stores: list) -> list:
        enabled = self._pdd_ap_monitor_scope_load()
        if enabled is None:
            return stores
        return [st for st in stores if st in enabled]

    def _pdd_ap_monitor_scope_dialog(self):
        stores = self._pdd_ap_all_scope_stores()
        if not stores:
            QMessageBox.information(self, "监控店铺", "当前没有可设置的店铺")
            return
        enabled = self._pdd_ap_monitor_scope_load()
        dlg = QDialog(self)
        dlg.setWindowTitle("自动监控店铺范围")
        dlg.resize(420, 520)
        lay = QVBoxLayout(dlg)
        tip = QLabel("勾选后,自动监控才会抓该店铺推广数据;手动抓数据不受此限制。")
        tip.setWordWrap(True)
        lay.addWidget(tip)
        lst = QListWidget()
        for st in stores:
            item = QListWidgetItem(st)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if enabled is None or st in enabled else Qt.Unchecked)
            lst.addItem(item)
        lay.addWidget(lst, 1)
        quick = QHBoxLayout(); quick.setSpacing(6)
        btn_all = QPushButton("全选")
        btn_none = QPushButton("全不选")
        btn_all.clicked.connect(lambda _=False: [lst.item(i).setCheckState(Qt.Checked) for i in range(lst.count())])
        btn_none.clicked.connect(lambda _=False: [lst.item(i).setCheckState(Qt.Unchecked) for i in range(lst.count())])
        quick.addWidget(btn_all); quick.addWidget(btn_none); quick.addStretch(1)
        lay.addLayout(quick)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject)
        lay.addWidget(buttons)
        if dlg.exec_() != QDialog.Accepted:
            return
        selected = [lst.item(i).text() for i in range(lst.count()) if lst.item(i).checkState() == Qt.Checked]
        self._pdd_ap_monitor_scope_save(selected)
        self.pdd_ap_status.setText(f"🔄 自动监控店铺范围: {len(selected)}/{len(stores)} 个店铺")

    def _pdd_ap_open_promo_center(self):
        """🔗 进入推广中心:选店铺 → 用该店登录态打开推广中心列表页。"""
        from PyQt5.QtWidgets import QInputDialog
        stores = sorted(self._pdd_stores_read().keys())
        if not stores:
            stores = sorted({(r.get("store") or "").strip()
                             for r in getattr(self, "_pdd_ap_recs", []) if r.get("store")})
        if not stores:
            QMessageBox.warning(self, "推广中心", "没有可选店铺"); return
        store, ok = QInputDialog.getItem(self, "进入推广中心", "选择店铺:", stores, 0, False)
        if not ok or not store:
            return
        self._open_in_chrome("https://yingxiao.pinduoduo.com/goods/promotion/list?msfrom=mms_sidenav", store)
        self.pdd_ap_status.setText(f"🔗 已打开「{store}」推广中心")

    def _pdd_pub_open_goods_list(self):
        """🔗 进入商品列表:选店铺 → 用该店登录态打开 PDD 商品列表页。"""
        from PyQt5.QtWidgets import QInputDialog
        stores = sorted(self._pdd_stores_read().keys())
        if not stores:
            stores = sorted({(r.get("store") or "").strip()
                             for r in (getattr(self, "_pdd_pub_all", []) or []) if r.get("store")})
        if not stores:
            QMessageBox.warning(self, "商品列表", "没有可选店铺"); return
        store, ok = QInputDialog.getItem(self, "进入商品列表", "选择店铺:", stores, 0, False)
        if not ok or not store:
            return
        self._open_in_chrome("https://mms.pinduoduo.com/goods/goods_list", store)

    def _pdd_ap_batch_op(self, action):
        """批量 暂停/删除:对勾选的多条,按店铺分组,逐店铺跑 roas_batch(单浏览器顺序)。"""
        if self._pdd_ap_busy():
            QMessageBox.information(self, "自动推广", "已有任务在跑,请等它结束"); return
        recs = self._pdd_ap_checked_records()
        if not recs:
            QMessageBox.warning(self, "自动推广", "请先勾选要操作的商品"); return
        by_store = {}
        for r in recs:
            st = (r.get("store") or "").strip()
            if st:
                by_store.setdefault(st, []).append(str(r.get("goods_id")))
        if not by_store:
            QMessageBox.warning(self, "自动推广", "选中商品缺店铺信息"); return
        n_total = sum(len(v) for v in by_store.values())
        act_cn = "暂停" if action == "pause" else "删除"
        warn = ("\n\n⚠️ 删除不可逆(后台保留数据,需重新开车才能再投)!" if action == "delete" else "")
        ok = QMessageBox.question(
            self, f"批量{act_cn}",
            f"将批量{act_cn} {len(by_store)} 个店铺共 {n_total} 条推广计划。{warn}\n\n确定?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ok != QMessageBox.Yes:
            return
        items = list(by_store.items())
        def _run(i):
            if i >= len(items):
                self.pdd_ap_status.setText(f"✅ 批量{act_cn}完成({len(by_store)}店铺 {n_total}条),抓数据刷新中…")
                self._pdd_ap_monitor_refresh(stores_override=list(by_store.keys()))
                return
            store, gids = items[i]
            args = [r"D:/files/roas_batch.py", "--store", store,
                    "--goods-ids", ",".join(gids), "--action", action, "--apply"]
            def _done(code, out=""):
                self._pdd_ap_reload_table()
                QTimer.singleShot(800, lambda: _run(i + 1))
            self._pdd_ap_launch(args, f"批量{act_cn}「{store}」{len(gids)}条中…(开浏览器)", _done)
        _run(0)

    def _pdd_ap_policy_dialog(self):
        from roas_autopilot_settings import load, save
        from roas_autopilot_rule_editor import edit_rules
        updated = edit_rules(self, load(), self._pdd_get_store_list())
        if updated is not None:
            save(updated)
        return
        from roas_autopilot_settings import load, save
        from PyQt5.QtWidgets import QInputDialog
        data = load(); dlg = QDialog(self); dlg.setWindowTitle("自动调车设置"); dlg.setMinimumWidth(620)
        lay = QVBoxLayout(dlg); lay.addWidget(QLabel("按你的经营策略调整；保存后，下次自动调车生效。"))
        form = QFormLayout(); boxes = {}
        fields = [("no_conv_spend","0成交花费达到多少就关车（元）",0,99999,1),("conv_spend","有成交但亏损，花费达到多少才关车（元）",0,99999,1),("refund_rate","退款率（例如 20%=0.20）",0,1,.01),("stage_offset","二阶段：目标投产比在结算投产基础上加多少",0,5,.01),("budget_hit","花费达到日预算的多少比例才放量",0,1,.01),("budget_step","每次预算放大倍数",1,10,.1),("budget_max","预算最高上限（0=不封顶，建议填写）",0,999999,10),("min_orders","至少多少成交单才允许放量",0,9999,1)]
        for k,label,lo,hi,step in fields:
            b=QDoubleSpinBox(); b.setRange(lo,hi); b.setSingleStep(step); b.setValue(float(data[k])); boxes[k]=b; form.addRow(label,b)
        scale=QCheckBox("允许自动增加预算（放量）"); scale.setChecked(bool(data.get("scale",True))); form.addRow("放量开关",scale); lay.addLayout(form)
        lay.addWidget(QLabel("自定义规则（优先于默认规则）")); tbl=QTableWidget(0,4); tbl.setHorizontalHeaderLabels(["启用","规则名称","范围","动作"]); tbl.horizontalHeader().setStretchLastSection(True); lay.addWidget(tbl)
        rules=list(data.get("rules",[]));
        def render():
            tbl.setRowCount(len(rules))
            for i,r in enumerate(rules):
                tbl.setItem(i,0,QTableWidgetItem("✓" if r.get("enabled",True) else "—")); tbl.setItem(i,1,QTableWidgetItem(r.get("name","未命名规则"))); tbl.setItem(i,2,QTableWidgetItem(r.get("scope","全部店铺"))); tbl.setItem(i,3,QTableWidgetItem((r.get("action") or {}).get("label","仅提醒")))
        render(); row=QHBoxLayout(); add=QPushButton("＋ 新增规则"); delete=QPushButton("删除选中规则"); row.addWidget(add); row.addWidget(delete); row.addStretch(); lay.addLayout(row)
        def add_rule():
            ed=QDialog(dlg); ed.setWindowTitle("新增规则"); fl=QFormLayout(ed)
            name=QLineEdit("新规则"); scope=QComboBox(); scope.addItems(["全部店铺"]); field=QComboBox(); field.addItems(["花费", "结算投产比", "结算成交笔数"]); op=QComboBox(); op.addItems([">=", ">", "<=", "<", "="]); value=QDoubleSpinBox(); value.setRange(0,999999); value.setValue(100); action=QComboBox(); action.addItems(["仅提醒", "暂停推广", "调整目标投产", "增加日预算"])
            fl.addRow("规则名称",name); fl.addRow("适用店铺",scope); fl.addRow("当满足",field); fl.addRow("比较方式",op); fl.addRow("数值",value); fl.addRow("执行动作",action)
            bb2=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); fl.addRow(bb2); bb2.accepted.connect(ed.accept); bb2.rejected.connect(ed.reject)
            if ed.exec_()==QDialog.Accepted:
                labels={"仅提醒":("notify","仅提醒"),"暂停推广":("pause","暂停推广"),"调整目标投产":("adjust_target","调整目标投产"),"增加日预算":("raise_budget","增加日预算")}; typ,lab=labels[action.currentText()]
                rules.append({"id":"custom_"+str(int(time.time()*1000)),"name":name.text().strip() or "新规则","enabled":True,"priority":99,"scope":scope.currentText(),"conditions":[{"field":field.currentText(),"op":op.currentText(),"value":value.value()}],"action":{"type":typ,"label":lab}}); render()
        add.clicked.connect(add_rule); delete.clicked.connect(lambda: (rules.pop(tbl.currentRow()),render()) if tbl.currentRow()>=0 else None)
        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject); lay.addWidget(bb)
        if dlg.exec_()==QDialog.Accepted:
            data.update({k:b.value() for k,b in boxes.items()}); data["scale"]=scale.isChecked(); data["rules"]=rules; save(data); QMessageBox.information(self,"\u81ea\u52a8\u8c03\u8f66\u8bbe\u7f6e","\u8bbe\u7f6e\u5df2\u4fdd\u5b58\u3002")
    def _pdd_ap_autopilot_store(self, store, then=None, fresh=True):
        """对单个店铺跑自动调车(供多店铺串联 / 抓完自动调车用),不弹确认。then=完成后回调。
        fresh=True:先重新扫一遍数据再调(单独点🤖自动调车用);
        fresh=False:直接用刚抓的数据调(紧跟在「📊抓数据」后用 → 不重复开浏览器扫一遍)。"""
        args = [r"D:/files/roas_autopilot.py", "--store", store, "--apply"]
        if fresh:
            args.insert(3, "--fresh")
        def _done(code, out=""):
            self._pdd_ap_reload_table()
            if then:
                then()
        self._pdd_ap_launch(args, f"🤖 自动调车「{store}」中…", _done)

    def _pdd_ap_monitor_refresh(self, respect_dropdown=False, stores_override=None, apply_monitor_scope=False):
        """📊 抓数据:逐个店铺跑 roas_refresh 回传 live。
        stores_override:指定店铺列表时,只刷新这些店铺(批量暂停/删除后用于避免扫全店)。
        apply_monitor_scope=True 时,按自动监控店铺范围过滤。
        respect_dropdown=True(手动点抓数据):店铺下拉选了具体店 → 只抓那一个;选「全部」→ 抓所有有货店。
        respect_dropdown=False(自动监控):始终抓所有有货店(不漏)。
        勾了「抓完自动调车」则每店抓完顺手跑该店自动调车,再下一店。单浏览器顺序,不并发。"""
        sel = self.pdd_ap_store.currentText().strip() if hasattr(self, "pdd_ap_store") else "全部"
        if stores_override:
            stores, seen = [], set()
            for st in stores_override:
                st = (st or "").strip()
                if st and st not in seen:
                    seen.add(st); stores.append(st)
        elif respect_dropdown and sel and sel != "全部":
            stores = [sel]                       # 手动且选了具体店 → 只抓这店
        else:
            stores = self._pdd_ap_stores_to_run()
        if apply_monitor_scope:
            stores = self._pdd_ap_apply_monitor_scope(stores)
        if not stores:
            msg = "📊 自动监控范围内没有要抓的店铺,跳过" if apply_monitor_scope else "📊 没有在推广的店铺,跳过"
            self.pdd_ap_status.setText(msg)
            return
        auto_adjust = bool(getattr(self, "pdd_ap_auto_adjust", None) and self.pdd_ap_auto_adjust.isChecked())
        n = len(stores)
        def _run(i):
            if i >= n:
                self.pdd_ap_status.setText(f"📊 {n} 个店铺数据已回传" + ("(已自动调车)" if auto_adjust else ""))
                self._pdd_ap_reload_table()
                return
            st = stores[i]
            def _done(code, out=""):
                self._pdd_ap_reload_table()
                if auto_adjust:
                    # 紧跟抓数据后:数据已最新,自动调车不再重扫(fresh=False)→ 不重复开浏览器
                    self._pdd_ap_autopilot_store(st, then=lambda: QTimer.singleShot(800, lambda: _run(i + 1)), fresh=False)
                else:
                    QTimer.singleShot(600, lambda: _run(i + 1))
            self._pdd_ap_launch([r"D:/files/roas_refresh.py", "--store", st],
                                f"📊 抓「{st}」数据中…({i + 1}/{n})", _done)
        _run(0)

    def _pdd_ap_toggle_automon(self, on):
        """开/关自动监控定时器。"""
        if not hasattr(self, "_pdd_ap_mon_timer"):
            self._pdd_ap_mon_timer = QTimer(self)
            self._pdd_ap_mon_timer.timeout.connect(self._pdd_ap_automon_tick)
        if on:
            self._pdd_ap_automon_reschedule()
            self.pdd_ap_status.setText(f"🔄 自动监控已开:每 {self.pdd_ap_mon_interval.value()} 分钟抓一次"
                                       + ("(抓完自动调车)" if self.pdd_ap_auto_adjust.isChecked() else ""))
        else:
            self._pdd_ap_mon_timer.stop()
            self.pdd_ap_status.setText("🔄 自动监控已关")

    def _pdd_ap_automon_reschedule(self):
        """改间隔时重置定时器(仅当自动监控开着)。"""
        t = getattr(self, "_pdd_ap_mon_timer", None)
        if t and getattr(self, "pdd_ap_auto_mon", None) and self.pdd_ap_auto_mon.isChecked():
            t.start(max(1, self.pdd_ap_mon_interval.value()) * 60000)

    def _pdd_ap_automon_tick(self):
        """定时触发:抓一次数据。★若有任何浏览器任务在跑(视频/发布/比价/同步/开车/核对…)则让位
        ——避免抢同一 profile 把页面开成空白、两个任务一起卡死。但不等满一个间隔(那样全天跑任务会饿死监控),
        而是每 2 分钟短重试一次,一旦浏览器空闲立刻补抓。"""
        # 自动监控已关就别跑(短重试可能在关闭后才触发)
        if not (getattr(self, "pdd_ap_auto_mon", None) and self.pdd_ap_auto_mon.isChecked()):
            self._pdd_ap_mon_retry_pending = False
            return
        busy, who = self._pdd_browser_busy()
        if busy:
            import time as _t
            try:
                self.pdd_ap_status.setText(
                    f"🔄 自动监控:有其它浏览器任务在跑({who}),让位中,2分钟后重试 · {_t.strftime('%H:%M')}")
            except Exception:
                pass
            # 只排一个待定重试,避免叠加;到点 _retry 会清标志再判忙/闲
            if not getattr(self, "_pdd_ap_mon_retry_pending", False):
                self._pdd_ap_mon_retry_pending = True
                QTimer.singleShot(120000, self._pdd_ap_automon_retry)   # 2 分钟后重试
            return
        self._pdd_ap_mon_retry_pending = False
        self._pdd_ap_monitor_refresh(apply_monitor_scope=True)

    def _pdd_ap_automon_retry(self):
        """让位后的短重试:清待定标志,重新走 tick(再判忙/闲;仍忙会再排一个,空闲就抓)。"""
        self._pdd_ap_mon_retry_pending = False
        self._pdd_ap_automon_tick()

    def _pdd_ap_autopilot(self, silent=False):
        """🤖 自动调车:对【要跑的店铺】逐个 抓最新数据 → 止损关车 + 二阶段调投产 + 达标放量(真执行)。
        选「全部」=所有有车店铺轮着来(单浏览器顺序)。silent=自动链调用,不弹确认。"""
        if silent and self._pdd_ap_busy():
            return
        stores = self._pdd_ap_stores_to_run()
        if not stores:
            if not silent:
                QMessageBox.warning(self, "自动调车", "没有在推广的店铺")
            return
        if not silent:
            who = f"店铺「{stores[0]}」" if len(stores) == 1 else f"{len(stores)} 个有车店铺(轮着来)"
            ok = QMessageBox.question(
                self, "自动调车",
                f"对{who}自动调车:先抓最新数据,然后\n"
                "· 亏的(结算投产<保本且已花够钱)→ 自动关车止损\n"
                "· 二阶段 → 按结算投产+0.1 调投产\n"
                "· 达标(结算投产≥保本)且预算花光的 → 自动加预算放量(逐轮×1.5放大,不封顶)\n\n确定?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ok != QMessageBox.Yes:
                return
        n = len(stores)
        def _run(i):
            if i >= n:
                self.pdd_ap_status.setText(f"🤖 {n} 个店铺自动调车完成,详见 data/pdd/roas_autopilot_decision.json")
                self._pdd_ap_reload_table()
                return
            self._pdd_ap_autopilot_store(stores[i], then=lambda: QTimer.singleShot(800, lambda: _run(i + 1)))
        _run(0)

    def _pdd_ap_adjust_launch(self, gid, store, action, value=0.0, then=None):
        """行内 关车/重启/调车/调预算:跑 roas_adjust 单条。then=完成后接着跑的回调(串联多动作用)。"""
        if action == "pause":
            ok = QMessageBox.question(self, "关车", f"暂停商品 {gid} 的推广计划?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ok != QMessageBox.Yes:
                return
        elif action == "delete":
            ok = QMessageBox.question(
                self, "删除推广",
                f"删除商品 {gid} 的推广计划?\n\n(删除后数据后台保留,同商品再推广会继承历史;此操作不可在客户端撤销)",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ok != QMessageBox.Yes:
                return
        args = [r"D:/files/roas_adjust.py", "--store", store, "--goods-id", str(gid), "--action", action]
        if value:
            args += ["--value", str(value)]
        # 调预算直达 adId 抽屉:监控里现成有 ad_id,直接传,免去搜列表
        ad_id = str((getattr(self, "_pdd_ap_monitor", {}).get(str(gid)) or {}).get("ad_id", "") or "")
        if ad_id:
            args += ["--ad-id", ad_id]
        act_cn = {"pause": "关车", "resume": "重启", "set-roas": "调车", "set-budget": "调预算", "delete": "删除"}.get(action, action)
        def _done(code, out=""):
            ok = ('"ok": true' in out) or ('"ok":true' in out)
            if ok:
                # 乐观更新本地监控状态,立刻反映(不用再开浏览器抓一遍;下次📊抓数据会校正)
                mon = self._pdd_ap_load_json("roas_monitor.json")
                if action == "delete":
                    mon.pop(str(gid), None)                       # 删了 → 回到未推广
                    self._pdd_ap_monitor_save(mon)
                    done = self._pdd_ap_done_load()
                    if str(gid) in done:
                        done.pop(str(gid), None); self._pdd_ap_done_save(done)
                elif str(gid) in mon:
                    if action == "pause": mon[str(gid)]["status"] = "已暂停"
                    elif action == "resume": mon[str(gid)]["status"] = "推广中"
                    elif action == "set-roas" and value: mon[str(gid)]["target_roas"] = str(value)
                    elif action == "set-budget" and value: mon[str(gid)]["budget"] = str(int(value))
                    self._pdd_ap_monitor_save(mon)
                self.pdd_ap_status.setText(f"✅ {act_cn} {gid} 成功")
            else:
                self.pdd_ap_status.setText(f"⚠ {act_cn} {gid} 未成功(exit={code}),点📊重抓核对")
            self._pdd_ap_reload_table()
            if then:
                from PyQt5.QtCore import QTimer
                QTimer.singleShot(900, then)   # 稍等 profile 释放,再跑串联的下一个动作
        self._pdd_ap_launch(args, f"{act_cn} {gid} 中…(开浏览器)", _done)

    def _pdd_ap_adjust_dialog(self, gid, store):
        """调车:可单独/同时改 净目标投产比 和 预算日限额(勾哪个改哪个,默认只勾投产比)。"""
        from PyQt5.QtWidgets import (QDialog, QGridLayout, QDoubleSpinBox, QDialogButtonBox,
                                     QLabel, QCheckBox)
        mon = getattr(self, "_pdd_ap_monitor", {}).get(gid) or {}
        cur_roas = mon.get("target_roas", "")
        cur_bud = mon.get("budget", "")
        try:
            cur_roas_f = float(str(cur_roas).replace("%", "")) if cur_roas not in ("", None) else 2.0
        except (ValueError, TypeError):
            cur_roas_f = 2.0
        try:
            cur_bud_f = float(str(cur_bud)) if cur_bud not in ("", None, "不限") else 200.0
        except (ValueError, TypeError):
            cur_bud_f = 200.0

        dlg = QDialog(self); dlg.setWindowTitle("调车 — 投产比 / 预算")
        g = QGridLayout(dlg)
        g.addWidget(QLabel(f"商品 {gid}"), 0, 0, 1, 2)
        chk_roas = QCheckBox("调净目标投产比"); chk_roas.setChecked(True)
        sp_roas = QDoubleSpinBox(); sp_roas.setRange(0.1, 99.0); sp_roas.setDecimals(2); sp_roas.setSingleStep(0.1)
        sp_roas.setValue(cur_roas_f if cur_roas_f > 0 else 2.0)
        g.addWidget(chk_roas, 1, 0); g.addWidget(sp_roas, 1, 1)
        g.addWidget(QLabel(f"(当前 {cur_roas or '?'})"), 2, 1)
        chk_bud = QCheckBox("调预算日限额(元)"); chk_bud.setChecked(False)
        sp_bud = QDoubleSpinBox(); sp_bud.setRange(1.0, 100000.0); sp_bud.setDecimals(0); sp_bud.setSingleStep(50)
        sp_bud.setValue(cur_bud_f if cur_bud_f > 0 else 200.0)
        g.addWidget(chk_bud, 3, 0); g.addWidget(sp_bud, 3, 1)
        g.addWidget(QLabel(f"(当前 {cur_bud or '?'},PDD 最低200)"), 4, 1)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        g.addWidget(bb, 5, 0, 1, 2)
        # 勾选框联动启用/禁用对应输入框
        sp_roas.setEnabled(chk_roas.isChecked()); chk_roas.toggled.connect(sp_roas.setEnabled)
        sp_bud.setEnabled(chk_bud.isChecked()); chk_bud.toggled.connect(sp_bud.setEnabled)
        if dlg.exec_() != QDialog.Accepted:
            return
        jobs = []
        if chk_roas.isChecked():
            jobs.append(("set-roas", round(sp_roas.value(), 2)))
        if chk_bud.isChecked():
            jobs.append(("set-budget", float(round(sp_bud.value()))))
        if not jobs:
            self.pdd_ap_status.setText("调车:没勾要改的项")
            return
        self._pdd_ap_adjust_chain(gid, store, jobs)

    def _pdd_ap_adjust_chain(self, gid, store, jobs):
        """依次执行调车动作(set-roas / set-budget):一个完成再起下一个,避免浏览器 profile 冲突。"""
        if not jobs:
            self._pdd_ap_reload_table(); return
        action, value = jobs[0]
        rest = jobs[1:]
        self._pdd_ap_adjust_launch(gid, store, action, value=value,
                                   then=(lambda: self._pdd_ap_adjust_chain(gid, store, rest)) if rest else None)

    def _pdd_ap_toggle_all(self):
        tbl = self.pdd_ap_table
        target = any(self._cell_checkbox(tbl, r) and not self._cell_checkbox(tbl, r).isChecked()
                     for r in range(tbl.rowCount()))
        for r in range(tbl.rowCount()):
            cb = self._cell_checkbox(tbl, r)
            if cb: cb.setChecked(target)

    def _pdd_ap_checked_records(self) -> list:
        tbl = self.pdd_ap_table
        by_gid = {str(r.get("goods_id")): r for r in getattr(self, "_pdd_ap_recs", [])}
        out, seen = [], set()
        for r in range(tbl.rowCount()):
            cb = self._cell_checkbox(tbl, r)
            if cb and cb.isChecked():
                gid = str(cb.property("rec_id"))
                rec = by_gid.get(gid)
                if rec and gid not in seen:
                    seen.add(gid); out.append(rec)
        return out

    def _pdd_ap_claim_selected(self):
        """认领已有推广计划，补回本程序自动调车名单；不触发 PDD 操作。"""
        recs = self._pdd_ap_checked_records()
        if not recs:
            QMessageBox.warning(self, "加入自动推广", "请先勾选要加入自动推广的商品。")
            return
        live, not_live = [], []
        for rec in recs:
            gid = str(rec.get("goods_id") or "")
            if gid and self._pdd_ap_status_of(gid) != "未推广":
                live.append((gid, rec))
            else:
                not_live.append(gid)
        if not live:
            QMessageBox.warning(self, "加入自动推广", "勾选商品当前都不是推广中计划；不会加入，避免误登记。")
            return
        preview = "\n".join(f"  • {gid}  {(rec.get('target_name') or rec.get('name') or '')[:26]}" for gid, rec in live[:8])
        more = f"\n  …还有 {len(live) - 8} 条" if len(live) > 8 else ""
        skipped = f"\n\n另有 {len(not_live)} 条当前未推广，已跳过。" if not_live else ""
        msg = (f"将把以下 {len(live)} 条已存在的推广计划加入本程序自动推广名单：\n{preview}{more}\n\n"
               "不会重新开车，不会修改拼多多后台。\n"
               "加入后，自动调车可能按现有规则调整这些计划。" + skipped)
        if QMessageBox.question(self, "确认加入自动推广", msg,
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        done = self._pdd_ap_done_load()
        now = time.strftime("%Y-%m-%d %H:%M")
        for gid, rec in live:
            date_text, _ = self._pdd_ap_open_date_text(gid, rec, self._pdd_ap_status_of(gid))
            mon = (getattr(self, "_pdd_ap_monitor", {}) or {}).get(gid) or {}
            done[gid] = {"roas": mon.get("target_roas"), "at": date_text or now, "source": "manual_claim"}
        self._pdd_ap_done_save(done)
        self._pdd_ap_reload_table()
        self.pdd_ap_status.setText(f"✅ 已加入自动推广 {len(live)} 条；未推广跳过 {len(not_live)} 条")
        QMessageBox.information(self, "已加入自动推广",
                                f"已认领 {len(live)} 条推广计划。\n不会重新开车；后续自动调车会按规则管理它们。")

    def _pdd_ap_run_all_unpromoted(self):
        done = getattr(self, "_pdd_ap_done_map", {})
        recs = [r for r in getattr(self, "_pdd_ap_recs", []) if str(r.get("goods_id")) not in done]
        if not recs:
            QMessageBox.information(self, "自动推广", "没有未推广的在架商品")
            return
        self._pdd_ap_run_selected(recs=recs, confirm=True)

    def _pdd_ap_run_selected(self, recs=None, confirm=True, skip_ask=False):
        """对选中(或传入)的在架商品跑 roas_auto。confirm=False 预演不花钱。
        skip_ask=True:不弹内置确认框(调用方已自行确认,如一键跑品开车的预演后确认)。
        一次只跑一个店铺(多店铺先跑第一个,其余下次)。结果只更新状态标签,不甩日志。"""
        if getattr(self, "_pdd_ap_proc", None) and self._pdd_ap_proc.state() != QProcess.NotRunning:
            QMessageBox.information(self, "自动推广", "已有一批在跑,请等它结束")
            return
        if recs is None:
            recs = self._pdd_ap_checked_records()
        if not recs:
            QMessageBox.warning(self, "自动推广", "请先勾选商品(或用「一键全部未推广」)")
            return
        by_store = {}
        for r in recs:
            by_store.setdefault((r.get("store") or "").strip(), []).append(str(r.get("goods_id")))
        by_store.pop("", None)
        if not by_store:
            QMessageBox.warning(self, "自动推广", "选中商品缺店铺信息")
            return
        store_items = list(by_store.items())
        store, gids = store_items[0]
        remaining_recs = [rec for rec in recs if (rec.get("store") or "").strip() != store]
        tier = self.pdd_ap_tier.currentText(); budget = self.pdd_ap_budget.value()
        if confirm and not skip_ask:
            store_lines = "\n".join(f"  ? {shop}: {len(shop_gids)} \u6761" for shop, shop_gids in store_items)
            total = sum(len(shop_gids) for _, shop_gids in store_items)
            ok = QMessageBox.question(
                self, "\u786e\u8ba4\u5f00\u8f66",
                f"\u5c06\u6309\u5e97\u94fa\u4e32\u884c\u5bf9\u4ee5\u4e0b {len(store_items)} \u4e2a\u5e97\u94fa\u5408\u8ba1 {total} \u6761\u5728\u67b6\u94fe\u63a5\uff0c\u6309\u3010{tier}\u3011\u6863\u771f\u5efa\u7a33\u5b9a\u6210\u672c\u63a8\u5e7f\u8ba1\u5212(\u65e5\u9884\u7b97 {budget})\uff1a\n{store_lines}\n\n"
                "\u8fd9\u4f1a\u771f\u82b1\u94b1!\u5df2\u63a8\u5e7f / \u8001\u94fe\u63a5\u88ab\u9501 / \u4e8f\u672c\u6863\u4f1a\u81ea\u52a8\u8df3\u8fc7\u3002\n\n\u786e\u5b9a\u5f00\u8f66?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ok != QMessageBox.Yes:
                return
        from PyQt5.QtCore import QProcessEnvironment
        self.pdd_ap_status.setText(f"🚗 {'开车' if confirm else '预演'}中… 店铺「{store}」{len(gids)} 条(开浏览器,别碰鼠标键盘)")
        proc = QProcess(self); proc.setProcessChannelMode(QProcess.MergedChannels)
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONIOENCODING", "utf-8"); env.insert("PYTHONUTF8", "1")
        proc.setProcessEnvironment(env)
        self._pdd_ap_buf = []
        def _on_out(p=proc):
            try: self._pdd_ap_buf.append(bytes(p.readAllStandardOutput()).decode("utf-8", errors="replace"))
            except Exception: pass
        proc.readyReadStandardOutput.connect(_on_out)
        proc.finished.connect(lambda code, _s, cf=confirm, st=store, rest=remaining_recs: self._pdd_ap_run_done(code, cf, st, then=(lambda: self._pdd_ap_run_selected(recs=rest, confirm=cf, skip_ask=True)) if rest else None))
        args = ["-u", r"D:/files/roas_auto.py", "--store", store, "--goods-ids", ",".join(gids),
                "--tier", tier, "--budget", str(budget), "--limit", "0"]
        if self._pdd_task_center_show_browser_on():
            args.append("--show-browser")
        if confirm:
            args.append("--confirm")
        self._pdd_ap_proc = proc
        proc.start(sys.executable, args)

    def _pdd_ap_run_done(self, code, confirm, store="", then=None):
        """跑批结束:读结果 JSON,统计成功/跳过,标记已开车,刷新表;开车成功后自动抓该店数据更新真实状态。"""
        import json as _j
        built = skipped = 0
        try:
            data = _j.loads(Path(r"D:/files/data/pdd/roas_auto_result.json").read_text(encoding="utf-8"))
        except Exception as e:
            detail = f"完成(exit={code}),读结果失败: {str(e)[:50]}"
            self.pdd_ap_status.setText(detail)
            self._task_center_finish_current(False, detail)
            return
        done = self._pdd_ap_done_load()
        for r in data:
            stg = r.get("stage"); gid = str(r.get("goods_id", ""))
            if r.get("ok") and stg in ("confirmed", "confirmed_verified"):  # confirmed_verified=回列表核验真有live计划(2026-06-23)
                built += 1; done[gid] = {"roas": r.get("target_roas"), "at": time.strftime("%Y-%m-%d %H:%M")}
            elif confirm and stg == "verify_not_live" and r.get("ad_id") and "成功提示=True" in str(r.get("note", "")):
                built += 1; done[gid] = {"roas": r.get("target_roas"), "at": time.strftime("%Y-%m-%d %H:%M")}
            elif r.get("ok") and stg == "dry_run":
                built += 1
            else:
                skipped += 1
        if confirm:
            self._pdd_ap_done_save(done)
        tag = "开车" if confirm else "预演"
        detail = f"✅ {tag}完成:成功 {built} · 跳过 {skipped}(详情见 data/pdd/roas_auto_result.json)"
        self.pdd_ap_status.setText(detail)
        self._task_center_update_current_detail(detail)
        self._pdd_ap_reload_table()
        # ★开车成功后自动抓该店数据,把占位「已开车」刷成真实状态(推广中/受限/售罄…)→ 不再停留"已开车"
        if confirm and built > 0 and store:
            def _after(c2, out=""):
                self.pdd_ap_status.setText(f"✅ 开车 {built} 条 + 抓数据完成,状态已更新")
                self._pdd_ap_reload_table()
                if then:
                    QTimer.singleShot(900, then)
                else:
                    self._task_center_finish_current(code == 0, detail)
            # 开车后只抓「推广中心列表实时状态」(roas_monitor,不开商品详情页)→ 快、不翻旧品;
            # 利润率/实际保本走算账缓存(开车时新品已算)。要重算详情用「📊 抓数据」。
            QTimer.singleShot(900, lambda: self._pdd_ap_launch(
                [r"D:/files/roas_monitor.py", "--store", store],
                f"🚗 开车成功,正在抓「{store}」推广状态…", _after))
        else:
            if then:
                QTimer.singleShot(900, then)
            else:
                self._task_center_finish_current(code == 0, detail)


    def _pdd_refresh_mode_card(self):
        """读 pricing_rules.json 的默认规则,刷新左下角"当前模式"卡片。"""
        if not hasattr(self, "pdd_mode_name") or not hasattr(self, "pdd_mode_desc"):
            return
        try:
            rules = pricing_rules.load_rules()
            rule = pricing_rules.get_default_rule(rules) if rules else None
        except Exception:
            rule = None
        if rule:
            margin = float(rule.get("margin", 0))
            shipping = float(rule.get("shipping", 0))
            suffix = rule.get("spec_suffix", "")
            self.pdd_mode_name.setText(rule.get("name", "—"))
            self.pdd_mode_desc.setText(
                f"{margin*100:.0f}% 毛利 · {shipping:.0f} 元运费\n搭配:{suffix or '(无)'}")
        else:
            self.pdd_mode_name.setText("—")
            self.pdd_mode_desc.setText("(无定价规则)")

    def _pdd_refresh_rules_combo(self):
        """加载定价规则到下拉框,保留当前选中(按 id);若无则选默认规则。"""
        if not hasattr(self, "pdd_rule_combo"):
            return
        prev_id = self.pdd_rule_combo.currentData() if self.pdd_rule_combo.count() else None
        try:
            rules = pricing_rules.load_rules()
        except Exception as e:
            self.pdd_rule_combo.clear()
            self.pdd_rule_combo.addItem(f"⚠ 加载失败: {e}", None)
            return
        self.pdd_rule_combo.blockSignals(True)
        self.pdd_rule_combo.clear()
        default_idx = 0
        for i, r in enumerate(rules):
            mark = " ★" if r.get("is_default") else ""
            self.pdd_rule_combo.addItem(f"{r.get('name','(未命名)')}{mark}", r)
            if r.get("is_default"):
                default_idx = i
            if prev_id and r.get("id") == prev_id:
                default_idx = i  # 优先保留用户上次的选择
        self.pdd_rule_combo.setCurrentIndex(default_idx)
        self.pdd_rule_combo.blockSignals(False)
        # 信号被屏蔽过,手动触发一次同步左下角模式卡片 + 表格预估价
        self._pdd_on_rule_changed()

    def _pdd_on_rule_changed(self, *_):
        """规则下拉切换时同步:左下角模式卡片、顶部标题、表格「预计拼单价」列。"""
        rule = self.pdd_rule_combo.currentData() if hasattr(self, "pdd_rule_combo") else None
        if not isinstance(rule, dict):
            return
        name = rule.get("name", "")
        margin = float(rule.get("margin", 0))
        shipping = float(rule.get("shipping", 0))
        suffix = rule.get("spec_suffix", "")
        # 左下角模式卡片
        if hasattr(self, "pdd_mode_name"):
            self.pdd_mode_name.setText(name)
        if hasattr(self, "pdd_mode_desc"):
            self.pdd_mode_desc.setText(f"{margin*100:.0f}% 毛利 · {shipping:.0f} 元运费\n搭配:{suffix or '(无)'}")
        # 顶部标题
        if hasattr(self, "pdd_pending_title"):
            self.pdd_pending_title.setText(f"💎 {name} - 待发布商品")
        # 表格重渲染(沿用现有搜索过滤)
        if hasattr(self, "pdd_pending_table"):
            self._pdd_apply_filter()

    def _build_pdd_page_published(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(15, 12, 15, 12)
        lay.setSpacing(8)

        top = QWidget()
        top.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:6px;")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(15, 10, 15, 10)
        title = QLabel("📊 已发布商品历史（验证通过的真实上架记录）")
        title.setStyleSheet("font-size:14px;font-weight:bold;color:#4F46C8;background:transparent;border:none;")
        tl.addWidget(title)
        sub = QHBoxLayout()
        self.pdd_pub_search = QLineEdit()
        self.pdd_pub_search.setPlaceholderText("商品名 / 店铺 / goods_id;多个查询请用空格或逗号隔开依次输入")
        self.pdd_pub_search.setMinimumWidth(280)
        self._pdd_pub_filter_timer = QTimer(self)
        self._pdd_pub_filter_timer.setSingleShot(True)
        self._pdd_pub_filter_timer.timeout.connect(self._pdd_published_filter)
        self.pdd_pub_search.textChanged.connect(self._pdd_published_filter_later)
        sub.addWidget(self.pdd_pub_search)
        # 状态筛选(全部 / 已发布 / 已下架 / 未对齐)
        sub.addSpacing(10)
        fl = QLabel("筛选：")
        fl.setStyleSheet("color:#6B7280;background:transparent;border:none;")
        sub.addWidget(fl)
        self._pdd_pub_filter_state = "all"
        # 状态筛选合并成一个下拉(省空间):全部/已发布/已下架/已售罄/未对齐/待核价
        self._pdd_pub_filter_opts = [("全部", "all"), ("已发布", "listed"), ("已下架", "taken_down"),
                                     ("已售罄", "sold_out"), ("未对齐", "mismatch"), ("待核价", "need_price"),
                                     ("待修复", "spec_code_pending")]
        self.pdd_pub_filter_combo = QComboBox()
        for _lab, _k in self._pdd_pub_filter_opts:
            self.pdd_pub_filter_combo.addItem(_lab)
        self.pdd_pub_filter_combo.setFixedWidth(110)
        self.pdd_pub_filter_combo.currentIndexChanged.connect(
            lambda i: self._pdd_pub_set_filter(self._pdd_pub_filter_opts[i][1]))
        sub.addWidget(self.pdd_pub_filter_combo)
        sub.addStretch()
        btn_sync = QPushButton("🔄 同步PDD状态")
        btn_sync.setStyleSheet(
            "QPushButton{background:#10B981;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#059669;}")
        btn_sync.setToolTip("查询 PDD「全部」商品列表,逐行读状态:在售=已发布 / 已售罄 / 已下架；列表里没有=已下架")
        btn_sync.clicked.connect(self._pdd_sync_status)
        sub.addWidget(btn_sync)
        btn_goods = QPushButton("🔗 商品列表")
        btn_goods.setStyleSheet(
            "QPushButton{background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#EEF2FF;}")
        btn_goods.setToolTip("选店铺 → 用该店登录态打开 PDD 商品列表页")
        btn_goods.clicked.connect(self._pdd_pub_open_goods_list)
        sub.addWidget(btn_goods)
        btn_takedown_sel = QPushButton("🚫 批量下架选中")
        btn_takedown_sel.setStyleSheet(
            "QPushButton{background:#EF4444;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#DC2626;}")
        btn_takedown_sel.clicked.connect(self._pdd_takedown_selected)
        sub.addWidget(btn_takedown_sel)
        btn_del_store = QPushButton("🗑 删除（移入回收站）")
        btn_del_store.setStyleSheet(
            "QPushButton{background:#991B1B;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#7F1D1D;}")
        btn_del_store.setToolTip("两种状态可删:\n• 🚫 已下架 → 调 pdd_delete.py 去 PDD 后台真删除 + 标记 deleted(可回收 30 天)\n• ⊘ 未上架 → 仅清本地记录(PDD 上已不存在,无需调 PDD)")
        btn_del_store.clicked.connect(self._pdd_delete_store)
        sub.addWidget(btn_del_store)
        # 全局开关:显示浏览器(调试)。默认不勾 = 所有 PDD 操作(发布/核查/下架/删除/
        # 同步/恢复)浏览器都在屏幕外静默跑,不挡桌面;勾上 = 最大化显示,方便盯着排错。
        # (店铺登录扫码除外,那个永远显示。)待发布页也有一个,两边同步。
        sub.addWidget(self._pdd_make_show_browser_chk())

        btn_inspect = QPushButton("🔍 核查未对齐原因")
        btn_inspect.setStyleSheet(
            "QPushButton{background:#F59E0B;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#D97706;}")
        btn_inspect.setToolTip("对 status=mismatch 的商品逐个打开 PDD 编辑页,对比期望/实际,输出差异原因(分店铺串行)")
        btn_inspect.clicked.connect(self._pdd_inspect_mismatch)
        sub.addWidget(btn_inspect)
        btn_repair_spec = QPushButton("🔧 修复规格编码(选中)")
        btn_repair_spec.setStyleSheet(
            "QPushButton{background:#7C3AED;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#6D28D9;}")
        btn_repair_spec.setToolTip("逐个进入勾选商品的 PDD 编辑页；只填写空的规格编码。\n"
                                   "仅在至少写入一条编码后提交，不改价格、库存、规格名或其它字段。")
        btn_repair_spec.clicked.connect(self._pdd_repair_selected_spec_codes)
        sub.addWidget(btn_repair_spec)
        btn_manual_spec_ok = QPushButton("✅ 标记人工修复成功")
        btn_manual_spec_ok.setStyleSheet(
            "QPushButton{background:#059669;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#047857;}")
        btn_manual_spec_ok.setToolTip("仅把勾选商品的本地规格编码状态标为人工确认成功，清除规格编码导致的绿标；不打开或修改 PDD。")
        btn_manual_spec_ok.clicked.connect(self._pdd_mark_spec_code_manually_fixed)
        sub.addWidget(btn_manual_spec_ok)
        btn_force_mm = QPushButton("⚑ 强制标记未对齐")
        btn_force_mm.setStyleSheet(
            "QPushButton{background:white;color:#DC2626;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#FEF2F2;}")
        btn_force_mm.setToolTip("把勾选的商品状态强制改成「未对齐」,这样可以对它们再跑「核查未对齐」\n"
                                "(用于:程序误判为已对齐、但你确认价格/规格其实有问题的商品)")
        btn_force_mm.clicked.connect(self._pdd_force_mark_mismatch)
        sub.addWidget(btn_force_mm)
        btn_rollback = QPushButton("↩ 回退待发布")
        btn_rollback.setStyleSheet(
            "QPushButton{background:#7C3AED;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#6D28D9;}")
        btn_rollback.setToolTip("先下架勾选商品的 PDD 链接,下架成功后把它回退到待发布区(不自动发)\n"
                                "图片/批准文号从商品库按 1688 链接取回;原商品已从商品库删除则跳过")
        btn_rollback.clicked.connect(self._pdd_published_rollback)
        sub.addWidget(btn_rollback)
        btn_republish = QPushButton("🔁 重新再发布")
        btn_republish.setStyleSheet(
            "QPushButton{background:#0EA5E9;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#0284C7;}")
        btn_republish.setToolTip("不下架原商品,直接按勾选记录再发布一条新的(自动开始发布)\n"
                                 "图片/批准文号从商品库按 1688 链接取回;原商品已从商品库删除则跳过")
        btn_republish.clicked.connect(self._pdd_published_republish)
        sub.addWidget(btn_republish)
        btn_reload = QPushButton("🔄 刷新")
        btn_reload.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#4338CA;}")
        btn_reload.clicked.connect(self._pdd_load_published)
        sub.addWidget(btn_reload)
        tl.addLayout(sub)
        lay.addWidget(top)

        self.pdd_pub_table = QTableWidget()
        self.pdd_pub_table.setColumnCount(12)
        self.pdd_pub_table.setHorizontalHeaderLabels(
            ["全选", "图(选品/货品/上架)", "状态", "时间", "店铺", "商品名", "goods_id", "定价模式",
             "供货价", "拼单价", "库存", "操作"])
        self.pdd_pub_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)  # 商品名
        self.pdd_pub_table.setColumnWidth(0, 45)
        self.pdd_pub_table.setColumnWidth(1, 140)   # 图:选品图+货品图+上架主图 三缩图并排
        self.pdd_pub_table.setColumnWidth(2, 100)   # 状态
        self.pdd_pub_table.setColumnWidth(3, 145)   # 时间
        self.pdd_pub_table.setColumnWidth(4, 130)   # 店铺
        self.pdd_pub_table.setColumnWidth(6, 130)   # goods_id
        self.pdd_pub_table.setColumnWidth(7, 130)   # 定价模式
        self.pdd_pub_table.setColumnWidth(8, 80)    # 供货价
        self.pdd_pub_table.setColumnWidth(9, 90)    # 拼单价
        self.pdd_pub_table.setColumnWidth(10, 120)  # 库存
        # 点击「全选」表头切换所有勾选
        self.pdd_pub_table.horizontalHeader().sectionClicked.connect(self._pdd_pub_toggle_all)
        self.pdd_pub_table.setAlternatingRowColors(True)
        # 序号:显示垂直表头(行号 1,2,3…),随筛选/排序自动重排,不占数据列
        _vh = self.pdd_pub_table.verticalHeader()
        _vh.setVisible(True)
        _vh.setDefaultSectionSize(46)   # 行高加高,容三缩图
        _vh.setFixedWidth(38)
        _vh.setStyleSheet("QHeaderView::section{background:#F9FAFB;color:#9CA3AF;border:none;font-size:11px;}")
        lay.addWidget(self.pdd_pub_table, 1)

        self.pdd_pub_status = QLabel("（开发中）等待加载")
        self.pdd_pub_status.setStyleSheet("color:#6B7280;")
        lay.addWidget(self.pdd_pub_status)
        return page

    def _pdd_mark_spec_code_manually_fixed(self):
        """Record the user-confirmed completion of selected spec-code repairs locally only."""
        selected = self._pdd_pub_checked_records()
        targets = [item for item in selected if item.get("goods_id") and item.get("status") != "deleted"]
        if not targets:
            QMessageBox.information(self, "标记人工修复成功", "请先勾选要确认的已发布商品。")
            return
        names = "\n".join(f"  • {item.get('goods_id')}  {item.get('target_name','')[:30]}" for item in targets[:8])
        more = f"\n  …还有 {len(targets)-8} 条" if len(targets) > 8 else ""
        if QMessageBox.question(
                self, "确认人工修复成功",
                f"确认以下 {len(targets)} 条商品的规格编码已由人工修复完成？\n{names}{more}\n\n"
                "只更新本地发布历史并清除规格编码导致的绿标；不会打开或修改 PDD。",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        import json as _json
        path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        try:
            history = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
        except Exception as exc:
            QMessageBox.critical(self, "读取失败", f"读发布历史失败：\n{exc}")
            return
        target_ids = {str(item.get("goods_id")) for item in targets}
        confirmed_at = time.strftime("%Y-%m-%d %H:%M:%S")
        changed = 0
        for record in history:
            if str(record.get("goods_id", "")) not in target_ids:
                continue
            spec_code = dict(record.get("spec_code") or {})
            spec_code.update({"status": "ok", "reason": "manual-confirmed", "manually_confirmed_at": confirmed_at})
            record["spec_code"] = spec_code
            changed += 1
        try:
            path.write_text(_json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            QMessageBox.critical(self, "保存失败", str(exc))
            return
        self._pdd_load_published()
        QMessageBox.information(self, "已标记人工修复成功",
            f"✅ 已确认 {changed} 条商品的规格编码修复成功。\n"
            "规格编码导致的 🟢 标记已清除；AI 同款未核验导致的标记会保留。")
    def _pdd_force_mark_mismatch(self):
        """把勾选的已发布商品状态强制改成 mismatch(写回 history),
        让用户能对"程序误判为已对齐但实际有问题"的商品再跑核查未对齐。
        """
        selected = self._pdd_pub_checked_records()
        if not selected:
            QMessageBox.information(self, "强制标记未对齐", "请先勾选要标记的商品")
            return
        # 只改非 deleted 的(回收站的不动)
        targets = [s for s in selected if s.get("status") != "deleted" and s.get("goods_id")]
        if not targets:
            QMessageBox.warning(self, "强制标记未对齐", "勾选项都没有有效 goods_id 或在回收站")
            return
        names = "\n".join(f"  • {t.get('goods_id')}  {t.get('target_name','')[:30]}" for t in targets[:8])
        more = f"\n  …还有 {len(targets)-8} 条" if len(targets) > 8 else ""
        if QMessageBox.question(self, "确认强制标记未对齐",
                f"把以下 {len(targets)} 条状态改成「⚠ 未对齐」?\n{names}{more}\n\n"
                f"改完可以对它们点「🔍 核查未对齐原因」重新核查 + 自动修复。",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 写回 history
        import json as _json
        path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        try:
            hist = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
        except Exception as e:
            QMessageBox.critical(self, "读取失败", f"读 history 失败:\n{e}")
            return
        tgt_ids = {t.get("goods_id") for t in targets}
        n = 0
        for h in hist:
            if h.get("goods_id") in tgt_ids and h.get("status") != "mismatch":
                h["status"] = "mismatch"
                n += 1
        try:
            path.write_text(_json.dumps(hist, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pdd_load_published()
        QMessageBox.information(self, "已标记",
            f"✅ 已把 {n} 条标记为「未对齐」。\n现在勾选它们,点「🔍 核查未对齐原因」即可重新核查修复。")

    # ── 已发布:修复选中商品的空规格编码 ──────────────────────────────────
    def _pdd_repair_selected_spec_codes(self):
        selected = self._pdd_pub_checked_records()
        targets = [r for r in selected if r.get("goods_id") and r.get("store")
                   and r.get("status") not in ("deleted", "taken_down", "not_listed")]
        if not targets:
            QMessageBox.information(self, "修复规格编码", "请先勾选仍在架且带店铺信息的商品。")
            return
        old = getattr(self, "_pdd_spec_repair_proc", None)
        if old is not None and old.state() != QProcess.NotRunning:
            QMessageBox.information(self, "修复规格编码", "已有修复任务正在运行。")
            return
        by_store = {}
        for rec in targets:
            by_store.setdefault(rec["store"], []).append(rec)
        stores = "\n".join(f"  • {s}: {len(rs)} 条" for s, rs in by_store.items())
        if QMessageBox.question(
                self, "⚠ 确认修复规格编码",
                f"将逐个进入 {len(targets)} 条已发布商品的 PDD 编辑页。\n{stores}\n\n"
                "会补齐空白编码，并纠正与重新计算结果不一致的已有编码。\n"
                "仅在实际写入至少一条编码后提交。\n"
                "不会改价格、库存、规格名、图片或商品状态。\n\n确认执行？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._pdd_spec_repair_stores = list(by_store.items())
        self._pdd_spec_repair_idx = 0
        self._pdd_spec_repair_results = []
        self._pdd_spec_repair_next_store()

    def _pdd_spec_repair_next_store(self):
        if self._pdd_spec_repair_idx >= len(self._pdd_spec_repair_stores):
            self._pdd_spec_repair_finish()
            return
        store, records = self._pdd_spec_repair_stores[self._pdd_spec_repair_idx]
        ts = time.strftime("%Y%m%d_%H%M%S")
        root = Path(r"D:/files/data/pdd")
        in_path = root / f"spec_code_repair_in_{ts}_{self._pdd_spec_repair_idx}.json"
        out_path = root / f"spec_code_repair_out_{ts}_{self._pdd_spec_repair_idx}.json"
        payload = [{"goods_id": str(r.get("goods_id", "")), "target_name": r.get("target_name", ""),
                    "detail_url": r.get("detail_url", ""), "supplier_url": r.get("supplier_url", "") or "",
                    "units_map": r.get("units_map") or {}, "suffix": r.get("suffix", "") or ""}
                   for r in records]
        in_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self.pdd_pub_status.setText(f"🔧 修复规格编码：店铺「{store}」{len(records)} 条…")
        proc = QProcess(self); proc.setProcessChannelMode(QProcess.MergedChannels)
        log_path = root / "publish_logs" / f"spec_code_repair_{ts}_{self._pdd_spec_repair_idx}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        proc.setStandardOutputFile(str(log_path), QProcess.Truncate)
        args = ["-u", r"D:/files/pdd_inspect.py", "--store", store,
                "--records-json", str(in_path), "--output-json", str(out_path),
                "--repair-spec-code", "--auto-close"] + self._pdd_browser_args()
        proc.finished.connect(lambda code, _s, op=out_path, ip=in_path:
                              self._pdd_spec_repair_store_done(code, op, ip))
        self._pdd_spec_repair_proc = proc
        self._pdd_inspect_last_log = str(log_path)
        proc.start(sys.executable, args)

    def _pdd_spec_repair_store_done(self, code, out_path, in_path):
        try:
            data = json.loads(out_path.read_text(encoding="utf-8")) if out_path.exists() else []
            if isinstance(data, list):
                self._pdd_spec_repair_results.extend(data)
        except Exception as exc:
            print(f"[规格编码修复] 解析结果失败: {exc}")
        try: in_path.unlink()
        except Exception: pass
        self._pdd_spec_repair_idx += 1
        self._pdd_spec_repair_next_store()

    def _pdd_spec_repair_finish(self):
        results = getattr(self, "_pdd_spec_repair_results", []) or []
        # The edit-page direct readback is authoritative for fields just written.
        # PDD may still misread the detail table immediately after submit; do not
        # preserve an old green marker when the submit and all direct readbacks passed.
        updates = {}
        for item in results:
            spec = item.get("spec_code")
            if not isinstance(spec, dict):
                continue
            if item.get("submitted") and spec.get("write_verified"):
                saved = dict(spec)
                saved.update({"status": "ok", "reason": ""})
                updates[str(item.get("goods_id", ""))] = saved
            elif item.get("verified") and spec.get("status") == "ok":
                updates[str(item.get("goods_id", ""))] = spec
        if updates:
            hpath = Path(r"D:/files/data/pdd/pdd_publish_history.json")
            try:
                history = json.loads(hpath.read_text(encoding="utf-8-sig")) if hpath.exists() else []
                for rec in history:
                    if str(rec.get("goods_id", "")) in updates:
                        rec["spec_code"] = updates[str(rec.get("goods_id", ""))]
                hpath.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception as exc:
                print(f"[规格编码修复] 回写历史失败: {exc}")
        submitted = sum(1 for r in results if r.get("submitted"))
        self._pdd_load_published()
        self.pdd_pub_status.setText(f"✅ 规格编码修复完成：已提交 {submitted} · 未提交 {len(results)-submitted}")
        lines = [f"共处理 {len(results)} 条：已提交 {submitted} · 未提交 {len(results)-submitted}"]
        for item in results:
            result = item.get("spec_code") or {}
            reason = result.get("reason", "") or ";".join(item.get("reasons", []) or [])
            lines.append(f"• {item.get('goods_id','')} 写入 {result.get('written', 0)} 条 · 提交={'是' if item.get('submitted') else '否'} · {reason}")
        QMessageBox.information(self, "修复规格编码 — 完成", "\n".join(lines))
    # ── 已发布:核查未对齐原因(调 pdd_inspect.py) ───────────────────────
    def _pdd_inspect_mismatch(self):
        """对**勾选**的 status=mismatch 记录,分店铺批量调 pdd_inspect.py 抓取差异原因。
        完成后弹汇总弹窗 + 结果 JSON 落地 data/pdd/inspect_<时间>.json。
        """
        # 收集勾选的记录(复用 _pdd_published_filter 的过滤逻辑,跟当前表格展示一致)
        all_data = [r for r in (getattr(self, "_pdd_pub_all", []) or [])
                    if r.get("status") != "deleted"]
        state = getattr(self, "_pdd_pub_filter_state", "all")
        if state == "listed":
            all_data = [r for r in all_data if r.get("status") == "ok"]
        elif state == "taken_down":
            all_data = [r for r in all_data if r.get("status") == "taken_down"]
        elif state == "mismatch":
            all_data = [r for r in all_data if r.get("status") == "mismatch"]
        elif state == "need_price":
            all_data = [r for r in all_data if r.get("status") == "need_price"]
        kw = self.pdd_pub_search.text().strip()
        if kw:
            shown = [r for r in all_data if self._pdd_pub_kw_hit(r, kw)]
        else:
            shown = all_data
        # 直接读勾选框id收集(不靠行号 shown[r],防错位),只留 status=mismatch
        mismatches = [r for r in self._pdd_pub_checked_records()
                      if r.get("status") == "mismatch" and r.get("goods_id")]
        if not mismatches:
            QMessageBox.information(self, "核查未对齐",
                "请先勾选 ⚠ 未对齐 的商品(只对勾选的、且 status=mismatch 的核查)")
            return
        # 按 store 分组
        by_store: dict[str, list] = {}
        for r in mismatches:
            s = r.get("store", "")
            if not s or not r.get("goods_id"):
                continue
            by_store.setdefault(s, []).append(r)
        if not by_store:
            QMessageBox.warning(self, "核查未对齐", "未对齐记录都缺 store 或 goods_id,无法核查")
            return
        # 确认
        store_lines = "\n".join(f"  • {s}: {len(rs)} 条" for s, rs in by_store.items())
        if QMessageBox.question(self, "确认核查",
                f"将对 {len(mismatches)} 条未对齐记录逐个打开 PDD 编辑页对比期望/实际值,"
                f"分 {len(by_store)} 个店铺串行处理:\n{store_lines}\n\n"
                f"每条约 8-15 秒,期间不能关浏览器。继续?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) != QMessageBox.Yes:
            return
        # 状态变量
        self._pdd_inspect_stores = list(by_store.items())  # [(store, records), ...]
        self._pdd_inspect_results: list[dict] = []
        self._pdd_inspect_idx = 0  # 当前处理到第几个 store
        self._pdd_inspect_total_records = len(mismatches)
        self.pdd_pub_status.setText(f"🔍 核查中: 0/{len(mismatches)} (准备第 1 个店铺)")
        self._pdd_inspect_next_store()

    def _pdd_inspect_next_store(self):
        """处理下一个店铺的核查;全部完成 → 弹汇总弹窗。"""
        if self._pdd_inspect_idx >= len(self._pdd_inspect_stores):
            # 全部完成
            self._pdd_inspect_show_summary()
            return
        store, records = self._pdd_inspect_stores[self._pdd_inspect_idx]
        # 写 input json
        import time as _t
        ts = _t.strftime("%Y%m%d_%H%M%S")
        in_path  = Path(rf"D:/files/data/pdd/inspect_in_{ts}_{self._pdd_inspect_idx}.json")
        out_path = Path(rf"D:/files/data/pdd/inspect_out_{ts}_{self._pdd_inspect_idx}.json")
        in_path.parent.mkdir(parents=True, exist_ok=True)
        # 只把核查需要的字段写过去(避免 PDD store profile 路径泄漏等)
        payload = []
        for r in records:
            payload.append({
                "goods_id":         str(r.get("goods_id", "")),
                "target_name":      r.get("target_name", ""),
                "detail_url":       r.get("detail_url", ""),
                "supplier_cost":    float(r.get("supplier_cost", 0) or 0),
                "shipping":         float(r.get("shipping", 4.0) or 4.0),
                "margin":           float(r.get("margin", 0.9) or 0.9),
                "single_buy_extra": float(r.get("single_buy_extra", 2.0) or 2.0),
                "suffix":           r.get("suffix", "") or "",
                "stock":            int(r.get("stock", 0) or 0),
            })
        in_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

        # 启动子进程
        self.pdd_pub_status.setText(
            f"🔍 核查中: 店铺「{store}」 ({self._pdd_inspect_idx+1}/{len(self._pdd_inspect_stores)})  "
            f"{len(records)} 条…"
        )
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        # stdout+stderr 落盘,方便实时日志页 tail + 事后排查
        log_path = Path(rf"D:/files/data/pdd/publish_logs/inspect_{ts}_{self._pdd_inspect_idx}.log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        proc.setStandardOutputFile(str(log_path), QProcess.Truncate)
        args = [
            "-u", r"D:/files/pdd_inspect.py",
            "--store", store,
            "--records-json", str(in_path),
            "--output-json",  str(out_path),
            "--auto-close",
        ]
        args += self._pdd_browser_args()
        proc.finished.connect(
            lambda code, _s, op=out_path, ip=in_path:
                self._pdd_inspect_one_store_done(code, op, ip))
        self._pdd_inspect_proc = proc
        self._pdd_inspect_last_log = str(log_path)  # 实时日志页可选默认值
        proc.start(sys.executable, args)

    def _pdd_inspect_one_store_done(self, code, out_path, in_path):
        """一个店铺的核查完成 → 读结果 → 下一个店铺。"""
        try:
            if out_path.exists():
                data = json.loads(out_path.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    store = self._pdd_inspect_stores[self._pdd_inspect_idx][0]
                    for d in data:
                        d["store"] = store
                    self._pdd_inspect_results.extend(data)
        except Exception as e:
            print(f"[核查] 解析输出失败: {e}")
        # 删临时输入文件(输出文件保留,作记录)
        try:
            in_path.unlink()
        except Exception:
            pass
        self._pdd_inspect_idx += 1
        self._pdd_inspect_next_store()

    def _pdd_inspect_show_summary(self):
        """弹汇总弹窗,DetailedText 分 3 段:已对齐 / 已自动修复 / 仍有问题。
        ok=True 的记录回写 pdd_publish_history.json,把 status mismatch → ok。
        """
        results = self._pdd_inspect_results
        already_ok = [r for r in results if r.get("ok") and not r.get("fix_log")]
        fixed      = [r for r in results if r.get("fixed")]      # 修复后 ok
        unfixed    = [r for r in results if not r.get("ok") and not r.get("fixed")]

        # === 回写 history:把 ok=True 的从 mismatch → ok 并刷新表格 ===
        ok_ids = {str(r.get("goods_id", "")).strip()
                  for r in results if r.get("ok") and str(r.get("goods_id", "")).strip()}
        if ok_ids:
            import json as _json
            hpath = Path(r"D:/files/data/pdd/pdd_publish_history.json")
            try:
                hist = _json.load(open(hpath, encoding="utf-8-sig")) if hpath.exists() else []
                changed = 0
                for h in hist:
                    if (str(h.get("goods_id", "")).strip() in ok_ids
                            and h.get("status") == "mismatch"):
                        h["status"] = "ok"
                        changed += 1
                if changed:
                    hpath.write_text(_json.dumps(hist, ensure_ascii=False, indent=2),
                                     encoding="utf-8")
                    print(f"[核查] 回写 history: {changed} 条 mismatch → ok")
                    try:
                        self._pdd_load_published()
                    except Exception as _e:
                        print(f"[核查] 刷新已发布表失败: {_e}")
            except Exception as _e:
                print(f"[核查] 回写 history 失败: {_e}")
        self.pdd_pub_status.setText(
            f"✅ 核查完成: 已对齐 {len(already_ok)} · 自动修复 {len(fixed)} · 仍有问题 {len(unfixed)}")

        lines: list[str] = []
        lines.append(f"共核查 {len(results)} 条:")
        lines.append(f"  ✅ 已对齐(无需处理) {len(already_ok)}")
        lines.append(f"  🔧 自动修复成功     {len(fixed)}")
        lines.append(f"  ❌ 仍有问题/无法修复 {len(unfixed)}")

        if fixed:
            lines.append("")
            lines.append("【🔧 自动修复成功(以下差异都已解决)】")
            for r in fixed:
                lines.append(f"\n• 店铺={r.get('store','')}  goods_id={r.get('goods_id','')}")
                lines.append(f"  {r.get('name','')[:60]}")
                lines.append(f"  ✓ 已修正以下项:")
                for reason in (r.get("reasons", []) or []):
                    # 去掉原文里的 ❌(已经解决了,别用红叉误导),统一前缀"已修正"
                    clean = reason.replace("❌", "").strip()
                    lines.append(f"    ✓ {clean}")
                lines.append(f"  操作:")
                for step in (r.get("fix_log", []) or []):
                    lines.append(f"    → {step}")

        if unfixed:
            lines.append("")
            lines.append("【❌ 仍有问题】")
            for r in unfixed:
                lines.append(f"\n• 店铺={r.get('store','')}  goods_id={r.get('goods_id','')}")
                lines.append(f"  {r.get('name','')[:60]}")
                for reason in (r.get("reasons", []) or []):
                    lines.append(f"    - {reason}")
                # 修复后仍剩的差异
                if r.get("reasons2"):
                    lines.append(f"  修复后仍剩:")
                    for reason in r["reasons2"]:
                        lines.append(f"    - {reason}")
                if r.get("fix_log"):
                    lines.append(f"  修复操作:")
                    for step in r["fix_log"]:
                        lines.append(f"    → {step}")
                if r.get("fix_skipped_reason"):
                    lines.append(f"  跳过原因: {r['fix_skipped_reason']}")
                if r.get("url"):
                    lines.append(f"  🔗 {r['url']}")

        if already_ok:
            lines.append("")
            lines.append("【✅ 本来就对齐】")
            for r in already_ok[:10]:
                lines.append(f"  ✓ goods_id={r.get('goods_id','')}  {r.get('name','')[:50]}")
            if len(already_ok) > 10:
                lines.append(f"  …还有 {len(already_ok)-10} 条")

        try:
            mb = QMessageBox(self)
            mb.setIcon(QMessageBox.Warning if unfixed else QMessageBox.Information)
            mb.setWindowTitle("核查未对齐 — 汇总")
            # 自适应措辞:没遗留问题时用正面语气,不显示刺眼的"❌ 0"
            if unfixed:
                head = (f"⚠ 还有 {len(unfixed)} 条需人工处理\n\n"
                        f"共核查 {len(results)} 条:已对齐 {len(already_ok)} · "
                        f"自动修复 {len(fixed)} · 仍有问题 {len(unfixed)}")
            elif fixed:
                head = (f"✅ 全部处理完成,无遗留问题\n\n"
                        f"共核查 {len(results)} 条:自动修复 {len(fixed)} 条"
                        + (f",本来就对齐 {len(already_ok)} 条" if already_ok else ""))
            else:
                head = (f"✅ 全部本来就对齐,无需处理\n\n共核查 {len(results)} 条")
            mb.setText(head)
            mb.setDetailedText("\n".join(lines))
            mb.exec_()
        except Exception:
            QMessageBox.information(self, "核查未对齐", "\n".join(lines))

    def _pdd_takedown_mismatch(self):
        """触发 pdd_takedown.py 自动下架当前店铺所有 mismatch 商品"""
        store = self.pdd_store_combo.currentText() if hasattr(self, "pdd_store_combo") else ""
        if not store or "无已登录" in store:
            QMessageBox.warning(self, "下架核查", "请先在「待发布」页选择店铺")
            return
        mismatches = [r for r in (getattr(self, "_pdd_pub_all", []) or [])
                      if r.get("status") == "mismatch" and r.get("store") == store]
        if not mismatches:
            QMessageBox.information(self, "下架核查", f"店铺「{store}」无未对齐商品")
            return
        ans = QMessageBox.question(self, "确认下架核查",
            f"店铺「{store}」共 {len(mismatches)} 件未对齐商品。\n"
            "将打开浏览器逐个搜索 goods_id，找到则下架，未找到则标记 not_listed。\n\n确认执行？",
            QMessageBox.Yes | QMessageBox.No)
        if ans != QMessageBox.Yes:
            return
        if getattr(self, "_pdd_takedown_running", False):
            QMessageBox.information(self, "下架核查", "已有下架任务进行中")
            return
        self._pdd_takedown_running = True
        self.pdd_pub_status.setText(f"🚫 下架核查中：{store} 共 {len(mismatches)} 件…")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = ["-u", r"D:/files/pdd_takedown.py", "--store", store, "--auto-close"]
        args += self._pdd_browser_args()
        proc.finished.connect(lambda code, _s: self._pdd_takedown_finished(code))
        self._pdd_takedown_proc = proc
        proc.start("python", args)

    def _pdd_takedown_finished(self, code):
        self._pdd_takedown_running = False
        if code == 0:
            self.pdd_pub_status.setText("✅ 下架完成，已重新加载历史")
        else:
            self.pdd_pub_status.setText(f"⚠ 下架退出 code={code}")
        self._pdd_load_published()

    def _pdd_sync_status(self):
        """同步已发布商品的 PDD 实时状态(先查回收站=已删除,再查全部tab=在售/已下架/售罄)。
        勾了具体商品→同步勾选的;没勾→弹店铺多选框,自己挑1个/几个/全部。"""
        all_data = getattr(self, "_pdd_pub_all", []) or []
        sel = self._pdd_get_selected_records()
        if sel:
            # 勾选了具体记录 → 同步这些(按店铺分组)
            src = [r for r in sel if r.get("store") and r.get("goods_id")]
            if not src:
                QMessageBox.information(self, "同步状态", "暂无可同步的记录(勾选项缺 store/goods_id?)")
                return
            chosen = {}
            for r in src:
                chosen.setdefault(r.get("store", ""), []).append(r.get("goods_id", ""))
            summary = "\n".join(f"  • {s}: {len(ids)} 条" for s, ids in chosen.items())
            if QMessageBox.question(self, "同步状态",
                f"将同步勾选的 {len(src)} 条商品状态。\n\n{summary}\n\n确认？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) != QMessageBox.Yes:
                return
        else:
            # 全量 → 弹店铺多选框,自己挑要同步哪些店铺
            src = [r for r in all_data if r.get("store") and r.get("goods_id") and r.get("status") != "deleted"]
            target = {}
            for r in src:
                target.setdefault(r.get("store", ""), []).append(r.get("goods_id", ""))
            target.pop("", None)
            if not target:
                QMessageBox.information(self, "同步状态", "暂无可同步的记录")
                return
            chosen = self._pdd_sync_pick_stores(target)
            if not chosen:
                return
        if getattr(self, "_pdd_sync_running", False):
            QMessageBox.information(self, "同步状态", "已有同步任务进行中")
            return
        self._pdd_sync_queue = [(s, ids) for s, ids in chosen.items() if ids]
        self._pdd_sync_running = True
        self._pdd_run_next_sync()

    def _pdd_sync_pick_stores(self, target: dict):
        """弹店铺多选框(默认全选,带 全选/全不选),返回 {store: ids};取消/没勾返回 None。"""
        from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QCheckBox,
                                     QPushButton, QLabel, QDialogButtonBox)
        dlg = QDialog(self); dlg.setWindowTitle("同步状态 — 选择店铺")
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel("勾选要同步的店铺(会查 PDD 在售/已下架/售罄/回收站):"))
        boxes = {}
        for s, ids in target.items():
            cb = QCheckBox(f"{s}   ({len(ids)} 条)"); cb.setChecked(True)
            v.addWidget(cb); boxes[s] = cb
        row = QHBoxLayout()
        b_all = QPushButton("全选"); b_none = QPushButton("全不选")
        b_all.clicked.connect(lambda: [cb.setChecked(True) for cb in boxes.values()])
        b_none.clicked.connect(lambda: [cb.setChecked(False) for cb in boxes.values()])
        row.addWidget(b_all); row.addWidget(b_none); row.addStretch(1)
        v.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return None
        chosen = {s: target[s] for s, cb in boxes.items() if cb.isChecked()}
        if not chosen:
            QMessageBox.information(self, "同步状态", "没勾选任何店铺")
            return None
        return chosen

    def _pdd_run_next_sync(self):
        if not self._pdd_sync_queue:
            self._pdd_sync_running = False
            self.pdd_pub_status.setText("✅ 全部同步完成")
            self._pdd_load_published()
            return
        store, ids = self._pdd_sync_queue.pop(0)
        self.pdd_pub_status.setText(
            f"🔄 同步中：店铺「{store}」 {len(ids)} 条  剩余批次 {len(self._pdd_sync_queue)}")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = ["-u", r"D:/files/pdd_sync_status.py",
                "--store", store, "--auto-close"]
        if ids and len(ids) < 999:  # 指定 IDs 避免每个店铺全量同步
            args += ["--goods-ids", ",".join(ids)]
        args += self._pdd_browser_args()
        proc.finished.connect(lambda code, _s: QTimer.singleShot(1000, self._pdd_run_next_sync))
        self._pdd_sync_proc = proc
        proc.start("python", args)

    def _pdd_get_selected_records(self) -> list:
        """获取已发布表当前勾选的记录列表（兼容搜索过滤）"""
        return self._pdd_pub_checked_records()

    def _pdd_delete_record(self):
        """仅从本地 history JSON 删除选中记录（不删 PDD 店铺）"""
        sel = self._pdd_get_selected_records()
        if not sel:
            QMessageBox.information(self, "删除程序记录", "请先勾选要删除的记录")
            return
        names = "\n".join(f"  • {r.get('target_name','')[:30]} (id={r.get('goods_id','')})" for r in sel[:8])
        more = f"\n…还有 {len(sel)-8} 件" if len(sel) > 8 else ""
        if QMessageBox.question(self, "确认删除程序记录",
                f"将从本地历史中删除 {len(sel)} 条记录（不影响 PDD 店铺商品）:\n\n{names}{more}\n\n确认？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 删除：用 (goods_id, store, time) 三元组确保唯一
        keys = {(r.get("goods_id",""), r.get("store",""), r.get("time","")) for r in sel}
        import json as _json
        path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        try:
            history = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
        except Exception:
            history = []
        new_history = [r for r in history
                       if (r.get("goods_id",""), r.get("store",""), r.get("time","")) not in keys]
        with open(path, "w", encoding="utf-8") as f:
            _json.dump(new_history, f, ensure_ascii=False, indent=2)
        removed = len(history) - len(new_history)
        self._pdd_load_published()
        QMessageBox.information(self, "完成", f"已从程序记录中删除 {removed} 条")

    def _pdd_delete_store(self):
        """删除选中商品。两条路径:
        - status=taken_down → 调 pdd_delete.py 去 PDD 已下架页真删除 + 标记 deleted
        - status=not_listed → 直接本地标记 deleted(PDD 上已不存在,无需操作)
        """
        sel = self._pdd_get_selected_records()
        if not sel:
            QMessageBox.information(self, "删除店铺商品", "请先勾选要删除的商品")
            return
        valid_pdd        = [r for r in sel if r.get("status") == "taken_down"]
        valid_local_only = [r for r in sel if r.get("status") == "not_listed"]
        need_td          = [r for r in sel if r.get("status") in ("ok", "sold_out")]   # 已发布/售罄:必须先下架
        skipped = len(sel) - len(valid_pdd) - len(valid_local_only)
        if not valid_pdd and not valid_local_only:
            if need_td:
                QMessageBox.warning(self, "删除店铺商品",
                    f"勾选的 {len(need_td)} 件是【已发布 / 已售罄】,必须先【下架】才能删除。\n\n"
                    f"请先点「🚫 批量下架选中」把它们下架(变「已下架」)后,再来删除。")
            else:
                QMessageBox.warning(self, "删除店铺商品",
                    f"勾选的 {len(sel)} 件均不能删除\n"
                    f"只接受:🚫 已下架 (需 PDD 后台真删除) 或 ⊘ 未上架 (PDD 上已不存在,仅清本地)")
            return
        # 构造确认信息
        lines = []
        if valid_pdd:
            names = "\n".join(f"  • [{r.get('store','?')}] {r.get('target_name','')[:30]} (id={r.get('goods_id','')})"
                              for r in valid_pdd[:5])
            more = f"\n  …还有 {len(valid_pdd)-5} 件" if len(valid_pdd) > 5 else ""
            lines.append(f"【🚫 已下架 — 去 PDD 后台真删除】{len(valid_pdd)} 件\n{names}{more}")
        if valid_local_only:
            names = "\n".join(f"  • [{r.get('store','?')}] {r.get('target_name','')[:30]} (id={r.get('goods_id','')})"
                              for r in valid_local_only[:5])
            more = f"\n  …还有 {len(valid_local_only)-5} 件" if len(valid_local_only) > 5 else ""
            lines.append(f"【⊘ 未上架 — 仅清本地记录】{len(valid_local_only)} 件\n{names}{more}")
        if skipped:
            extra = f",其中 {len(need_td)} 件【已发布/售罄】需先下架才能删" if need_td else ""
            lines.append(f"⚠ 跳过 {skipped} 件(非 已下架/未上架 状态){extra}")
        msg = "\n\n".join(lines) + "\n\n确认？(不可撤销)"
        if QMessageBox.question(self, "⚠ 确认永久删除店铺商品", msg,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 1) 先处理 not_listed 的本地直接标记 deleted
        if valid_local_only:
            try:
                import json as _json
                path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
                history = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
                keys = {(r.get("goods_id",""), r.get("store",""), r.get("time","")) for r in valid_local_only}
                for r in history:
                    if (r.get("goods_id",""), r.get("store",""), r.get("time","")) in keys:
                        r["status"] = "deleted"
                with open(path, "w", encoding="utf-8") as f:
                    _json.dump(history, f, ensure_ascii=False, indent=2)
                print(f"[本地删除] 已标记 {len(valid_local_only)} 条 not_listed → deleted (移入回收站)")
            except Exception as e:
                QMessageBox.critical(self, "本地标记失败", str(e))
                return
            self._pdd_load_published()
        if not valid_pdd:
            # 只有本地清理,不需要起子进程
            QMessageBox.information(self, "完成",
                f"已把 {len(valid_local_only)} 件未上架记录移入回收站")
            return
        if getattr(self, "_pdd_del_running", False):
            QMessageBox.information(self, "删除店铺商品", "已有删除任务进行中")
            return
        # 2) 改用 valid_pdd 走原 PDD 删除流程(下面分组到 by_store 那段)
        valid = valid_pdd
        # 按店铺分组
        by_store = {}
        for r in valid:
            by_store.setdefault(r.get("store",""), []).append(r.get("goods_id",""))
        self._pdd_del_queue = [(s, ids) for s, ids in by_store.items() if ids]
        self._pdd_del_running = True
        self._pdd_run_next_delete()

    def _pdd_run_next_delete(self):
        if not self._pdd_del_queue:
            self._pdd_del_running = False
            self.pdd_pub_status.setText("✅ 全部删除完成")
            self._pdd_load_published()
            return
        store, ids = self._pdd_del_queue.pop(0)
        self.pdd_pub_status.setText(
            f"🗑 删除中：店铺「{store}」 {len(ids)} 件  剩余批次 {len(self._pdd_del_queue)}")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = ["-u", r"D:/files/pdd_delete.py",
                "--store", store, "--goods-ids", ",".join(ids), "--auto-close"]
        args += self._pdd_browser_args()
        proc.finished.connect(lambda code, _s: QTimer.singleShot(1000, self._pdd_run_next_delete))
        self._pdd_del_proc = proc
        proc.start("python", args)

    def _pdd_pub_toggle_all(self, col: int):
        """点表头(图列插到 col 1 后,各列右移 1):
           col 0 全选;col 3 切换时间排序 ↓/↑;col 4 弹菜单筛选店铺;col 7 筛选定价模式
        """
        # col 3 时间排序
        if col == 3:
            cur = getattr(self, "_pdd_pub_sort_time_desc", None)
            self._pdd_pub_sort_time_desc = True if cur is None else (not cur)
            arrow = " ↓" if self._pdd_pub_sort_time_desc else " ↑"
            h = self.pdd_pub_table.horizontalHeaderItem(3)
            if h: h.setText("时间" + arrow)
            self._pdd_published_filter()
            return
        # col 4 店铺筛选(弹菜单列出所有店铺)
        if col == 4:
            all_stores = sorted({(r.get("store") or "").strip()
                                  for r in (getattr(self, "_pdd_pub_all", []) or [])
                                  if (r.get("store") or "").strip()})
            menu = QMenu(self)
            menu.setStyleSheet(
                "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
                "QMenu::item{color:#111827;padding:6px 18px;}"
                "QMenu::item:selected{background:#EEF2FF;color:#111827;}"
            )
            cur = getattr(self, "_pdd_pub_filter_store", None)
            act_all = menu.addAction(("● " if cur is None else "  ") + "全部店铺")
            menu.addSeparator()
            store_acts = []
            for s in all_stores:
                act = menu.addAction(("● " if cur == s else "  ") + s)
                store_acts.append((act, s))
            # 在表头第 3 列正下方弹出
            from PyQt5.QtCore import QPoint
            hdr = self.pdd_pub_table.horizontalHeader()
            section_x = hdr.sectionPosition(4)
            menu_pos = hdr.mapToGlobal(QPoint(section_x, hdr.height()))
            chosen = menu.exec_(menu_pos)
            picked = None
            if chosen == act_all:
                self._pdd_pub_filter_store = None
                picked = "全部店铺"
            else:
                for act, s in store_acts:
                    if chosen == act:
                        self._pdd_pub_filter_store = s
                        picked = s
                        break
            if picked is None:
                return  # 用户没选
            mark = "" if self._pdd_pub_filter_store is None else f" (筛选: {self._pdd_pub_filter_store[:8]})"
            h = self.pdd_pub_table.horizontalHeaderItem(4)
            if h: h.setText("店铺" + mark)
            self._pdd_published_filter()
            return
        # col 7 定价模式筛选(弹菜单)
        if col == 7:
            all_modes = sorted({(r.get("mode") or "").strip()
                                 for r in (getattr(self, "_pdd_pub_all", []) or [])
                                 if (r.get("mode") or "").strip()})
            menu = QMenu(self)
            menu.setStyleSheet(
                "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
                "QMenu::item{color:#111827;padding:6px 18px;}"
                "QMenu::item:selected{background:#EEF2FF;color:#111827;}"
            )
            cur = getattr(self, "_pdd_pub_filter_mode", None)
            act_all = menu.addAction(("● " if cur is None else "  ") + "全部定价模式")
            menu.addSeparator()
            mode_acts = []
            for m in all_modes:
                act = menu.addAction(("● " if cur == m else "  ") + m)
                mode_acts.append((act, m))
            from PyQt5.QtCore import QPoint
            hdr = self.pdd_pub_table.horizontalHeader()
            section_x = hdr.sectionPosition(7)
            menu_pos = hdr.mapToGlobal(QPoint(section_x, hdr.height()))
            chosen = menu.exec_(menu_pos)
            picked = None
            if chosen == act_all:
                self._pdd_pub_filter_mode = None
                picked = "全部"
            else:
                for act, m in mode_acts:
                    if chosen == act:
                        self._pdd_pub_filter_mode = m
                        picked = m
                        break
            if picked is None:
                return
            mark = "" if self._pdd_pub_filter_mode is None else f" (筛选: {self._pdd_pub_filter_mode[:8]})"
            h = self.pdd_pub_table.horizontalHeaderItem(7)
            if h: h.setText("定价模式" + mark)
            self._pdd_published_filter()
            return
        # col 0 全选/选前 N 条 —— 弹菜单
        if col != 0:
            return
        total_rows = self.pdd_pub_table.rowCount()
        if total_rows == 0:
            return
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu{background:white;color:#111827;border:1px solid #D1D5DB;padding:4px;}"
            "QMenu::item{color:#111827;padding:6px 18px;}"
            "QMenu::item:selected{background:#EEF2FF;color:#111827;}"
        )
        act_10  = menu.addAction(f"选前 10 条" + ("" if total_rows >= 10 else f" (只有 {total_rows} 条)"))
        act_50  = menu.addAction(f"选前 50 条" + ("" if total_rows >= 50 else f" (只有 {total_rows} 条)"))
        menu.addSeparator()
        act_all = menu.addAction(f"全选当前显示({total_rows})")
        act_clr = menu.addAction("取消全选")
        from PyQt5.QtCore import QPoint
        hdr = self.pdd_pub_table.horizontalHeader()
        section_x = hdr.sectionPosition(0)
        menu_pos = hdr.mapToGlobal(QPoint(section_x, hdr.height()))
        chosen = menu.exec_(menu_pos)
        if not chosen:
            return
        # 算要勾选的 row 数 + 是否清除
        target_n = 0
        do_clear = False
        if chosen == act_10:
            target_n = min(10, total_rows)
        elif chosen == act_50:
            target_n = min(50, total_rows)
        elif chosen == act_all:
            target_n = total_rows
        elif chosen == act_clr:
            do_clear = True
        # 先全部取消,再勾选前 target_n 行(设控件勾选框,经 stateChanged 同步到 item)
        for r in range(total_rows):
            cb = self._cell_checkbox(self.pdd_pub_table, r)
            if cb:
                cb.setChecked(False)
        if not do_clear:
            for r in range(target_n):
                cb = self._cell_checkbox(self.pdd_pub_table, r)
                if cb:
                    cb.setChecked(True)

    def _pdd_ap_save_review(self, review: dict):
        """Persist local human-review state only after an explicit UI action."""
        import json as _j
        p = Path(r"D:/files/data/pdd/roas_takedown_review.json")
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(_j.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
        self._pdd_ap_review = review

    def _pdd_ap_save_target_review(self, review: dict):
        """Persist target-adjustment review state only; this never calls PDD."""
        import json as _j
        p = Path(r"D:/files/data/pdd/roas_target_adjust_review.json")
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(_j.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
        self._pdd_ap_target_review = review

    def _pdd_ap_save_pause_review(self, review: dict):
        """Persist pause-review state only; this never pauses a plan."""
        import json as _j
        p = Path(r"D:/files/data/pdd/roas_pause_review.json")
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(_j.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
        self._pdd_ap_pause_review = review

    def _pdd_ap_pause_review_selected(self):
        reviews = getattr(self, "_pdd_ap_pause_review", {}) or {}
        return [r for r in self._pdd_ap_checked_records() if str(r.get("goods_id", "")) in reviews]

    def _pdd_ap_update_suggestions_selected(self, status):
        """Update local advice status only; never invoke an operational action."""
        selected = self._pdd_ap_checked_records()
        maps = (
            ("_pdd_ap_pause_review", self._pdd_ap_save_pause_review),
            ("_pdd_ap_target_review", self._pdd_ap_save_target_review),
            ("_pdd_ap_review", self._pdd_ap_save_review),
        )
        selected_ids = {str(rec.get("goods_id", "")) for rec in selected}
        if not selected_ids:
            QMessageBox.information(self, "\u5904\u7406\u5efa\u8bae", "\u8bf7\u5148\u52fe\u9009\u5e26\u5efa\u8bae\u6807\u8bb0\u7684\u5546\u54c1")
            return
        changed = 0
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for attr, saver in maps:
            review = dict(getattr(self, attr, {}) or {})
            touched = False
            for gid in selected_ids:
                item = review.get(gid)
                if not isinstance(item, dict) or item.get("status") != "pending":
                    continue
                item = dict(item)
                item.update(status=status)
                item["ignored_at" if status == "ignored" else "confirmed_at"] = now
                review[gid] = item
                changed += 1
                touched = True
            if touched:
                saver(review)
        if not changed:
            QMessageBox.information(self, "\u5904\u7406\u5efa\u8bae", "\u9009\u4e2d\u5546\u54c1\u6ca1\u6709\u5f85\u5904\u7406\u7684\u5efa\u8bae")
            return
        self._pdd_ap_apply_filter()
    def _pdd_ap_ignore_pause_review_selected(self):
        selected = self._pdd_ap_pause_review_selected()
        if not selected:
            QMessageBox.information(self, "\u5ffd\u7565\u6682\u505c\u5efa\u8bae", "\u8bf7\u5148\u52fe\u9009\u5e26\u23f8\u7684\u6682\u505c\u63a8\u5e7f\u5efa\u8bae")
            return
        review = dict(getattr(self, "_pdd_ap_pause_review", {}) or {})
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for rec in selected:
            item = dict(review.get(str(rec["goods_id"])) or {})
            item.update(status="ignored", ignored_at=now)
            review[str(rec["goods_id"])] = item
        self._pdd_ap_save_pause_review(review)
        self._pdd_ap_apply_filter()

    def _pdd_ap_confirm_pause_review_selected(self):
        selected = [r for r in self._pdd_ap_pause_review_selected() if (self._pdd_ap_pause_review.get(str(r.get("goods_id")), {}) or {}).get("status", "pending") == "pending"]
        if not selected:
            QMessageBox.information(self, "\u6807\u8bb0\u6682\u505c\u5df2\u4eba\u5de5\u5904\u7406", "\u8bf7\u5148\u52fe\u9009\u72b6\u6001\u4e3a\u5f85\u5ba1\u6838\u7684\u23f8\u5efa\u8bae")
            return
        review = dict(getattr(self, "_pdd_ap_pause_review", {}) or {})
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for rec in selected:
            item = dict(review.get(str(rec["goods_id"])) or {})
            item.update(status="confirmed_manual", confirmed_at=now)
            review[str(rec["goods_id"])] = item
        self._pdd_ap_save_pause_review(review)
        self._pdd_ap_apply_filter()
    def _pdd_ap_target_review_selected(self):
        reviews = getattr(self, "_pdd_ap_target_review", {}) or {}
        return [r for r in self._pdd_ap_checked_records() if str(r.get("goods_id", "")) in reviews]

    def _pdd_ap_ignore_target_review_selected(self):
        selected = self._pdd_ap_target_review_selected()
        if not selected:
            QMessageBox.information(self, "\u5ffd\u7565\u6295\u4ea7\u63d0\u9192", "\u8bf7\u5148\u52fe\u9009\u5e26\U0001F514\u7684\u76ee\u6807\u6295\u4ea7\u63d0\u9192")
            return
        review = dict(getattr(self, "_pdd_ap_target_review", {}) or {})
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for rec in selected:
            item = dict(review.get(str(rec["goods_id"])) or {})
            item.update(status="ignored", ignored_at=now)
            review[str(rec["goods_id"])] = item
        self._pdd_ap_save_target_review(review)
        self._pdd_ap_apply_filter()

    def _pdd_ap_confirm_target_review_selected(self):
        selected = [r for r in self._pdd_ap_target_review_selected() if (self._pdd_ap_target_review.get(str(r.get("goods_id")), {}) or {}).get("status", "pending") == "pending"]
        if not selected:
            QMessageBox.information(self, "\u6807\u8bb0\u5df2\u4eba\u5de5\u5904\u7406", "\u8bf7\u5148\u52fe\u9009\u72b6\u6001\u4e3a\u5f85\u5ba1\u6838\u7684\U0001F514\u63d0\u9192")
            return
        review = dict(getattr(self, "_pdd_ap_target_review", {}) or {})
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for rec in selected:
            item = dict(review.get(str(rec["goods_id"])) or {})
            item.update(status="confirmed_manual", confirmed_at=now)
            review[str(rec["goods_id"])] = item
        self._pdd_ap_save_target_review(review)
        self._pdd_ap_apply_filter()
    def _pdd_ap_review_selected(self):
        selected = [r for r in self._pdd_ap_checked_records() if str(r.get("goods_id", "")) in getattr(self, "_pdd_ap_review", {})]
        return selected

    def _pdd_ap_ignore_review_selected(self):
        selected = self._pdd_ap_review_selected()
        if not selected:
            QMessageBox.information(self, "\u5ffd\u7565\u4e0b\u67b6\u5efa\u8bae", "\u8bf7\u5148\u52fe\u9009\u5e26\u26a0\u7684\u4eba\u5de5\u4e0b\u67b6\u5efa\u8bae\u5546\u54c1")
            return
        if QMessageBox.question(self, "\u5ffd\u7565\u4e0b\u67b6\u5efa\u8bae", f"\u5c06\u5ffd\u7565 {len(selected)} \u6761\u4eba\u5de5\u4e0b\u67b6\u5efa\u8bae\uff1b\u4e0d\u4f1a\u6267\u884c\u4efb\u4f55\u63a8\u5e7f\u6216\u4e0b\u67b6\u64cd\u4f5c\u3002", QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        review = dict(getattr(self, "_pdd_ap_review", {}) or {})
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for rec in selected:
            item = dict(review.get(str(rec["goods_id"])) or {})
            item.update(status="ignored", ignored_at=now)
            review[str(rec["goods_id"])] = item
        self._pdd_ap_save_review(review)
        self._pdd_ap_apply_filter()

    def _pdd_ap_confirm_review_selected(self):
        selected = self._pdd_ap_review_selected()
        selected = [r for r in selected if (self._pdd_ap_review.get(str(r.get("goods_id")), {}) or {}).get("status", "pending") == "pending"]
        if not selected:
            QMessageBox.information(self, "\u5ffd\u7565\u4e0b\u67b6\u5efa\u8bae", "\u8bf7\u52fe\u9009\u72b6\u6001\u4e3a\u5f85\u5ba1\u6838\u7684\u26a0\u5546\u54c1")
            return
        answer = QMessageBox.question(self, "\u786e\u8ba4\u5ba1\u6838\u4e0b\u67b6\u2026", f"\u4f60\u786e\u8ba4\u8fd9 {len(selected)} \u4ef6\u5546\u54c1\u5e94\u8fdb\u5165\u4e0b\u67b6\u6d41\u7a0b\u5417\uff1f\n\n\u4e0b\u4e00\u6b65\u4ecd\u4f1a\u663e\u793a\u65e2\u6709\u7684\u5b9e\u9645\u4e0b\u67b6\u4e8c\u6b21\u786e\u8ba4\uff1b\u53d6\u6d88\u4e8c\u6b21\u786e\u8ba4\u4e0d\u4f1a\u6267\u884c\u4e0b\u67b6\u3002", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        review = dict(getattr(self, "_pdd_ap_review", {}) or {})
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for rec in selected:
            item = dict(review.get(str(rec["goods_id"])) or {})
            item.update(status="confirmed", confirmed_at=now)
            review[str(rec["goods_id"])] = item
        self._pdd_ap_save_review(review)
        self._pdd_takedown_records(selected)

    def _pdd_ap_takedown_selected(self):
        """自动推广页：把勾选商品交给已发布页的原有批量下架链路。"""
        selected = [r for r in self._pdd_ap_checked_records() if r.get("goods_id")]
        self._pdd_takedown_records(selected)

    def _pdd_takedown_selected(self):
        """已发布页：把勾选商品交给共用的批量下架链路。"""
        selected = [r for r in self._pdd_pub_checked_records() if r.get("goods_id")]
        self._pdd_takedown_records(selected)

    def _pdd_takedown_records(self, selected):
        """共用批量下架：按店铺串行调用既有 pdd_takedown.py。"""
        if not selected:
            QMessageBox.information(self, "批量下架", "请先勾选要下架的商品")
            return
        by_store = {}
        for rec in selected:
            by_store.setdefault(rec.get("store", ""), []).append(rec)
        names = "\n".join(f"  • [{r.get('store','?')}] {r.get('target_name','')[:30]} (id={r.get('goods_id','')})"
                          for r in selected[:8])
        more = f"\n…还有 {len(selected)-8} 件" if len(selected) > 8 else ""
        ans = QMessageBox.question(self, "确认批量下架",
            f"将下架以下 {len(selected)} 件商品（按店铺分批，每店铺独立浏览器）：\n\n{names}{more}\n\n"
            "这是实际下架操作；确认后会从拼多多后台下架。",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ans != QMessageBox.Yes:
            return
        if getattr(self, "_pdd_takedown_running", False):
            QMessageBox.information(self, "批量下架", "已有下架任务进行中")
            return
        self._pdd_takedown_queue = list(by_store.items())
        self._pdd_takedown_running = True
        self._pdd_run_next_takedown()

    def _pdd_set_takedown_status(self, message: str):
        """下架队列可从已发布或自动推广页启动；只更新已创建的页面状态栏。"""
        if hasattr(self, "pdd_pub_status"):
            self.pdd_pub_status.setText(message)
        if hasattr(self, "pdd_ap_status"):
            self.pdd_ap_status.setText(message)

    def _pdd_run_next_takedown(self):
        if not self._pdd_takedown_queue:
            self._pdd_takedown_running = False
            self._pdd_set_takedown_status("✅ 全部批量下架完成")
            if hasattr(self, "pdd_pub_table"):
                self._pdd_load_published()
            if hasattr(self, "pdd_ap_table"):
                self._pdd_ap_reload_table()
            return
        store, recs = self._pdd_takedown_queue.pop(0)
        ids = ",".join(r["goods_id"] for r in recs)
        self._pdd_set_takedown_status(
            f"🚫 下架中：店铺「{store}」 {len(recs)} 件  剩余批次 {len(self._pdd_takedown_queue)}")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = ["-u", r"D:/files/pdd_takedown.py",
                "--store", store, "--goods-ids", ids, "--auto-close"]
        args += self._pdd_browser_args()
        proc.finished.connect(lambda code, _s: QTimer.singleShot(1000, self._pdd_run_next_takedown))
        self._pdd_takedown_proc = proc
        proc.start("python", args)

    # ── 已发布 → 待发布:重建待发布记录(回退/重发共用) ───────────────────────
    def _pdd_published_to_pending(self, pub: dict, lib_by_link: dict):
        """把一条已发布(history)记录重建成一条待发布(pending)记录。
        已发布记录没存图片 URL/批准文号,靠 supplier_url 匹配商品库取回。
        返回 (pending_dict, "") 或 (None, 失败原因)。
        """
        link = (pub.get("supplier_url", "") or "").strip()
        if not link:
            return None, "该记录缺少 1688 链接,无法重建"
        lib = lib_by_link.get(link)
        if not lib:
            return None, "原商品已不在商品库(按 1688 链接匹配不到),请重新比价后发布"
        img_url = (lib.get("image", "") or "").strip()
        img_local = (lib.get("image_local", "") or "").strip()
        if not img_url and not (img_local and Path(img_local).exists()):
            return None, "商品库里该商品无可用图片,请重新比价"
        pend = {
            "library_id":    lib.get("id", ""),
            "prod_id":       lib.get("prod_id", ""),
            "name":          pub.get("target_name", "") or lib.get("name", ""),
            "image":         img_url,
            "image_local":   img_local,
            "category":      lib.get("category", ""),
            "supplier_link": link,
            "supplier_cost": float(pub.get("supplier_cost", 0) or lib.get("supplier_cost", 0) or 0),
            "cost_ref":      lib.get("cost_ref", ""),
            "cost_supplier": lib.get("cost_supplier", ""),
            "is_special":    lib.get("is_special", ""),
            "license_no":    lib.get("license_no", ""),
            # 定价规则:用已发布记录里冻结的参数(保持和原来一致)
            "pricing_rule_name":     pub.get("mode", ""),
            "rule_shipping":         float(pub.get("shipping", 4.0)),
            "rule_margin":           float(pub.get("margin", 0.9)),
            "rule_single_buy_extra": float(pub.get("single_buy_extra", 2.0)),
            "rule_spec_suffix":      pub.get("suffix", "+面膜1片"),
            "rule_stock":            int(pub.get("stock", 8888) or 8888),
            "store":         pub.get("store", ""),
            "carousel_shift": 0,
        }
        return pend, ""

    def _pdd_build_lib_link_index(self) -> dict:
        """supplier_link → 商品库 record(首个命中)。供重建待发布匹配图片/批准文号用。"""
        try:
            lib = product_library.load_library()
        except Exception:
            lib = []
        idx = {}
        for L in lib:
            k = (L.get("supplier_link", "") or "").strip()
            if k and k not in idx:
                idx[k] = L
        return idx

    def _pdd_start_queue_for(self, ids: set):
        """以指定 pending id 集合静默启动发布队列(不弹「发几条」框)。"""
        ids = set(i for i in ids if i)
        if not ids:
            return
        if getattr(self, "_pdd_qrun_active", False):
            # 已在跑 → 把新 id 并入勾选范围(None 表示跑全部,已涵盖)
            cur = getattr(self, "_pdd_qrun_selected_ids", None)
            if cur is not None:
                self._pdd_qrun_selected_ids = cur | ids
            return
        self._pdd_qrun_paused = False
        self._pdd_qrun_stop_requested = False
        if not getattr(self, "_pdd_qrun_batch", None):
            self._pdd_qrun_batch = {"success": [], "failed": []}
        self._pdd_qrun_selected_ids = set(ids)
        self._pdd_qrun_active = True
        self.pdd_pending_btn_start.setEnabled(True)
        self.pdd_pending_btn_start.setText("预约队列")
        self.pdd_pending_btn_pause.setEnabled(True)
        self.pdd_pending_btn_stop.setEnabled(True)
        self._pdd_pending_process_next()

    def _pdd_published_republish(self):
        """🔁 重新再发布:不下架,按勾选的已发布记录重建待发布 → 自动开始发布。"""
        selected = self._pdd_pub_checked_records()
        if not selected:
            QMessageBox.information(self, "重新再发布", "请先勾选要重发的已发布商品")
            return
        lib_by_link = self._pdd_build_lib_link_index()
        pendings, fails = [], []
        for pub in selected:
            pend, reason = self._pdd_published_to_pending(pub, lib_by_link)
            if pend:
                pendings.append(pend)
            else:
                fails.append((pub.get("target_name", "")[:24], reason))
        if not pendings:
            QMessageBox.warning(self, "重新再发布",
                "没有可重发的商品:\n\n" + "\n".join(f"• {n}: {r}" for n, r in fails))
            return
        names = "\n".join(f"  • [{p.get('store','?')}] {p.get('name','')[:28]}" for p in pendings[:8])
        more = f"\n  …还有 {len(pendings)-8} 条" if len(pendings) > 8 else ""
        msg = (f"将重新发布以下 {len(pendings)} 条(不下架原商品,直接再发一条新的):\n\n{names}{more}")
        if fails:
            msg += (f"\n\n⚠ {len(fails)} 条无法重发,已跳过:\n"
                    + "\n".join(f"  • {n}: {r}" for n, r in fails[:6]))
        msg += "\n\n确认后会写入待发布并自动开始发布。"
        if QMessageBox.question(self, "确认重新再发布", msg,
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        recs = pending_publish.load_pending()
        new_ids = []
        for p in pendings:
            recs, _id, _new = pending_publish.submit(recs, p, dedupe=False)  # 允许同 prod_id 重发
            new_ids.append(_id)
        try:
            pending_publish.save_pending(recs)
        except Exception as e:
            QMessageBox.critical(self, "重新再发布", f"写入待发布失败:\n{e}")
            return
        self._pdd_pending_records = pending_publish.load_pending()
        # 切到待发布页,刷新,自动开始发布
        try:
            self.pdd_nav.setCurrentRow(1)
        except Exception:
            pass
        self._pdd_pending_apply_filter()
        self._pdd_start_queue_for(set(new_ids))
        self.pdd_pending_status.setText(f"🔁 重新再发布:已加入 {len(new_ids)} 条并开始发布")

    def _pdd_published_rollback(self):
        """↩ 回退待发布:先下架勾选商品的 goods_id,下架成功后回退到待发布区(不自动发)。"""
        selected = self._pdd_pub_checked_records()
        cand = [r for r in selected if r.get("goods_id")]
        if not cand:
            QMessageBox.information(self, "回退待发布", "请先勾选要回退的已发布商品(需有 goods_id)")
            return
        lib_by_link = self._pdd_build_lib_link_index()
        valid, fails = [], []
        for pub in cand:
            pend, reason = self._pdd_published_to_pending(pub, lib_by_link)
            if pend:
                valid.append((pub, pend))
            else:
                fails.append((pub.get("target_name", "")[:24], reason))
        if not valid:
            QMessageBox.warning(self, "回退待发布",
                "没有可回退的商品(都无法重建待发布):\n\n"
                + "\n".join(f"• {n}: {r}" for n, r in fails))
            return
        if getattr(self, "_pdd_rollback_running", False):
            QMessageBox.information(self, "回退待发布", "已有回退任务进行中")
            return
        names = "\n".join(f"  • [{pub.get('store','?')}] {pub.get('target_name','')[:26]} (id={pub.get('goods_id','')})"
                          for pub, _ in valid[:8])
        more = f"\n  …还有 {len(valid)-8} 条" if len(valid) > 8 else ""
        msg = (f"将下架并回退以下 {len(valid)} 条到待发布:\n\n{names}{more}\n\n"
               "流程:先在 PDD 下架这些 ID → 下架成功后回退到待发布区(不会自动重发,停在待发布等你)。")
        if fails:
            msg += ("\n\n⚠ {} 条无法回退,已排除:\n".format(len(fails))
                    + "\n".join(f"  • {n}: {r}" for n, r in fails[:6]))
        if QMessageBox.question(self, "确认回退待发布", msg,
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 按店铺分组,逐店铺下架;每店铺下架成功后回退该店铺的记录
        by_store = {}
        for pub, pend in valid:
            by_store.setdefault(pub.get("store", ""), []).append((pub, pend))
        self._pdd_rollback_queue = list(by_store.items())
        self._pdd_rollback_running = True
        self._pdd_rollback_result = {"added": [], "skipped": []}
        self.pdd_pub_status.setText("↩ 回退待发布:准备下架…")
        self._pdd_run_next_rollback()

    def _pdd_run_next_rollback(self):
        if not self._pdd_rollback_queue:
            self._pdd_rollback_running = False
            res = getattr(self, "_pdd_rollback_result", {"added": [], "skipped": []})
            self._pdd_load_published()
            try:
                self._pdd_pending_records = pending_publish.load_pending()
                self._pdd_pending_apply_filter()
            except Exception:
                pass
            added, skipped = res["added"], res["skipped"]
            summary = f"✅ 回退完成:已回退 {len(added)} 条到待发布"
            if skipped:
                summary += f" · {len(skipped)} 条未回退(下架未成功)"
            self.pdd_pub_status.setText(summary)
            lines = []
            if added:
                lines.append("已回退到待发布:\n" + "\n".join(f"  • {n}" for n in added[:10]))
            if skipped:
                lines.append("未回退(PDD 下架未达成,原商品仍在售):\n"
                             + "\n".join(f"  • {n}" for n in skipped[:10]))
            QMessageBox.information(self, "回退待发布 — 汇总", "\n\n".join(lines) or summary)
            return
        store, items = self._pdd_rollback_queue.pop(0)
        ids = ",".join(pub["goods_id"] for pub, _ in items)
        self.pdd_pub_status.setText(
            f"↩ 下架中:店铺「{store}」 {len(items)} 件  剩余批次 {len(self._pdd_rollback_queue)}")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = ["-u", r"D:/files/pdd_takedown.py",
                "--store", store, "--goods-ids", ids, "--auto-close"]
        args += self._pdd_browser_args()
        proc.finished.connect(
            lambda code, _s, st=store, it=items: self._pdd_rollback_store_done(st, it))
        self._pdd_rollback_proc = proc
        proc.start("python", args)

    def _pdd_rollback_store_done(self, store, items):
        """一个店铺下架子进程结束 → 读 history 确认哪些 goods_id 真下架了 → 回退这些到待发布。"""
        import json as _json
        # 读最新 history,判定下架是否达成(taken_down / not_listed 都算"已不在售")
        status_by_gid = {}
        try:
            path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
            hist = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
            for h in hist:
                gid = h.get("goods_id", "")
                if gid:
                    status_by_gid[gid] = h.get("status", "")
        except Exception:
            pass
        DOWN_OK = ("taken_down", "not_listed")
        recs = pending_publish.load_pending()
        for pub, pend in items:
            gid = pub.get("goods_id", "")
            nm = f"[{store}] {pub.get('target_name','')[:24]}"
            if status_by_gid.get(gid) in DOWN_OK:
                recs, _id, _new = pending_publish.submit(recs, pend, dedupe=False)
                self._pdd_rollback_result["added"].append(nm)
            else:
                self._pdd_rollback_result["skipped"].append(nm)
        try:
            pending_publish.save_pending(recs)
        except Exception as e:
            print(f"[回退] 写待发布失败: {e}")
        QTimer.singleShot(1000, self._pdd_run_next_rollback)

    # ── 已发布历史：加载 / 过滤 ──────────────────────────────────────────
    def _pdd_load_published(self):
        import json as _json
        path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        try:
            self._pdd_pub_all = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
        except Exception:
            self._pdd_pub_all = []
        active_stores = self._pdd_active_store_names()
        # 已发布（排除 deleted / 退店归档）
        non_deleted = [r for r in self._pdd_pub_all
                       if r.get("status") != "deleted" and self._pdd_record_store_active(r, active_stores)]
        self._pdd_render_published(non_deleted)
        # 回收站（仅 deleted）
        if hasattr(self, "pdd_rec_table"):
            recycle = [r for r in self._pdd_pub_all
                       if r.get("status") == "deleted" and self._pdd_record_store_active(r, active_stores)]
            self._pdd_render_recycle(recycle)
        # 同步左侧导航计数
        try:
            pub_n = len(non_deleted)
            rec_n = sum(1 for r in self._pdd_pub_all
                        if r.get("status") == "deleted" and self._pdd_record_store_active(r, active_stores))
            # idx:商品库0/待发布1/已发布2/监控下架3/视频4/生图换图5/回收站6
            it = self.pdd_nav.item(2)
            if it: it.setText(f"📊  已发布 ({pub_n})")
            it_rec = self.pdd_nav.item(6)
            if it_rec: it_rec.setText(f"🗑  回收站 ({rec_n})")
        except Exception:
            pass

    def _pdd_pub_set_filter(self, state: str):
        """切换已发布页状态筛选(all / listed / taken_down / mismatch)。"""
        self._pdd_pub_filter_state = state
        self._pdd_published_filter()

    def _pdd_pub_checked_records(self) -> list:
        """已发布表:按勾选框里存的 goods_id 收集勾选记录(直接读id,不靠行号 shown[r],防错位下错商品)。"""
        by_gid = {}
        for r in (getattr(self, "_pdd_pub_all", []) or []):
            gid = str(r.get("goods_id") or "")
            if gid and gid not in by_gid:
                by_gid[gid] = r
        out, seen = [], set()
        for row in range(self.pdd_pub_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_pub_table, row)
            if cb and cb.isChecked():
                gid = cb.property("rec_id")
                if gid:
                    gid = str(gid)
                    rec = by_gid.get(gid)
                    if rec and gid not in seen:
                        seen.add(gid); out.append(rec)
        return out

    def _pdd_pub_kw_hit(self, r, kw: str) -> bool:
        """已发布搜索匹配:多个查询用【空格或逗号(中英文)】隔开 → 命中任意一个即显示(OR,适合批量贴多个ID);
        单个查询 = 在 商品名/店铺/goods_id 里做子串匹配。"""
        kw = (kw or "").strip().lower()
        if not kw:
            return True
        import re as _re
        tokens = [t for t in _re.split(r"[\s,，、]+", kw) if t]
        if not tokens:
            return True
        blob = f"{r.get('target_name','')} {r.get('store','')} {r.get('goods_id','')}".lower()
        return any(t in blob for t in tokens)

    def _pdd_get_displayed_records(self) -> list:
        """返回当前已发布表格实际显示的记录列表(按表格 row 顺序),
        过滤逻辑跟 _pdd_published_filter 完全一致。
        任何"按表格 row index 收集勾选"的入口都应该用此 helper。
        """
        active_stores = self._pdd_active_store_names()
        data = [r for r in (getattr(self, "_pdd_pub_all", []) or [])
                if r.get("status") != "deleted" and self._pdd_record_store_active(r, active_stores)]   # 排除回收站/退店
        state = getattr(self, "_pdd_pub_filter_state", "all")
        if state == "listed":
            data = [r for r in data if r.get("status") == "ok"]
        elif state == "taken_down":
            data = [r for r in data if r.get("status") == "taken_down"]
        elif state == "sold_out":
            data = [r for r in data if r.get("status") == "sold_out"]
        elif state == "mismatch":
            data = [r for r in data if r.get("status") == "mismatch"]
        elif state == "need_price":
            data = [r for r in data if r.get("status") == "need_price"]
        elif state == "spec_code_pending":
            data = [r for r in data
                    if isinstance(r.get("spec_code"), dict) and r["spec_code"].get("status") != "ok"]
        kw = self.pdd_pub_search.text().strip()
        if kw:
            data = [r for r in data if self._pdd_pub_kw_hit(r, kw)]
        # 店铺筛选(点表头第 4 列弹菜单)
        store_filter = getattr(self, "_pdd_pub_filter_store", None)
        if store_filter:
            data = [r for r in data if r.get("store", "") == store_filter]
        # 定价模式筛选(点表头第 7 列弹菜单)
        mode_filter = getattr(self, "_pdd_pub_filter_mode", None)
        if mode_filter:
            data = [r for r in data if r.get("mode", "") == mode_filter]
        # 时间排序(点表头第 3 列切换 ↓ / ↑)
        sort_dir = getattr(self, "_pdd_pub_sort_time_desc", None)
        if sort_dir is not None:
            data = sorted(data, key=lambda r: r.get("time", ""), reverse=bool(sort_dir))
        return data

    def _pdd_published_filter_later(self):
        timer = getattr(self, "_pdd_pub_filter_timer", None)
        if timer is not None:
            timer.start(260)
        else:
            self._pdd_published_filter()

    def _pdd_published_filter(self):
        self._pdd_render_published(self._pdd_get_displayed_records())

    def _pdd_render_published(self, records):
        old = getattr(self, "_pdd_pub_img_loader", None)
        if old is not None:
            try: old.stop()
            except Exception: pass
        self.pdd_pub_table.setUpdatesEnabled(False)
        self.pdd_pub_table.setRowCount(0)
        self.pdd_pub_table.setRowCount(len(records))
        image_load_limit = len(records)
        img_tasks = []   # 图列:选品图/货品图/上架主图 异步加载
        # 选品图/货品图回查表:已发布记录没存这两张图,按 supplier_url=库supplier_link / target_name=库name 映射
        _lib = getattr(self, "_pdd_lib_records", None)
        if not _lib:
            try:
                _lib = product_library.load_library()
            except Exception:
                _lib = []
        _lib_by_supplier, _lib_by_name = {}, {}
        for _lr0 in _lib:
            _sl = (_lr0.get("supplier_link") or "").strip()
            if _sl and _sl not in _lib_by_supplier:
                _lib_by_supplier[_sl] = _lr0
            _nm = (_lr0.get("name") or "").strip()
            if _nm and _nm not in _lib_by_name:
                _lib_by_name[_nm] = _lr0
        for row, r in enumerate(records):
            status = r.get("status", "ok")
            is_mismatch = status == "mismatch"
            is_need_price = status == "need_price"
            status_text = {
                "ok": "✅ 已发布",
                "mismatch": "⚠ 未对齐",
                "need_price": "💰 待人工核价",
                "taken_down": "🚫 已下架",
                "sold_out": "🛒 已售罄",
                "not_listed": "⊘ 未上架",
            }.get(status, status)
            # 拼单价(基准):按规则的 1 份估算 (供货价 + 运费) / (1 - 毛利率);多规格商品实际价
            # 各行不同,此处只显示基准值。规则字段缺失时回退默认 (运费 4 元 / 毛利 90%)
            supplier_cost = float(r.get("supplier_cost", 0) or 0)
            ship = float(r.get("shipping", 4.0) or 4.0)
            mar = float(r.get("margin", 0.9) or 0.9)
            if supplier_cost > 0 and mar < 0.99:
                group_price = round((supplier_cost + ship) / (1 - mar), 2)
                group_price_str = f"¥{group_price:.2f}"
            else:
                group_price_str = "-"
            # 导入品(非本程序上架)无成本算不出拼单价 → 直接显示从 PDD 抓回的价格(区间)
            if r.get("external") and r.get("pdd_price"):
                group_price_str = f"¥{r.get('pdd_price')}"
            # 🟢 绿旗:AI没核同款(连不上回退按热度发)或人工强发的 → 提示人工复核是否对版
            _gate = r.get("publish_gate", "")
            _green = _gate in ("heat_fallback", "force_style")
            _spec_code = r.get("spec_code") if isinstance(r.get("spec_code"), dict) else {}
            _spec_incomplete = bool(_spec_code) and _spec_code.get("status") != "ok"
            _green = _green or _spec_incomplete
            _nm = r.get("target_name", "")
            if r.get("external"):
                _nm = "🚩 " + _nm
            elif _green:
                _nm = "🟢 " + _nm
            cells = [
                status_text,
                r.get("time", ""),
                r.get("store", ""),
                _nm,
                r.get("goods_id", ""),
                r.get("mode", ""),
                f"¥{r.get('supplier_cost', 0):.2f}" if r.get('supplier_cost') else "-",
                group_price_str,
                str(r.get("stock", "")),
            ]
            # 复选框(列 0):纯控件式(item 设 Enabled 不画原生框,避免双框);读取改读控件
            chk_item = QTableWidgetItem()
            chk_item.setFlags(Qt.ItemIsEnabled)
            self.pdd_pub_table.setItem(row, 0, chk_item)
            self.pdd_pub_table.setCellWidget(row, 0, self._make_check_widget(gid=r.get("goods_id")))
            # 列 1 是图(下方单独渲染);文本列从列 2 开始(原 +1,因前插图列改 +2)
            for offset, v in enumerate(cells):
                c = offset + 2
                it = QTableWidgetItem(str(v))
                if c in (2, 3, 6, 7, 8, 9, 10):
                    it.setTextAlignment(Qt.AlignCenter)
                if is_mismatch:
                    it.setBackground(QColor("#FEF3C7"))
                    if c == 2:
                        it.setForeground(QColor("#92400E"))
                elif is_need_price:
                    it.setBackground(QColor("#FFEDD5"))  # 橙底,区别于未对齐的黄底
                    if c == 2:
                        it.setForeground(QColor("#C2410C"))
                        note = r.get("price_note", "")
                        if note:
                            it.setToolTip(note)
                else:
                    if c == 2:
                        it.setForeground(QColor("#10B981"))
                # 拼单价用绿字突出(列 c=9)
                if c == 9 and group_price_str != "-":
                    it.setForeground(QColor("#10B981"))
                # 非本程序上架(导入品):商品名格(c=5)悬浮提示来源
                if c == 5 and r.get("external"):
                    it.setToolTip(r.get("note", "非本程序上架"))
                # 🟢 绿旗(c=5):AI未核同款,需人工复核是否对版
                elif c == 5 and _green:
                    it.setToolTip("🟢 AI未核验同款就发布的"
                                  + ("(AI连不上,回退按热度发)" if _gate == "heat_fallback" else "(人工强发:无视AI,按相似度+热度发)")
                                  + " → 请人工复核发布的商品是否和货源对版")

                if c == 5 and _spec_incomplete:
                    _spec_tip = "\u89c4\u683c\u7f16\u7801\u5f85\u4eba\u5de5\u590d\u6838: " + str(_spec_code.get("reason", "\u90e8\u5206\u89c4\u683c\u7f16\u7801\u672a\u586b\u5199"))
                    if _gate in ("heat_fallback", "force_style"):
                        _spec_tip = "AI\u540c\u6b3e\u6838\u9a8c\u5f85\u590d\u6838\n" + _spec_tip
                    it.setToolTip("\U0001F7E2 " + _spec_tip)
                self.pdd_pub_table.setItem(row, c, it)
            url = r.get("detail_url", "")
            sup = (r.get("supplier_url") or "").strip()
            if url or sup:
                op_w = QWidget(); op_w.setStyleSheet("background:transparent;")
                _ol = QHBoxLayout(op_w); _ol.setContentsMargins(2, 2, 2, 2); _ol.setSpacing(3)
                if url:
                    if is_mismatch:
                        btn = QPushButton("🚫 核查")
                        btn.setStyleSheet(
                            "QPushButton{background:#F59E0B;color:white;border:none;border-radius:4px;padding:4px 8px;}"
                            "QPushButton:hover{background:#D97706;}")
                    else:
                        btn = QPushButton("🔗 查看")
                        btn.setStyleSheet(
                            "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;padding:4px 8px;}"
                            "QPushButton:hover{background:#4338CA;}")
                    btn.clicked.connect(
                        lambda _, u=url, s=r.get("store", ""): self._pdd_open_in_chrome(u, s))
                    _ol.addWidget(btn)
                if sup:
                    btn_sup = QPushButton("🛒 货源")
                    btn_sup.setToolTip("打开 1688 货源链接(系统浏览器)")
                    btn_sup.setStyleSheet(
                        "QPushButton{background:#FB923C;color:white;border:none;border-radius:4px;padding:4px 8px;}"
                        "QPushButton:hover{background:#EA580C;}")
                    btn_sup.clicked.connect(lambda _, u=sup: self._pdd_open_supplier_link(u))
                    _ol.addWidget(btn_sup)
                self.pdd_pub_table.setCellWidget(row, 11, op_w)
            # 图列(列 1):选品图 | 货品图 | 上架主图 三缩图并排(查不到的显示「—」)
            # 优先用记录里平移存的图(新发布一定有);老记录回查商品库兜底
            _lr = (_lib_by_supplier.get((r.get("supplier_url") or "").strip())
                   or _lib_by_name.get((r.get("target_name") or "").strip()))
            _rec_xp  = (r.get("xuanpin_image") or "").strip()
            _rec_src = (r.get("source_image") or "").strip()
            if _rec_xp:
                sel_local, sel_url = "", _rec_xp
            else:
                sel_local = (_lr.get("image_local") or "") if _lr else ""
                sel_url   = (_lr.get("image") or "") if _lr else ""
            src_url   = _rec_src or (self._pdd_source_image(_lr) if _lr else "")
            main_url  = (r.get("published_main_image") or "").strip()
            img_cell = QWidget(); img_cell.setStyleSheet("background:transparent;")
            _hl = QHBoxLayout(img_cell); _hl.setContentsMargins(2, 2, 2, 2); _hl.setSpacing(3)
            for _local, _url, _tip, _border in (
                (sel_local, sel_url,  "选品图(我方)",     "#E5E7EB"),
                ("",        src_url,  "货品图(1688货源)", "#FDE68A"),
                ("",        main_url, "上架主图(PDD)",    "#A7F3D0"),
            ):
                _lbl = ClickableImageLabel()
                _lbl.setAlignment(Qt.AlignCenter)
                _lbl.setFixedSize(40, 40)
                _lbl.setToolTip(_tip)
                _lbl.setStyleSheet(
                    f"color:#9CA3AF;background:white;border:1px solid {_border};border-radius:3px;")
                if row >= image_load_limit and (_local or _url):
                    u = "https:" + _url if _url.startswith("//") else _url
                    _lbl.set_image_source(_local, u, r.get("target_name", ""))
                    _lbl.setText("图")
                elif _local and Path(_local).exists():
                    try:
                        pix = QPixmap(_local)
                        if not pix.isNull():
                            _lbl.setPixmap(pix.scaled(38, 38, Qt.KeepAspectRatio, Qt.SmoothTransformation))
                        else:
                            _lbl.setText("📷")
                    except Exception:
                        _lbl.setText("📷")
                    _lbl.set_image_source(_local, _url, r.get("target_name", ""))
                elif _url:
                    u = "https:" + _url if _url.startswith("//") else _url
                    _lbl.set_image_source("", u, r.get("target_name", ""))
                    _lbl.setText("…")
                    img_tasks.append((_lbl, u))
                else:
                    _lbl.setText("—")
                _hl.addWidget(_lbl)
            self.pdd_pub_table.setCellWidget(row, 1, img_cell)
        # 统计:排除回收站;若按店铺筛选了,则只统计该店铺(共/✅/⚠ 跟着店铺独立算)
        base = [r for r in (getattr(self, "_pdd_pub_all", []) or []) if r.get("status") != "deleted"]
        sf = getattr(self, "_pdd_pub_filter_store", None)
        if sf:
            base = [r for r in base if r.get("store", "") == sf]
        all_n = len(base)
        ok_n = sum(1 for r in base if r.get("status", "ok") == "ok")
        warn_n = all_n - ok_n
        shown = len(records)
        prefix = f"店铺「{sf}」 " if sf else ""
        self.pdd_pub_status.setText(
            f"{prefix}共 {all_n} 条 (✅ {ok_n} · ⚠ {warn_n})  ·  显示 {shown} 条"
            if all_n else "暂无发布记录")
        self.pdd_pub_table.setUpdatesEnabled(True)
        if img_tasks:
            self._pdd_pub_img_loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_pub_thumb_cache")
            self._pdd_pub_img_loader.image_ready.connect(self._pdd_library_set_thumb)  # 通用:bytes→缩图
            self._pdd_pub_img_loader.start()

    def _build_pdd_page_recycle(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(15, 12, 15, 12)
        lay.setSpacing(8)

        top = QWidget()
        top.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:6px;")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(15, 10, 15, 10)
        title = QLabel("🗑 回收站（PDD 仅支持恢复 30 天内删除的商品）")
        title.setStyleSheet("font-size:14px;font-weight:bold;color:#991B1B;background:transparent;border:none;")
        tl.addWidget(title)
        sub = QHBoxLayout()
        self.pdd_rec_search = QLineEdit()
        self.pdd_rec_search.setPlaceholderText("搜索商品名 / 店铺 / goods_id …")
        self.pdd_rec_search.setMinimumWidth(280)
        self.pdd_rec_search.textChanged.connect(self._pdd_recycle_filter)
        sub.addWidget(self.pdd_rec_search)
        sub.addStretch()
        btn_restore = QPushButton("🔄 恢复选中")
        btn_restore.setStyleSheet(
            "QPushButton{background:#10B981;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#059669;}")
        btn_restore.setToolTip("从 PDD 回收站恢复（恢复成功后会回到「已下架」tab）")
        btn_restore.clicked.connect(self._pdd_restore_selected)
        sub.addWidget(btn_restore)
        btn_purge = QPushButton("🗑 永久清除")
        btn_purge.setStyleSheet(
            "QPushButton{background:#991B1B;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#7F1D1D;}")
        btn_purge.setToolTip("仅从本地回收站删除记录，不影响 PDD（PDD 自己 30 天后会清理）")
        btn_purge.clicked.connect(self._pdd_purge_recycle)
        sub.addWidget(btn_purge)
        btn_reload = QPushButton("🔄 刷新")
        btn_reload.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;"
            "padding:6px 12px;}QPushButton:hover{background:#4338CA;}")
        btn_reload.clicked.connect(self._pdd_load_published)
        sub.addWidget(btn_reload)
        tl.addLayout(sub)
        lay.addWidget(top)

        self.pdd_rec_table = QTableWidget()
        self.pdd_rec_table.setColumnCount(7)
        self.pdd_rec_table.setHorizontalHeaderLabels(
            ["全选", "删除时间", "店铺", "商品名", "goods_id", "供货价", "操作"])
        self.pdd_rec_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.pdd_rec_table.setColumnWidth(0, 45)
        self.pdd_rec_table.setColumnWidth(1, 145)
        self.pdd_rec_table.setColumnWidth(2, 130)
        self.pdd_rec_table.setColumnWidth(4, 130)
        self.pdd_rec_table.setColumnWidth(5, 80)
        self.pdd_rec_table.setColumnWidth(6, 120)
        self.pdd_rec_table.setAlternatingRowColors(True)
        self.pdd_rec_table.verticalHeader().setVisible(False)
        self.pdd_rec_table.verticalHeader().setDefaultSectionSize(36)
        self.pdd_rec_table.horizontalHeader().sectionClicked.connect(self._pdd_rec_toggle_all)
        lay.addWidget(self.pdd_rec_table, 1)

        self.pdd_rec_status = QLabel("等待加载")
        self.pdd_rec_status.setStyleSheet("color:#6B7280;")
        lay.addWidget(self.pdd_rec_status)
        return page

    def _pdd_rec_toggle_all(self, col: int):
        if col != 0:
            return
        any_unchecked = False
        for r in range(self.pdd_rec_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_rec_table, r)
            if cb and not cb.isChecked():
                any_unchecked = True; break
        for r in range(self.pdd_rec_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_rec_table, r)
            if cb: cb.setChecked(any_unchecked)

    def _pdd_recycle_filter(self):
        kw = self.pdd_rec_search.text().strip().lower()
        data = [r for r in (getattr(self, "_pdd_pub_all", []) or []) if r.get("status") == "deleted"]
        if kw:
            kws = kw.split()
            def hit(r):
                blob = f"{r.get('target_name','')} {r.get('store','')} {r.get('goods_id','')}".lower()
                return all(k in blob for k in kws)
            data = [r for r in data if hit(r)]
        self._pdd_render_recycle(data)

    def _pdd_render_recycle(self, records):
        self.pdd_rec_table.setRowCount(0)
        for r in records:
            row = self.pdd_rec_table.rowCount()
            self.pdd_rec_table.insertRow(row)
            # 勾选框:统一控件式(同其它 PDD 表),不画原生 item 框,避免双框/错乱
            self.pdd_rec_table.setCellWidget(row, 0, self._make_check_widget())
            cells = [
                r.get("deleted_at", r.get("time", "")),
                r.get("store", ""),
                r.get("target_name", ""),
                r.get("goods_id", ""),
                f"¥{r.get('supplier_cost', 0):.2f}" if r.get('supplier_cost') else "-",
            ]
            for off, v in enumerate(cells):
                c = off + 1
                it = QTableWidgetItem(str(v))
                if c in (1, 4, 5):
                    it.setTextAlignment(Qt.AlignCenter)
                self.pdd_rec_table.setItem(row, c, it)
            url = r.get("detail_url", "")
            if url:
                btn = QPushButton("🔗 查看")
                btn.setStyleSheet(
                    "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;padding:4px 8px;}"
                    "QPushButton:hover{background:#4338CA;}")
                btn.clicked.connect(
                    lambda _, u=url, s=r.get("store", ""): self._pdd_open_in_chrome(u, s))
                self.pdd_rec_table.setCellWidget(row, 6, btn)
        all_n = sum(1 for r in (self._pdd_pub_all or []) if r.get("status") == "deleted")
        self.pdd_rec_status.setText(
            f"回收站共 {all_n} 条  ·  显示 {len(records)} 条" if all_n else "回收站为空")

    def _pdd_restore_selected(self):
        """从回收站恢复选中商品"""
        kw = self.pdd_rec_search.text().strip().lower()
        data = [r for r in (getattr(self, "_pdd_pub_all", []) or []) if r.get("status") == "deleted"]
        if kw:
            kws = kw.split()
            def hit(r):
                blob = f"{r.get('target_name','')} {r.get('store','')} {r.get('goods_id','')}".lower()
                return all(k in blob for k in kws)
            data = [r for r in data if hit(r)]
        sel = []
        for ri in range(self.pdd_rec_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_rec_table, ri)
            if cb and cb.isChecked() and ri < len(data) and data[ri].get("goods_id"):
                sel.append(data[ri])
        if not sel:
            QMessageBox.information(self, "恢复", "请先勾选要恢复的商品")
            return
        names = "\n".join(f"  • [{r.get('store','?')}] {r.get('target_name','')[:30]} (id={r.get('goods_id','')})" for r in sel[:8])
        more = f"\n…还有 {len(sel)-8} 件" if len(sel) > 8 else ""
        if QMessageBox.question(self, "确认恢复",
                f"将从 PDD 回收站恢复 {len(sel)} 件商品（恢复后位于「已下架」tab）:\n\n{names}{more}\n\n确认？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) != QMessageBox.Yes:
            return
        if getattr(self, "_pdd_restore_running", False):
            QMessageBox.information(self, "恢复", "已有恢复任务进行中")
            return
        by_store = {}
        for r in sel:
            by_store.setdefault(r.get("store",""), []).append(r.get("goods_id",""))
        self._pdd_restore_queue = [(s, ids) for s, ids in by_store.items() if ids]
        self._pdd_restore_running = True
        self._pdd_run_next_restore()

    def _pdd_run_next_restore(self):
        if not self._pdd_restore_queue:
            self._pdd_restore_running = False
            self.pdd_rec_status.setText("✅ 全部恢复完成")
            self._pdd_load_published()
            return
        store, ids = self._pdd_restore_queue.pop(0)
        self.pdd_rec_status.setText(
            f"🔄 恢复中：店铺「{store}」 {len(ids)} 件  剩余批次 {len(self._pdd_restore_queue)}")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = ["-u", r"D:/files/pdd_restore.py",
                "--store", store, "--goods-ids", ",".join(ids), "--auto-close"]
        args += self._pdd_browser_args()
        proc.finished.connect(lambda code, _s: QTimer.singleShot(1000, self._pdd_run_next_restore))
        self._pdd_restore_proc = proc
        proc.start("python", args)

    def _pdd_purge_recycle(self):
        """仅从本地 history 删除回收站中的记录"""
        kw = self.pdd_rec_search.text().strip().lower()
        data = [r for r in (getattr(self, "_pdd_pub_all", []) or []) if r.get("status") == "deleted"]
        if kw:
            kws = kw.split()
            def hit(r):
                blob = f"{r.get('target_name','')} {r.get('store','')} {r.get('goods_id','')}".lower()
                return all(k in blob for k in kws)
            data = [r for r in data if hit(r)]
        sel = []
        for ri in range(self.pdd_rec_table.rowCount()):
            cb = self._cell_checkbox(self.pdd_rec_table, ri)
            if cb and cb.isChecked() and ri < len(data):
                sel.append(data[ri])
        if not sel:
            QMessageBox.information(self, "清除", "请先勾选要清除的记录")
            return
        if QMessageBox.question(self, "确认清除",
                f"将从本地回收站永久清除 {len(sel)} 条记录（不影响 PDD）\n确认？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        keys = {(r.get("goods_id",""), r.get("store",""), r.get("time","")) for r in sel}
        import json as _json
        path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        try:
            history = _json.load(open(path, encoding="utf-8-sig")) if path.exists() else []
        except Exception:
            history = []
        new_history = [r for r in history
                       if (r.get("goods_id",""), r.get("store",""), r.get("time","")) not in keys]
        with open(path, "w", encoding="utf-8") as f:
            _json.dump(new_history, f, ensure_ascii=False, indent=2)
        self._pdd_load_published()

    def _build_pdd_page_pricing(self) -> QWidget:
        """定价规则页：左侧规则列表 + 右侧表单编辑

        每条规则对应一种品类玩法,核心字段「防比价搭配」是定价杠杆(规格名加搭配后
        PDD 系统无法判定单品比价过高,支持高毛利定价)。
        """
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(15, 12, 15, 12)
        lay.setSpacing(8)

        # 顶部条
        top = QWidget()
        top.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:6px;")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(15, 10, 15, 10)
        title = QLabel("💎 定价规则")
        title.setStyleSheet("font-size:14px;font-weight:bold;color:#4F46C8;background:transparent;border:none;")
        tl.addWidget(title)
        desc = QLabel("管理不同品类的定价方案。「防比价搭配」决定规格名追加的内容(如 +面膜1片),"
                      "用于规避 PDD 单品比价。每条规则一种品类玩法,发布时在「待发布」页选用。")
        desc.setStyleSheet("color:#6B7280;background:transparent;border:none;font-size:11px;")
        desc.setWordWrap(True)
        tl.addWidget(desc)
        lay.addWidget(top)

        # 主体: 左列表 + 右表单
        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("QSplitter::handle{background:transparent;}")

        # 左侧
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(6)
        btn_new = QPushButton("➕ 新建规则")
        btn_new.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;"
            "padding:7px 10px;}QPushButton:hover{background:#4338CA;}")
        btn_new.clicked.connect(self._pricing_new_rule)
        ll.addWidget(btn_new)
        self.pricing_list = QListWidget()
        self.pricing_list.setStyleSheet(
            "QListWidget{border:1px solid #E5E7EB;border-radius:6px;background:white;}"
            "QListWidget::item{padding:8px 10px;border-bottom:1px solid #F3F4F6;}"
            "QListWidget::item:selected{background:#EEF2FF;color:#1F2937;}"
            "QListWidget::item:hover{background:#F9FAFB;}")
        self.pricing_list.currentItemChanged.connect(self._pricing_on_list_select)
        ll.addWidget(self.pricing_list, 1)
        splitter.addWidget(left)

        # 右侧表单
        right = QWidget()
        right.setStyleSheet("background:white;border:1px solid #E5E7EB;border-radius:6px;")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(20, 15, 20, 15)
        rl.setSpacing(10)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setSpacing(10)

        self.pricing_name = QLineEdit()
        self.pricing_name.setPlaceholderText("例如:面膜类强付费 / 护肤套装走量")
        form.addRow(QLabel("规则名称"), self.pricing_name)

        self.pricing_suffix = QLineEdit()
        self.pricing_suffix.setPlaceholderText("例如: +面膜1片  / +精华小样2ml  / +化妆刷")
        suffix_row = QWidget()
        sr = QVBoxLayout(suffix_row)
        sr.setContentsMargins(0, 0, 0, 0)
        sr.setSpacing(2)
        sr.addWidget(self.pricing_suffix)
        hint = QLabel("⚠ 防比价杠杆:规格名追加此内容后,PDD 系统无法判定单品比价。按品类配套(面膜/护肤/彩妆等)。")
        hint.setStyleSheet("color:#F59E0B;font-size:10px;")
        hint.setWordWrap(True)
        sr.addWidget(hint)
        form.addRow(QLabel("防比价搭配"), suffix_row)

        self.pricing_shipping = QDoubleSpinBox()
        self.pricing_shipping.setRange(0.0, 200.0)
        self.pricing_shipping.setDecimals(2)
        self.pricing_shipping.setSingleStep(0.5)
        self.pricing_shipping.setSuffix(" 元")
        form.addRow(QLabel("运费"), self.pricing_shipping)

        self.pricing_margin = QDoubleSpinBox()
        self.pricing_margin.setRange(0.0, 0.99)
        self.pricing_margin.setDecimals(2)
        self.pricing_margin.setSingleStep(0.01)
        form.addRow(QLabel("毛利率"), self.pricing_margin)

        self.pricing_single_extra = QDoubleSpinBox()
        self.pricing_single_extra.setRange(0.0, 100.0)
        self.pricing_single_extra.setDecimals(2)
        self.pricing_single_extra.setSingleStep(0.5)
        self.pricing_single_extra.setSuffix(" 元")
        form.addRow(QLabel("单买价加价"), self.pricing_single_extra)

        self.pricing_stock = QSpinBox()
        self.pricing_stock.setRange(0, 999999)
        self.pricing_stock.setSingleStep(100)
        form.addRow(QLabel("改后库存"), self.pricing_stock)

        self.pricing_default = QCheckBox("设为默认规则(发布时无店铺绑定时默认选中)")
        form.addRow(QLabel(""), self.pricing_default)

        self.pricing_store_list = QListWidget()
        self.pricing_store_list.setMaximumHeight(118)
        self.pricing_store_list.setStyleSheet(
            "QListWidget{border:1px solid #E5E7EB;border-radius:4px;background:#F9FAFB;}"
            "QListWidget::item{padding:3px 6px;}")
        self.pricing_store_list.setToolTip("勾选后，一键跑品/提交待发布选择该店铺时会默认使用这条规则。")
        form.addRow(QLabel("绑定店铺"), self.pricing_store_list)

        rl.addLayout(form)

        # 公式预览
        self.pricing_formula = QLabel()
        self.pricing_formula.setStyleSheet("color:#6B7280;background:#F9FAFB;border:1px dashed #E5E7EB;"
                                           "border-radius:4px;padding:8px;font-size:11px;")
        self.pricing_formula.setWordWrap(True)
        rl.addWidget(self.pricing_formula)
        for w in (self.pricing_shipping, self.pricing_margin, self.pricing_single_extra):
            w.valueChanged.connect(self._pricing_update_formula)

        rl.addStretch()

        # 底部按钮
        btm = QHBoxLayout()
        btn_save = QPushButton("💾 保存")
        btn_save.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;"
            "padding:8px 18px;}QPushButton:hover{background:#4338CA;}"
            "QPushButton:disabled{background:#D1D5DB;}")
        btn_save.clicked.connect(self._pricing_save_current)
        btm.addWidget(btn_save)
        btn_del = QPushButton("🗑 删除")
        btn_del.setStyleSheet(
            "QPushButton{background:#FEE2E2;color:#B91C1C;border:1px solid #FCA5A5;border-radius:4px;"
            "padding:8px 18px;}QPushButton:hover{background:#FECACA;}"
            "QPushButton:disabled{color:#9CA3AF;background:#F3F4F6;border-color:#E5E7EB;}")
        btn_del.clicked.connect(self._pricing_delete_current)
        btm.addWidget(btn_del)
        btm.addStretch()
        self.pricing_status = QLabel("")
        self.pricing_status.setStyleSheet("color:#6B7280;font-size:11px;")
        btm.addWidget(self.pricing_status)
        rl.addLayout(btm)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([260, 540])
        lay.addWidget(splitter, 1)

        # 持有状态
        self._pricing_rules = []
        self._pricing_current_id = None
        self._pricing_loading = False  # 加载表单时屏蔽 valueChanged 误触
        self._pricing_reload_list()
        return page

    # ── 定价规则: 辅助方法 ───────────────────────────────────────────────
    def _pricing_store_names(self) -> list[str]:
        try:
            stores = self._pdd_get_store_list()
        except Exception:
            stores = []
        return [s for s in stores if s and "无已登录" not in s]

    def _pricing_set_bound_store_checks(self, bound_stores=None):
        if not hasattr(self, "pricing_store_list"):
            return
        bound = set(bound_stores or [])
        stores = self._pricing_store_names()
        self.pricing_store_list.blockSignals(True)
        self.pricing_store_list.clear()
        if not stores:
            item = QListWidgetItem("未找到已登录店铺")
            item.setFlags(item.flags() & ~Qt.ItemIsEnabled)
            self.pricing_store_list.addItem(item)
        else:
            for store in stores:
                item = QListWidgetItem(store)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked if store in bound else Qt.Unchecked)
                self.pricing_store_list.addItem(item)
        self.pricing_store_list.blockSignals(False)

    def _pricing_get_bound_stores_from_form(self) -> list[str]:
        if not hasattr(self, "pricing_store_list"):
            return []
        stores = []
        for i in range(self.pricing_store_list.count()):
            item = self.pricing_store_list.item(i)
            if item.flags() & Qt.ItemIsUserCheckable and item.checkState() == Qt.Checked:
                stores.append(item.text())
        return stores

    def _pricing_rule_index_for_store(self, rules: list[dict], store: str) -> int:
        default_idx = 0
        for i, r in enumerate(rules):
            if r.get("is_default"):
                default_idx = i
            if store and store in (r.get("bound_stores") or []):
                return i
        return default_idx

    def _pricing_reload_list(self, select_id: str = None):
        try:
            self._pricing_rules = pricing_rules.load_rules()
        except Exception as e:
            QMessageBox.critical(self, "加载失败", f"读取定价规则失败:\n{e}")
            self._pricing_rules = []
        self.pricing_list.blockSignals(True)
        self.pricing_list.clear()
        for r in self._pricing_rules:
            mark = "  ★默认" if r.get("is_default") else ""
            item = QListWidgetItem(f"{r.get('name','(未命名)')}{mark}")
            item.setData(Qt.UserRole, r.get("id"))
            sub = r.get("spec_suffix", "")
            bound = r.get("bound_stores") or []
            bound_text = "、".join(bound) if bound else "未绑定"
            tip = (f"搭配: {sub}\n毛利率: {r.get('margin',0)*100:.0f}%  运费: {r.get('shipping',0)}元\n"
                   f"单买加价: {r.get('single_buy_extra',0)}元  库存: {r.get('stock',0)}\n"
                   f"绑定店铺: {bound_text}")
            item.setToolTip(tip)
            self.pricing_list.addItem(item)
        self.pricing_list.blockSignals(False)

        # 选中目标
        target = select_id or self._pricing_current_id
        target_row = 0
        if target:
            for i in range(self.pricing_list.count()):
                if self.pricing_list.item(i).data(Qt.UserRole) == target:
                    target_row = i
                    break
        if self.pricing_list.count() > 0:
            self.pricing_list.setCurrentRow(target_row)
        else:
            self._pricing_dict_to_form(None)

    def _pricing_on_list_select(self, curr, _prev):
        if not curr:
            self._pricing_dict_to_form(None)
            return
        rid = curr.data(Qt.UserRole)
        self._pricing_current_id = rid
        rule = pricing_rules.get_rule_by_id(self._pricing_rules, rid)
        self._pricing_dict_to_form(rule)

    def _pricing_dict_to_form(self, rule: dict):
        self._pricing_loading = True
        try:
            if not rule:
                self.pricing_name.setText("")
                self.pricing_suffix.setText("")
                self.pricing_shipping.setValue(0.0)
                self.pricing_margin.setValue(0.0)
                self.pricing_single_extra.setValue(0.0)
                self.pricing_stock.setValue(0)
                self.pricing_default.setChecked(False)
                self._pricing_set_bound_store_checks([])
            else:
                self.pricing_name.setText(rule.get("name", ""))
                self.pricing_suffix.setText(rule.get("spec_suffix", ""))
                self.pricing_shipping.setValue(float(rule.get("shipping", 0)))
                self.pricing_margin.setValue(float(rule.get("margin", 0)))
                self.pricing_single_extra.setValue(float(rule.get("single_buy_extra", 0)))
                self.pricing_stock.setValue(int(rule.get("stock", 0)))
                self.pricing_default.setChecked(bool(rule.get("is_default")))
                self._pricing_set_bound_store_checks(rule.get("bound_stores") or [])
        finally:
            self._pricing_loading = False
        self._pricing_update_formula()

    def _pricing_form_to_dict(self) -> dict:
        return {
            "id": self._pricing_current_id or "",
            "name": self.pricing_name.text().strip(),
            "spec_suffix": self.pricing_suffix.text().strip(),
            "shipping": self.pricing_shipping.value(),
            "margin": self.pricing_margin.value(),
            "single_buy_extra": self.pricing_single_extra.value(),
            "stock": self.pricing_stock.value(),
            "is_default": self.pricing_default.isChecked(),
            "bound_stores": self._pricing_get_bound_stores_from_form(),
        }

    def _pricing_update_formula(self):
        if self._pricing_loading:
            return
        s = self.pricing_shipping.value()
        m = self.pricing_margin.value()
        e = self.pricing_single_extra.value()
        # 用 10 元供货价举例
        cost = 10 * 1 + s
        if m < 0.99:
            gp = cost / (1 - m)
            sp = gp + e
            self.pricing_formula.setText(
                f"公式预览(单份规格,供货价=10元举例):\n"
                f"  成本 = 供货价×份数 + 运费 = 10 + {s} = {cost:.2f}\n"
                f"  拼单价 = 成本 / (1 - 毛利率) = {cost:.2f} / {1-m:.2f} = {gp:.2f}\n"
                f"  单买价 = 拼单价 + 加价 = {gp:.2f} + {e} = {sp:.2f}")
        else:
            self.pricing_formula.setText("⚠ 毛利率不能等于 1(分母为零)")

    def _pricing_new_rule(self):
        rule = {
            "id": pricing_rules._new_id(),
            "name": "新规则",
            "spec_suffix": "",
            "shipping": 4.0,
            "margin": 0.9,
            "single_buy_extra": 2.0,
            "stock": 8888,
            "is_default": False,
            "bound_stores": [],
        }
        self._pricing_rules = pricing_rules.upsert_rule(self._pricing_rules, rule)
        try:
            pricing_rules.save_rules(self._pricing_rules)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pricing_current_id = rule["id"]
        self._pricing_reload_list(select_id=rule["id"])
        self.pricing_status.setText("已新建,记得改名称和搭配后保存")
        self.pricing_name.setFocus()
        self.pricing_name.selectAll()

    def _pricing_save_current(self):
        data = self._pricing_form_to_dict()
        if not data["name"]:
            QMessageBox.warning(self, "保存失败", "规则名称不能为空")
            return
        if data["margin"] >= 0.99:
            QMessageBox.warning(self, "保存失败", "毛利率必须小于 0.99")
            return
        if not data["id"]:
            data["id"] = pricing_rules._new_id()
            self._pricing_current_id = data["id"]
        self._pricing_rules = pricing_rules.upsert_rule(self._pricing_rules, data)
        if data["is_default"]:
            self._pricing_rules = pricing_rules.set_default(self._pricing_rules, data["id"])
        try:
            pricing_rules.save_rules(self._pricing_rules)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pricing_reload_list(select_id=data["id"])
        self.pricing_status.setText(f"已保存:{data['name']}")

    def _pricing_delete_current(self):
        if not self._pricing_current_id:
            return
        if len(self._pricing_rules) <= 1:
            QMessageBox.information(self, "无法删除", "至少保留一条规则")
            return
        rule = pricing_rules.get_rule_by_id(self._pricing_rules, self._pricing_current_id)
        name = rule.get("name", "(未命名)") if rule else ""
        if QMessageBox.question(self, "确认删除",
                                f"确定删除规则「{name}」?此操作不可撤销。",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._pricing_rules = pricing_rules.delete_rule(self._pricing_rules, self._pricing_current_id)
        try:
            pricing_rules.save_rules(self._pricing_rules)
        except Exception as e:
            QMessageBox.critical(self, "保存失败", str(e))
            return
        self._pricing_current_id = None
        self._pricing_reload_list()
        self.pricing_status.setText(f"已删除:{name}")

    # ════════════════════════════════════════════════════════════════════════
    #  🎨 生图换图子页:gpt-image-2 生成直通车推广主图 → 换 PDD 主图
    # ════════════════════════════════════════════════════════════════════════

    def _build_pdd_page_genimg(self) -> QWidget:
        """🎨 生图换图:用 gpt-image-2 API 给在架商品的【货品图】生成直通车推广主图,
        再换成 PDD 主图并提交。详见 handoff §17。生成走 API 不开浏览器,换主图按店铺开浏览器。"""
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(6)
        title = QLabel("🎨 生图换图(直通车推广主图)")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        tip = QLabel("用 gpt-image-2 给在架商品的货品图生成推广主图(产品不变+大字报卖点)→ 换成 PDD 主图并提交。"
                     "文案从商品标题自动抠卖点。生成走 API 不开浏览器;换主图阶段会开浏览器操作,期间别碰鼠标键盘。已换的不重复换。")
        tip.setStyleSheet("color:#9CA3AF;font-size:11px;"); tip.setWordWrap(True)
        lay.addWidget(tip)

        # 工具栏行1:刷新 + 搜索 + 分类 + 店铺 + 统计
        bar1 = QHBoxLayout(); bar1.setSpacing(6)
        btn_reload = QPushButton("🔄 刷新"); btn_reload.clicked.connect(self._pdd_genimg_reload_table)
        bar1.addWidget(btn_reload)
        bar1.addWidget(QLabel("搜索:"))
        self.pdd_genimg_search = QLineEdit(); self.pdd_genimg_search.setPlaceholderText("商品名 / goods_id")
        self.pdd_genimg_search.setFixedWidth(200)
        self.pdd_genimg_search.textChanged.connect(self._pdd_genimg_apply_filter)
        bar1.addWidget(self.pdd_genimg_search)
        bar1.addWidget(QLabel("分类:"))
        self.pdd_genimg_cat = QComboBox(); self.pdd_genimg_cat.addItems(["全部", "未换", "已换"])
        self.pdd_genimg_cat.currentIndexChanged.connect(self._pdd_genimg_apply_filter)
        bar1.addWidget(self.pdd_genimg_cat)
        bar1.addWidget(QLabel("店铺:"))
        self.pdd_genimg_store = QComboBox(); self.pdd_genimg_store.addItem("全部")
        self.pdd_genimg_store.currentIndexChanged.connect(self._pdd_genimg_apply_filter)
        bar1.addWidget(self.pdd_genimg_store)
        bar1.addStretch(1)
        self.pdd_genimg_stats = QLabel(""); self.pdd_genimg_stats.setStyleSheet("color:#6B7280;font-size:11px;")
        bar1.addWidget(self.pdd_genimg_stats)
        lay.addLayout(bar1)

        # 工具栏行2:批量操作 + 进度
        bar2 = QHBoxLayout(); bar2.setSpacing(6)
        bar2.addWidget(QLabel("\u53c2\u8003\u56fe:"))
        self.pdd_genimg_ref_combo = QComboBox()
        self.pdd_genimg_ref_combo.addItems(["\u8d27\u54c1\u56fe", "\u9009\u54c1\u56fe"])
        self.pdd_genimg_ref_combo.setToolTip("\u9009\u62e9\u751f\u6210\u63a8\u5e7f\u56fe\u65f6\u4f20\u7ed9\u56fe\u50cf\u6a21\u578b\u7684\u53c2\u8003\u56fe;\u9ed8\u8ba4\u6cbf\u7528\u8d27\u54c1\u56fe")
        bar2.addWidget(self.pdd_genimg_ref_combo)
        btn_chk = QPushButton("☑ 全选当前"); btn_chk.clicked.connect(self._pdd_genimg_toggle_all)
        bar2.addWidget(btn_chk)
        btn_do = QPushButton("🎨 生成并换主图(选中)")
        btn_do.setStyleSheet("background:#10B981;color:white;font-weight:bold;border-radius:4px;padding:6px 14px;")
        btn_do.clicked.connect(lambda: self._pdd_genimg_generate_selected())
        bar2.addWidget(btn_do)
        btn_all = QPushButton("🎨 一键全部未换")
        btn_all.setStyleSheet("background:#4F46C8;color:white;font-weight:bold;border-radius:4px;padding:6px 14px;")
        btn_all.clicked.connect(self._pdd_genimg_generate_untransferred)
        bar2.addWidget(btn_all)
        btn_gen = QPushButton("🖼 只生图(选中)")
        btn_gen.setToolTip("只生成推广图存起来(不换主图),你在 AI生图列复核满意再换")
        btn_gen.setStyleSheet("background:white;color:#10B981;border:1px solid #6EE7B7;border-radius:4px;padding:6px 14px;")
        btn_gen.clicked.connect(lambda: self._pdd_genimg_generate_selected(mode="gen_only"))
        bar2.addWidget(btn_gen)
        btn_chg = QPushButton("🔄 已有图换主图(选中)")
        btn_chg.setToolTip("用已生成的AI图直接换主图(不重新生成、不花钱)")
        btn_chg.setStyleSheet("background:white;color:#4F46C8;border:1px solid #C7D2FE;border-radius:4px;padding:6px 14px;")
        btn_chg.clicked.connect(lambda: self._pdd_genimg_generate_selected(mode="change_only"))
        bar2.addWidget(btn_chg)
        btn_prompt = QPushButton("✏️ 编辑提示词")
        btn_prompt.setToolTip("打开提示词文件用记事本编辑;改完存盘下次生成生效。保留 {主}{副}{标签} 占位")
        btn_prompt.setStyleSheet("background:white;color:#DC2626;border:1px solid #FCA5A5;"
                               "border-radius:4px;padding:6px 14px;")
        btn_prompt.clicked.connect(self._pdd_genimg_edit_prompt)
        bar2.addWidget(btn_prompt)
        btn_api = QPushButton("⚙️ API/模型设置")
        btn_api.setToolTip("修改/切换 生图换图 的图像API(中转地址/模型/密钥)+ 文案DeepSeek;改完即生效,不用重启")
        btn_api.setStyleSheet("background:white;color:#0891B2;border:1px solid #67E8F9;border-radius:4px;padding:6px 14px;")
        btn_api.clicked.connect(self._pdd_genimg_api_settings)
        bar2.addWidget(btn_api)
        bar2.addStretch(1)
        self.pdd_genimg_status = QLabel(""); self.pdd_genimg_status.setStyleSheet("color:#9CA3AF;font-size:11px;")
        bar2.addWidget(self.pdd_genimg_status)
        lay.addLayout(bar2)

        self.pdd_genimg_table = QTableWidget(0, 10)
        self.pdd_genimg_table.setHorizontalHeaderLabels(
            ["\u9009", "goods_id", "\u9009\u54c1\u56fe", "\u8d27\u54c1\u56fe", "AI\u751f\u56fe", "\u5546\u54c1\u540d", "\u5e97\u94fa", "\u4e0a\u67b6\u65e5\u671f", "\u72b6\u6001", "\u64cd\u4f5c"])
        h = self.pdd_genimg_table.horizontalHeader()
        for c, mode in ((0, QHeaderView.Fixed), (1, QHeaderView.Fixed),
                        (2, QHeaderView.Fixed), (3, QHeaderView.Fixed), (4, QHeaderView.Fixed),
                        (5, QHeaderView.Stretch), (6, QHeaderView.Fixed),
                        (7, QHeaderView.Fixed), (8, QHeaderView.Fixed),
                        (9, QHeaderView.Fixed)):
            h.setSectionResizeMode(c, mode)
        self.pdd_genimg_table.setColumnWidth(0, 44)
        self.pdd_genimg_table.setColumnWidth(1, 108)
        self.pdd_genimg_table.setColumnWidth(2, 54)
        self.pdd_genimg_table.setColumnWidth(3, 54)
        self.pdd_genimg_table.setColumnWidth(4, 54)
        self.pdd_genimg_table.setColumnWidth(6, 110)
        self.pdd_genimg_table.setColumnWidth(7, 92)
        self.pdd_genimg_table.setColumnWidth(8, 82)
        self.pdd_genimg_table.setColumnWidth(9, 128)
        self.pdd_genimg_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pdd_genimg_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.pdd_genimg_table.verticalHeader().setDefaultSectionSize(48)
        lay.addWidget(self.pdd_genimg_table, 1)
        self.pdd_genimg_status.setText("首次打开，正在加载数据…")
        return page

    def _pdd_genimg_src_image(self, rec) -> str:
        """取该商品的货品图 URL(生图参考图):优先记录里平移存档的 source_image(转原图大小),
        没有再回查商品库;都没有返回 ''。"""
        si = (rec.get("source_image") or "").strip()
        if si and si.lower() != "none":
            return self._alicdn_original(si)
        try:
            return self._pdd_source_image_for_publish(rec) or ""
        except Exception:
            return ""

    def _pdd_genimg_library_record(self, rec) -> dict:
        """\u6309 supplier_url / \u5546\u54c1\u540d\u56de\u67e5\u5546\u54c1\u5e93,\u7528\u4e8e\u8865\u9009\u54c1\u56fe\u548c\u8001\u8bb0\u5f55\u8d27\u54c1\u56fe\u3002"""
        lib = getattr(self, "_pdd_lib_records", None)
        if not lib:
            try:
                lib = product_library.load_library()
                self._pdd_lib_records = lib
            except Exception:
                lib = []
        sup = (rec.get("supplier_url") or "").strip()
        name = (rec.get("target_name") or rec.get("name") or rec.get("title") or "").strip()
        for lr in lib or []:
            if sup and (lr.get("supplier_link") or "").strip() == sup:
                return lr
        for lr in lib or []:
            if name and (lr.get("name") or "").strip() == name:
                return lr
        return {}

    def _pdd_genimg_xuanpin_image(self, rec) -> tuple[str, str]:
        """\u8fd4\u56de\u9009\u54c1\u56fe (local_path, image_url)\u3002\u4f18\u5148\u53d1\u5e03\u5386\u53f2\u5e73\u79fb\u56fe,\u518d\u56de\u67e5\u5546\u54c1\u5e93\u3002"""
        xp = (rec.get("xuanpin_image") or "").strip()
        if xp and xp.lower() != "none":
            return "", xp
        img = (rec.get("image") or "").strip()
        if img and img.lower() != "none":
            if Path(img).exists():
                return img, ""
            if img.startswith(("http://", "https://", "//")):
                return "", img
        lr = self._pdd_genimg_library_record(rec)
        if lr:
            return (lr.get("image_local") or "").strip(), (lr.get("image") or "").strip()
        return "", ""

    def _pdd_genimg_reference_image(self, rec) -> tuple[str, str, str]:
        """\u6839\u636e\u5de5\u5177\u680f\u9009\u62e9\u8fd4\u56de\u751f\u56fe\u53c2\u8003\u56fe: (source_path_or_url, label, missing_label)\u3002"""
        combo = getattr(self, "pdd_genimg_ref_combo", None)
        use_xuanpin = combo is not None and combo.currentText() == "\u9009\u54c1\u56fe"
        if use_xuanpin:
            local, url = self._pdd_genimg_xuanpin_image(rec)
            src = local if local and Path(local).exists() else (url or "")
            return src, "\u9009\u54c1\u56fe", "\u9009\u54c1\u56fe"
        return self._pdd_genimg_src_image(rec), "\u8d27\u54c1\u56fe", "\u8d27\u54c1\u56fe"

    def _pdd_genimg_done_for(self, gid) -> bool:
        return str(gid) in (getattr(self, "_pdd_genimg_done_map", {}) or {})

    def _pdd_genimg_reload_table(self):
        """重读在架记录 + 已换记录,刷新店铺下拉,再按当前筛选渲染。"""
        self._pdd_genimg_recs = self._pdd_video_published_records()   # 复用:在架商品
        self._pdd_genimg_done_map = _promo_done_load()
        cur = self.pdd_genimg_store.currentText() if hasattr(self, "pdd_genimg_store") else "全部"
        stores = sorted({(r.get("store") or "").strip() for r in self._pdd_genimg_recs if r.get("store")})
        self.pdd_genimg_store.blockSignals(True)
        self.pdd_genimg_store.clear(); self.pdd_genimg_store.addItem("全部")
        for s in stores:
            self.pdd_genimg_store.addItem(s)
        idx = self.pdd_genimg_store.findText(cur)
        self.pdd_genimg_store.setCurrentIndex(idx if idx >= 0 else 0)
        self.pdd_genimg_store.blockSignals(False)
        self._pdd_genimg_apply_filter()

    def _pdd_genimg_apply_filter(self):
        kw = (self.pdd_genimg_search.text() or "").strip().lower()
        cat = self.pdd_genimg_cat.currentText()
        store = self.pdd_genimg_store.currentText()
        rows = []
        for rec in getattr(self, "_pdd_genimg_recs", []):
            gid = str(rec.get("goods_id", ""))
            name = rec.get("target_name") or rec.get("name") or rec.get("title") or ""
            st = (rec.get("store") or "")
            done = self._pdd_genimg_done_for(gid)
            if kw and kw not in gid.lower() and kw not in name.lower():
                continue
            if store != "全部" and st != store:
                continue
            if cat == "未换" and done:
                continue
            if cat == "已换" and not done:
                continue
            rows.append((rec, gid, name, st, done))
        display_rows = rows
        self._pdd_genimg_render(display_rows)
        recs = getattr(self, "_pdd_genimg_recs", [])
        total = len(recs)
        done_n = sum(1 for r in recs if self._pdd_genimg_done_for(r.get("goods_id")))
        self.pdd_genimg_stats.setText(
            f"共 {total} 商品 · 已换 {done_n} · 未换 {total - done_n} · "
            + f"当前显示 {len(rows)}")

    def _pdd_genimg_render(self, rows):
        tbl = self.pdd_genimg_table
        try:
            t = getattr(self, "_pdd_genimg_render_timer", None)
            if t is not None:
                t.stop()
        except Exception:
            pass
        self._pdd_genimg_render_token = int(getattr(self, "_pdd_genimg_render_token", 0) or 0) + 1
        token = self._pdd_genimg_render_token
        rows = list(rows or [])
        tbl.setUpdatesEnabled(False)
        tbl.clearContents()
        tbl.setRowCount(len(rows))
        tbl.setUpdatesEnabled(True)
        if not rows:
            return
        if len(rows) <= 80:
            tbl.setUpdatesEnabled(False)
            img_tasks = self._pdd_genimg_fill_rows(rows, 0)
            tbl.setUpdatesEnabled(True)
            self._pdd_genimg_start_thumb_loader(img_tasks)
            return
        self._pdd_genimg_pending_rows = rows
        self._pdd_genimg_pending_img_tasks = []
        self._pdd_genimg_render_pos = 0
        self.pdd_genimg_status.setText(f"正在加载列表 0/{len(rows)}")
        self._pdd_genimg_render_next_chunk(token)

    def _pdd_genimg_render_next_chunk(self, token):
        if token != getattr(self, "_pdd_genimg_render_token", None):
            return
        rows = getattr(self, "_pdd_genimg_pending_rows", []) or []
        pos = int(getattr(self, "_pdd_genimg_render_pos", 0) or 0)
        if pos >= len(rows):
            self.pdd_genimg_status.setText(f"已加载 {len(rows)} 条，正在补缩略图…")
            self._pdd_genimg_start_thumb_loader(getattr(self, "_pdd_genimg_pending_img_tasks", []) or [])
            self._pdd_genimg_pending_img_tasks = []
            return
        end = min(len(rows), pos + 40)
        tbl = self.pdd_genimg_table
        tbl.setUpdatesEnabled(False)
        img_tasks = self._pdd_genimg_fill_rows(rows[pos:end], pos)
        tbl.setUpdatesEnabled(True)
        pending_tasks = getattr(self, "_pdd_genimg_pending_img_tasks", None)
        if pending_tasks is not None:
            pending_tasks.extend(img_tasks)
        else:
            self._pdd_genimg_start_thumb_loader(img_tasks)
        self._pdd_genimg_render_pos = end
        self.pdd_genimg_status.setText(f"正在加载列表 {end}/{len(rows)}")
        if end < len(rows):
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(lambda t=token: self._pdd_genimg_render_next_chunk(t))
            self._pdd_genimg_render_timer = timer
            timer.start(25)
        else:
            self.pdd_genimg_status.setText(f"已加载 {len(rows)} 条，正在补缩略图…")
            self._pdd_genimg_start_thumb_loader(getattr(self, "_pdd_genimg_pending_img_tasks", []) or [])
            self._pdd_genimg_pending_img_tasks = []

    def _pdd_genimg_fill_rows(self, rows, start_row=0):
        import os as _os
        tbl = self.pdd_genimg_table
        img_tasks = []
        for off, (rec, gid, name, store, done) in enumerate(rows):
            r = start_row + off
            tbl.setCellWidget(r, 0, self._make_check_widget(False, gid=gid))
            review = (getattr(self, "_pdd_ap_review", {}) or {}).get(gid) or {}
            id_item = QTableWidgetItem(("⚠ " + gid) if review else gid)
            if review: id_item.setToolTip("待人工确认下架：" + str(review.get("reason", "")))
            tbl.setItem(r, 1, id_item)
            xp_lbl = ClickableImageLabel(); xp_lbl.setAlignment(Qt.AlignCenter); xp_lbl.setFixedSize(44, 44)
            xp_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #E5E7EB;border-radius:3px;")
            xp_local, xp_url = self._pdd_genimg_xuanpin_image(rec)
            if xp_local and Path(xp_local).exists():
                xp_lbl.setText("")
                xp_lbl.set_image_source(local_path=xp_local, image_url=xp_url, product_name=name + " · 选品图")
                try:
                    img_tasks.append((xp_lbl, Path(xp_local).resolve().as_uri()))
                except Exception:
                    xp_lbl.setText("")
            elif xp_url:
                if xp_url.startswith("//"):
                    xp_url = "https:" + xp_url
                xp_lbl.setText("")
                xp_lbl.set_image_source(image_url=xp_url, product_name=name + " · 选品图")
                img_tasks.append((xp_lbl, xp_url))
            else:
                xp_lbl.setText("无")
            tbl.setCellWidget(r, 2, xp_lbl)

            img_lbl = ClickableImageLabel(); img_lbl.setAlignment(Qt.AlignCenter); img_lbl.setFixedSize(44, 44)
            img_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #FDE68A;border-radius:3px;")
            src = self._pdd_genimg_src_image(rec)
            if src:
                if src.startswith("//"):
                    src = "https:" + src
                img_lbl.setText("")
                img_lbl.set_image_source(image_url=src, product_name=name + " · 货品图")
                img_tasks.append((img_lbl, src))
            else:
                img_lbl.setText("无")
            tbl.setCellWidget(r, 3, img_lbl)

            ai_lbl = ClickableImageLabel(); ai_lbl.setAlignment(Qt.AlignCenter); ai_lbl.setFixedSize(44, 44)
            ai_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #A7F3D0;border-radius:3px;")
            promo = _os.path.join(r"D:/files/data/promo", gid + ".jpg")
            if _os.path.exists(promo):
                ai_lbl.setText("")
                ai_lbl.set_image_source(local_path=promo, product_name=name + " · AI生图")
                try:
                    img_tasks.append((ai_lbl, Path(promo).resolve().as_uri()))
                except Exception:
                    ai_lbl.setText("")
            else:
                ai_lbl.setText("未生成")
            tbl.setCellWidget(r, 4, ai_lbl)
            tbl.setItem(r, 5, QTableWidgetItem(name))
            tbl.setItem(r, 6, QTableWidgetItem(store))
            t = str(rec.get("time") or "")
            tbl.setItem(r, 7, QTableWidgetItem(t.split(" ")[0] if t else "—"))
            it_s = QTableWidgetItem("✅ 已换" if done else "— 未换")
            it_s.setForeground(QColor("#10B981") if done else QColor("#9CA3AF"))
            tbl.setItem(r, 8, it_s)
            w = QWidget(); hl = QHBoxLayout(w); hl.setContentsMargins(2, 0, 2, 0); hl.setSpacing(3)
            url = rec.get("detail_url") or ""
            if url:
                bl = QPushButton("🔗"); bl.setFixedHeight(24); bl.setToolTip("用该店铺登录态 Chrome 打开 PDD 商品页")
                bl.clicked.connect(lambda _, u=url, s=rec.get("store"): self._open_in_chrome(u, s))
                hl.addWidget(bl)
            b = QPushButton("🎨 生成换图"); b.setFixedHeight(24)
            b.setToolTip("给这个商品生成推广主图并换成 PDD 主图")
            b.clicked.connect(lambda _, x=rec: self._pdd_genimg_generate_selected([x]))
            hl.addWidget(b); hl.addStretch(1)
            tbl.setCellWidget(r, 9, w)
        return img_tasks

    def _pdd_genimg_start_thumb_loader(self, img_tasks):
        if not img_tasks:
            return
        loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_genimg_thumb_cache")
        loader.image_ready.connect(self._pdd_library_set_thumb)
        loaders = getattr(self, "_pdd_genimg_img_loaders", [])
        loaders.append(loader)
        self._pdd_genimg_img_loaders = loaders
        loader.finished.connect(lambda l=loader: self._pdd_genimg_img_loaders.remove(l) if l in self._pdd_genimg_img_loaders else None)
        loader.start()
    def _pdd_genimg_toggle_all(self):
        tbl = self.pdd_genimg_table
        target = any(self._cell_checkbox(tbl, r) and not self._cell_checkbox(tbl, r).isChecked()
                     for r in range(tbl.rowCount()))
        for r in range(tbl.rowCount()):
            cb = self._cell_checkbox(tbl, r)
            if cb:
                cb.setChecked(target)

    def _pdd_genimg_checked_records(self) -> list:
        tbl = self.pdd_genimg_table
        by_gid = {str(r.get("goods_id")): r for r in getattr(self, "_pdd_genimg_recs", [])}
        out, seen = [], set()
        for r in range(tbl.rowCount()):
            cb = self._cell_checkbox(tbl, r)
            if cb and cb.isChecked():
                gid = str(cb.property("rec_id"))
                rec = by_gid.get(gid)
                if rec and gid not in seen:
                    seen.add(gid); out.append(rec)
        return out

    def _pdd_genimg_generate_untransferred(self):
        recs = [r for r in getattr(self, "_pdd_genimg_recs", [])
                if not self._pdd_genimg_done_for(r.get("goods_id"))]
        if not recs:
            QMessageBox.information(self, "生图换图", "没有未换主图的商品(全部已换)。")
            return
        self._pdd_genimg_generate_selected(recs)

    def _pdd_genimg_generate_selected(self, recs=None, mode="full", no_confirm=False, _from_task_center=False):
        """生成/换主图。mode: full=生成+换 / gen_only=只生图 / change_only=已有AI图只换主图。recs=None 取勾选。"""
        import os as _os
        if recs is None:
            recs = self._pdd_genimg_checked_records()
        busy, busy_name = self._task_center_busy()
        if busy and not _from_task_center:
            if recs:
                self._task_center_enqueue(
                    f"生图换图 {len(recs)} 个",
                    lambda recs=list(recs), mode=mode: self._pdd_genimg_generate_selected(recs, mode, True, _from_task_center=True),
                    f"等待 {busy_name} 结束后自动开始")
            else:
                QMessageBox.information(self, "生图换图", "请先勾选商品(可多选)。")
            return
        if not recs:
            QMessageBox.information(self, "生图换图", "请先勾选商品(可多选)。")
            return
        jobs, no_src = [], []
        ref_label = "\u8d27\u54c1\u56fe"
        missing_label = "\u8d27\u54c1\u56fe"
        for rec in recs:
            gid = str(rec.get("goods_id") or "")
            if mode == "change_only":
                if not _os.path.exists(_os.path.join(r"D:/files/data/promo", gid + ".jpg")):
                    no_src.append(gid); continue
                src = ""
            else:
                src, ref_label, missing_label = self._pdd_genimg_reference_image(rec)
                if not src:
                    no_src.append(gid); continue
            jobs.append({"gid": gid, "name": rec.get("target_name") or rec.get("name") or "",
                         "store": rec.get("store") or "", "src_url": src,
                         "detail_url": rec.get("detail_url") or ""})
        if not jobs:
            QMessageBox.information(self, "\u751f\u56fe\u6362\u56fe",
                "\u9009\u4e2d\u7684\u5546\u54c1" + ("\u90fd\u6ca1\u6709\u5df2\u751f\u6210\u7684AI\u56fe,\u65e0\u6cd5\u6362\u56fe\u3002"
                    if mode == "change_only" else f"\u90fd\u6ca1\u6709{missing_label},\u65e0\u6cd5\u751f\u6210\u3002"))
            return
        _act = {"gen_only": "只生成推广图存起来(不换主图)",
                "change_only": "用已生成的AI图换成 PDD 主图(不重新生成)"}.get(mode, "生成推广图并换成 PDD 主图(提交生效)")
        msg = (f"\u5c06\u7ed9 {len(jobs)} \u4e2a\u5546\u54c1:{_act}\u3002\n\n"
               "\u2022 \u751f\u6210\u8d70 gpt-image-2 API(\u4e0d\u5f00\u6d4f\u89c8\u5668,\u4e0d\u9650\u6d41)\n"
               f"\u2022 \u751f\u56fe\u53c2\u8003\u56fe: {ref_label}\n"
               "\u2022 \u6362\u4e3b\u56fe\u9636\u6bb5\u4f1a\u5f00\u5bf9\u5e94\u5e97\u94fa\u6d4f\u89c8\u5668(\u9700\u8be5\u5e97\u5df2\u767b\u5f55)\n"
               "\u2022 \u6bcf\u4e2a\u5546\u54c1\u7ea6 1-2 \u5206\u949f\n")
        if no_src:
            msg += f"\u2022 {len(no_src)} \u4e2a\u5546\u54c1\u6ca1{missing_label},\u4f1a\u8df3\u8fc7\n"
        msg += "\n\u786e\u8ba4\u5f00\u59cb?"
        if not no_confirm and QMessageBox.question(self, "生成并换主图", msg,
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._task_center_register_running(f"生图换图 {len(jobs)} 个", _act)
        self.pdd_genimg_status.setText("生图换图:启动中…")
        from PyQt5.QtWidgets import QProgressDialog
        _dlg = QProgressDialog("正在生成推广图…", None, 0, 0, self)
        _dlg.setWindowTitle("生图换图进行中(请稍候,别关客户端)")
        _dlg.setMinimumWidth(400)
        _dlg.setMinimumDuration(0)
        _dlg.setValue(0)
        _dlg.show()
        self._pdd_genimg_dlg = _dlg
        def _on_genimg_prog(m):
            self.pdd_genimg_status.setText(m)
            d = getattr(self, "_pdd_genimg_dlg", None)
            if d is not None:
                try:
                    d.setLabelText(m)
                except Exception:
                    pass
        self._pdd_genimg_task_ok = True
        self._pdd_genimg_task_detail = ""
        t = GenImgThread(jobs, mode, self)
        t.progress.connect(_on_genimg_prog)
        t.finished_summary.connect(self._pdd_genimg_done)
        def _genimg_cleanup():
            self._pdd_genimg_thread = None
            self._task_center_finish_current(
                getattr(self, "_pdd_genimg_task_ok", True),
                getattr(self, "_pdd_genimg_task_detail", ""))
            d = getattr(self, "_pdd_genimg_dlg", None)
            if d is not None:
                try:
                    d.close()
                except Exception:
                    pass
                self._pdd_genimg_dlg = None
        t.finished.connect(_genimg_cleanup)
        self._pdd_genimg_thread = t
        t.start()

    def _pdd_genimg_done(self, summary: dict):
        if summary.get("error"):
            detail = f"生图换图失败:{summary['error']}"
            self._pdd_genimg_task_ok = False
            self._pdd_genimg_task_detail = detail
            self.pdd_genimg_status.setText("生图换图失败")
            if self._task_center_should_defer_dialog():
                self._task_center_update_current_detail(detail)
            else:
                QMessageBox.critical(self, "生图换图", f"出错:{summary['error']}")
            return
        gen = summary.get("generated", 0)
        ok = summary.get("changed_ok", 0)
        gen_fail = summary.get("gen_fail", []) or []
        chg_fail = summary.get("change_fail", []) or []
        skipped = summary.get("skipped", []) or []
        lines = [f"✓ 生成推广图 {gen} 张", f"✓ 换主图成功 {ok} 个"]
        if gen_fail:
            lines.append(f"✗ 生成失败 {len(gen_fail)}:")
            for g, _rsn in gen_fail[:5]:
                lines.append(f"   • {g}: {(_rsn or '')[:160]}")
        if chg_fail:
            lines.append(f"✗ 换主图失败 {len(chg_fail)}:" + ", ".join(str(g) for g, _ in chg_fail[:5]))
        if skipped:
            lines.append(f"⏭ 跳过 {len(skipped)}")
        detail = "\n".join(lines)
        self._pdd_genimg_task_ok = not (gen_fail or chg_fail)
        self._pdd_genimg_task_detail = detail
        self.pdd_genimg_status.setText(f"完成:生成 {gen} · 换主图 {ok}")
        self._pdd_genimg_reload_table()
        if getattr(self, "_auto_pub_recs", None):
            # 在自动发布链里:不弹框,接下一棒(补视频/开车 由 _auto_chain_video 按勾选决定)
            QTimer.singleShot(800, self._auto_chain_video)
            return
        if self._task_center_should_defer_dialog():
            self._task_center_update_current_detail(detail)
        else:
            QMessageBox.information(self, "生图换图完成", detail)

    def _pdd_genimg_edit_prompt(self):
        """打开提示词文件用记事本编辑(改完存盘,下次生成生效)。"""
        import os
        from image_gen import EDIT_PROMPT
        path = r"D:/files/data/pdd/image_prompt.txt"
        try:
            if not os.path.exists(path):
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(EDIT_PROMPT.strip() + "\n")
            os.startfile(path)
            QMessageBox.information(self, "编辑提示词",
                "已用记事本打开提示词文件。改完按 Ctrl+S 存盘后,下次生成就用新提示词。"
                "注意:如需自动抠文案,可在提示词里保留 {主}{副}{标签} 占位。")
        except Exception as e:
            QMessageBox.warning(self, "编辑提示词", f"打不开:{e!r}")

    def _pdd_genimg_api_settings(self):
        """⚙️ 修改/切换 生图换图 用的【图像API】(image_api.json):base_url/model/key。
        只改这几个字段,保留文件里其它字段(备注等);改完即生效(子进程下次读取)。
        注:文案模型 DeepSeek 仅当提示词含 {主}{副}{标签} 占位时才用,当前提示词没有 → 这里不放,
        DeepSeek 配置是全项目共用(份数/产品类型/智能SKU),不在生图页改。"""
        import json as _json
        IMG = r"D:/files/data/pdd/image_api.json"

        def _load(p):
            try:
                d = _json.loads(Path(p).read_text(encoding="utf-8"))
                return d if isinstance(d, dict) else {}
            except Exception:
                return {}
        img = _load(IMG)

        dlg = QDialog(self); dlg.setWindowTitle("⚙️ 生图换图 — 图像API设置"); dlg.resize(560, 240)
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel("改完点保存即生效(下次生成/换图时读取,不用重启)。密钥只存本地 json、不进打包。"))

        gb1 = QGroupBox("图像API(生图换图主力 · 如 gpt-image-2 中转)")
        f1 = QFormLayout(gb1)
        ed_img_url = QLineEdit(img.get("base_url", "")); ed_img_url.setPlaceholderText("国内节点如 https://grsai.dakka.com.cn")
        # 模型:可编辑下拉(记忆常用)——下拉用你用过的模型自动攒,也可直接输入新模型名,保存后记住
        _img_presets = [m for m in (img.get("model_presets") or []) if m]
        for _m in ("gpt-image-2", img.get("model", "")):
            if _m and _m not in _img_presets:
                _img_presets.insert(0, _m)
        ed_img_model = QComboBox(); ed_img_model.setEditable(True)
        ed_img_model.addItems(_img_presets)
        ed_img_model.setCurrentText(img.get("model", ""))
        ed_img_model.setToolTip("下拉选常用模型,或直接输入新模型名;保存后自动记进下拉")
        ed_img_key = QLineEdit(img.get("key", "")); ed_img_key.setEchoMode(QLineEdit.Password)
        f1.addRow("中转地址 base_url：", ed_img_url)
        f1.addRow("模型 model：", ed_img_model)
        f1.addRow("密钥 key：", ed_img_key)
        v.addWidget(gb1)

        chk_show = QCheckBox("显示密钥")
        chk_show.toggled.connect(lambda on: ed_img_key.setEchoMode(
            QLineEdit.Normal if on else QLineEdit.Password))
        v.addWidget(chk_show)

        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Save).setText("💾 保存")
        bb.button(QDialogButtonBox.Cancel).setText("取消")
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return

        # 只更新这几个字段,其它(备注/provider/enabled)原样保留
        img["base_url"] = ed_img_url.text().strip()
        _img_model = ed_img_model.currentText().strip()
        img["model"] = _img_model
        # 把选/输的模型记进预设(去重、置顶),下次下拉就有
        _pl = [m for m in (img.get("model_presets") or []) if m]
        if _img_model and _img_model not in _pl:
            _pl.insert(0, _img_model)
        img["model_presets"] = _pl
        img["key"] = ed_img_key.text().strip()
        try:
            Path(IMG).parent.mkdir(parents=True, exist_ok=True)
            Path(IMG).write_text(_json.dumps(img, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.critical(self, "API设置", f"保存失败:\n{e}")
            return
        self.pdd_genimg_status.setText("✅ API/模型设置已保存,下次生成生效")
        QMessageBox.information(self, "API设置", "已保存。下次生成/换图就用新配置(不用重启客户端)。")

    # ════════════════════════════════════════════════════════════════════════
    #  🔑 API管理:统一管理所有外部 API/密钥(生图图像API / 云端DeepSeek / 万邦比价)
    # ════════════════════════════════════════════════════════════════════════
    def _build_pdd_page_apikeys(self) -> QWidget:
        """🔑 一处管所有外部 API 的 地址/模型/密钥。改完点【💾 全部保存】即生效(引擎子进程下次调用重读,不用重启)。"""
        import json as _json
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(8)
        title = QLabel("🔑 API / 密钥统一管理")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        tip = QLabel("一处管所有外部 API 的 地址/模型/密钥。改完点【💾 全部保存】即生效(各引擎子进程下次调用时重读 json,不用重启)。"
                     "密钥只存本地 json、不进打包。")
        tip.setStyleSheet("color:#9CA3AF;font-size:11px;"); tip.setWordWrap(True)
        lay.addWidget(tip)

        update_box = QGroupBox("软件更新")
        update_form = QFormLayout(update_box)
        self.pdd_update_version_label = QLabel(f"v{_read_app_version()}")
        self.pdd_update_version_label.setStyleSheet("color:#374151;font-weight:bold;")
        self.pdd_update_status_label = QLabel("未检查")
        self.pdd_update_status_label.setStyleSheet("color:#6B7280;font-size:11px;")
        update_btn_row = QWidget()
        update_btn_lay = QHBoxLayout(update_btn_row)
        update_btn_lay.setContentsMargins(0, 0, 0, 0)
        self.pdd_update_check_btn = QPushButton("检查更新")
        self.pdd_update_check_btn.setStyleSheet("background:#4F46C8;color:white;font-weight:bold;border-radius:4px;padding:6px 16px;")
        self.pdd_update_check_btn.clicked.connect(self._pdd_manual_check_update)
        update_btn_lay.addWidget(self.pdd_update_check_btn)
        update_btn_lay.addStretch(1)
        update_form.addRow("当前版本：", self.pdd_update_version_label)
        update_form.addRow("更新状态：", self.pdd_update_status_label)
        update_form.addRow("", update_btn_row)
        lay.addWidget(update_box)

        def _load(name):
            try:
                d = _json.loads((Path(r"D:/files/data/pdd") / name).read_text(encoding="utf-8"))
                return d if isinstance(d, dict) else {}
            except Exception:
                return {}
        img = _load("image_api.json"); llm = _load("llm_api.json"); wb = _load("wanbang_api.json")
        ark = _load("ark_api.json")
        self._apikeys_cfg = {"image_api.json": img, "llm_api.json": llm,
                             "wanbang_api.json": wb, "ark_api.json": ark}
        self._apikeys_fields = {}       # (file, field) -> QLineEdit
        keyedits = []                   # 密钥框,供"显示密钥"统一切换

        def _row(form, label, fk, field, password=False, placeholder=""):
            ed = QLineEdit(str(self._apikeys_cfg[fk].get(field) or ""))
            if placeholder:
                ed.setPlaceholderText(placeholder)
            if password:
                ed.setEchoMode(QLineEdit.Password); keyedits.append(ed)
            form.addRow(label, ed)
            self._apikeys_fields[(fk, field)] = ed

        gb1 = QGroupBox("① 图像生图 API(生图换图 · grsai 流式出图,如 gpt-image-2)")
        f1 = QFormLayout(gb1)
        _row(f1, "中转地址 base_url：", "image_api.json", "base_url", placeholder="如 https://grsai.dakka.com.cn")
        _img_presets = [m for m in (img.get("model_presets") or []) if m]
        for _m in ("gpt-image-2", img.get("model", "")):
            if _m and _m not in _img_presets:
                _img_presets.insert(0, _m)
        cb_img_model = QComboBox(); cb_img_model.setEditable(True); cb_img_model.addItems(_img_presets)
        cb_img_model.setCurrentText(img.get("model", ""))
        cb_img_model.setToolTip("下拉选常用模型或直接输入新模型名,保存后记进下拉")
        f1.addRow("模型 model：", cb_img_model)
        self._apikeys_img_model = cb_img_model
        _row(f1, "密钥 key：", "image_api.json", "key", password=True)
        _row(f1, "比例 aspect_ratio：", "image_api.json", "aspect_ratio", placeholder="如 1024x1024 或 16:9")
        # 备选 grsai 全球节点:国内节点失败时回退,同一个 /v1/api/generate 流式接口
        _fb = img.get("fallback") or {}
        ed_fb_url = QLineEdit(str(_fb.get("base_url") or "")); ed_fb_url.setPlaceholderText("备选全球节点,如 https://grsaiapi.com;留空=不回退")
        ed_fb_key = QLineEdit(str(_fb.get("key") or "")); ed_fb_key.setEchoMode(QLineEdit.Password); keyedits.append(ed_fb_key)
        f1.addRow("备选 base_url：", ed_fb_url)
        f1.addRow("备选 key：", ed_fb_key)
        self._apikeys_fb_url = ed_fb_url; self._apikeys_fb_key = ed_fb_key
        lay.addWidget(gb1)

        gb2 = QGroupBox("② 云端大模型 DeepSeek(份数 / 产品类型 / 智能SKU / 生图文案)")
        f2 = QFormLayout(gb2)
        _row(f2, "厂商 provider：", "llm_api.json", "provider", placeholder="deepseek / openai / qwen")
        _row(f2, "地址 base_url：", "llm_api.json", "base_url", placeholder="如 https://api.deepseek.com")
        _row(f2, "模型 model：", "llm_api.json", "model", placeholder="如 deepseek-chat")
        _row(f2, "密钥 key：", "llm_api.json", "key", password=True)
        ck_llm = QCheckBox("启用"); ck_llm.setChecked(bool(llm.get("enabled", True)))
        f2.addRow("", ck_llm); self._apikeys_llm_enabled = ck_llm
        lay.addWidget(gb2)

        gb3 = QGroupBox("③ 万邦比价 API(比价①万邦)")
        f3 = QFormLayout(gb3)
        _row(f3, "key：", "wanbang_api.json", "key", password=True)
        _row(f3, "secret：", "wanbang_api.json", "secret", password=True)
        ck_wb = QCheckBox("启用"); ck_wb.setChecked(bool(wb.get("enabled", True)))
        f3.addRow("", ck_wb); self._apikeys_wb_enabled = ck_wb
        lay.addWidget(gb3)

        gb4 = QGroupBox("④ 火山方舟 视觉理解(同款核对 · 判 PDD候选图 vs 货源图 是否同款)")
        f4 = QFormLayout(gb4)
        _row(f4, "地址 base_url：", "ark_api.json", "base_url",
             placeholder="如 https://ark.cn-beijing.volces.com/api/v3")
        _row(f4, "模型 model：", "ark_api.json", "model",
             placeholder="视觉理解模型ID,如 doubao-seed-2-0-mini-260428")
        _row(f4, "密钥 key：", "ark_api.json", "key", password=True)
        lay.addWidget(gb4)

        bar = QHBoxLayout()
        ck_show = QCheckBox("显示密钥")
        ck_show.toggled.connect(lambda on: [e.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password) for e in keyedits])
        bar.addWidget(ck_show); bar.addStretch(1)
        btn_save = QPushButton("💾 全部保存")
        btn_save.setStyleSheet("background:#10B981;color:white;font-weight:bold;border-radius:4px;padding:7px 18px;")
        btn_save.clicked.connect(self._pdd_apikeys_save)
        bar.addWidget(btn_save)
        lay.addLayout(bar)
        self.pdd_apikeys_status = QLabel(""); self.pdd_apikeys_status.setStyleSheet("color:#6B7280;font-size:11px;")
        lay.addWidget(self.pdd_apikeys_status)
        lay.addStretch(1)
        return page

    def _pdd_manual_check_update(self):
        thread = getattr(self, "_update_check_thread", None)
        if thread is not None and thread.isRunning():
            return
        self.pdd_update_check_btn.setEnabled(False)
        self.pdd_update_status_label.setText("正在检查更新...")
        self.status.showMessage("正在检查更新...")
        self._update_check_thread = UpdateCheckThread(self)
        self._update_check_thread.result_signal.connect(self._pdd_manual_update_done)
        self._update_check_thread.finished.connect(self._update_check_thread.deleteLater)
        self._update_check_thread.start()

    def _pdd_manual_update_done(self, result):
        self.pdd_update_check_btn.setEnabled(True)
        self.app_version = _read_app_version()
        self.setWindowTitle(f"{APP_TITLE} v{self.app_version}")
        self.pdd_update_version_label.setText(f"v{self.app_version}")
        self._update_check_thread = None
        if isinstance(result, Exception):
            msg = f"检查失败: {result}"
            self.pdd_update_status_label.setText(msg)
            self.status.showMessage(msg, 8000)
            QMessageBox.warning(self, "检查更新", msg)
            return

        raw_msg = str(getattr(result, "message", "") or "")
        if getattr(result, "updated", False):
            msg = f"已更新到 v{self.app_version}，请关闭并重新打开客户端。"
            self.pdd_update_status_label.setText(msg)
            self.status.showMessage(msg, 10000)
            QMessageBox.information(self, "检查更新", msg)
        elif not getattr(result, "checked", False):
            msg = "自动更新未启用" if "disabled" in raw_msg.lower() else raw_msg or "未执行检查"
            self.pdd_update_status_label.setText(msg)
            self.status.showMessage(msg, 8000)
            QMessageBox.information(self, "检查更新", msg)
        elif "already current" in raw_msg.lower():
            msg = f"已是最新版本 v{self.app_version}"
            self.pdd_update_status_label.setText(msg)
            self.status.showMessage(msg, 8000)
            QMessageBox.information(self, "检查更新", msg)
        else:
            msg = raw_msg or "检查完成，未应用更新。"
            self.pdd_update_status_label.setText(msg)
            self.status.showMessage(msg, 8000)
            QMessageBox.information(self, "检查更新", msg)

    def _pdd_apikeys_save(self):
        """保存 API管理 页:只改编辑的字段,保留各 json 其它字段(备注/sort 等);写回三个文件。"""
        import json as _json
        cfg = self._apikeys_cfg
        for (fk, field), ed in self._apikeys_fields.items():
            cfg[fk][field] = ed.text().strip()
        im = self._apikeys_img_model.currentText().strip()
        cfg["image_api.json"]["model"] = im
        _pl = [m for m in (cfg["image_api.json"].get("model_presets") or []) if m]
        if im and im not in _pl:
            _pl.insert(0, im)
        cfg["image_api.json"]["model_presets"] = _pl
        # 备选 grsai 全球节点(image_api.json.fallback):填了 base_url+key 才回退,留空=去掉回退
        _fbu = self._apikeys_fb_url.text().strip(); _fbk = self._apikeys_fb_key.text().strip()
        if _fbu or _fbk:
            _fb = cfg["image_api.json"].get("fallback") or {}
            _fb["base_url"] = _fbu; _fb["key"] = _fbk
            _fb["provider"] = "grsai-global"; _fb.setdefault("model", "gpt-image-2")
            cfg["image_api.json"]["fallback"] = _fb
        else:
            cfg["image_api.json"].pop("fallback", None)
        cfg["llm_api.json"]["enabled"] = self._apikeys_llm_enabled.isChecked()
        cfg["wanbang_api.json"]["enabled"] = self._apikeys_wb_enabled.isChecked()
        try:
            for name, d in cfg.items():
                (Path(r"D:/files/data/pdd") / name).write_text(
                    _json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.critical(self, "API管理", f"保存失败:\n{e}")
            return
        self.pdd_apikeys_status.setText("✅ 已全部保存,下次调用生效(不用重启)")
        QMessageBox.information(self, "API管理", "已保存。各引擎下次调用就用新配置(不用重启客户端)。")

    def _build_pdd_page_video(self) -> QWidget:
        """🎬 视频补传:把每个已发布商品在磁力金牛「投流分析」里的【全部】带货视频
        下载并发到 PDD 多多视频(平台按商品id自动匹配)。详见 handoff §16。
        搜索 / 分类(全部·未传·已传)/ 店铺筛选 / 已传视频数 / 统计 / 批量补传。"""
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(6)
        title = QLabel("🎬 视频补传(多多视频)")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        tip = QLabel("取每个已发布商品在磁力金牛「投流分析」里的全部带货视频 → 下载 → 发到 PDD 多多视频"
                     "(按商品id自动匹配,内容声明固定「内容无需标注」,不同步店铺动态)。已传的不重复传。")
        tip.setStyleSheet("color:#9CA3AF;font-size:11px;"); tip.setWordWrap(True)
        lay.addWidget(tip)

        # 工具栏行1:刷新 + 搜索 + 分类 + 店铺 + 统计
        bar1 = QHBoxLayout(); bar1.setSpacing(6)
        btn_reload = QPushButton("🔄 刷新"); btn_reload.clicked.connect(self._pdd_video_reload_table)
        bar1.addWidget(btn_reload)
        bar1.addWidget(QLabel("搜索:"))
        self.pdd_video_search = QLineEdit(); self.pdd_video_search.setPlaceholderText("商品名 / goods_id")
        self.pdd_video_search.setFixedWidth(200)
        self.pdd_video_search.textChanged.connect(self._pdd_video_apply_filter)
        bar1.addWidget(self.pdd_video_search)
        bar1.addWidget(QLabel("分类:"))
        self.pdd_video_cat = QComboBox(); self.pdd_video_cat.addItems(["全部", "未传", "已传"])
        self.pdd_video_cat.currentIndexChanged.connect(self._pdd_video_apply_filter)
        bar1.addWidget(self.pdd_video_cat)
        bar1.addWidget(QLabel("店铺:"))
        self.pdd_video_store = QComboBox(); self.pdd_video_store.addItem("全部")
        self.pdd_video_store.currentIndexChanged.connect(self._pdd_video_apply_filter)
        bar1.addWidget(self.pdd_video_store)
        bar1.addStretch(1)
        self.pdd_video_stats = QLabel(""); self.pdd_video_stats.setStyleSheet("color:#6B7280;font-size:11px;")
        bar1.addWidget(self.pdd_video_stats)
        lay.addLayout(bar1)

        # 工具栏行2:批量操作 + 进度
        bar2 = QHBoxLayout(); bar2.setSpacing(6)
        btn_chk = QPushButton("☑ 全选当前"); btn_chk.clicked.connect(self._pdd_video_toggle_all)
        bar2.addWidget(btn_chk)
        btn_do = QPushButton("⬆️ 补传选中商品视频")
        btn_do.setStyleSheet("background:#10B981;color:white;font-weight:bold;border-radius:4px;padding:6px 14px;")
        btn_do.clicked.connect(lambda: self._pdd_video_supplement_selected())
        bar2.addWidget(btn_do)
        btn_all = QPushButton("⬆️ 一键补传全部未传")
        btn_all.setStyleSheet("background:#4F46C8;color:white;font-weight:bold;border-radius:4px;padding:6px 14px;")
        btn_all.clicked.connect(self._pdd_video_supplement_untransferred)
        bar2.addWidget(btn_all)
        btn_local = QPushButton("📁 批量自定义视频")
        btn_local.setToolTip("勾选多个商品后点这里:弹窗给每个商品分别挑本地视频上传(不用改文件名),一次跑多个。")
        btn_local.setStyleSheet("background:white;color:#0891B2;border:1px solid #67E8F9;"
                                "border-radius:4px;padding:6px 14px;")
        btn_local.clicked.connect(self._pdd_video_upload_local_batch)
        bar2.addWidget(btn_local)
        btn_dmv = QPushButton("🎬 打开多多视频")
        btn_dmv.setToolTip("用 live_creator 登录态 Chrome 直达 PDD 创作者中心·多多视频(看/管理已传视频)")
        btn_dmv.setStyleSheet("background:white;color:#DC2626;border:1px solid #FCA5A5;"
                              "border-radius:4px;padding:6px 14px;")
        btn_dmv.clicked.connect(self._pdd_video_open_dmv)
        bar2.addWidget(btn_dmv)
        btn_clean = QPushButton("🧹 清理视频缓存")
        btn_clean.setToolTip("删除 data/videos 里下载/上传用的本地视频文件(已传记录在 json,不影响)")
        btn_clean.clicked.connect(self._pdd_video_clear_cache)
        bar2.addWidget(btn_clean)
        self.pdd_video_chk_show_browser = QCheckBox("显示浏览器")
        self.pdd_video_chk_show_browser.setToolTip(
            "勾上(默认):取视频/上传视频时浏览器显示在屏幕上(可盯着看/手动过验证码);不勾=屏幕外静默运行")
        self.pdd_video_chk_show_browser.setChecked(self._pdd_task_center_show_browser_on())
        self.pdd_video_chk_show_browser.toggled.connect(self._pdd_set_task_center_show_browser)
        bar2.addWidget(self.pdd_video_chk_show_browser)
        bar2.addStretch(1)
        self.pdd_video_status = QLabel(""); self.pdd_video_status.setStyleSheet("color:#9CA3AF;font-size:11px;")
        bar2.addWidget(self.pdd_video_status)
        lay.addLayout(bar2)

        self.pdd_video_table = QTableWidget(0, 9)
        self.pdd_video_table.setHorizontalHeaderLabels(
            ["选", "goods_id", "主图", "商品名", "店铺", "上架日期", "已传视频", "状态", "操作"])
        h = self.pdd_video_table.horizontalHeader()
        for c, mode in ((0, QHeaderView.Fixed), (1, QHeaderView.ResizeToContents),
                        (2, QHeaderView.Fixed), (3, QHeaderView.Interactive),
                        (4, QHeaderView.ResizeToContents), (5, QHeaderView.ResizeToContents),
                        (6, QHeaderView.ResizeToContents), (7, QHeaderView.ResizeToContents),
                        (8, QHeaderView.Stretch)):
            h.setSectionResizeMode(c, mode)
        self.pdd_video_table.setColumnWidth(0, 44)    # 勾选框列固定宽,不再被挤
        self.pdd_video_table.setColumnWidth(2, 54)    # 主图缩略图列
        self.pdd_video_table.setColumnWidth(3, 380)   # 商品名:固定宽
        self.pdd_video_table.setWordWrap(True)        # 换行:长商品名完整显示(折行,不省略)
        self.pdd_video_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pdd_video_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.pdd_video_table.verticalHeader().setDefaultSectionSize(48)   # 容纳缩略图
        lay.addWidget(self.pdd_video_table, 1)
        # 不在 build/启动时渲染(几十行×缩图很慢);首次切到 PDD 标签页时才渲染(_on_main_tab_changed)
        return page

    def _pdd_video_published_records(self) -> list:
        """读 pdd_publish_history.json 里【在架】的已发布商品。
        ★ 排除已下架(taken_down)/回收站(deleted):下架商品在多多视频里匹配不到、传不了。"""
        import json as _json
        p = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        try:
            data = _json.loads(p.read_text(encoding="utf-8-sig"))
        except Exception:
            return []
        recs = data if isinstance(data, list) else (data.get("records") or data.get("history") or [])
        # status: ok=在架 / taken_down=已下架 / not_listed=未上架 / deleted=回收站
        # 只留在架的(taken_down/not_listed/deleted 都匹配不到商品、传不了)
        active_stores = self._pdd_active_store_names()
        return [r for r in recs
                if r.get("goods_id")
                and r.get("status") not in ("taken_down", "deleted", "not_listed")
                and self._pdd_record_store_active(r, active_stores)]

    def _pdd_video_reload_table(self):
        """重读已发布记录 + 已传记录,刷新店铺下拉,再按当前筛选渲染。"""
        self._pdd_video_recs = self._pdd_video_published_records()
        self._pdd_video_uploads = _video_uploads_load()
        # 店铺下拉(保留当前选择)
        cur = self.pdd_video_store.currentText() if hasattr(self, "pdd_video_store") else "全部"
        stores = sorted({(r.get("store") or "").strip() for r in self._pdd_video_recs if r.get("store")})
        self.pdd_video_store.blockSignals(True)
        self.pdd_video_store.clear(); self.pdd_video_store.addItem("全部")
        for s in stores:
            self.pdd_video_store.addItem(s)
        idx = self.pdd_video_store.findText(cur)
        self.pdd_video_store.setCurrentIndex(idx if idx >= 0 else 0)
        self.pdd_video_store.blockSignals(False)
        self._pdd_video_apply_filter()

    def _open_in_chrome(self, url, store=None, profile=None):
        """用程序的 Chrome + 指定登录态 profile 打开 PDD 链接(不是系统默认 Edge、也不是桌面默认 Chrome)。
        profile 直接给 profile 目录名(如 'live_creator');否则 store 给了用 pdd_profiles/<该店铺profile>。
        都没有/找不到 Chrome 则退默认浏览器。"""
        try:
            from pdd_publish import find_chrome
            import subprocess
            chrome = find_chrome()
            if chrome:
                # ★ 强制新窗口 + 屏幕内位置/大小:店铺 profile 的窗口位置被发布自动化设到了屏幕外
                #   (-32000),Chrome 会记住 → 不指定就开到桌面外。拉回屏幕内(同 _pdd_open_in_chrome)。
                args = [chrome, "--no-first-run", "--no-default-browser-check", "--new-window",
                        "--window-position=80,60", "--window-size=1280,860"]
                prof = profile or (self._pdd_stores_read().get(store) if store else None)
                if prof:
                    pdir = Path(r"D:/files/pdd_profiles") / prof
                    args.append(f"--user-data-dir={pdir}")
                args.append(url)
                subprocess.Popen(args)
                return
        except Exception:
            pass
        QDesktopServices.openUrl(QUrl(url))

    def _pdd_video_open_insight(self, rec):
        """开磁力金牛「商品洞察」页(反查 productId + 自动登录,持久 jinfu_profile)。
        起 InsightOpenThread 后台开浏览器,不阻塞 UI;首次自动密码登录,之后 session 复用。"""
        try:
            import video_pipe
            pid = video_pipe.resolve_product_id(rec)
        except Exception as e:
            QMessageBox.warning(self, "商品洞察", f"反查 productId 失败:{e}")
            return
        if not pid:
            QMessageBox.information(self, "商品洞察",
                "没找到该商品的磁力金牛 productId(商品库里按供应链接/选品图反查不到)。")
            return
        th = getattr(self, "_insight_thread", None)
        if th is not None and th.isRunning():
            QMessageBox.information(self, "商品洞察", "已有一个洞察窗口在开,先关掉它再开下一个。")
            return
        self._insight_thread = InsightOpenThread(pid, self)
        self._insight_thread.status.connect(lambda m: self.pdd_video_status.setText(m))
        self._insight_thread.start()
        self.pdd_video_status.setText("正在打开商品洞察…")

    def _pdd_video_clear_cache(self):
        """清理 data/videos 里下载/拷贝的本地视频文件(传成功的本会自动删,这里清积压/失败残留)。"""
        import os, glob
        d = r"D:/files/data/videos"
        files = [f for f in glob.glob(os.path.join(d, "*")) if os.path.isfile(f)]
        if not files:
            QMessageBox.information(self, "清理视频缓存", "data/videos 里没有本地视频文件,无需清理。")
            return
        sz = sum((os.path.getsize(f) for f in files), 0)
        if QMessageBox.question(
                self, "清理视频缓存",
                f"将删除 data/videos 里 {len(files)} 个本地视频文件(约 {sz/1048576:.0f} MB)。\n\n"
                "这些是下载/拷贝来用于上传的临时文件,已传记录在 video_uploads.json 里、不受影响。\n确认?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        n, freed = 0, 0
        for f in files:
            try:
                s = os.path.getsize(f); os.remove(f); n += 1; freed += s
            except Exception:
                pass
        self.pdd_video_status.setText(f"已清理 {n} 个视频文件,释放 {freed/1048576:.0f} MB")
        QMessageBox.information(self, "清理完成", f"删了 {n} 个文件,释放约 {freed/1048576:.0f} MB。")

    def _pdd_video_open_dmv(self):
        """打开多多视频:当前店铺筛选选了某店→直接开那店;筛选「全部」→弹框选店铺。用该店 profile 的登录态。"""
        url = "https://live.pinduoduo.com/n-creator/video/home?from=mms&msfrom=mms_sidenav"
        cur = self.pdd_video_store.currentText() if hasattr(self, "pdd_video_store") else "全部"
        if cur and cur != "全部":
            self._open_in_chrome(url, store=cur)
            return
        stores = [self.pdd_video_store.itemText(i) for i in range(self.pdd_video_store.count())
                  if self.pdd_video_store.itemText(i) not in ("", "全部")]
        if not stores:
            self._open_in_chrome(url, profile="live_creator")
            return
        from PyQt5.QtWidgets import QInputDialog
        store, ok = QInputDialog.getItem(self, "打开多多视频", "选择要打开的店铺:", stores, 0, False)
        if ok and store:
            self._open_in_chrome(url, store=store)

    def _pdd_video_uploaded_count(self, gid) -> int:
        e = (getattr(self, "_pdd_video_uploads", {}) or {}).get(str(gid))
        return len(e.get("photo_ids", [])) if e else 0

    def _pdd_video_apply_filter(self):
        kw = (self.pdd_video_search.text() or "").strip().lower()
        cat = self.pdd_video_cat.currentText()
        store = self.pdd_video_store.currentText()
        rows = []
        for rec in getattr(self, "_pdd_video_recs", []):
            gid = str(rec.get("goods_id", ""))
            name = rec.get("target_name") or rec.get("name") or rec.get("title") or ""
            st = (rec.get("store") or "")
            cnt = self._pdd_video_uploaded_count(gid)
            if kw and kw not in gid.lower() and kw not in name.lower():
                continue
            if store != "全部" and st != store:
                continue
            if cat == "未传" and cnt > 0:
                continue
            if cat == "已传" and cnt == 0:
                continue
            rows.append((rec, gid, name, st, cnt))
        self._pdd_video_render(rows)
        recs = getattr(self, "_pdd_video_recs", [])
        total = len(recs)
        done = sum(1 for r in recs if self._pdd_video_uploaded_count(r.get("goods_id")) > 0)
        vids = sum(self._pdd_video_uploaded_count(r.get("goods_id")) for r in recs)
        self.pdd_video_stats.setText(
            f"共 {total} 商品 · 已传 {done} · 未传 {total - done} · 累计视频 {vids} 条 · 当前显示 {len(rows)}")

    def _pdd_video_render(self, rows):
        tbl = self.pdd_video_table
        tbl.setRowCount(len(rows))
        img_tasks = []   # [(QLabel, url)] 给 ImageBatchLoader 异步下载
        for r, (rec, gid, name, store, cnt) in enumerate(rows):
            tbl.setCellWidget(r, 0, self._make_check_widget(False, gid=gid))
            review = (getattr(self, "_pdd_ap_review", {}) or {}).get(gid) or {}
            id_item = QTableWidgetItem(("⚠ " + gid) if review else gid)
            if review: id_item.setToolTip("待人工确认下架：" + str(review.get("reason", "")))
            tbl.setItem(r, 1, id_item)
            # 主图(上架主图优先,回退选品图/快手图)
            img_lbl = QLabel(); img_lbl.setAlignment(Qt.AlignCenter); img_lbl.setFixedSize(44, 44)
            img_lbl.setStyleSheet("color:#9CA3AF;background:#FAFAFA;border:1px solid #E5E7EB;border-radius:3px;")
            img_url = (rec.get("published_main_image") or rec.get("image")
                       or rec.get("xuanpin_image") or "")
            if img_url:
                if img_url.startswith("//"):
                    img_url = "https:" + img_url
                img_lbl.setText("…")
                img_tasks.append((img_lbl, img_url))
            else:
                img_lbl.setText("📷")
            tbl.setCellWidget(r, 2, img_lbl)
            tbl.setItem(r, 3, QTableWidgetItem(name))
            tbl.setItem(r, 4, QTableWidgetItem(store))
            # 上架日期(取 time 的日期部分)
            t = str(rec.get("time") or "")
            tbl.setItem(r, 5, QTableWidgetItem(t.split(" ")[0] if t else "—"))
            it_c = QTableWidgetItem(str(cnt)); it_c.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(r, 6, it_c)
            it_s = QTableWidgetItem("✅ 已传" if cnt > 0 else "— 未传")
            it_s.setForeground(QColor("#10B981") if cnt > 0 else QColor("#9CA3AF"))
            tbl.setItem(r, 7, it_s)
            w = QWidget(); hl = QHBoxLayout(w); hl.setContentsMargins(2, 0, 2, 0); hl.setSpacing(3)
            url = rec.get("detail_url") or ""
            if url:
                bl = QPushButton("🔗"); bl.setFixedHeight(24); bl.setToolTip("用该店铺登录态 Chrome 打开 PDD 商品页")
                bl.clicked.connect(lambda _, u=url, s=rec.get("store"): self._open_in_chrome(u, s))
                hl.addWidget(bl)
            b = QPushButton("⬆️ 补传"); b.setFixedHeight(24); b.setToolTip("从磁力金牛投流分析取该商品全部视频并上传")
            b.clicked.connect(lambda _, x=rec: self._pdd_video_supplement_selected([x]))
            hl.addWidget(b)
            bi = QPushButton("📊 洞察"); bi.setFixedHeight(24)
            bi.setToolTip("打开磁力金牛该商品的「商品洞察」页(载体分析里看推广视频)")
            bi.clicked.connect(lambda _, x=rec: self._pdd_video_open_insight(x))
            hl.addWidget(bi)
            bf = QPushButton("📁"); bf.setFixedHeight(24); bf.setToolTip("上传本地/自定义路径的视频到该商品(自动按商品id匹配)")
            bf.clicked.connect(lambda _, x=rec: self._pdd_video_upload_local(x))
            hl.addWidget(bf); hl.addStretch(1)
            tbl.setCellWidget(r, 8, w)
        # 异步加载缩略图(先停旧 loader 防 QThread 警告)
        if img_tasks:
            old = getattr(self, "_pdd_video_img_loader", None)
            if old is not None:
                try:
                    old.stop()
                except Exception:
                    pass
            self._pdd_video_img_loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_video_thumb_cache")
            self._pdd_video_img_loader.image_ready.connect(self._pdd_library_set_thumb)
            self._pdd_video_img_loader.start()

    def _pdd_video_toggle_all(self):
        tbl = self.pdd_video_table
        target = any(self._cell_checkbox(tbl, r) and not self._cell_checkbox(tbl, r).isChecked()
                     for r in range(tbl.rowCount()))
        for r in range(tbl.rowCount()):
            cb = self._cell_checkbox(tbl, r)
            if cb:
                cb.setChecked(target)

    def _pdd_video_show_browser(self) -> bool:
        """视频模块「显示浏览器」开关:优先读视频页控件,未加载时读任务中心总控。"""
        c = getattr(self, "pdd_video_chk_show_browser", None)
        return c.isChecked() if c is not None else self._pdd_task_center_show_browser_on()

    def _pdd_video_start_local_jobs(self, jobs, title="自定义视频上传"):
        self._task_center_register_running(title, "上传本地视频到 PDD 多多视频")
        self._pdd_video_task_ok = True
        self._pdd_video_task_detail = ""
        self.pdd_video_status.setText(f"{title}:启动中…")
        t = VideoUploadLocalThread(jobs, self, show_browser=self._pdd_video_show_browser())
        t.progress.connect(lambda m: self.pdd_video_status.setText(m))
        t.finished_summary.connect(self._pdd_video_done)
        t.finished.connect(lambda: (setattr(self, "_pdd_video_thread", None), self._task_center_finish_current(
            getattr(self, "_pdd_video_task_ok", True),
            getattr(self, "_pdd_video_task_detail", ""))))
        self._pdd_video_thread = t
        t.start()
    def _pdd_video_upload_local(self, rec, _from_task_center=False):
        """自定义路径视频上传:给该商品从本地选视频文件,直接传到多多视频(跳过磁力金牛取数)。"""
        gid = str(rec.get("goods_id") or "")
        if not gid:
            return
        name = rec.get("target_name") or rec.get("name") or ""
        files, _ = QFileDialog.getOpenFileNames(
            self, f"选择要上传到「{name[:20] or gid}」的本地视频(可多选)",
            "", "视频 (*.mp4 *.mov *.avi *.m4v *.wmv);;所有文件 (*.*)")
        if not files:
            return
        if QMessageBox.question(
                self, "上传本地视频",
                f"将把 {len(files)} 个本地视频上传到商品「{name[:24] or gid}」(goods_id={gid})。\n\n"
                "• 文件会按商品id重命名,平台自动匹配商品\n"
                "• 需 PDD 创作者中心(live_creator)已登录\n"
                "• 会自动开浏览器操作,期间别碰鼠标键盘\n\n确认开始?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        jobs = [(gid, rec.get("store") or "", list(files))]
        busy, busy_name = self._task_center_busy()
        if busy and not _from_task_center:
            self._task_center_enqueue(
                f"上传视频 {gid}",
                lambda jobs=list(jobs): self._pdd_video_start_local_jobs(jobs, "自定义视频上传"),
                f"等待 {busy_name} 结束后自动开始")
            return
        self._pdd_video_start_local_jobs(jobs, "自定义视频上传")

    def _pdd_video_upload_local_batch(self, _from_task_center=False):
        """批量自定义上传:勾选多个商品 → 弹对话框给每个商品挑本地视频(不用改名)→ 一次跑多个。"""
        recs = self._pdd_video_checked_records()
        if not recs:
            QMessageBox.information(self, "批量自定义上传", "请先勾选要自定义上传视频的商品(可多选)。")
            return
        products = [(str(r.get("goods_id")), r.get("store") or "",
                     r.get("target_name") or r.get("name") or "") for r in recs]
        dlg = VideoLocalAssignDialog(products, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        jobs = dlg.get_jobs()
        if not jobs:
            QMessageBox.information(self, "批量自定义上传", "没有给任何商品选视频。")
            return
        nprod = len(jobs); nvid = sum(len(v) for _, _, v in jobs)   # jobs=(gid,store,paths) 3元组
        if QMessageBox.question(
                self, "批量自定义上传",
                f"将给 {nprod} 个商品共上传 {nvid} 个本地视频。\n\n"
                "• 文件按商品id重命名,平台自动匹配商品\n"
                "• 需 PDD 创作者中心(live_creator)已登录\n"
                "• 会自动开浏览器操作,期间别碰鼠标键盘\n\n确认开始?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        busy, busy_name = self._task_center_busy()
        if busy and not _from_task_center:
            self._task_center_enqueue(
                f"批量自定义上传 {nprod} 个商品",
                lambda jobs=list(jobs): self._pdd_video_start_local_jobs(jobs, "批量自定义上传"),
                f"等待 {busy_name} 结束后自动开始")
            return
        self._pdd_video_start_local_jobs(jobs, "批量自定义上传")

    def _pdd_video_supplement_untransferred(self):
        recs = [r for r in getattr(self, "_pdd_video_recs", [])
                if self._pdd_video_uploaded_count(r.get("goods_id")) == 0]
        if not recs:
            QMessageBox.information(self, "视频补传", "没有未传的商品(全部已传)。")
            return
        self._pdd_video_supplement_selected(recs)

    def _pdd_video_checked_records(self) -> list:
        tbl = self.pdd_video_table
        by_gid = {str(r.get("goods_id")): r for r in getattr(self, "_pdd_video_recs", [])}
        out = []
        for r in range(tbl.rowCount()):
            cb = self._cell_checkbox(tbl, r)
            if cb and cb.isChecked():
                rec = by_gid.get(str(cb.property("rec_id")))
                if rec:
                    out.append(rec)
        return out

    def _pdd_video_supplement_selected(self, recs=None, no_confirm=False, _from_task_center=False):
        if recs is None:
            recs = self._pdd_video_checked_records()
        if not recs:
            QMessageBox.information(self, "视频补传", "请先勾选要补传视频的商品。")
            return
        busy, busy_name = self._task_center_busy()
        if busy and not _from_task_center:
            self._task_center_enqueue(
                f"视频补传 {len(recs)} 个",
                lambda recs=list(recs): self._pdd_video_supplement_selected(recs, True, _from_task_center=True),
                f"等待 {busy_name} 结束后自动开始")
            return
        n = len(recs)
        if not no_confirm and QMessageBox.question(
                self, "视频补传",
                f"将对 {n} 个商品:从磁力金牛「投流分析」取它们的【全部】带货视频 → 下载 → "
                f"发到 PDD 多多视频(按商品id自动匹配)。\n\n"
                "• 需磁力金牛 + PDD 创作者中心(live_creator)都已登录\n"
                "• 会自动开浏览器操作,期间别碰鼠标键盘\n"
                "• 内容声明固定「内容无需标注」\n\n确认开始?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._task_center_register_running(f"视频补传 {len(recs)} 个", "取视频、下载并上传到多多视频")
        self._pdd_video_task_ok = True
        self._pdd_video_task_detail = ""
        self.pdd_video_status.setText("视频补传:启动中…")
        t = VideoSupplementThread(list(recs), self, show_browser=self._pdd_video_show_browser())
        t.progress.connect(lambda m: self.pdd_video_status.setText(m))
        t.finished_summary.connect(self._pdd_video_done)
        t.finished.connect(lambda: (setattr(self, "_pdd_video_thread", None), self._task_center_finish_current(
            getattr(self, "_pdd_video_task_ok", True),
            getattr(self, "_pdd_video_task_detail", ""))))
        self._pdd_video_thread = t
        t.start()

    def _pdd_video_done(self, summary: dict):
        _in_chain = getattr(self, "_auto_in_video_chain", False)
        if summary.get("error"):
            detail = f"视频补传出错:{summary['error']}"
            self._pdd_video_task_ok = False
            self._pdd_video_task_detail = detail
            self.pdd_video_status.setText("视频补传:出错")
            if _in_chain:
                self._auto_in_video_chain = False
                self._oc_maybe_promote()   # 出错也别卡住开车环节
            elif self._task_center_should_defer_dialog():
                self._task_center_update_current_detail(detail)
            else:
                QMessageBox.warning(self, "视频补传", f"出错:{summary['error']}")
            return
        head = (f"商品 {summary.get('products', 0)} 个 · 找到视频 {summary.get('videos_found', 0)} 条 · "
                f"下载 {summary.get('downloaded', 0)} · 发布成功 {summary.get('uploaded_ok', 0)} · "
                f"失败 {summary.get('uploaded_fail', 0)}")
        msg = head
        if summary.get("failures"):
            msg += "\n\n失败明细:\n" + "\n".join(
                f"  {g} {fn}: {reason} {toast}".rstrip() for g, fn, reason, toast in summary["failures"][:10])
        if summary.get("skipped"):
            msg += "\n\n跳过:\n" + "\n".join(f"  {g}: {why}" for g, why in summary["skipped"][:10])
        self._pdd_video_task_ok = int(summary.get("uploaded_fail", 0) or 0) == 0 and not summary.get("failures")
        self._pdd_video_task_detail = msg
        self._pdd_video_reload_table()   # 刷新已传数/状态/统计
        self.pdd_video_status.setText("视频补传完成:" + head)
        if _in_chain:
            # 自动链:不弹完成框,直接接开车环节(若勾了⑥)
            self._auto_in_video_chain = False
            self._oc_maybe_promote()
        elif self._task_center_should_defer_dialog():
            self._task_center_update_current_detail(msg)
        else:
            QMessageBox.information(self, "视频补传完成", msg)

    def _build_pdd_page_stores(self) -> QWidget:
        """店铺管理:列 stores.json + 新增扫码登录 + 重命名 + 删除。"""
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(6)
        title = QLabel("🏪 店铺管理")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)

        bar = QHBoxLayout(); bar.setSpacing(6)
        btn_add = QPushButton("➕ 新增扫码登录")
        btn_add.setStyleSheet("background:#10B981;color:white;font-weight:bold;border-radius:4px;"
                              "padding:6px 14px;")
        btn_add.clicked.connect(self._pdd_store_add_login)
        bar.addWidget(btn_add)
        btn_check = QPushButton("🔍 检查登录")
        btn_check.setToolTip("后台 headless 打开每个店铺,看 cookies 是否还有效\n掉线的会列出来,需要重新扫码")
        btn_check.setStyleSheet("background:#4F46C8;color:white;font-weight:bold;border-radius:4px;"
                                "padding:6px 14px;")
        btn_check.clicked.connect(self._pdd_store_check_logins)
        bar.addWidget(btn_check)
        btn_refresh = QPushButton("🔄 刷新"); btn_refresh.clicked.connect(self._pdd_store_reload_table)
        bar.addWidget(btn_refresh)
        btn_open_root = QPushButton("📂 打开 profile 根目录"); btn_open_root.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(r"D:/files/pdd_profiles")))
        bar.addWidget(btn_open_root)
        # 顶部常驻删除按钮:操作列被「店铺名」Stretch 挤到屏幕外看不到,这里给个始终可见的入口
        btn_del = QPushButton("🗑 删除选中店铺")
        btn_del.setToolTip("删除表中选中的那一行店铺(stores.json 移除 + 删除 profile 目录)")
        btn_del.setStyleSheet("background:#EF4444;color:white;font-weight:bold;border-radius:4px;"
                              "padding:6px 14px;")
        btn_del.clicked.connect(lambda: self._pdd_store_delete_selected())
        bar.addWidget(btn_del)
        btn_archive = QPushButton("📦 归档退店历史")
        btn_archive.setToolTip("把 stores.json 已不存在店铺的发布历史移出主历史；会先备份并写入归档文件")
        btn_archive.setStyleSheet("background:#F59E0B;color:white;font-weight:bold;border-radius:4px;"
                                  "padding:6px 14px;")
        btn_archive.clicked.connect(self._pdd_archive_retired_store_history)
        bar.addWidget(btn_archive)
        btn_delete_history = QPushButton("🧹 删除退店历史")
        btn_delete_history.setToolTip("把 stores.json 已不存在店铺的发布历史从主历史删除；会弹窗列出店铺和条数")
        btn_delete_history.setStyleSheet("background:#DC2626;color:white;font-weight:bold;border-radius:4px;"
                                         "padding:6px 14px;")
        btn_delete_history.clicked.connect(self._pdd_delete_retired_store_history)
        bar.addWidget(btn_delete_history)
        bar.addWidget(QLabel("店铺:"))
        self.pdd_store_home_combo = QComboBox()
        self.pdd_store_home_combo.setMinimumWidth(220)
        self.pdd_store_home_combo.setToolTip("选择要打开后台首页的店铺")
        bar.addWidget(self.pdd_store_home_combo)
        btn_home = QPushButton("🏠 进入店铺首页")
        btn_home.setToolTip("使用所选店铺登录态打开 PDD 商家后台首页")
        btn_home.clicked.connect(self._pdd_store_open_home_selected)
        bar.addWidget(btn_home)
        bar.addStretch(1)
        self.pdd_store_status = QLabel("")
        self.pdd_store_status.setStyleSheet("color:#9CA3AF;font-size:11px;")
        bar.addWidget(self.pdd_store_status)
        lay.addLayout(bar)

        self.pdd_store_table = QTableWidget(0, 6)
        self.pdd_store_table.setHorizontalHeaderLabels(
            ["店铺名", "状态", "profile 目录", "最近活动", "占用", "操作"])
        h = self.pdd_store_table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.Stretch)
        h.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.pdd_store_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pdd_store_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.pdd_store_table.verticalHeader().setDefaultSectionSize(30)
        lay.addWidget(self.pdd_store_table, 1)

        self._pdd_store_reload_table()
        return page

    # ── 店铺管理:helpers ──────────────────────────────────────────────────
    def _pdd_stores_path(self) -> Path:
        return Path(r"D:/files/pdd_profiles/stores.json")

    def _pdd_stores_read(self) -> dict:
        import json as _json
        p = self._pdd_stores_path()
        try:
            return _json.load(open(p, encoding="utf-8")) if p.exists() else {}
        except Exception:
            return {}

    def _pdd_open_supplier_link(self, url: str):
        """打开 1688 货源链接 —— 用系统默认浏览器(不占 PDD 店铺 profile,你想点几次点几次)。"""
        url = (url or "").strip()
        if not url:
            return
        if not url.lower().startswith("http"):
            url = "https://" + url
        try:
            from PyQt5.QtGui import QDesktopServices
            from PyQt5.QtCore import QUrl
            QDesktopServices.openUrl(QUrl(url))
        except Exception as e:
            QMessageBox.warning(self, "打开货源", f"打开 1688 链接失败:\n{e}")

    def _pdd_open_in_chrome(self, url: str, store: str = ""):
        """用跑品同款 Chrome + 该店铺已登录 profile 打开链接(而非系统默认浏览器)。

        找不到 Chrome 或匹配不到店铺 profile 时回落 QDesktopServices(系统默认浏览器)。
        注意:用的是自动化跑品同一个 user-data-dir,看完不关窗口会导致之后对该店铺
        跑品/核查时 Playwright 因 profile 被占用而启动失败。
        """
        try:
            import sys as _s
            if r"D:/files" not in _s.path:
                _s.path.insert(0, r"D:/files")
            from pdd_takedown import find_chrome as _fc, PROFILE_DIR as _pr
            chrome_exe = _fc()
            stores = self._pdd_stores_read()
            prof_name = None
            if store:
                if store in stores:
                    prof_name = stores[store]
                else:
                    m = next((k for k in stores if store in k or k in store), None)
                    if m:
                        prof_name = stores[m]
            profile_dir = (_pr / prof_name) if prof_name else None
            if profile_dir and profile_dir.exists():
                import subprocess
                # 手动查看是要"亲眼看"的:强制新窗口 + 定位到屏幕内可见位置,
                # 避免复用某次静默操作残留在屏幕外(-32000)的旧窗口导致看不到。
                subprocess.Popen([
                    chrome_exe,
                    f"--user-data-dir={profile_dir}",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "--new-window",
                    "--window-position=80,60",
                    "--window-size=1280,860",
                    url,
                ])
                return
            print(f"[查看] 未匹配到店铺 profile (store={store!r}),回落系统默认浏览器")
        except Exception as e:
            print(f"[查看] Chrome 启动失败,回落系统默认浏览器: {e}")
        QDesktopServices.openUrl(QUrl(url))

    def _pdd_stores_write(self, data: dict):
        import json as _json
        p = self._pdd_stores_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(_json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def _dir_size(path: Path) -> int:
        total = 0
        try:
            for f in path.rglob("*"):
                try:
                    if f.is_file(): total += f.stat().st_size
                except Exception: pass
        except Exception: pass
        return total

    @staticmethod
    def _human_size(n: int) -> str:
        for u in ("B", "KB", "MB", "GB"):
            if n < 1024: return f"{n:.0f} {u}"
            n /= 1024
        return f"{n:.1f} TB"

    def _pdd_store_reload_table(self):
        import time as _t
        stores = self._pdd_stores_read()
        root = Path(r"D:/files/pdd_profiles")
        login_status = getattr(self, "_pdd_store_login_status", {}) or {}
        rows = []
        for name, prof in stores.items():
            d = root / prof
            mt = ""; sz = ""; dir_missing = False
            if d.exists():
                try:
                    mt = _t.strftime("%Y-%m-%d %H:%M", _t.localtime(d.stat().st_mtime))
                except Exception: pass
                sz = self._human_size(self._dir_size(d))
            else:
                mt = "（目录不存在）"
                dir_missing = True
            st = login_status.get(name) or ({"status": "missing", "msg": "profile 目录不存在"} if dir_missing else None)
            rows.append((name, prof, mt, sz, st))
        if hasattr(self, "pdd_store_home_combo"):
            cur = self.pdd_store_home_combo.currentText().strip()
            self.pdd_store_home_combo.blockSignals(True)
            self.pdd_store_home_combo.clear()
            for name, *_ in rows:
                self.pdd_store_home_combo.addItem(name)
            if rows:
                idx = self.pdd_store_home_combo.findText(cur)
                self.pdd_store_home_combo.setCurrentIndex(idx if idx >= 0 else 0)
            self.pdd_store_home_combo.blockSignals(False)
        self.pdd_store_table.setRowCount(len(rows))
        for r, (name, prof, mt, sz, st) in enumerate(rows):
            self.pdd_store_table.setItem(r, 0, QTableWidgetItem(name))
            status_key = (st or {}).get("status", "unknown")
            status_text = {
                "ok": "✅ 正常",
                "dropped": "🔑 已掉线",
                "error": "⚠ 检查失败",
                "checking": "🔍 检查中",
                "missing": "⚠ 目录缺失",
                "unknown": "— 未检查",
            }.get(status_key, "— 未检查")
            st_item = QTableWidgetItem(status_text)
            st_item.setToolTip((st or {}).get("msg", "尚未检查登录态"))
            if status_key == "ok":
                st_item.setForeground(QColor("#047857"))
            elif status_key in ("dropped", "error", "missing"):
                st_item.setForeground(QColor("#DC2626"))
            elif status_key == "checking":
                st_item.setForeground(QColor("#4F46C8"))
            else:
                st_item.setForeground(QColor("#6B7280"))
            self.pdd_store_table.setItem(r, 1, st_item)
            self.pdd_store_table.setItem(r, 2, QTableWidgetItem(prof))
            self.pdd_store_table.setItem(r, 3, QTableWidgetItem(mt))
            self.pdd_store_table.setItem(r, 4, QTableWidgetItem(sz))
            # 操作单元格
            w = QWidget(); hl = QHBoxLayout(w); hl.setContentsMargins(2, 0, 2, 0); hl.setSpacing(4)
            b_ren = QPushButton("✏️"); b_ren.setToolTip("重命名(只改 stores.json,不动 profile 目录)")
            b_ren.setFixedSize(28, 24); b_ren.clicked.connect(
                lambda _, n=name: self._pdd_store_rename(n))
            b_open = QPushButton("📂"); b_open.setToolTip("打开 profile 目录")
            b_open.setFixedSize(28, 24); b_open.clicked.connect(
                lambda _, p=prof: QDesktopServices.openUrl(QUrl.fromLocalFile(str(root / p))))
            b_home = QPushButton("🏠"); b_home.setToolTip("进入店铺首页(使用该店铺登录态打开 PDD 商家后台首页)")
            b_home.setFixedSize(28, 24); b_home.clicked.connect(
                lambda _, n=name: self._open_in_chrome("https://mms.pinduoduo.com/home/?msfrom=mms_sidenav", n))
            b_chk = QPushButton("🔍"); b_chk.setToolTip("只检查这个店铺的登录态")
            b_chk.setFixedSize(28, 24); b_chk.clicked.connect(
                lambda _, n=name: self._pdd_store_check_one(n))
            b_del = QPushButton("🗑"); b_del.setToolTip("删除店铺(stores.json 移除 + 删除 profile 目录)")
            b_del.setFixedSize(28, 24); b_del.clicked.connect(
                lambda _, n=name: self._pdd_store_delete(n))
            hl.addWidget(b_ren); hl.addWidget(b_open); hl.addWidget(b_home); hl.addWidget(b_chk); hl.addWidget(b_del); hl.addStretch(1)
            self.pdd_store_table.setCellWidget(r, 5, w)
        self.pdd_store_status.setText(f"共 {len(rows)} 个已登录店铺")

    def _pdd_store_rename(self, old_name: str):
        from PyQt5.QtWidgets import QInputDialog
        new_name, ok = QInputDialog.getText(self, "重命名店铺",
                                            f"将「{old_name}」重命名为:", text=old_name)
        if not ok: return
        new_name = (new_name or "").strip()
        if not new_name or new_name == old_name: return
        stores = self._pdd_stores_read()
        if new_name in stores:
            QMessageBox.warning(self, "重命名", f"店铺名「{new_name}」已存在")
            return
        if old_name not in stores:
            QMessageBox.warning(self, "重命名", f"原店铺「{old_name}」不存在,刷新一下")
            return
        # 保持 OrderedDict 风格的位置
        new_stores = {}
        for k, v in stores.items():
            new_stores[new_name if k == old_name else k] = v
        self._pdd_stores_write(new_stores)
        self._pdd_store_reload_table()
        self.pdd_store_status.setText(f"已重命名: {old_name} → {new_name}")

    def _pdd_store_delete(self, name: str):
        import shutil
        stores = self._pdd_stores_read()
        prof = stores.get(name)
        if not prof:
            QMessageBox.warning(self, "删除", f"店铺「{name}」不在 stores.json 中"); return
        d = Path(r"D:/files/pdd_profiles") / prof
        sz = self._human_size(self._dir_size(d)) if d.exists() else "0 B"
        msg = (f"将删除店铺「{name}」:\n\n"
               f"• stores.json 中移除该条目\n"
               f"• 删除 profile 目录 {d}\n"
               f"  (占用 {sz},包含 cookie/登录态,删除后需重新扫码登录)\n\n"
               f"⚠ 删除前请关闭所有用此 profile 的 Chrome 窗口,否则会失败。\n"
               f"此操作不可恢复,确认?")
        if QMessageBox.question(self, "确认删除", msg,
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return
        # 先删目录,再改 stores.json(目录删失败就不动配置)
        if d.exists():
            try:
                shutil.rmtree(d)
            except Exception as e:
                QMessageBox.critical(self, "删除失败",
                                     f"删除 profile 目录失败: {e}\n\n"
                                     f"通常是 Chrome 仍在占用该 profile。\n"
                                     f"请关掉相关 Chrome 窗口或在任务管理器结束 chrome.exe 后再试。")
                return
        stores.pop(name, None)
        self._pdd_stores_write(stores)
        self._pdd_store_reload_table()
        self.pdd_store_status.setText(f"已删除: {name}")

    def _pdd_store_open_home_selected(self):
        combo = getattr(self, "pdd_store_home_combo", None)
        name = combo.currentText().strip() if combo is not None else ""
        if not name:
            QMessageBox.warning(self, "进入店铺首页", "请先选择店铺")
            return
        self._open_in_chrome("https://mms.pinduoduo.com/home/?msfrom=mms_sidenav", name)

    def _pdd_store_delete_selected(self):
        """顶部「🗑 删除选中店铺」:取表中当前选中行的店铺名,走现成的删除流程(带二次确认)。"""
        tbl = self.pdd_store_table
        r = tbl.currentRow()
        if r < 0:
            sel = tbl.selectionModel().selectedRows() if tbl.selectionModel() else []
            r = sel[0].row() if sel else -1
        if r < 0:
            QMessageBox.information(self, "删除店铺", "请先在下方表格里点选要删除的那一行店铺。")
            return
        item = tbl.item(r, 0)
        name = item.text().strip() if item else ""
        if not name:
            QMessageBox.warning(self, "删除店铺", "选中行没有读到店铺名,刷新后再试。")
            return
        self._pdd_store_delete(name)

    def _pdd_archive_retired_store_history(self):
        """人工确认后，把退店店铺的发布历史移出主历史并保存到归档文件。"""
        import json as _json
        hist_path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        if not hist_path.exists():
            QMessageBox.information(self, "归档退店历史", "未找到发布历史文件。")
            return
        try:
            raw = _json.loads(hist_path.read_text(encoding="utf-8-sig"))
        except Exception as e:
            QMessageBox.critical(self, "归档退店历史", f"读取发布历史失败:\n{e}")
            return
        if isinstance(raw, list):
            recs = list(raw)
            container = "list"
        elif isinstance(raw, dict):
            key = "records" if isinstance(raw.get("records"), list) else ("history" if isinstance(raw.get("history"), list) else "")
            if not key:
                QMessageBox.warning(self, "归档退店历史", "发布历史结构无法识别，未做任何修改。")
                return
            recs = list(raw.get(key) or [])
            container = key
        else:
            QMessageBox.warning(self, "归档退店历史", "发布历史结构无法识别，未做任何修改。")
            return

        active = self._pdd_active_store_names()
        if not active:
            QMessageBox.warning(self, "归档退店历史", "当前没有读到有效店铺列表。为避免误归档，已停止。")
            return
        retired = [r for r in recs if (r.get("store") or "").strip() and (r.get("store") or "").strip() not in active]
        if not retired:
            QMessageBox.information(self, "归档退店历史", "没有发现退店历史记录。")
            return

        groups = {}
        for r in retired:
            st = (r.get("store") or "").strip()
            groups[st] = groups.get(st, 0) + 1
        lines = [f"{name}: {count} 条" for name, count in sorted(groups.items())]
        msg = ("将把以下退店店铺的发布历史从主历史移到归档文件。\n\n"
               + "\n".join(lines[:12])
               + (f"\n...另有 {len(lines)-12} 个店铺" if len(lines) > 12 else "")
               + f"\n\n合计 {len(retired)} 条。\n"
               + "会先备份原始 pdd_publish_history.json，再写归档；不会操作 PDD 后台。\n\n确认归档？")
        if QMessageBox.question(self, "确认归档退店历史", msg,
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return

        ts = time.strftime("%Y%m%d_%H%M%S")
        backup_dir = hist_path.parent / "backups"
        archive_path = hist_path.parent / "pdd_publish_history.archived_stores.json"
        try:
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup_path = backup_dir / f"pdd_publish_history_before_archive_{ts}.json"
            backup_path.write_text(hist_path.read_text(encoding="utf-8-sig"), encoding="utf-8")

            archive_data = []
            if archive_path.exists():
                try:
                    old = _json.loads(archive_path.read_text(encoding="utf-8-sig"))
                    archive_data = old if isinstance(old, list) else []
                except Exception:
                    archive_data = []
            archive_data.append({
                "archived_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "stores": groups,
                "source": str(hist_path),
                "backup": str(backup_path),
                "records": retired,
            })
            archive_path.write_text(_json.dumps(archive_data, ensure_ascii=False, indent=2), encoding="utf-8")

            retired_ids = {id(r) for r in retired}
            remaining = [r for r in recs if id(r) not in retired_ids]
            if container == "list":
                out = remaining
            else:
                out = dict(raw)
                out[container] = remaining
            hist_path.write_text(_json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.critical(self, "归档失败", f"写入失败，已停止：\n{e}")
            return

        self._pdd_load_published()
        try:
            self._pdd_ap_reload_table()
        except Exception:
            pass
        try:
            self._pdd_video_reload_table()
        except Exception:
            pass
        try:
            self._pdd_genimg_reload_table()
        except Exception:
            pass
        QMessageBox.information(
            self, "归档完成",
            f"已归档 {len(retired)} 条退店历史。\n\n备份：{backup_path}\n归档：{archive_path}")

    def _pdd_delete_retired_store_history(self):
        """人工确认后，从主发布历史删除退店店铺记录。"""
        import json as _json
        hist_path = Path(r"D:/files/data/pdd/pdd_publish_history.json")
        if not hist_path.exists():
            QMessageBox.information(self, "删除退店历史", "未找到发布历史文件。")
            return
        try:
            raw = _json.loads(hist_path.read_text(encoding="utf-8-sig"))
        except Exception as e:
            QMessageBox.critical(self, "删除退店历史", f"读取发布历史失败:\n{e}")
            return
        if isinstance(raw, list):
            recs = list(raw)
            container = "list"
        elif isinstance(raw, dict):
            key = "records" if isinstance(raw.get("records"), list) else ("history" if isinstance(raw.get("history"), list) else "")
            if not key:
                QMessageBox.warning(self, "删除退店历史", "发布历史结构无法识别，未做任何修改。")
                return
            recs = list(raw.get(key) or [])
            container = key
        else:
            QMessageBox.warning(self, "删除退店历史", "发布历史结构无法识别，未做任何修改。")
            return

        active = self._pdd_active_store_names()
        if not active:
            QMessageBox.warning(self, "删除退店历史", "当前没有读到有效店铺列表。为避免误删，已停止。")
            return
        retired = [r for r in recs if (r.get("store") or "").strip() and (r.get("store") or "").strip() not in active]
        if not retired:
            QMessageBox.information(self, "删除退店历史", "没有发现退店历史记录。")
            return

        groups = {}
        for r in retired:
            st = (r.get("store") or "").strip()
            groups[st] = groups.get(st, 0) + 1
        lines = [f"{name}: {count} 条" for name, count in sorted(groups.items())]
        msg = ("将从主发布历史删除以下退店店铺记录。\n\n"
               + "\n".join(lines[:12])
               + (f"\n...另有 {len(lines)-12} 个店铺" if len(lines) > 12 else "")
               + f"\n\n合计 {len(retired)} 条。\n"
               + "不会操作 PDD 后台。确认后将直接从主发布历史删除。\n\n确认删除？")
        if QMessageBox.question(self, "确认删除退店历史", msg,
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return

        try:
            retired_ids = {id(r) for r in retired}
            remaining = [r for r in recs if id(r) not in retired_ids]
            if container == "list":
                out = remaining
            else:
                out = dict(raw)
                out[container] = remaining
            hist_path.write_text(_json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            QMessageBox.critical(self, "删除失败", f"写入失败，已停止：\n{e}")
            return

        self._pdd_load_published()
        try:
            self._pdd_ap_reload_table()
        except Exception:
            pass
        try:
            self._pdd_video_reload_table()
        except Exception:
            pass
        try:
            self._pdd_genimg_reload_table()
        except Exception:
            pass
        QMessageBox.information(
            self, "删除完成",
            f"已从主发布历史删除 {len(retired)} 条退店历史。")
    def _pdd_store_add_login(self):
        """启动 pdd_publish.py --new(纯登录,扫码后退出),log 落盘 + 完成后刷新表格。"""
        if getattr(self, "_pdd_store_login_proc", None) is not None:
            QMessageBox.information(self, "新增登录",
                                    "已有一个登录子进程在跑,请等其完成或关闭浏览器。")
            return
        import time as _t
        ts = _t.strftime("%Y%m%d_%H%M%S")
        log_path = Path(rf"D:/files/data/pdd/publish_logs/login_{ts}.log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._pdd_store_login_before = dict(self._pdd_stores_read())
        except Exception:
            self._pdd_store_login_before = {}
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        proc.setStandardOutputFile(str(log_path), QProcess.Truncate)
        args = ["-u", r"D:/files/pdd_publish.py", "--new"]
        proc.finished.connect(lambda code, _s: self._pdd_store_login_done(code, log_path))
        self._pdd_store_login_proc = proc
        # 让实时日志页能默认选中这个 log
        self._pdd_inspect_last_log = str(log_path)
        proc.start(sys.executable, args)
        self.pdd_store_status.setText(
            f"🟢 已启动登录子进程,请在弹出的 Chrome 窗口扫码 (log: {log_path.name})")
        QMessageBox.information(
            self, "新增登录",
            "已启动 Chrome,请在浏览器内扫码登录 PDD 店铺(最多等 300 秒)。\n\n"
            "登录成功后会自动检测店铺名并写入 stores.json,浏览器自动关闭。\n"
            "可切到「📋 实时日志」查看进度。"
        )

    def _pdd_store_login_done(self, code: int, log_path: Path):
        self._pdd_store_login_proc = None
        updated_names = []
        if code == 0:
            before = getattr(self, "_pdd_store_login_before", {}) or {}
            try:
                after = self._pdd_stores_read()
            except Exception:
                after = {}
            updated_names = [name for name, prof in after.items() if before.get(name) != prof]
            if updated_names:
                status_map = getattr(self, "_pdd_store_login_status", {}) or {}
                for name in updated_names:
                    status_map[name] = {"status": "ok", "msg": "刚扫码登录成功"}
                self._pdd_store_login_status = status_map
        self._pdd_store_reload_table()
        if code == 0:
            names = "、".join(updated_names)
            suffix = f"\n\n已自动标记为正常:{names}" if names else ""
            self.pdd_store_status.setText(f"✅ 登录子进程完成,已刷新店铺列表 (log: {log_path.name})")
            QMessageBox.information(
                self, "登录成功",
                "✅ 店铺扫码登录成功!\n\n已写入 stores.json 并刷新店铺列表,浏览器已自动关闭。" + suffix)
        else:
            self.pdd_store_status.setText(
                f"⚠ 登录子进程退出 code={code} (log: {log_path.name})")
            QMessageBox.warning(
                self, "登录未完成",
                f"⚠ 登录子进程退出 code={code}。\n\n"
                f"可能原因:未检测到店铺名 / 扫码超时 / 中途关了浏览器。\n"
                f"可到「📋 实时日志」查看:{log_path.name}")
        self._pdd_store_login_before = {}

    def _pdd_store_check_one(self, name: str):
        """只检查单个店铺登录态,不覆盖其它店铺状态。"""
        if getattr(self, "_pdd_store_check_thread", None) is not None:
            QMessageBox.information(self, "检查中", "登录态检查正在跑,请稍候")
            return
        stores = self._pdd_stores_read()
        if name not in stores:
            QMessageBox.warning(self, "检查登录", f"店铺「{name}」不在 stores.json 中")
            return
        try:
            import sys as _s
            _s.path.insert(0, r"D:/files")
            from pdd_takedown import find_chrome as _fc, PROFILE_DIR as _pr
            chrome_exe = _fc()
            profile_root = _pr
        except Exception as e:
            QMessageBox.critical(self, "环境异常", f"找 Chrome 失败:\n{e}")
            return
        status_map = getattr(self, "_pdd_store_login_status", {}) or {}
        status_map[name] = {"status": "checking", "msg": "正在检查"}
        self._pdd_store_login_status = status_map
        self._pdd_store_reload_table()
        self.pdd_store_status.setText(f"🔍 正在检查「{name}」...")
        t = CheckStoreLoginsThread({name: stores[name]}, chrome_exe, profile_root)
        self._pdd_store_check_thread = t

        def _on_progress(store_name, status, msg):
            status_map = getattr(self, "_pdd_store_login_status", {}) or {}
            status_map[store_name] = {"status": status, "msg": msg}
            self._pdd_store_login_status = status_map
            self._pdd_store_reload_table()

        def _on_done(results):
            self._pdd_store_check_thread = None
            status_map = getattr(self, "_pdd_store_login_status", {}) or {}
            for r in results:
                store_name = r.get("store") or name
                status_map[store_name] = {"status": r.get("status", "error"), "msg": r.get("msg", "")}
            self._pdd_store_login_status = status_map
            self._pdd_store_reload_table()
            r = results[0] if results else {"status": "error", "msg": "无检查结果"}
            icon = {"ok": "✅", "dropped": "🔑", "error": "⚠"}.get(r.get("status"), "?")
            self.pdd_store_status.setText(f"{icon} {name}: {r.get('msg', '')}")

        t.progress.connect(_on_progress)
        t.finished_all.connect(_on_done)
        t.start()
    def _pdd_store_check_logins(self):
        """后台 headless 检查所有店铺登录态。"""
        if getattr(self, "_pdd_store_check_thread", None) is not None:
            QMessageBox.information(self, "检查中", "登录态检查正在跑,请稍候")
            return
        try:
            stores = self._pdd_stores_read()
        except Exception as e:
            QMessageBox.critical(self, "读取失败", f"读 stores.json 失败:\n{e}")
            return
        if not stores:
            QMessageBox.information(self, "无店铺", "stores.json 里没有店铺。先扫码登录一个。")
            return
        # 拿 chrome 路径(复用 pdd_takedown 的 find_chrome)
        try:
            import sys as _s
            _s.path.insert(0, r"D:/files")
            from pdd_takedown import find_chrome as _fc, PROFILE_DIR as _pr
            chrome_exe = _fc()
            profile_root = _pr
        except Exception as e:
            QMessageBox.critical(self, "环境异常", f"找 Chrome 失败:\n{e}")
            return
        self._pdd_store_login_status = {name: {"status": "checking", "msg": "等待检查"}
                                        for name in stores.keys()}
        self._pdd_store_reload_table()
        self.pdd_store_status.setText(f"🔍 检查中... 共 {len(stores)} 家")
        # 启动线程。批量检查保持静默:只更新表格状态和底部状态栏,不弹进度窗口。
        t = CheckStoreLoginsThread(stores, chrome_exe, profile_root)
        self._pdd_store_check_thread = t
        def _on_progress(name, status, msg):
            icon = {"ok": "✅", "dropped": "🔑", "error": "⚠"}.get(status, "?")
            self._pdd_store_login_status[name] = {"status": status, "msg": msg}
            self._pdd_store_reload_table()
            self.pdd_store_status.setText(f"{icon} {name}: {msg}")

        def _on_done(results):
            self._pdd_store_check_thread = None
            self._pdd_store_login_status = {
                r.get("store", ""): {"status": r.get("status", "error"), "msg": r.get("msg", "")}
                for r in results if r.get("store")}
            self._pdd_store_reload_table()
            ok_n = sum(1 for r in results if r["status"] == "ok")
            dropped = [r["store"] for r in results if r["status"] == "dropped"]
            err = [r["store"] for r in results if r["status"] == "error"]
            summary = f"完成。OK {ok_n} / 掉线 {len(dropped)} / 异常 {len(err)}"
            if dropped:
                summary += f"\n\n🔑 需要重新扫码:\n  • " + "\n  • ".join(dropped)
            if err:
                summary += f"\n\n⚠ 检查异常:\n  • " + "\n  • ".join(err)
            self.pdd_store_status.setText(
                f"🔍 检查完成 OK={ok_n} 掉线={len(dropped)} 异常={len(err)}")
            if dropped or err:
                self.status.showMessage(summary.replace("\n", "  "), 12000)

        t.progress.connect(_on_progress)
        t.finished_all.connect(_on_done)
        t.start()

    def _task_center_init(self):
        if not hasattr(self, "_task_center_items"):
            self._task_center_items = []
            self._task_center_seq = 0
            self._task_center_running = None

    def _task_center_is_queued_run(self) -> bool:
        self._task_center_init()
        item = getattr(self, "_task_center_running", None)
        return bool(item and item.get("starter") is not None)

    def _task_center_has_waiting(self) -> bool:
        self._task_center_init()
        return any(x.get("status") == "等待中" for x in self._task_center_items)

    def _task_center_should_defer_dialog(self) -> bool:
        return self._task_center_is_queued_run() or self._task_center_has_waiting()

    def _task_center_update_current_detail(self, detail=""):
        self._task_center_init()
        item = getattr(self, "_task_center_running", None)
        if item and detail:
            item["detail"] = str(detail)
            self._task_center_refresh()

    def _task_center_busy(self):
        def _proc_running(name):
            p = getattr(self, name, None)
            try:
                return bool(p) and p.state() != QProcess.NotRunning
            except Exception:
                return False
        checks = [
            ("一键跑品", getattr(self, "_oc_running", False)),
            ("待发布队列", getattr(self, "_pdd_qrun_active", False)),
            ("生图换图", getattr(self, "_pdd_genimg_thread", None) is not None),
            ("视频任务", getattr(self, "_pdd_video_thread", None) is not None),
            ("自动推广", self._pdd_ap_busy() if hasattr(self, "_pdd_ap_busy") else False),
            ("店铺监控下架", _proc_running("_pdd_zs_proc")),
            ("已发布批量操作", _proc_running("_pdd_takedown_proc") or _proc_running("_pdd_sync_proc") or _proc_running("_pdd_del_proc") or _proc_running("_pdd_restore_proc")),
            ("店铺登录", _proc_running("_pdd_store_login_proc")),
        ]
        for label, flag in checks:
            if flag:
                return True, label
        return False, ""

    def _task_center_enqueue(self, title, starter, detail=""):
        self._task_center_init()
        self._task_center_seq += 1
        item = {
            "id": self._task_center_seq,
            "title": title,
            "detail": detail,
            "status": "等待中",
            "created": time.strftime("%H:%M:%S"),
            "started": "",
            "ended": "",
            "starter": starter,
        }
        self._task_center_items.append(item)
        self._task_center_refresh()
        self.status.showMessage(f"已加入任务中心: {title}")
        QTimer.singleShot(100, self._task_center_try_start_next)
        return item

    def _task_center_register_running(self, title, detail=""):
        self._task_center_init()
        if getattr(self, "_task_center_running", None):
            return self._task_center_running
        self._task_center_seq += 1
        item = {
            "id": self._task_center_seq,
            "title": title,
            "detail": detail,
            "status": "运行中",
            "created": time.strftime("%H:%M:%S"),
            "started": time.strftime("%H:%M:%S"),
            "ended": "",
            "starter": None,
        }
        self._task_center_running = item
        self._task_center_items.append(item)
        self._task_center_refresh()
        return item

    def _task_center_try_start_next(self):
        self._task_center_init()
        if getattr(self, "_task_center_running", None):
            return
        busy, _name = self._task_center_busy()
        if busy:
            return
        item = next((x for x in self._task_center_items if x.get("status") == "等待中"), None)
        if not item:
            self._task_center_refresh()
            return
        item["status"] = "运行中"
        item["started"] = time.strftime("%H:%M:%S")
        self._task_center_running = item
        self._task_center_refresh()
        try:
            item["starter"]()
        except Exception as e:
            item["status"] = "失败"
            item["detail"] = f"{item.get('detail','')} {e!r}".strip()
            item["ended"] = time.strftime("%H:%M:%S")
            self._task_center_running = None
            self._task_center_refresh()
            QTimer.singleShot(300, self._task_center_try_start_next)

    def _task_center_finish_current(self, ok=True, detail=""):
        self._task_center_init()
        item = getattr(self, "_task_center_running", None)
        if item:
            item["status"] = "已完成" if ok else "失败"
            item["ended"] = time.strftime("%H:%M:%S")
            if detail:
                item["detail"] = detail
            self._task_center_running = None
            self._task_center_refresh()
        QTimer.singleShot(500, self._task_center_try_start_next)

    def _task_center_cancel_selected(self):
        self._task_center_init()
        tbl = getattr(self, "pdd_task_table", None)
        if tbl is None:
            return
        rows = sorted({i.row() for i in tbl.selectedIndexes()}, reverse=True)
        ids = []
        for r in rows:
            it = tbl.item(r, 0)
            if it:
                try: ids.append(int(it.text()))
                except Exception: pass
        for item in self._task_center_items:
            if item.get("id") in ids and item.get("status") == "等待中":
                item["status"] = "已取消"
                item["ended"] = time.strftime("%H:%M:%S")
        self._task_center_refresh()

    def _task_center_clear_done(self):
        self._task_center_init()
        self._task_center_items = [x for x in self._task_center_items if x.get("status") in ("等待中", "运行中")]
        self._task_center_refresh()

    def _task_center_refresh(self):
        self._task_center_init()
        tbl = getattr(self, "pdd_task_table", None)
        if tbl is None:
            return
        items = list(self._task_center_items)
        tbl.setRowCount(len(items))
        for r, item in enumerate(items):
            vals = [str(item.get("id", "")), item.get("status", ""), item.get("title", ""),
                    item.get("detail", ""), item.get("created", ""), item.get("started", ""), item.get("ended", "")]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if c in (0, 1, 4, 5, 6):
                    it.setTextAlignment(Qt.AlignCenter)
                if c == 1:
                    color = {"等待中": "#F59E0B", "运行中": "#2563EB", "已完成": "#10B981", "失败": "#DC2626", "已取消": "#6B7280"}.get(v, "#111827")
                    it.setForeground(QColor(color))
                tbl.setItem(r, c, it)
        if hasattr(self, "pdd_task_status"):
            waiting = sum(1 for x in items if x.get("status") == "等待中")
            running = sum(1 for x in items if x.get("status") == "运行中")
            self.pdd_task_status.setText(f"运行中 {running} · 等待中 {waiting} · 共 {len(items)}")

    def _build_pdd_page_tasks(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(8)
        title = QLabel("🧭 任务中心")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        bar = QHBoxLayout(); bar.setSpacing(8)
        btn_refresh = QPushButton("🔄 刷新")
        btn_refresh.clicked.connect(self._task_center_refresh)
        bar.addWidget(btn_refresh)
        btn_cancel = QPushButton("取消等待任务")
        btn_cancel.setToolTip("只能取消还没开始的等待任务，运行中的任务请到对应页面停止")
        btn_cancel.clicked.connect(self._task_center_cancel_selected)
        bar.addWidget(btn_cancel)
        btn_clear = QPushButton("清理已完成")
        btn_clear.clicked.connect(self._task_center_clear_done)
        bar.addWidget(btn_clear)
        self.pdd_task_show_browser = QCheckBox("显示浏览器")
        self.pdd_task_show_browser.setToolTip("勾上:任务中心后续启动的发布/视频/换图/推广浏览器显示在屏幕上;不勾=屏幕外静默运行")
        self.pdd_task_show_browser.setChecked(self._pdd_task_center_show_browser_on())
        self.pdd_task_show_browser.toggled.connect(self._pdd_set_task_center_show_browser)
        bar.addWidget(self.pdd_task_show_browser)
        bar.addStretch(1)
        self.pdd_task_status = QLabel("")
        self.pdd_task_status.setStyleSheet("color:#6B7280;font-size:11px;")
        bar.addWidget(self.pdd_task_status)
        lay.addLayout(bar)
        self.pdd_task_table = QTableWidget(0, 7)
        self.pdd_task_table.setHorizontalHeaderLabels(["ID", "状态", "任务", "说明", "创建", "开始", "结束"])
        h = self.pdd_task_table.horizontalHeader()
        for c in range(7):
            h.setSectionResizeMode(c, QHeaderView.Fixed)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        for c, w in {0: 54, 1: 86, 2: 170, 4: 82, 5: 82, 6: 82}.items():
            self.pdd_task_table.setColumnWidth(c, w)
        self.pdd_task_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pdd_task_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        lay.addWidget(self.pdd_task_table, 1)
        self._task_center_refresh()
        return page
    def _build_pdd_page_log(self) -> QWidget:
        """实时日志页:扫 data/pdd/publish_logs/*.log,选中一个 tail。
        QFileSystemWatcher 监听 + 1s QTimer 兜底(Windows 上 append 有时不触发 watcher)。
        """
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(6)

        title = QLabel("📋 实时日志")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)

        bar = QHBoxLayout(); bar.setSpacing(6)
        self.pdd_log_combo = QComboBox()
        self.pdd_log_combo.setMinimumWidth(360)
        self.pdd_log_combo.currentIndexChanged.connect(self._pdd_log_switch_file)
        bar.addWidget(self.pdd_log_combo, 1)
        btn_refresh = QPushButton("🔄 刷新文件列表"); btn_refresh.clicked.connect(self._pdd_log_refresh_files)
        bar.addWidget(btn_refresh)
        self.pdd_log_follow_btn = QPushButton("⏸ 暂停跟随")
        self.pdd_log_follow_btn.setCheckable(True)
        self.pdd_log_follow_btn.toggled.connect(self._pdd_log_toggle_follow)
        bar.addWidget(self.pdd_log_follow_btn)
        btn_clear = QPushButton("🗑 清空显示"); btn_clear.clicked.connect(lambda: self.pdd_log_view.clear())
        bar.addWidget(btn_clear)
        btn_open = QPushButton("📂 打开目录"); btn_open.clicked.connect(self._pdd_log_open_dir)
        bar.addWidget(btn_open)
        lay.addLayout(bar)

        self.pdd_log_view = QPlainTextEdit()
        self.pdd_log_view.setReadOnly(True)
        self.pdd_log_view.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.pdd_log_view.setStyleSheet(
            "background:#111827;color:#E5E7EB;font-family:Consolas,'Courier New',monospace;"
            "font-size:11px;border:1px solid #374151;border-radius:4px;")
        lay.addWidget(self.pdd_log_view, 1)

        self.pdd_log_status = QLabel("(未选择文件)")
        self.pdd_log_status.setStyleSheet("color:#9CA3AF;font-size:11px;")
        lay.addWidget(self.pdd_log_status)

        # 状态
        self._pdd_log_dir = Path(r"D:/files/data/pdd/publish_logs")
        self._pdd_log_dir.mkdir(parents=True, exist_ok=True)
        self._pdd_log_current: str = ""   # 当前文件路径
        self._pdd_log_offset: int = 0     # 已读字节
        self._pdd_log_follow: bool = True

        # watcher + 兜底 timer
        self._pdd_log_watcher = QFileSystemWatcher(self)
        self._pdd_log_watcher.fileChanged.connect(lambda _p: self._pdd_log_tail_incr())
        self._pdd_log_timer = QTimer(self)
        self._pdd_log_timer.setInterval(1000)
        self._pdd_log_timer.timeout.connect(self._pdd_log_tail_incr)
        self._pdd_log_timer.start()

        # 初次填充
        self._pdd_log_refresh_files()
        return page

    def _pdd_log_refresh_files(self):
        try:
            files = sorted(self._pdd_log_dir.glob("*.log"),
                           key=lambda p: p.stat().st_mtime, reverse=True)
        except Exception:
            files = []
        prev = self._pdd_log_current
        self.pdd_log_combo.blockSignals(True)
        self.pdd_log_combo.clear()
        for f in files[:200]:
            import time as _t
            mt = _t.strftime("%m-%d %H:%M:%S", _t.localtime(f.stat().st_mtime))
            sz = f.stat().st_size
            label = f"{mt}  {f.name}  ({sz//1024} KB)"
            self.pdd_log_combo.addItem(label, str(f))
        self.pdd_log_combo.blockSignals(False)
        # 恢复选中:优先 prev,其次 self._pdd_inspect_last_log,其次第一项
        target = prev or getattr(self, "_pdd_inspect_last_log", "") or (
            str(files[0]) if files else "")
        if target:
            for i in range(self.pdd_log_combo.count()):
                if self.pdd_log_combo.itemData(i) == target:
                    self.pdd_log_combo.setCurrentIndex(i)
                    return
        if self.pdd_log_combo.count() > 0:
            self.pdd_log_combo.setCurrentIndex(0)

    def _pdd_log_switch_file(self, _idx: int):
        path = self.pdd_log_combo.currentData()
        if not path:
            return
        # 切换:重置 watcher + offset,读末尾 N 行
        if self._pdd_log_current and self._pdd_log_current in self._pdd_log_watcher.files():
            self._pdd_log_watcher.removePath(self._pdd_log_current)
        self._pdd_log_current = path
        self._pdd_log_offset = 0
        self.pdd_log_view.clear()
        try:
            p = Path(path)
            data = p.read_bytes()
            # 大文件只取末尾 60KB
            if len(data) > 60 * 1024:
                data = data[-60 * 1024:]
                self.pdd_log_view.appendPlainText(f"--- 文件较大,只显示末尾 60KB ---")
            text = data.decode("utf-8", errors="replace")
            self.pdd_log_view.appendPlainText(text)
            self._pdd_log_offset = p.stat().st_size
            if self._pdd_log_follow:
                sb = self.pdd_log_view.verticalScrollBar()
                sb.setValue(sb.maximum())
            self._pdd_log_watcher.addPath(path)
            self.pdd_log_status.setText(f"已加载 {p.name}  ({self._pdd_log_offset} 字节)")
        except Exception as e:
            self.pdd_log_status.setText(f"读取失败: {e}")

    def _pdd_log_tail_incr(self):
        path = self._pdd_log_current
        if not path:
            return
        try:
            p = Path(path)
            if not p.exists():
                return
            size = p.stat().st_size
            if size < self._pdd_log_offset:
                # 文件被截断/轮转,重读末尾
                self._pdd_log_offset = 0
                self.pdd_log_view.clear()
            if size == self._pdd_log_offset:
                return
            with open(p, "rb") as f:
                f.seek(self._pdd_log_offset)
                chunk = f.read()
            self._pdd_log_offset = size
            text = chunk.decode("utf-8", errors="replace")
            # appendPlainText 会自动换行,逐行 append 避免空行
            for line in text.splitlines():
                self.pdd_log_view.appendPlainText(line)
            if self._pdd_log_follow:
                sb = self.pdd_log_view.verticalScrollBar()
                sb.setValue(sb.maximum())
            self.pdd_log_status.setText(f"{p.name}  ({size} 字节)")
            # watcher 在某些 OS 上 fileChanged 后会停止跟踪 → 重新 add
            if path not in self._pdd_log_watcher.files():
                self._pdd_log_watcher.addPath(path)
        except Exception as e:
            self.pdd_log_status.setText(f"tail 异常: {e}")

    def _pdd_log_toggle_follow(self, checked: bool):
        self._pdd_log_follow = not checked
        self.pdd_log_follow_btn.setText("▶ 继续跟随" if checked else "⏸ 暂停跟随")

    def _pdd_log_open_dir(self):
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._pdd_log_dir)))
        except Exception:
            pass

    def _build_pdd_page_config(self) -> QWidget:
        return self._build_pdd_placeholder("⚙ 配置",
            "全局配置占位(运费/毛利率/单买加价已在定价规则中维护,这里暂无独立配置)")

    def _build_pdd_placeholder(self, title: str, desc: str) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(30, 30, 30, 30)
        t = QLabel(title)
        t.setStyleSheet("font-size:18px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(t)
        d = QLabel(desc)
        d.setStyleSheet("color:#9CA3AF;font-size:12px;padding:20px 0;")
        d.setWordWrap(True)
        d.setAlignment(Qt.AlignTop)
        lay.addWidget(d, 1)
        return page

    def _apply_styles(self):
        self.setStyleSheet("""
            QMainWindow,QWidget{background:#F3F4F6;}
            QGroupBox{font-weight:bold;font-size:11px;color:#6B7280;
                border:1px solid #E5E7EB;border-radius:6px;
                margin-top:8px;padding-top:6px;}
            QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 4px;}
            QLabel{color:#374151;}
            QComboBox,QSpinBox,QTimeEdit{
                border:1px solid #D1D5DB;border-radius:5px;
                padding:3px 6px;background:white;color:#374151;min-height:24px;}
            QComboBox:focus,QSpinBox:focus,QTimeEdit:focus{border-color:#4F46C8;}
            QComboBox::drop-down{border:none;width:18px;}
            QCheckBox{color:#374151;spacing:5px;}
            QCheckBox::indicator{width:14px;height:14px;border-radius:3px;
                border:1.5px solid #D1D5DB;background:white;}
            QCheckBox::indicator:checked{background:#4F46C8;border-color:#4F46C8;}
            QHeaderView::section{background:#4F46C8;color:white;font-weight:bold;
                padding:6px 8px;border:none;font-size:11px;}
            QTableWidget{gridline-color:#F3F4F6;border:1px solid #E5E7EB;
                background:white;alternate-background-color:#F9FAFB;}
            QTableWidget::item{padding:4px 8px;color:#374151;}
            QTableWidget::item:selected{background:#EEF2FF;color:#4F46C8;}
            QPlainTextEdit{background:#0F172A;color:#94A3B8;
                border:none;font-family:Consolas,monospace;font-size:11px;}
            QStatusBar{background:#F9FAFB;color:#6B7280;font-size:11px;}
            QSplitter::handle{background:#E5E7EB;}
            QScrollBar:vertical{width:5px;background:#F3F4F6;}
            QScrollBar::handle:vertical{background:#D1D5DB;border-radius:3px;}
        """)

    # ── 侧边栏 ───────────────────────────────────────────────────────────
    def _build_sidebar(self):
        panel = QWidget()
        panel.setFixedWidth(222)
        panel.setStyleSheet("QWidget{background:white;border-right:1px solid #E5E7EB;}")
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(13, 14, 13, 12)
        lay.setSpacing(8)

        title = QLabel("⚡ 选品助手")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#4F46C8;")
        lay.addWidget(title)
        lay.addWidget(self._hline())

        # ── 目标类目 ──
        cat_box = QGroupBox("目标类目")
        cl = QVBoxLayout(cat_box)
        cl.setSpacing(5)

        # 全选 / 全不选 / 复用上次
        sel_row = QHBoxLayout()
        sel_row.setSpacing(4)
        for txt, ca in [("全选", True), ("全不选", False)]:
            b = QPushButton(txt)
            b.setFixedHeight(20)
            b.setStyleSheet(
                "QPushButton{background:#F3F4F6;border-radius:3px;font-size:10px;"
                "border:1px solid #D1D5DB;padding:0 8px;color:#374151;}"
                "QPushButton:hover{background:#E5E7EB;}")
            b.clicked.connect(lambda _, c=ca: self._set_all_cats(c))
            sel_row.addWidget(b)

        self.btn_restore_cats = QPushButton("↩ 复用上次")
        self.btn_restore_cats.setFixedHeight(20)
        self.btn_restore_cats.setEnabled(CAT_SEL_PATH.exists())
        self.btn_restore_cats.setToolTip("恢复上次抓取时勾选的类目")
        self.btn_restore_cats.setStyleSheet(
            "QPushButton{background:#EEF2FF;border-radius:3px;font-size:10px;"
            "border:1px solid #C7D2FE;padding:0 8px;color:#4F46C8;}"
            "QPushButton:hover{background:#E0E7FF;}"
            "QPushButton:disabled{background:#F3F4F6;color:#9CA3AF;border-color:#E5E7EB;}")
        self.btn_restore_cats.clicked.connect(self._restore_last_cat_selection)
        sel_row.addWidget(self.btn_restore_cats)

        sel_row.addStretch()
        cl.addLayout(sel_row)

        # 类目勾选树
        self.cat_tree = QTreeWidget()
        self.cat_tree.setHeaderHidden(True)
        self.cat_tree.setColumnCount(1)
        self.cat_tree.setMinimumHeight(150)
        self.cat_tree.setMaximumHeight(230)
        self.cat_tree.setStyleSheet("""
            QTreeWidget {
                border: 1px solid #E5E7EB; border-radius: 5px;
                background: white; font-size: 11px; outline: none;
            }
            QTreeWidget::item { padding: 2px 2px; }
            QTreeWidget::item:hover { background: #EEF2FF; }
            QTreeWidget::item:selected { background: #EEF2FF; color: #4F46C8; }
            QTreeWidget::indicator {
                width: 13px; height: 13px; border-radius: 3px;
                border: 1.5px solid #C7D2FE; background: white;
            }
            QTreeWidget::indicator:checked {
                background: #4F46C8; border-color: #4F46C8;
            }
            QTreeWidget::indicator:indeterminate {
                background: #A5B4FC; border-color: #4F46C8;
            }
        """)
        cl.addWidget(self.cat_tree)

        self.combo_count_lbl = QLabel("请先扫描类目")
        self.combo_count_lbl.setStyleSheet("color:#9CA3AF;font-size:11px;padding-top:2px;")
        cl.addWidget(self.combo_count_lbl)

        self.btn_scan = QPushButton("🔍  扫描 / 更新类目")
        self.btn_scan.setFixedHeight(28)
        self.btn_scan.setStyleSheet("""
            QPushButton{background:#EEF2FF;color:#4F46C8;border-radius:5px;
                font-size:11px;border:1px solid #C7D2FE;}
            QPushButton:hover{background:#E0E7FF;}
            QPushButton:disabled{background:#F3F4F6;color:#9CA3AF;border-color:#E5E7EB;}
        """)
        self.btn_scan.clicked.connect(self._scan_categories)
        cl.addWidget(self.btn_scan)
        lay.addWidget(cat_box)

        # ── 统计周期 ──
        period_box = QGroupBox("统计周期")
        pl = QHBoxLayout(period_box)
        pl.setSpacing(4)
        self.period_combo = QComboBox()
        self.period_combo.addItems(["今天", "昨天", "近7天", "近14天", "近30天"])
        self.period_combo.setCurrentText("今天")
        pl.addWidget(self.period_combo)
        lay.addWidget(period_box)

        # ── 首次上架筛选 ──
        date_box = QGroupBox("首次上架筛选")
        dl = QVBoxLayout(date_box)
        dl.setSpacing(6)
        for row_lbl, attr, widget in [
            ("年份", "year_spin",  None),
            ("月份", "month_combo", None),
        ]:
            row = QHBoxLayout()
            lb = QLabel(row_lbl)
            lb.setFixedWidth(28)
            row.addWidget(lb)
            if row_lbl == "年份":
                self.year_spin = QSpinBox()
                self.year_spin.setRange(2020, 2030)
                self.year_spin.setValue(2026)
                row.addWidget(self.year_spin)
            else:
                self.month_combo = QComboBox()
                self.month_combo.addItem("全年", 0)
                for m in range(1, 13):
                    self.month_combo.addItem(f"{m}月", m)
                self.month_combo.setCurrentIndex(5)
                row.addWidget(self.month_combo)
            dl.addLayout(row)
        lay.addWidget(date_box)

        # ── 定时采集 ──
        sched_box = QGroupBox("⏰ 定时采集")
        sl = QVBoxLayout(sched_box)
        sl.setSpacing(6)
        self.cb_schedule = QCheckBox("启用定时采集")
        sl.addWidget(self.cb_schedule)

        t_row = QHBoxLayout()
        tl = QLabel("时间")
        tl.setFixedWidth(28)
        self.sched_time = QTimeEdit()
        self.sched_time.setDisplayFormat("HH:mm")
        self.sched_time.setTime(QTime(9, 0))
        t_row.addWidget(tl)
        t_row.addWidget(self.sched_time)
        sl.addLayout(t_row)

        self.sched_next_lbl = QLabel("下次运行: --")
        self.sched_next_lbl.setStyleSheet("color:#9CA3AF;font-size:10px;")
        sl.addWidget(self.sched_next_lbl)
        lay.addWidget(sched_box)

        lay.addStretch()
        lay.addWidget(self._hline())

        # ── 开始 / 停止 ──
        self.btn_start = QPushButton("▶  开始抓取")
        self.btn_start.setFixedHeight(38)
        self.btn_start.setStyleSheet("""
            QPushButton{background:#4F46C8;color:white;border-radius:7px;
                font-weight:bold;font-size:13px;}
            QPushButton:hover{background:#4338CA;}
            QPushButton:disabled{background:#A5B4FC;}
        """)
        self.btn_start.clicked.connect(self.start_scrape)
        lay.addWidget(self.btn_start)

        self.btn_stop = QPushButton("⏹  停止")
        self.btn_stop.setFixedHeight(34)
        self.btn_stop.setEnabled(False)
        self.btn_stop.setStyleSheet("""
            QPushButton{background:#EF4444;color:white;border-radius:7px;
                font-weight:bold;font-size:12px;}
            QPushButton:hover{background:#DC2626;}
            QPushButton:disabled{background:#FCA5A5;}
        """)
        self.btn_stop.clicked.connect(self.stop_scrape)
        lay.addWidget(self.btn_stop)

        # 联动信号
        self.cat_tree.itemChanged.connect(self._on_cat_tree_item_changed)
        self.cb_schedule.stateChanged.connect(self._on_schedule_changed)
        self.sched_time.timeChanged.connect(self._on_schedule_changed)

        return panel

    # ── 类目树交互 ───────────────────────────────────────────────────────
    def _on_cat_tree_item_changed(self, item, col):
        if col != 0:
            return
        self.cat_tree.blockSignals(True)
        state = item.checkState(0)

        # 向下级联：选中/取消选中所有子孙
        if state in (Qt.Checked, Qt.Unchecked):
            def _set_down(node, s):
                for i in range(node.childCount()):
                    c = node.child(i)
                    c.setCheckState(0, s)
                    _set_down(c, s)
            _set_down(item, state)

        # 向上更新父节点（全选/全不选/半选）
        def _update_up(node):
            p = node.parent()
            if p is None:
                return
            n = p.childCount()
            checked = sum(1 for i in range(n) if p.child(i).checkState(0) == Qt.Checked)
            partial = sum(1 for i in range(n) if p.child(i).checkState(0) == Qt.PartiallyChecked)
            if checked == n:
                p.setCheckState(0, Qt.Checked)
            elif checked == 0 and partial == 0:
                p.setCheckState(0, Qt.Unchecked)
            else:
                p.setCheckState(0, Qt.PartiallyChecked)
            _update_up(p)
        _update_up(item)

        self.cat_tree.blockSignals(False)
        self._refresh_combo_count()

    def _set_all_cats(self, check_all: bool):
        """全选 / 全不选所有类目"""
        state = Qt.Checked if check_all else Qt.Unchecked
        self.cat_tree.blockSignals(True)
        for i in range(self.cat_tree.topLevelItemCount()):
            l1 = self.cat_tree.topLevelItem(i)
            l1.setCheckState(0, state)
            for j in range(l1.childCount()):
                l2 = l1.child(j)
                l2.setCheckState(0, state)
                for k in range(l2.childCount()):
                    l2.child(k).setCheckState(0, state)
        self.cat_tree.blockSignals(False)
        self._refresh_combo_count()

    def _restore_last_cat_selection(self):
        """从文件恢复上次的类目勾选状态"""
        if not CAT_SEL_PATH.exists():
            return
        try:
            with open(CAT_SEL_PATH, encoding="utf-8") as f:
                saved: list = json.load(f)
        except Exception as e:
            QMessageBox.warning(self, "恢复失败", f"读取上次选择失败：{e}")
            return

        if not saved:
            return

        saved_set = set(saved)   # {"美妆>彩妆>口红", ...}

        # 先全不选，再按保存列表勾选
        self.cat_tree.blockSignals(True)
        for i in range(self.cat_tree.topLevelItemCount()):
            l1_item = self.cat_tree.topLevelItem(i)
            l1 = l1_item.text(0)
            l1_item.setCheckState(0, Qt.Unchecked)
            for j in range(l1_item.childCount()):
                l2_item = l1_item.child(j)
                l2 = l2_item.text(0)
                l2_item.setCheckState(0, Qt.Unchecked)
                for k in range(l2_item.childCount()):
                    l3_item = l2_item.child(k)
                    combo = f"{l1}>{l2}>{l3_item.text(0)}"
                    l3_item.setCheckState(
                        0, Qt.Checked if combo in saved_set else Qt.Unchecked)

        # 从下往上更新父节点的半选/全选状态
        for i in range(self.cat_tree.topLevelItemCount()):
            l1_item = self.cat_tree.topLevelItem(i)
            for j in range(l1_item.childCount()):
                l2_item = l1_item.child(j)
                n = l2_item.childCount()
                checked = sum(
                    1 for k in range(n)
                    if l2_item.child(k).checkState(0) == Qt.Checked)
                if checked == n:
                    l2_item.setCheckState(0, Qt.Checked)
                elif checked == 0:
                    l2_item.setCheckState(0, Qt.Unchecked)
                else:
                    l2_item.setCheckState(0, Qt.PartiallyChecked)

            n2 = l1_item.childCount()
            c2 = sum(1 for j in range(n2)
                     if l1_item.child(j).checkState(0) == Qt.Checked)
            p2 = sum(1 for j in range(n2)
                     if l1_item.child(j).checkState(0) == Qt.PartiallyChecked)
            if c2 == n2:
                l1_item.setCheckState(0, Qt.Checked)
            elif c2 == 0 and p2 == 0:
                l1_item.setCheckState(0, Qt.Unchecked)
            else:
                l1_item.setCheckState(0, Qt.PartiallyChecked)

        self.cat_tree.blockSignals(False)
        self._refresh_combo_count()

        n = len(saved_set)
        self.status.showMessage(f"已恢复上次选择：{n} 个三级类目")

    def _refresh_combo_count(self):
        combos = self._get_selected_combos()
        n = len(combos)
        if not self._tree_data:
            self.combo_count_lbl.setText("请先扫描类目")
            self.combo_count_lbl.setStyleSheet("color:#9CA3AF;font-size:11px;")
        elif n == 0:
            self.combo_count_lbl.setText("⚠ 未选择任何类目")
            self.combo_count_lbl.setStyleSheet("color:#EF4444;font-size:11px;")
        else:
            self.combo_count_lbl.setText(f"将抓取 {n} 个三级类目")
            self.combo_count_lbl.setStyleSheet(
                "color:#4F46C8;font-size:11px;font-weight:bold;")

    def _get_selected_combos(self):
        """读取树中所有勾选的 L3 节点，返回 'L1>L2>L3' 列表"""
        if not self._tree_data or not hasattr(self, "cat_tree"):
            return []
        combos = []
        for i in range(self.cat_tree.topLevelItemCount()):
            l1_item = self.cat_tree.topLevelItem(i)
            l1 = l1_item.text(0)
            for j in range(l1_item.childCount()):
                l2_item = l1_item.child(j)
                l2 = l2_item.text(0)
                for k in range(l2_item.childCount()):
                    l3_item = l2_item.child(k)
                    if l3_item.checkState(0) == Qt.Checked:
                        combos.append(f"{l1}>{l2}>{l3_item.text(0)}")
        return combos

    # ── 类目扫描 ─────────────────────────────────────────────────────────
    def _scan_categories(self):
        self.log.clear()
        self.progress.setVisible(True)
        self.btn_scan.setEnabled(False)
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.combo_count_lbl.setText("扫描中…")
        self.combo_count_lbl.setStyleSheet("color:#F59E0B;font-size:11px;")
        self.status.showMessage("正在扫描类目树，请稍候…")
        self.thread = DiscoverThread()
        self.thread.log_signal.connect(self._on_log)
        self.thread.done_signal.connect(self._on_discover_done)
        self.thread.error_signal.connect(self._on_discover_error)
        self.thread.start()

    def _on_discover_done(self, tree_data):
        self._tree_data = tree_data
        self._rebuild_l1()
        self._set_idle("类目扫描完成")
        self.log.appendHtml('<span style="color:#4ADE80">✅ 类目树已更新，可开始抓取</span>')

    def _on_discover_error(self, msg):
        self.log.appendHtml(f'<span style="color:#F87171">[错误] {_esc(msg)}</span>')
        self._set_idle("扫描失败，请查看日志")
        self._refresh_combo_count()

    def _try_load_category_tree(self):
        if TREE_PATH.exists():
            try:
                with open(TREE_PATH, encoding="utf-8") as f:
                    self._tree_data = json.load(f)
                self._rebuild_l1()
            except Exception:
                pass

    def _rebuild_l1(self):
        """用 _tree_data 重建类目勾选树，默认全部勾选"""
        self.cat_tree.blockSignals(True)
        self.cat_tree.clear()
        for l1, l2_dict in self._tree_data.items():
            l1_item = QTreeWidgetItem([l1])
            l1_item.setFlags(l1_item.flags() | Qt.ItemIsUserCheckable)
            l1_item.setCheckState(0, Qt.Checked)
            for l2, l3_list in l2_dict.items():
                l2_item = QTreeWidgetItem([l2])
                l2_item.setFlags(l2_item.flags() | Qt.ItemIsUserCheckable)
                l2_item.setCheckState(0, Qt.Checked)
                for l3 in l3_list:
                    l3_item = QTreeWidgetItem([l3])
                    l3_item.setFlags(l3_item.flags() | Qt.ItemIsUserCheckable)
                    l3_item.setCheckState(0, Qt.Checked)
                    l2_item.addChild(l3_item)
                l1_item.addChild(l2_item)
            self.cat_tree.addTopLevelItem(l1_item)
        self.cat_tree.expandAll()
        self.cat_tree.blockSignals(False)
        self._refresh_combo_count()

    # ── 工具栏 ───────────────────────────────────────────────────────────
    def _build_toolbar(self):
        bar = QWidget()
        bar.setMinimumHeight(44)   # 不再 setFixedHeight:窗口窄时工具栏可折成多行、长高
        bar.setStyleSheet("QWidget{background:white;border-radius:8px;border:1px solid #E5E7EB}")
        _sp = bar.sizePolicy()
        _sp.setHeightForWidth(True)  # 让 bar 随宽度变化重算高度(FlowLayout 折行后变高)
        bar.setSizePolicy(_sp)
        lay = FlowLayout(bar)        # 单行 HBox → 自动换行:窗口可缩小、不最大化也看全
        lay.setContentsMargins(12, 6, 12, 6)

        lay.addWidget(QLabel("📦 <b>商品数据</b>"))
        self.count_label = QLabel("共 0 条")
        self.count_label.setStyleSheet("color:#6B7280;font-size:12px;")
        lay.addWidget(self.count_label)
        lay.addWidget(self._vline())

        self.btn_import_selection = self._mkbtn("导入选品表", "#0EA5E9", self.import_selection_excel)
        self.btn_import_selection.setToolTip("导入本程序导出的选品 Excel,写入本地选品历史并显示到选品表。")
        self.btn_import_selection.setEnabled(True)
        self.btn_export_excel = self._mkbtn("导出 Excel", "#4F46C8", self.export_excel)
        self.btn_export_html  = self._mkbtn("导出 HTML",  "#7C3AED", self.export_html)
        self.btn_clear        = self._mkbtn("清空",        "#6B7280", self.clear_table)

        # 刷新按钮：始终可点
        self.btn_refresh = QPushButton("🔄 刷新")
        self.btn_refresh.setFixedHeight(30)
        self.btn_refresh.setFixedWidth(60)
        self.btn_refresh.setStyleSheet(
            "QPushButton{background:#0EA5E9;color:white;border-radius:5px;"
            "font-size:12px;font-weight:500;border:none;}"
            "QPushButton:hover{background:#0284C7;}")
        self.btn_refresh.clicked.connect(self._reload_from_disk)

        lay.addWidget(self._vline())

        # 勾选操作
        def _selbtn(txt, slot):
            b = QPushButton(txt)
            b.setFixedHeight(30)
            b.setFixedWidth(54)
            b.setStyleSheet(
                "QPushButton{background:#F3F4F6;color:#374151;border-radius:5px;"
                "font-size:11px;border:1px solid #D1D5DB;}"
                "QPushButton:hover{background:#E5E7EB;}")
            b.clicked.connect(slot)
            return b

        self.btn_sel_all    = _selbtn("全选",   self._select_all_rows)
        self.btn_sel_none   = _selbtn("反选",   self._deselect_all_rows)

        # 智能选品:按推荐分降序排序 + 自动勾选前 N 个
        self.btn_smart_pick = QPushButton("🎯 智能选品")
        self.btn_smart_pick.setFixedHeight(30)
        self.btn_smart_pick.setFixedWidth(96)
        self.btn_smart_pick.setToolTip(
            "按推荐分从高到低排序,并自动勾选前 N 个(弹窗填 N)。\n"
            "之后可直接「批量比价」或「一键跑品」。")
        self.btn_smart_pick.setStyleSheet(
            "QPushButton{background:#059669;color:white;border-radius:5px;"
            "font-size:12px;font-weight:600;border:none;}"
            "QPushButton:hover{background:#047857;}")
        self.btn_smart_pick.clicked.connect(self._smart_pick)

        # 批量比价
        self.btn_bulk_cmp = QPushButton("🔍 批量比价")
        self.btn_bulk_cmp.setFixedHeight(30)
        self.btn_bulk_cmp.setFixedWidth(90)
        self.btn_bulk_cmp.setStyleSheet(
            "QPushButton{background:#D97706;color:white;border-radius:5px;"
            "font-size:12px;font-weight:500;border:none;}"
            "QPushButton:hover{background:#B45309;}")
        self.btn_bulk_cmp.clicked.connect(self._start_bulk_compare)

        # 一键跑品:勾选商品 → 同步进商品库 → 比价→货品核对→发布(避免重复比价)
        self.btn_xuanpin_oneclick = QPushButton("🚀 一键跑品")
        self.btn_xuanpin_oneclick.setFixedHeight(30)
        self.btn_xuanpin_oneclick.setFixedWidth(96)
        self.btn_xuanpin_oneclick.setToolTip(
            "对勾选商品全自动:同步进商品库 → 1688比价 → 货品核对(不一致/不确定拦下) → 自动发布。\n"
            "比价只跑一次(不会选品比价后又在商品库重复比)。")
        self.btn_xuanpin_oneclick.setStyleSheet(
            "QPushButton{background:#7C3AED;color:white;border-radius:5px;"
            "font-size:12px;font-weight:600;border:none;}"
            "QPushButton:hover{background:#6D28D9;}")
        self.btn_xuanpin_oneclick.clicked.connect(self._xuanpin_oneclick_start)

        self.btn_xuanpin_auto = QPushButton("🤖 全自动跑品")
        self.btn_xuanpin_auto.setFixedHeight(30)
        self.btn_xuanpin_auto.setFixedWidth(110)
        self.btn_xuanpin_auto.setToolTip("一键到底:智能选品(挑Top-N未入库)→ 比价→核对→发布→换主图→补视频→自动推广开车,全程无人值守。\n(具体跑哪几步看一键跑品弹窗勾选,含⑥开车)")
        self.btn_xuanpin_auto.setStyleSheet(
            "QPushButton{background:#7C3AED;color:white;border:none;border-radius:5px;"
            "font-size:11px;font-weight:bold;}QPushButton:hover{background:#6D28D9;}")
        self.btn_xuanpin_auto.clicked.connect(self._xuanpin_auto_run)

        self.btn_bulk_stop = QPushButton("⏹ 停止")
        self.btn_bulk_stop.setFixedHeight(30)
        self.btn_bulk_stop.setFixedWidth(62)
        self.btn_bulk_stop.setEnabled(False)
        self.btn_bulk_stop.setStyleSheet(
            "QPushButton{background:#EF4444;color:white;border-radius:5px;"
            "font-size:12px;font-weight:500;border:none;}"
            "QPushButton:disabled{background:#D1D5DB;}"
            "QPushButton:hover{background:#DC2626;}")
        self.btn_bulk_stop.clicked.connect(self._stop_bulk_compare)

        # 手动比价:对选中商品跑一次抓取,候选列表弹窗让用户挑同款
        self.btn_manual_cmp = QPushButton("🖱 手动比价")
        self.btn_manual_cmp.setFixedHeight(30)
        self.btn_manual_cmp.setFixedWidth(90)
        self.btn_manual_cmp.setToolTip("选中一条商品后点击:自动跑 1688 图搜,弹窗列出候选,你勾选同款写回")
        self.btn_manual_cmp.setStyleSheet(
            "QPushButton{background:#0EA5E9;color:white;border-radius:5px;"
            "font-size:12px;font-weight:500;border:none;}"
            "QPushButton:hover{background:#0284C7;}")
        self.btn_manual_cmp.clicked.connect(self._start_manual_compare)

        # 已比价筛选切换
        self.btn_compared = QPushButton("📋 已比价")
        self.btn_compared.setFixedHeight(30)
        self.btn_compared.setFixedWidth(80)
        self.btn_compared.setCheckable(True)
        self.btn_compared.setStyleSheet("""
            QPushButton {
                background: #F3F4F6; color: #374151;
                border-radius: 5px; font-size: 12px;
                font-weight: 500; border: 1px solid #D1D5DB;
            }
            QPushButton:hover  { background: #E5E7EB; }
            QPushButton:checked {
                background: #059669; color: white; border: none;
            }
            QPushButton:checked:hover { background: #047857; }
        """)
        self.btn_compared.clicked.connect(self._toggle_compared_filter)

        # 仅未入库:隐藏已进商品库(处理过)的品,避免每次抓新表重复
        self.btn_inlib = QPushButton("🆕 仅未入库")
        self.btn_inlib.setFixedHeight(30)
        self.btn_inlib.setFixedWidth(96)
        self.btn_inlib.setCheckable(True)
        self.btn_inlib.setToolTip("勾上后只显示【没进过商品库】的品,已处理过的隐藏,避免重复选。")
        self.btn_inlib.setStyleSheet(
            "QPushButton{background:#F3F4F6;color:#374151;border-radius:5px;font-size:12px;"
            "font-weight:500;border:1px solid #D1D5DB;}"
            "QPushButton:hover{background:#E5E7EB;}"
            "QPushButton:checked{background:#2563EB;color:white;border:none;}"
            "QPushButton:checked:hover{background:#1D4ED8;}")
        self.btn_inlib.clicked.connect(self._toggle_inlib_filter)

        # 选品入库:勾选商品直接加入 PDD 商品库(不跑比价/发布);想直接跑用「🚀 一键跑品」
        self.btn_xuanpin_addlib = QPushButton("📚 加入商品库")
        self.btn_xuanpin_addlib.setFixedHeight(30)
        self.btn_xuanpin_addlib.setFixedWidth(110)
        self.btn_xuanpin_addlib.setToolTip("把勾选商品加入 PDD 商品库(按商品ID去重合并),不跑比价/发布;入库后自动跳到商品库。")
        self.btn_xuanpin_addlib.setStyleSheet(
            "QPushButton{background:#059669;color:white;border:none;border-radius:5px;"
            "font-size:11px;font-weight:bold;}QPushButton:hover{background:#047857;}")
        self.btn_xuanpin_addlib.clicked.connect(self._xuanpin_add_to_library)

        # 删除选中已比价数据（仅在已比价模式下可用）
        self.btn_del_compared = QPushButton("🗑 删除选中比价")
        self.btn_del_compared.setFixedHeight(30)
        self.btn_del_compared.setToolTip("从 compared_products.json 中删除勾选商品的比价数据（不删除商品本身）")
        self.btn_del_compared.setEnabled(False)
        self.btn_del_compared.setStyleSheet("""
            QPushButton {
                background: #FEE2E2; color: #B91C1C;
                border-radius: 5px; font-size: 12px;
                font-weight: 500; border: 1px solid #FCA5A5;
                padding: 0 10px;
            }
            QPushButton:hover { background: #FECACA; }
            QPushButton:disabled {
                background: #F3F4F6; color: #9CA3AF;
                border-color: #E5E7EB;
            }
        """)
        self.btn_del_compared.clicked.connect(self._delete_selected_compared)

        # 快捷加载最近含已比价数据的历史文件
        self.btn_load_latest_compared = QPushButton("📂 加载含比价数据")
        self.btn_load_latest_compared.setFixedHeight(30)
        self.btn_load_latest_compared.setToolTip(
            "扫描所有 products_*.json，自动加载最近一个含已比价数据的文件")
        self.btn_load_latest_compared.setStyleSheet("""
            QPushButton {
                background: #FEF3C7; color: #92400E;
                border-radius: 5px; font-size: 12px;
                font-weight: 500; border: 1px solid #F59E0B;
                padding: 0 10px;
            }
            QPushButton:hover { background: #FDE68A; }
        """)
        self.btn_load_latest_compared.clicked.connect(self._load_latest_with_compared)

        # 清除表头筛选（有筛选时才高亮）
        self.btn_clear_filter = QPushButton("🧹 清除筛选")
        self.btn_clear_filter.setFixedHeight(30)
        self.btn_clear_filter.setFixedWidth(90)
        self.btn_clear_filter.setVisible(False)
        self.btn_clear_filter.setStyleSheet(
            "QPushButton{background:#DC2626;color:white;border-radius:5px;"
            "font-size:11px;font-weight:500;border:none;}"
            "QPushButton:hover{background:#B91C1C;}")
        self.btn_clear_filter.clicked.connect(self._clear_strip_filters)

        for b in [self.btn_export_excel, self.btn_export_html,
                  self.btn_refresh, self.btn_clear,
                  self.btn_sel_all, self.btn_sel_none, self.btn_smart_pick,
                  self.btn_bulk_cmp, self.btn_xuanpin_oneclick, self.btn_xuanpin_addlib, self.btn_xuanpin_auto, self.btn_bulk_stop, self.btn_manual_cmp,
                  self.btn_compared, self.btn_inlib, self.btn_del_compared,
                  self.btn_load_latest_compared, self.btn_import_selection,
                  self.btn_clear_filter]:
            lay.addWidget(b)
        # (已删「🤖全自动」勾选框:一键跑品弹窗的「跑哪几步④换图⑤补视频」步骤已取代它,
        #  启动时 _auto_full 由弹窗步骤重设、勾选框被覆盖=死开关;手动发布走待发布页自己的「全自动」。)
        # 显示浏览器(调试)勾选框:与 PDD 区那两个共享同一开关,选品区比价也能控制显隐
        lay.addWidget(self._pdd_make_show_browser_chk())
        return bar

    # ── 筛选栏 ───────────────────────────────────────────────────────────
    def _build_filter_bar(self):
        bar = QWidget()
        bar.setFixedHeight(38)
        bar.setStyleSheet("QWidget{background:white;border-radius:7px;border:1px solid #E5E7EB;}")
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(10, 0, 10, 0)
        lay.setSpacing(8)

        # 历史记录 — 多选按钮
        lay.addWidget(QLabel("📚 历史:"))

        self.btn_history_select = QPushButton("📂 选择时段")
        self.btn_history_select.setFixedHeight(26)
        self.btn_history_select.setStyleSheet(
            "QPushButton{background:#4F46C8;color:white;border-radius:5px;"
            "font-size:11px;border:none;padding:0 10px;}"
            "QPushButton:hover{background:#4338CA;}")
        self.btn_history_select.clicked.connect(self._show_history_selector)
        lay.addWidget(self.btn_history_select)

        self.lbl_history_sel = QLabel("当前最新数据")
        self.lbl_history_sel.setStyleSheet(
            "color:#4B5563;font-size:11px;max-width:220px;")
        lay.addWidget(self.lbl_history_sel)

        # 保留隐藏的 history_combo 供内部 _reload_history_combo / _delete_history 复用
        self.history_combo = QComboBox()
        self.history_combo.setVisible(False)

        self.btn_del_history = QPushButton("🗑 删除")
        self.btn_del_history.setFixedHeight(24)
        self.btn_del_history.setStyleSheet(
            "QPushButton{background:#EF4444;color:white;border-radius:4px;"
            "font-size:11px;border:none;padding:0 8px;}"
            "QPushButton:disabled{background:#D1D5DB;}"
            "QPushButton:hover{background:#DC2626;}")
        self.btn_del_history.clicked.connect(self._delete_history)
        lay.addWidget(self.btn_del_history)

        lay.addWidget(self._vline())

        # 类目筛选 — 树形弹窗按钮
        lay.addWidget(QLabel("类目:"))
        self.btn_cat_filter = QPushButton("全部类目  ▾")
        self.btn_cat_filter.setFixedHeight(26)
        self.btn_cat_filter.setMinimumWidth(150)
        self.btn_cat_filter.setStyleSheet("""
            QPushButton{background:white;color:#374151;border:1px solid #D1D5DB;
                border-radius:5px;font-size:11px;padding:0 10px;text-align:left;}
            QPushButton:hover{background:#F3F4F6;border-color:#4F46C8;}
            QPushButton[active="true"]{border-color:#4F46C8;color:#4F46C8;font-weight:bold;}
        """)
        self.btn_cat_filter.clicked.connect(self._show_cat_filter_popup)
        lay.addWidget(self.btn_cat_filter)

        # 弹出树（延迟创建，首次 show 时初始化）
        self._cat_popup = None

        lay.addStretch()

        # ── 商品名称搜索 ──────────────────────────────────────────────────
        lay.addWidget(self._vline())
        lay.addWidget(QLabel("🔍 搜索:"))

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("输入商品名称关键词…")
        self.search_input.setFixedHeight(26)
        self.search_input.setMinimumWidth(220)
        self.search_input.setMaximumWidth(340)
        self.search_input.setClearButtonEnabled(True)
        self.search_input.setStyleSheet(
            "QLineEdit{"
            "  border:1px solid #D1D5DB;border-radius:5px;"
            "  padding:2px 8px;font-size:12px;background:white;color:#374151;"
            "}"
            "QLineEdit:focus{border-color:#4F46C8;}"
        )
        self.search_input.textChanged.connect(self._on_name_search_changed)
        lay.addWidget(self.search_input)

        return bar

    def _mkbtn(self, text, color, slot):
        b = QPushButton(text)
        b.setFixedHeight(30)
        b.setFixedWidth(96)
        b.setStyleSheet(f"QPushButton{{background:{color};color:white;border-radius:5px;"
                        f"font-size:12px;font-weight:500;border:none;}}"
                        f"QPushButton:disabled{{background:#D1D5DB;}}")
        b.clicked.connect(slot)
        b.setEnabled(False)
        return b

    def _col_value(self, p: dict, key: str) -> str:
        """某列用于"筛选/去重"的文本值。推荐列返回标签(🔥强推/👍可做/…),其余原样。"""
        if key == "_reco":
            rc = p.get("_reco")
            if not isinstance(rc, dict):
                rc = xuanpin_reco.score_product(p); p["_reco"] = rc
            return rc.get("label", "")
        return str(p.get(key, "") or "").strip()

    def _get_col_unique_values(self, key: str) -> list:
        """获取指定列在全量数据中的唯一值 + 数量(已排序),返回 [(值, 数量), ...]。
        筛选下拉显示"值 (数量)";真实筛选值存 UserRole。"""
        from collections import Counter
        c = Counter()
        for p in self._all_prods:
            v = self._col_value(p, key)
            if v:
                c[v] += 1
        return sorted(c.items())

    def _on_strip_filter(self, key: str, value):
        """表头筛选箭头弹窗确认后更新筛选状态（value 为 set）"""
        if isinstance(value, set) and value:
            self._strip_filters[key] = value
        else:
            self._strip_filters.pop(key, None)
        self._apply_filters()

    @staticmethod
    def _match_strip(val: str, pattern: str) -> bool:
        """支持 >N  <N  >=N  <=N  =N  以及普通文字包含"""
        v = val.strip()
        p = pattern.strip()
        if not p:
            return True
        for op, fn in [(">=", lambda a, b: a >= b),
                       ("<=", lambda a, b: a <= b),
                       (">",  lambda a, b: a >  b),
                       ("<",  lambda a, b: a <  b),
                       ("=",  lambda a, b: a == b)]:
            if p.startswith(op):
                try:
                    thr = float(p[len(op):].strip())
                    num = float(re.sub(r"[^\d.]", "", v) or "nan")
                    return fn(num, thr)
                except (ValueError, TypeError):
                    return True
        return p.lower() in v.lower()

    def _clear_strip_filters(self):
        """清空所有表头筛选"""
        self._strip_filters.clear()
        hdr = self.table.horizontalHeader()
        if hasattr(hdr, "clear_all_filters"):
            hdr.clear_all_filters()
        self.btn_clear_filter.setVisible(False)
        self._apply_filters()

    def _on_name_search_changed(self, text: str):
        """商品名称搜索框内容变化时触发"""
        self._name_search = text.strip()
        self._apply_filters()

    def _build_table(self):
        tbl = QTableWidget()
        tbl.setColumnCount(len(COLUMNS))

        # ── 替换为带筛选箭头的自定义表头 ──
        col_keys = [key for _, key, _ in COLUMNS]
        hdr = FilterableHeaderView(col_keys, self._get_col_unique_values, tbl)
        hdr.setStyleSheet("""
            QHeaderView::section {
                background: #4F46C8;
                color: white;
                font-weight: bold;
                font-size: 12px;
                padding: 4px 20px 4px 6px;
                border: none;
                border-right: 1px solid #6366F1;
            }
            QHeaderView::section:first {
                border-radius: 0px;
            }
            QHeaderView::section:hover {
                background: #4338CA;
            }
        """)
        tbl.setHorizontalHeader(hdr)
        hdr.filter_applied.connect(self._on_strip_filter)

        tbl.setHorizontalHeaderLabels([c[0] for c in COLUMNS])
        hdr.setStretchLastSection(False)
        tbl.verticalHeader().setVisible(False)
        tbl.setAlternatingRowColors(True)
        tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setSortingEnabled(True)
        tbl.setShowGrid(False)
        tbl.verticalHeader().setDefaultSectionSize(28)
        for i, (_, _, w) in enumerate(COLUMNS):
            tbl.setColumnWidth(i, w)
        tbl.setContextMenuPolicy(Qt.CustomContextMenu)
        tbl.customContextMenuRequested.connect(self._on_table_context_menu)

        # 第0列表头显示勾选图标，点击全选/取消全选
        sel_header = QTableWidgetItem("☑")
        sel_header.setTextAlignment(Qt.AlignCenter)
        tbl.setHorizontalHeaderItem(0, sel_header)
        hdr.sectionClicked.connect(
            lambda idx: self._toggle_all_rows() if idx == 0 else None)
        # 已比价模式下的内联编辑
        tbl.itemChanged.connect(self._on_table_item_changed)
        return tbl

    def _build_log(self):
        frame = QWidget()
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(0, 4, 0, 0)
        lay.setSpacing(4)
        hdr = QLabel("📡 运行日志")
        hdr.setStyleSheet("color:#6B7280;font-size:11px;font-weight:bold;padding-left:4px;")
        lay.addWidget(hdr)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(2000)
        lay.addWidget(self.log)
        return frame

    def _load_latest_with_compared(self):
        """扫描 products_*.json 找最近一个含已比价数据的，加载到主表"""
        import glob, os
        files = sorted([f for f in glob.glob(str(DATA_DIR / "products_*.json"))
                        if _is_main_product_file(f)],
                       key=os.path.getmtime, reverse=True)
        for fp in files:
            try:
                with open(fp, encoding="utf-8") as f:
                    products = json.load(f)
            except Exception:
                continue
            m = [p for p in products if (p.get("cost_ref") or p.get("supplier_link")
                                          or p.get("cost_supplier") or p.get("pdd_price")
                                          or p.get("pdd_link"))]
            if m:
                self._all_prods = products
                try:
                    self._update_filter_cats(products)
                except Exception:
                    pass
                # 自动开启已比价筛选
                if not self.btn_compared.isChecked():
                    self.btn_compared.setChecked(True)
                self._compared_only = True
                self._apply_filters()
                fn = os.path.basename(fp)
                self.status.showMessage(f"已加载 {fn}（含 {len(m)} 件已比价）", 8000)
                QMessageBox.information(self, "加载完成",
                    f"已加载历史文件：\n{fn}\n含 {len(m)} 件已比价商品\n（已自动启用「📋 已比价」筛选）")
                return
        QMessageBox.information(self, "未找到", "所有 products 文件均无已比价数据")

    # ── PDD 待发布页：数据加载 ──────────────────────────────────────────
    def _pdd_get_store_list(self) -> list[str]:
        """从 stores.json 直接读店铺名列表(不依赖任何 UI 控件)。
        Phase 4 后 pdd_store_combo 已从待发布页移除,商品库提交对话框用此 helper。
        """
        try:
            import json as _json
            stores_path = Path(r"D:/files/pdd_profiles/stores.json")
            if stores_path.exists():
                data = _json.load(open(stores_path, encoding="utf-8"))
                return list(data.keys()) if isinstance(data, dict) else []
        except Exception:
            pass
        return []

    def _pdd_active_store_names(self) -> set:
        """当前仍保留登录 profile 的店铺名；读失败/为空时不主动隐藏历史。"""
        try:
            return set(self._pdd_get_store_list())
        except Exception:
            return set()

    def _pdd_record_store_active(self, rec: dict, active: set | None = None) -> bool:
        """退店归档:历史记录保留,日常页面默认隐藏 stores.json 中已不存在的店铺。"""
        active = active if active is not None else self._pdd_active_store_names()
        if not active:
            return True
        store = (rec.get("store") or "").strip()
        return (not store) or store in active

    def _pdd_load_stores(self):
        """兼容老逻辑:若 pdd_store_combo 还存在则填充(防御性,Phase 4 后通常不存在)。"""
        if not hasattr(self, "pdd_store_combo"):
            return
        try:
            import json as _json
            stores_path = Path(r"D:/files/pdd_profiles/stores.json")
            stores = _json.load(open(stores_path, encoding="utf-8")) if stores_path.exists() else {}
        except Exception:
            stores = {}
        self.pdd_store_combo.clear()
        for name in stores:
            self.pdd_store_combo.addItem(name)
        if not stores:
            self.pdd_store_combo.addItem("（无已登录店铺）")

    def _pdd_find_latest_compared(self):
        """读最新 products_*.json，返回已比价商品列表"""
        import json as _json, glob, os, re
        try:
            files = sorted(
                [f for f in glob.glob(r"D:/files/data/products_*.json") if _is_main_product_file(f)],
                key=os.path.getmtime, reverse=True)
            for fp in files:
                d = _json.load(open(fp, encoding="utf-8"))
                m = [p for p in d if (p.get("cost_ref") or p.get("supplier_link")
                                       or p.get("cost_supplier") or p.get("pdd_price")
                                       or p.get("pdd_link")) and p.get("image")]
                if m:
                    return m, os.path.basename(fp)
        except Exception:
            pass
        return [], ""

    @staticmethod
    def _pdd_parse_cost(cost_ref: str) -> float:
        """从 cost_ref 文本提取首个金额，如 '¥3.71 (¥3.71+运0)' → 3.71"""
        import re
        if not cost_ref:
            return 0.0
        m = re.search(r'(\d+\.?\d*)', str(cost_ref))
        return float(m.group(1)) if m else 0.0

    def _pdd_refresh_pending(self):
        """刷新已比价数据并重渲染表格"""
        products, fp_name = self._pdd_find_latest_compared()
        self._pdd_all_products = products
        self._pdd_source_file = fp_name
        self._pdd_render_pending_table(products)

    def _pdd_render_pending_table(self, products):
        """根据 products 列表渲染表格"""
        self.pdd_pending_table.setRowCount(0)
        for prod in products:
            row = self.pdd_pending_table.rowCount()
            self.pdd_pending_table.insertRow(row)
            # 复选框（真可点击）
            chk_item = QTableWidgetItem()
            chk_item.setFlags(chk_item.flags() | Qt.ItemIsUserCheckable)
            chk_item.setCheckState(Qt.Unchecked)
            chk_item.setTextAlignment(Qt.AlignCenter)
            self.pdd_pending_table.setItem(row, 0, chk_item)
            # 图占位
            img_item = QTableWidgetItem("📷")
            img_item.setTextAlignment(Qt.AlignCenter)
            self.pdd_pending_table.setItem(row, 1, img_item)
            # 商品名
            self.pdd_pending_table.setItem(row, 2, QTableWidgetItem(prod.get("name", "")))
            # 供货价
            cost = self._pdd_parse_cost(prod.get("cost_ref", ""))
            cost_item = QTableWidgetItem(f"¥{cost:.2f}" if cost else "-")
            cost_item.setTextAlignment(Qt.AlignCenter)
            self.pdd_pending_table.setItem(row, 3, cost_item)
            # 预计拼单价(按当前选中规则计算: (供货价×1份 + 运费) / (1 - 毛利率))
            rule = self.pdd_rule_combo.currentData() if hasattr(self, "pdd_rule_combo") else None
            if isinstance(rule, dict):
                _ship = float(rule.get("shipping", 4.0))
                _margin = float(rule.get("margin", 0.9))
            else:
                _ship, _margin = 4.0, 0.9
            est_price = round((cost + _ship) / (1 - _margin), 2) if cost and _margin < 0.99 else 0
            price_item = QTableWidgetItem(f"¥{est_price:.2f}" if est_price else "-")
            price_item.setTextAlignment(Qt.AlignCenter)
            price_item.setForeground(QColor("#10B981"))
            self.pdd_pending_table.setItem(row, 4, price_item)
            # 状态
            status_item = QTableWidgetItem("⚪ 待发布")
            status_item.setTextAlignment(Qt.AlignCenter)
            self.pdd_pending_table.setItem(row, 5, status_item)
            # 发布按钮
            btn = QPushButton("🚀 发布")
            btn.setStyleSheet(
                "QPushButton{background:#4F46C8;color:white;border:none;border-radius:4px;padding:4px 8px;}"
                "QPushButton:hover{background:#4338CA;}")
            btn.clicked.connect(lambda _, p=prod: self._pdd_publish_one(p))
            self.pdd_pending_table.setCellWidget(row, 6, btn)
        src = getattr(self, "_pdd_source_file", "")
        all_n = len(getattr(self, "_pdd_all_products", []) or [])
        shown = len(products)
        msg = (f"共 {all_n} 件已比价  ·  显示 {shown} 件  ·  来源：{src}"
               if all_n else "未找到已比价商品")
        self.pdd_pending_status.setText(msg)

    def _pdd_apply_filter(self):
        """根据搜索框关键词过滤"""
        kw = self.pdd_search_input.text().strip().lower()
        all_prods = getattr(self, "_pdd_all_products", []) or []
        if not kw:
            self._pdd_render_pending_table(all_prods)
        else:
            kws = kw.split()
            filtered = [p for p in all_prods
                        if all(k in (p.get("name", "") or "").lower() for k in kws)]
            self._pdd_render_pending_table(filtered)

    def _pdd_toggle_all(self, col: int):
        """点击「全选」表头切换所有勾选状态"""
        if col != 0:
            return
        # 检测当前状态：若有任何未勾选，则全部勾选；否则全部取消
        any_unchecked = False
        for r in range(self.pdd_pending_table.rowCount()):
            it = self.pdd_pending_table.item(r, 0)
            if it and it.checkState() != Qt.Checked:
                any_unchecked = True
                break
        new_state = Qt.Checked if any_unchecked else Qt.Unchecked
        for r in range(self.pdd_pending_table.rowCount()):
            it = self.pdd_pending_table.item(r, 0)
            if it:
                it.setCheckState(new_state)

    def _pdd_get_selected(self):
        """返回所有勾选行对应的商品列表"""
        selected = []
        # 当前显示的 products 顺序与 table row 顺序一致
        kw = self.pdd_search_input.text().strip().lower()
        all_prods = getattr(self, "_pdd_all_products", []) or []
        if kw:
            kws = kw.split()
            shown = [p for p in all_prods
                     if all(k in (p.get("name", "") or "").lower() for k in kws)]
        else:
            shown = all_prods
        for r in range(self.pdd_pending_table.rowCount()):
            it = self.pdd_pending_table.item(r, 0)
            if it and it.checkState() == Qt.Checked and r < len(shown):
                selected.append(shown[r])
        return selected

    def _pdd_publish_batch(self):
        """批量发布选中商品 - 加入队列顺序执行"""
        sel = self._pdd_get_selected()
        if not sel:
            QMessageBox.information(self, "批量发布", "请先勾选要发布的商品")
            return
        store = self.pdd_store_combo.currentText()
        names = "\n".join(f"• {p.get('name','')[:40]}" for p in sel[:5])
        more = f"\n…还有 {len(sel)-5} 件" if len(sel) > 5 else ""
        ans = QMessageBox.question(self, "确认批量发布",
            f"店铺: {store}\n共 {len(sel)} 件将依次发布（同店铺无法并行）:\n{names}{more}\n\n确认执行？",
            QMessageBox.Yes | QMessageBox.No)
        if ans == QMessageBox.Yes:
            self._pdd_enqueue(sel)

    def _pdd_publish_one(self, prod: dict):
        """单个商品发布：加入队列"""
        self._pdd_enqueue([prod])

    def _pdd_enqueue(self, prods: list):
        """把商品加入发布队列，启动处理（如未运行）"""
        if not hasattr(self, "_pdd_queue"):
            self._pdd_queue = []
            self._pdd_running = False
            self._pdd_proc = None
        store = self.pdd_store_combo.currentText()
        if not store or "无已登录" in store:
            QMessageBox.warning(self, "PDD 发布", "请先选择店铺")
            return
        # 校验 supplier_link
        valid = [p for p in prods if p.get("supplier_link") and p.get("image")]
        if not valid:
            QMessageBox.warning(self, "PDD 发布", "选中商品缺少 supplier_link 或 image")
            return
        self._pdd_queue.extend([(p, store) for p in valid])
        self._pdd_set_row_status_for(prods, "🟡 排队中")
        if not self._pdd_running:
            self._pdd_process_next()

    def _pdd_set_row_status_for(self, prods: list, status: str):
        """根据商品对象设置对应行的状态"""
        all_prods = getattr(self, "_pdd_all_products", []) or []
        kw = self.pdd_search_input.text().strip().lower()
        if kw:
            kws = kw.split()
            shown = [p for p in all_prods if all(k in (p.get("name","") or "").lower() for k in kws)]
        else:
            shown = all_prods
        prod_ids = {id(p) for p in prods}
        for r, p in enumerate(shown):
            if id(p) in prod_ids:
                it = self.pdd_pending_table.item(r, 5)
                if it:
                    it.setText(status)

    def _pdd_process_next(self):
        """从队列取下一个商品执行"""
        if not self._pdd_queue:
            self._pdd_running = False
            self.pdd_pending_status.setText("✅ 所有发布任务已完成")
            return
        self._pdd_running = True
        prod, store = self._pdd_queue.pop(0)
        self._pdd_current_prod = prod
        # 1) 下载图片到 D 盘项目目录(避免占 C 盘;异常残留时也只污染 D 盘)
        import urllib.request, os, time, uuid
        from pathlib import Path
        try:
            pdd_temp_dir = Path(r"D:/files/data/pdd/temp")
            pdd_temp_dir.mkdir(parents=True, exist_ok=True)
            # 进入新任务前,清理 1 小时前的残留(防止异常退出累积)
            try:
                cutoff = time.time() - 3600
                for old in pdd_temp_dir.glob("pdd_pub_*"):
                    try:
                        if old.stat().st_mtime < cutoff:
                            old.unlink()
                    except Exception:
                        pass
            except Exception:
                pass
            tmp_path = str(pdd_temp_dir / f"pdd_pub_{uuid.uuid4().hex[:12]}.jpg")
            # 发布用图:开关=货源图时用 1688 货源主图搜同款;否则/查不到用选品图 prod["image"]
            _use_src = self._pdd_publish_use_source()
            _src_url = self._pdd_source_image_for_publish(prod)   # 货源图(原图):存档 + 开关开时当发布图
            _pub_url = _src_url if (_use_src and _src_url) else (prod.get("image") or "")
            import hashlib as _hh, shutil as _sh, threading as _thr
            from PyQt5.QtWidgets import QApplication as _QApp
            _cache_dir = Path(__file__).parent / "data" / "img_cache"
            def _fetch_one(_u):
                if not _u:
                    return False
                # ★ 先本地缓存(表格缩略图下过的同一套)→ 0网络;否则后台下载+主线程processEvents不冻+25s超时
                try:
                    _cp = _cache_dir / _hh.md5(_u.encode("utf-8")).hexdigest()
                    if _cp.exists() and _cp.stat().st_size > 0:
                        _sh.copyfile(str(_cp), tmp_path); return True
                except Exception:
                    pass
                _r = {}
                def _w():
                    try:
                        _req = urllib.request.Request(_u, headers={"User-Agent": "Mozilla/5.0"})
                        with _DL_OPENER.open(_req, timeout=20) as _rr, open(tmp_path, "wb") as _f:
                            _f.write(_rr.read())
                        _r["ok"] = True
                    except Exception:
                        pass
                _th = _thr.Thread(target=_w, daemon=True); _th.start()
                _waited = 0.0
                while _th.is_alive() and _waited < 25:
                    _QApp.processEvents(); time.sleep(0.05); _waited += 0.05
                return bool(_r.get("ok"))
            if _fetch_one(_pub_url):
                if _use_src and _src_url:
                    print(f"[发布用图] 货源图 {_src_url[:70]}", flush=True)
            elif _use_src and _src_url and prod.get("image") and _fetch_one(prod["image"]):
                print("[发布用图] 货源图失败,回退选品图", flush=True)
            else:
                raise RuntimeError("图片获取失败(缓存无 + 下载超时/失败)")
        except Exception as e:
            self._pdd_set_row_status_for([prod], f"❌ 图下载失败")
            self.pdd_pending_status.setText(f"[!] 图片下载失败: {e}")
            QTimer.singleShot(500, self._pdd_process_next)
            return
        # 2) 解析供货价
        cost = self._pdd_parse_cost(prod.get("cost_ref", ""))
        # 3) 启动 pdd_publish.py
        self._pdd_set_row_status_for([prod], "🔵 发布中")
        self.pdd_pending_status.setText(f"🚀 发布: {prod.get('name','')[:40]}  剩余队列: {len(self._pdd_queue)}")
        proc = QProcess(self)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        args = [
            "-u", r"D:/files/pdd_publish.py",
            "--store", store,
            "--image", tmp_path,
            "--xuanpin-image-url", prod.get("image", "") or "",   # 选品图URL:平移进 history
            "--source-image-url",  _src_url or "",                # 货源图URL:平移进 history
            "--supplier-url", prod["supplier_link"],
            "--supplier-cost", str(cost) if cost else "0",
            "--auto-close",
        ]
        if self._pdd_smart_sku_on():
            args.append("--smart-sku")
        # 注:同款核对闸门(--vlm-gate)暂只在待发布/一键跑品主路径(Flow A)启用;
        # 此商品库直发队列(Flow B)收尾把 exit=2 当"上架未对齐"、且未落日志,识别不了 no_same_style,
        # 先不挂闸门,避免误标(后续给 Flow B 补 no_same_style 处理再启用)。
        # 透传当前选中的定价规则。若无选中或加载失败则不传,走 pdd_publish.py 内置默认值。
        rule = self.pdd_rule_combo.currentData() if hasattr(self, "pdd_rule_combo") else None
        if isinstance(rule, dict):
            args += [
                "--shipping",     str(rule.get("shipping", 4.0)),
                "--margin",       str(rule.get("margin", 0.9)),
                "--single-extra", str(rule.get("single_buy_extra", 2.0)),
                "--suffix",       str(rule.get("spec_suffix", "+面膜1片")),
                "--stock",        str(int(rule.get("stock", 8888))),
                "--rule-name",    str(rule.get("name", "")),
            ]
            self.pdd_pending_status.setText(
                f"🚀 发布: {prod.get('name','')[:40]}  规则: {rule.get('name','')}  剩余: {len(self._pdd_queue)}")
        args += self._pdd_browser_args()
        proc.finished.connect(lambda code, _s, p=prod, t=tmp_path: self._pdd_on_finished(code, p, t))
        self._pdd_proc = proc
        proc.start("python", args)

    def _pdd_on_finished(self, code: int, prod: dict, tmp_path: str):
        """子进程完成回调
        exit_code: 0=验证通过真实发布; 2=已上架但核对差异; 其他=异常
        """
        import os
        if code == 0:
            status = "🟢 已发布"
        elif code == 2:
            status = "🟡 上架未对齐"
        else:
            status = f"❌ 异常({code})"
        self._pdd_set_row_status_for([prod], status)
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        # 任何上架（ok 或 mismatch）都会写入历史，刷新表
        if code in (0, 2):
            self._pdd_load_published()
        QTimer.singleShot(1000, self._pdd_process_next)

    def _hline(self):
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("border:none;border-top:1px solid #E5E7EB;")
        return line

    def _vline(self):
        line = QFrame()
        line.setFrameShape(QFrame.VLine)
        line.setStyleSheet("border:none;border-left:1px solid #E5E7EB;")
        return line

    # ── 历史记录 ─────────────────────────────────────────────────────────
    def _load_history(self):
        """读 scrape_history.json，兼容 main.py (time/total/json) 和 client.py (timestamp/count/filename) 两种 schema"""
        if not HISTORY_PATH.exists():
            return []
        try:
            with open(HISTORY_PATH, encoding="utf-8") as f:
                raw = json.load(f)
        except Exception:
            return []
        import os as _os
        normalized = []
        for e in raw:
            ts = e.get("timestamp") or e.get("time") or ""
            # 紧凑格式 20260521_215532 → 转成 2026-05-21 21:55:32
            if ts and "_" in ts and "-" not in ts:
                try:
                    ts = datetime.strptime(ts, "%Y%m%d_%H%M%S").strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    pass
            cnt = e.get("count") or e.get("total") or 0
            fn = e.get("filename") or ""
            if not fn:
                j = e.get("json", "")
                if j:
                    fn = _os.path.basename(j)
            new_e = dict(e)
            new_e["timestamp"] = ts
            new_e["count"] = cnt
            new_e["filename"] = fn
            normalized.append(new_e)
        return normalized

    def _write_history_entry(self):
        history = self._load_history()
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        files = sorted(
            [f for f in DATA_DIR.glob("products_*.json")
             if _is_main_product_file(f)],
            key=lambda f: f.stat().st_mtime
        )
        entry = {
            "timestamp": ts,
            "filename":  files[-1].name if files else "",
            "count":     len(self._all_prods),
            "year":      self._last_year,
            "month":     self._last_month,
            "combos_n":  len(self._last_combos),
        }
        history.append(entry)
        history = history[-60:]   # 最多保留60条
        try:
            with open(HISTORY_PATH, "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _reload_history_combo(self):
        history = self._load_history()
        self.history_combo.blockSignals(True)
        self.history_combo.clear()
        self.history_combo.addItem("── 当前数据 ──", "")
        today     = datetime.now().strftime("%Y-%m-%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        for entry in reversed(history):
            ts    = entry.get("timestamp", "")
            cnt   = entry.get("count", 0)
            fn    = entry.get("filename", "")
            day   = ts[:10]
            tag   = "今天" if day == today else ("昨天" if day == yesterday else day)
            label = f"{tag} {ts[11:16]}  ({cnt}条)"
            self.history_combo.addItem(label, fn)
        self.history_combo.blockSignals(False)
        # 有历史记录 或 有孤立 products_*.json 都允许删除
        has_orphans = any(f.name != "products_live.json"
                          for f in DATA_DIR.glob("products_*.json"))
        self.btn_del_history.setEnabled(bool(history) or has_orphans)

    def _on_history_selected(self, idx):
        fn = self.history_combo.currentData()
        if not fn:
            return
        path = DATA_DIR / fn
        if not path.exists():
            return
        try:
            with open(path, encoding="utf-8-sig") as f:
                products = json.load(f)
            products = _merge_compared_into(products)
            self._all_prods = products
            self._update_filter_cats(products)
            self._apply_filters()
        except Exception:
            pass

    def _on_history_combo_changed(self, idx):
        fn = self.history_combo.currentData()
        self.btn_del_history.setEnabled(bool(fn))

    # ── 历史多选 ──────────────────────────────────────────────────────────
    def _show_history_selector(self):
        history = self._load_history()
        dlg = HistorySelectDialog(history, len(self._all_prods), parent=self)
        if dlg.exec_() != QDialog.Accepted:
            return
        keys = dlg.selected_keys()
        if not keys:
            QMessageBox.information(self, "提示", "未勾选任何时间段")
            return
        self._load_selected_histories(keys, history)

    def _load_selected_histories(self, keys, history_entries):
        """加载并合并多个时间段数据，按 prod_id/name 去重"""
        merged = {}   # key → prod dict（用 prod_id 或 name 作为唯一键）

        today     = datetime.now().strftime("%Y-%m-%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        labels = []

        for key in keys:
            if key == "__current__":
                prods = list(self._all_prods)
                labels.append("当前数据")
            else:
                path = DATA_DIR / key
                if not path.exists():
                    continue
                try:
                    with open(path, encoding="utf-8-sig") as f:
                        prods = json.load(f)
                except Exception:
                    continue
                # 找对应的 timestamp 作为标签
                for entry in history_entries:
                    if entry.get("filename") == key:
                        ts  = entry.get("timestamp", "")
                        day = ts[:10]
                        tag = "今天" if day == today else ("昨天" if day == yesterday else day)
                        labels.append(f"{tag} {ts[11:16]}")
                        break
                else:
                    labels.append(key)

            for p in prods:
                uid = p.get("prod_id") or p.get("id") or p.get("name", "")
                if uid and uid not in merged:
                    merged[uid] = p

        combined = list(merged.values())
        combined = _merge_compared_into(combined)
        self._all_prods = combined
        self._update_filter_cats(combined)
        self._apply_filters()

        sel_txt = " + ".join(labels) if labels else "无"
        self.lbl_history_sel.setText(sel_txt[:40] + ("…" if len(sel_txt) > 40 else ""))
        self.status.showMessage(f"已合并 {len(keys)} 个时间段  共 {len(combined)} 条（去重后）")

    def _delete_history(self):
        history = self._load_history()
        if not history:
            # 历史空但可能还有孤立 products_*.json
            orphan_files = [f for f in DATA_DIR.glob("products_*.json")
                            if _is_main_product_file(f)]
            if not orphan_files:
                QMessageBox.information(self, "提示", "暂无历史记录或孤立数据文件可删除")
                return
            ans = QMessageBox.question(self, "清理孤立数据文件",
                f"历史记录已为空，但磁盘还有 {len(orphan_files)} 个 products_*.json 残留。\n"
                f"是否一并清理？（保留 products_live.json）",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if ans != QMessageBox.Yes:
                return
            removed = 0
            for f in orphan_files:
                try: f.unlink(); removed += 1
                except Exception: pass
            self._all_prods = []
            self._update_filter_cats([])
            self._apply_filters()
            self._reload_history_combo()
            QMessageBox.information(self, "完成", f"已清理 {removed} 个孤立数据文件，内存视图已清空")
            return

        # ── 选择要删除的条目 ──────────────────────────────────────────
        dlg = QDialog(self)
        dlg.setWindowTitle("选择要删除的历史记录")
        dlg.setMinimumWidth(380)
        dlg.setMinimumHeight(300)
        dlg.setWindowFlags(dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        dlay = QVBoxLayout(dlg)
        dlay.setContentsMargins(14, 14, 14, 10)
        dlay.setSpacing(8)

        tip = QLabel("⚠️ 勾选要删除的时间段（同时删除数据文件，操作不可恢复）")
        tip.setStyleSheet("color:#EF4444;font-size:11px;")
        tip.setWordWrap(True)
        dlay.addWidget(tip)

        lw = QListWidget()
        lw.setStyleSheet(
            "QListWidget{border:1px solid #E5E7EB;border-radius:6px;}"
            "QListWidget::item{padding:4px 6px;}"
            "QListWidget::item:selected{background:#FEE2E2;color:#1F2937;}")
        today     = datetime.now().strftime("%Y-%m-%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        for entry in reversed(history):
            ts  = entry.get("timestamp", "")
            cnt = entry.get("count", 0)
            fn  = entry.get("filename", "")
            day = ts[:10]
            tag = "今天" if day == today else ("昨天" if day == yesterday else day)
            lbl = f"🕐 {tag} {ts[11:16]}  ({cnt}条)  [{fn}]"
            it  = QListWidgetItem(lbl)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Unchecked)
            # UserRole 用 timestamp（秒级唯一）+ fn + label，避免空 fn 撞行
            it.setData(Qt.UserRole, (ts, fn, f"{tag} {ts[11:16]}"))
            lw.addItem(it)
        dlay.addWidget(lw)
        # 一键清空所有 (0条) 空记录
        btn_clean_empty = QPushButton("🧹 一键清理所有 (0条) 空记录")
        btn_clean_empty.setFixedHeight(24)
        btn_clean_empty.setStyleSheet(
            "QPushButton{background:#FEF3C7;color:#92400E;border-radius:4px;"
            "font-size:11px;border:1px solid #F59E0B;padding:2px 10px;}"
            "QPushButton:hover{background:#FDE68A;}")
        def _check_all_empty():
            for i in range(lw.count()):
                ts, fn, _ = lw.item(i).data(Qt.UserRole)
                if not fn:  # 空文件名 = 0条
                    lw.item(i).setCheckState(Qt.Checked)
        btn_clean_empty.clicked.connect(_check_all_empty)
        dlay.addWidget(btn_clean_empty)

        # 全选 / 全不选 行
        sel_row = QHBoxLayout()
        for txt, state in [("全选", Qt.Checked), ("全不选", Qt.Unchecked)]:
            b = QPushButton(txt)
            b.setFixedHeight(24)
            b.setStyleSheet("QPushButton{background:#F3F4F6;border-radius:4px;"
                            "font-size:11px;border:1px solid #D1D5DB;padding:0 10px;}"
                            "QPushButton:hover{background:#E5E7EB;}")
            b.clicked.connect(lambda _, s=state, w=lw:
                              [w.item(i).setCheckState(s) for i in range(w.count())])
            sel_row.addWidget(b)
        sel_row.addStretch()
        dlay.addLayout(sel_row)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("确认删除")
        btns.button(QDialogButtonBox.Ok).setStyleSheet(
            "QPushButton{background:#EF4444;color:white;border-radius:4px;"
            "font-size:11px;border:none;padding:2px 14px;}"
            "QPushButton:hover{background:#DC2626;}")
        btns.button(QDialogButtonBox.Cancel).setText("取消")
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        dlay.addWidget(btns)

        if dlg.exec_() != QDialog.Accepted:
            return

        to_delete = []
        for i in range(lw.count()):
            it = lw.item(i)
            if it.checkState() == Qt.Checked:
                ts, fn, label = it.data(Qt.UserRole)
                to_delete.append((ts, fn, label))

        if not to_delete:
            QMessageBox.information(self, "提示", "未勾选任何条目")
            return

        # ── 二次确认 ────────────────────────────────────────────────
        names = "\n".join(f"  • {label}" for _, _, label in to_delete)
        if QMessageBox.question(
                self, "确认删除",
                f"确定删除以下 {len(to_delete)} 条历史记录？\n\n{names}\n\n"
                f"（同时删除对应数据文件，不可恢复）",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No) != QMessageBox.Yes:
            return

        # ── 执行删除：按 timestamp 唯一标识 ──────────────────────
        ts_to_delete = {ts for ts, _, _ in to_delete}
        history_new = [e for e in history if e.get("timestamp") not in ts_to_delete]
        try:
            with open(HISTORY_PATH, "w", encoding="utf-8") as f:
                json.dump(history_new, f, ensure_ascii=False, indent=2)
        except Exception as e:
            QMessageBox.warning(self, "写入失败", f"history.json 写入失败：{e}")
            return

        deleted_files = 0
        skipped_empty = 0
        for ts, fn, _ in to_delete:
            if not fn:
                skipped_empty += 1
                continue
            p = DATA_DIR / fn
            if p.exists():
                try:
                    p.unlink()
                    deleted_files += 1
                except Exception:
                    pass

        self._reload_history_combo()

        # 检测孤立 products_*.json（不在 history 中）
        new_history = self._load_history()
        history_files = {e.get("filename", "") for e in new_history if e.get("filename")}
        all_files = [f for f in DATA_DIR.glob("products_*.json") if _is_main_product_file(f)]
        orphan_files = [f for f in all_files if f.name not in history_files]
        if orphan_files:
            ans = QMessageBox.question(self, "发现孤立数据文件",
                f"磁盘上还有 {len(orphan_files)} 个 products_*.json 没有对应历史记录"
                f"（中间快照 / 旧抓取残留 / checkpoint）。\n\n"
                f"是否一并删除？（保留 products_live.json）",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if ans == QMessageBox.Yes:
                for f in orphan_files:
                    try: f.unlink()
                    except Exception: pass
                deleted_files += len(orphan_files)

        # 重新扫描剩余文件
        remaining_files = sorted(
            [f for f in DATA_DIR.glob("products_*.json") if _is_main_product_file(f)],
            key=lambda f: f.stat().st_mtime
        )
        if remaining_files:
            try:
                with open(remaining_files[-1], encoding="utf-8") as f:
                    new_prods = json.load(f)
                new_prods = _merge_compared_into(new_prods)
                self._all_prods = new_prods
                self._update_filter_cats(new_prods)
                self._apply_filters()
                self.status.showMessage(
                    f"已删除 {len(to_delete)} 条，剩余加载: {remaining_files[-1].name} ({len(new_prods)}条)", 8000)
            except Exception:
                pass
        else:
            # 没有任何产品文件了，清空内存视图
            self._all_prods = []
            self._update_filter_cats([])
            self._apply_filters()

        msg = f"已删除 {len(to_delete)} 条记录，清理 {deleted_files} 个数据文件"
        if skipped_empty:
            msg += f"（{skipped_empty} 条空记录无文件可删）"
        if not remaining_files:
            msg += "\n\n所有数据文件已清空"
        self.status.showMessage(msg, 8000)
        QMessageBox.information(self, "删除完成", msg)

    # ── 类目筛选 ─────────────────────────────────────────────────────────
    def _update_filter_cats(self, products):
        """收集数据中的类目层级，存入 _filter_cat_data，更新弹窗树"""
        l1_set, l2_set, l3_set = set(), set(), set()
        for p in products:
            parts = [x.strip() for x in p.get("category_label", "").split(">") if x.strip()]
            if len(parts) >= 1: l1_set.add(parts[0])
            if len(parts) >= 2: l2_set.add(f"{parts[0]}>{parts[1]}")
            if len(parts) >= 3: l3_set.add(f"{parts[0]}>{parts[1]}>{parts[2]}")
        self._filter_cat_data = (l1_set, l2_set, l3_set)
        # 若弹窗已创建则刷新树内容
        if self._cat_popup:
            self._rebuild_cat_popup_tree()
        # 检查当前筛选键是否还有效
        if self._cat_filter_key:
            all_keys = l1_set | l2_set | l3_set
            if self._cat_filter_key not in all_keys:
                self._cat_filter_key = ""
                self._update_cat_filter_btn()

    def _apply_filters(self):
        filtered = self._all_prods
        # 类目筛选
        if self._cat_filter_key:
            filtered = [p for p in filtered
                        if p.get("category_label", "").startswith(self._cat_filter_key)]
        # 已比价筛选（1688 或 拼多多 有任意一方数据即算已比价）
        if self._compared_only:
            filtered = [p for p in filtered
                        if (p.get("cost_ref") or p.get("supplier_link") or p.get("cost_supplier")
                            or p.get("pdd_price") or p.get("pdd_link"))]
        # 仅未入库:隐藏已进商品库(处理过)的品,避免每次抓新表重复选
        if self._hide_in_library:
            inlib = getattr(self, "_inlib_ids_cache", None)
            if inlib is None:
                inlib = self._inlib_ids_cache = self._inlib_prod_ids()
            filtered = [p for p in filtered if str(p.get("prod_id", "")) not in inlib]
        # 商品名称关键词搜索（多关键词空格分隔，全部命中才保留）
        if self._name_search:
            kws = self._name_search.lower().split()
            filtered = [p for p in filtered
                        if all(kw in (p.get("name", "") or "").lower() for kw in kws)]
        # 表头列筛选（set = 勾选值；str = 文字/范围）
        for key, f in self._strip_filters.items():
            if isinstance(f, set):
                filtered = [p for p in filtered
                            if self._col_value(p, key) in f]
            else:
                filtered = [p for p in filtered
                            if self._match_strip(self._col_value(p, key), str(f))]
        self.products = filtered
        self._fill_table(filtered)
        for b in [self.btn_export_excel, self.btn_export_html, self.btn_clear]:
            b.setEnabled(bool(filtered))
        n_cmp = sum(1 for p in self._all_prods
                    if (p.get("cost_ref") or p.get("supplier_link")
                        or p.get("pdd_price") or p.get("pdd_link")))
        cmp_txt = f"  ·  已比价 {len(filtered)} 件" if self._compared_only else f"  ·  已比价 {n_cmp} 件"
        n_sf = len(self._strip_filters)
        sf_txt = f"  ·  🔍 {n_sf} 列筛选" if n_sf else ""
        srch_txt = f"  ·  搜索: 「{self._name_search}」" if self._name_search else ""
        self.count_label.setText(f"共 {len(filtered)} 条{cmp_txt}{sf_txt}{srch_txt}")
        self.btn_clear_filter.setVisible(bool(n_sf))

    # ── 类目筛选弹窗（树形三级）────────────────────────────────────────────
    def _show_cat_filter_popup(self):
        """首次创建弹窗，后续直接显示"""
        if self._cat_popup is None:
            self._create_cat_popup()
        self._rebuild_cat_popup_tree()
        # 定位到按钮正下方
        btn_pos = self.btn_cat_filter.mapToGlobal(
            self.btn_cat_filter.rect().bottomLeft())
        self._cat_popup.move(btn_pos)
        self._cat_popup.show()
        self._cat_popup.raise_()

    def _create_cat_popup(self):
        """创建弹窗框架（只执行一次）"""
        popup = QFrame(self, Qt.Popup | Qt.FramelessWindowHint)
        popup.setStyleSheet(
            "QFrame{background:white;border:1px solid #D1D5DB;"
            "border-radius:8px;}")
        popup.setFixedWidth(290)

        lay = QVBoxLayout(popup)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(5)

        # 搜索框
        search = QLineEdit()
        search.setPlaceholderText("🔍 搜索类目…")
        search.setStyleSheet(
            "QLineEdit{border:1px solid #D1D5DB;border-radius:5px;"
            "padding:4px 8px;font-size:11px;}")
        search.textChanged.connect(self._on_cat_popup_search)
        lay.addWidget(search)
        self._cat_popup_search = search

        # 全部类目按钮
        btn_all = QPushButton("🏷  全部类目")
        btn_all.setStyleSheet(
            "QPushButton{background:#EEF2FF;color:#4F46C8;border:none;"
            "border-radius:5px;font-size:11px;font-weight:bold;"
            "padding:5px 10px;text-align:left;}"
            "QPushButton:hover{background:#E0E7FF;}")
        btn_all.clicked.connect(lambda: self._set_cat_filter("", "全部类目"))
        lay.addWidget(btn_all)

        # 类目树 — 隐藏默认 branch 箭头，用文字前缀代替
        tree = QTreeWidget()
        tree.setHeaderHidden(True)
        tree.setColumnCount(1)
        tree.setMaximumHeight(420)
        tree.setIndentation(0)           # 取消系统缩进，由文字前缀控制
        tree.setExpandsOnDoubleClick(False)  # 禁止双击展开，全走单击
        tree.setStyleSheet("""
            QTreeWidget {
                border: 1px solid #E5E7EB; border-radius: 6px;
                background: white; font-size: 11px; outline: none;
            }
            QTreeWidget::item { padding: 4px 6px; }
            QTreeWidget::item:hover { background: #EEF2FF; }
            QTreeWidget::item:selected { background: #4F46C8; color: white; }
            QTreeWidget::branch { width: 0px; }
        """)
        tree.itemClicked.connect(self._on_cat_popup_item_clicked)
        lay.addWidget(tree)
        self._cat_popup_tree = tree

        self._cat_popup = popup

    # UserRole   = filter key (e.g. "美妆>彩妆")
    # UserRole+1 = clean name (e.g. "彩妆")
    # UserRole+2 = level  (0=L1, 1=L2, 2=L3)
    _L1_ICON  = "🔶"   # 橙色菱形 — 一级
    _L2_DOT   = "🔹"   # 蓝色菱形 — 二级
    _L3_DOT   = "  ·"  # 灰色点   — 三级

    def _item_display(self, level: int, name: str, expanded: bool = False) -> str:
        if level == 0:
            arrow = "▼ " if expanded else "▶ "
            return f"{self._L1_ICON} {arrow}{name}"
        elif level == 1:
            arrow = "▼ " if expanded else "▶ "
            return f"  {self._L2_DOT} {arrow}{name}"
        else:
            return f"    {self._L3_DOT} {name}"

    def _rebuild_cat_popup_tree(self):
        """用 _filter_cat_data 重建弹窗树内容"""
        if not hasattr(self, "_filter_cat_data"):
            return
        l1_set, l2_set, l3_set = self._filter_cat_data
        tree = self._cat_popup_tree
        tree.blockSignals(True)
        tree.clear()

        for l1 in sorted(l1_set):
            has_l2 = any(p.startswith(l1 + ">") for p in l2_set)
            l1_item = QTreeWidgetItem([self._item_display(0, l1, False)])
            l1_item.setData(0, Qt.UserRole,     l1)
            l1_item.setData(0, Qt.UserRole + 1, l1)
            l1_item.setData(0, Qt.UserRole + 2, 0)
            f = l1_item.font(0); f.setBold(True); l1_item.setFont(0, f)
            l1_item.setForeground(0, QColor("#92400E"))

            for l2_path in sorted(p for p in l2_set if p.startswith(l1 + ">")):
                l2_name = l2_path.split(">")[1]
                has_l3  = any(p.startswith(l2_path + ">") for p in l3_set)
                l2_item = QTreeWidgetItem([self._item_display(1, l2_name, False)])
                l2_item.setData(0, Qt.UserRole,     l2_path)
                l2_item.setData(0, Qt.UserRole + 1, l2_name)
                l2_item.setData(0, Qt.UserRole + 2, 1)
                l2_item.setForeground(0, QColor("#1E40AF"))

                for l3_path in sorted(p for p in l3_set if p.startswith(l2_path + ">")):
                    l3_name = l3_path.split(">")[2]
                    l3_item = QTreeWidgetItem([self._item_display(2, l3_name)])
                    l3_item.setData(0, Qt.UserRole,     l3_path)
                    l3_item.setData(0, Qt.UserRole + 1, l3_name)
                    l3_item.setData(0, Qt.UserRole + 2, 2)
                    l3_item.setForeground(0, QColor("#4B5563"))
                    l2_item.addChild(l3_item)

                l1_item.addChild(l2_item)

            tree.addTopLevelItem(l1_item)

        tree.collapseAll()
        self._highlight_cat_popup_current()
        tree.blockSignals(False)

    def _highlight_cat_popup_current(self):
        """展开并选中当前筛选项"""
        key = self._cat_filter_key
        if not key:
            return
        def _find(item):
            if item.data(0, Qt.UserRole) == key:
                item.setSelected(True)
                p = item.parent()
                while p:
                    if not p.isExpanded():
                        p.setExpanded(True)
                        lv = p.data(0, Qt.UserRole + 2) or 0
                        nm = p.data(0, Qt.UserRole + 1) or ""
                        p.setText(0, self._item_display(lv, nm, True))
                    p = p.parent()
                return True
            for i in range(item.childCount()):
                if _find(item.child(i)):
                    return True
            return False
        for i in range(self._cat_popup_tree.topLevelItemCount()):
            _find(self._cat_popup_tree.topLevelItem(i))

    def _on_cat_popup_item_clicked(self, item, col):
        level = item.data(0, Qt.UserRole + 2) or 0
        name  = item.data(0, Qt.UserRole + 1) or item.text(0)
        key   = item.data(0, Qt.UserRole) or ""

        if item.childCount() > 0:
            # 有子节点：展开/收起，弹窗保持打开，仅静默更新筛选
            expanded = not item.isExpanded()
            item.setExpanded(expanded)
            item.setText(0, self._item_display(level, name, expanded))
            # 静默更新筛选（不关闭弹窗）
            self._cat_filter_key = key
            self._update_cat_filter_btn()
            self._apply_filters()
        else:
            # 叶子节点（L3 或无子节点的 L2）：筛选 + 关闭弹窗
            self._set_cat_filter(key, name)

    def _on_cat_popup_search(self, text):
        """搜索时展开匹配项"""
        t = text.strip().lower()
        def _filter(item):
            nm    = item.data(0, Qt.UserRole + 1) or ""
            match = (not t) or (t in nm.lower())
            child_vis = False
            for i in range(item.childCount()):
                cv = _filter(item.child(i))
                child_vis = child_vis or cv
            visible = match or child_vis
            item.setHidden(not visible)
            if child_vis and not item.isExpanded():
                item.setExpanded(True)
                lv = item.data(0, Qt.UserRole + 2) or 0
                item.setText(0, self._item_display(lv, nm, True))
            return visible
        for i in range(self._cat_popup_tree.topLevelItemCount()):
            _filter(self._cat_popup_tree.topLevelItem(i))

    def _set_cat_filter(self, key: str, label: str):
        """设置类目筛选键，更新按钮，刷新表格"""
        self._cat_filter_key = key
        self._update_cat_filter_btn()
        if self._cat_popup:
            self._cat_popup.hide()
        self._apply_filters()

    def _update_cat_filter_btn(self):
        if self._cat_filter_key:
            # 只显示最末一级名称，避免按钮太长
            short = self._cat_filter_key.split(">")[-1]
            self.btn_cat_filter.setText(f"{short}  ▾")
            self.btn_cat_filter.setProperty("active", "true")
        else:
            self.btn_cat_filter.setText("全部类目  ▾")
            self.btn_cat_filter.setProperty("active", "false")
        # 强制刷新样式
        self.btn_cat_filter.style().unpolish(self.btn_cat_filter)
        self.btn_cat_filter.style().polish(self.btn_cat_filter)

    # ── 定时采集 ─────────────────────────────────────────────────────────
    def _setup_scheduler(self):
        self._sched_timer = QTimer(self)
        self._sched_timer.timeout.connect(self._check_schedule)
        self._sched_timer.start(60_000)   # 每分钟检查一次

    def _check_schedule(self):
        if not self.cb_schedule.isChecked():
            return
        if self.thread and self.thread.isRunning():
            return
        now = datetime.now()
        t   = self.sched_time.time()
        if now.hour == t.hour() and now.minute == t.minute():
            self.log.appendHtml(
                '<span style="color:#FBBF24;font-weight:bold">'
                '⏰ 定时任务触发，开始采集...</span>')
            self.start_scrape()

    def _on_schedule_changed(self):
        if not self.cb_schedule.isChecked():
            self.sched_next_lbl.setText("下次运行: --")
            return
        t   = self.sched_time.time()
        now = datetime.now()
        nxt = now.replace(hour=t.hour(), minute=t.minute(), second=0, microsecond=0)
        if nxt <= now:
            nxt += timedelta(days=1)
        self.sched_next_lbl.setText(f"下次: {nxt.strftime('%m-%d %H:%M')}")

    # ── 抓取控制 ──────────────────────────────────────────────────────────
    def start_scrape(self):
        try:
            combos = self._get_selected_combos()
            if not self._tree_data:
                ret = QMessageBox.question(
                    self, "未扫描类目",
                    "尚未加载类目数据。\n\n"
                    "点击「是」自动发现所有类目并抓取\n"
                    "点击「否」先点「🔍 扫描/更新类目」",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if ret == QMessageBox.No:
                    return
                combos = []
            elif not combos:
                QMessageBox.warning(self, "提示", "当前筛选条件下无可用类目")
                return

            year  = self.year_spin.value()
            month = self.month_combo.currentData()
            self._last_combos = combos
            self._last_year   = year
            self._last_month  = month

            # 保存本次类目选择，供下次"复用上次"使用
            if combos:
                try:
                    with open(CAT_SEL_PATH, "w", encoding="utf-8") as _sf:
                        json.dump(combos, _sf, ensure_ascii=False, indent=2)
                    self.btn_restore_cats.setEnabled(True)
                except Exception:
                    pass

            self.log.clear()
            self.table.setRowCount(0)
            self.products = []
            self._all_prods = []
            self._update_count()
            self.progress.setVisible(True)
            self.btn_start.setEnabled(False)
            self.btn_scan.setEnabled(False)
            self.btn_stop.setEnabled(True)
            for b in [self.btn_export_excel, self.btn_export_html, self.btn_clear]:
                b.setEnabled(False)
            n_info = f"{len(combos)} 个三级类目" if combos else "全部类目"
            self.status.showMessage(f"正在抓取 {n_info}…")

            period = self.period_combo.currentText() if hasattr(self, 'period_combo') else "今天"
            self.thread = ScraperThread(combos, year, month, period=period)
            self.thread.log_signal.connect(self._on_log)
            self.thread.done_signal.connect(self._on_done)
            self.thread.error_signal.connect(self._on_error)
            self.thread.start()
        except Exception:
            QMessageBox.critical(self, "启动失败", traceback.format_exc()[:2000])
            self._set_idle("启动失败")

    def stop_scrape(self):
        if self.thread:
            self.thread.stop()
            self.thread.quit()
        self._set_idle("已停止")

    def _set_idle(self, msg="就绪"):
        self.progress.setVisible(False)
        self.btn_start.setEnabled(True)
        self.btn_scan.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.status.showMessage(msg)

    # ── 信号处理 ──────────────────────────────────────────────────────────
    def _on_log(self, line):
        try:
            # 特殊控制信号:ScrapeWorker 子进程 stdout 直接重定向到 log 文件后,
            # 主线程不接收每行 log,改用 QTimer tail 文件展示。这两条信号控制 tail 起止。
            if line.startswith("__SCRAPE_LOG_START__:"):
                self._scrape_log_path = line.split(":", 1)[1]
                self._scrape_log_offset = 0
                if not hasattr(self, "_scrape_tail_timer"):
                    from PyQt5.QtCore import QTimer
                    self._scrape_tail_timer = QTimer(self)
                    self._scrape_tail_timer.setInterval(800)
                    self._scrape_tail_timer.timeout.connect(self._tail_scrape_log)
                self._scrape_tail_timer.start()
                self.log.appendPlainText(f"[log] 落盘 + 实时 tail: {self._scrape_log_path}")
                return
            if line.startswith("__SCRAPE_LOG_END__:"):
                # 子进程退出,跑一次 tail 拿剩余字节,然后停 timer
                self._tail_scrape_log()
                if hasattr(self, "_scrape_tail_timer"):
                    self._scrape_tail_timer.stop()
                self.log.appendPlainText(line.replace("__SCRAPE_LOG_END__:", "[log] "))
                return
            # 兼容旧路径(其他线程可能直接 emit 单行)
            esc = _esc(line)
            if "[OK]" in line or "完成" in line:
                self.log.appendHtml(f'<span style="color:#4ADE80">{esc}</span>')
            elif "[!]" in line or "失败" in line or "Error" in line:
                self.log.appendHtml(f'<span style="color:#F87171">{esc}</span>')
            elif line.startswith("===") or "发现子类目" in line or "扫描:" in line:
                self.log.appendHtml(
                    f'<span style="color:#FBBF24;font-weight:bold">{esc}</span>')
            elif "第" in line and "页" in line:
                self.log.appendHtml(f'<span style="color:#60A5FA">{esc}</span>')
            else:
                self.log.appendPlainText(line)
            sb = self.log.verticalScrollBar()
            sb.setValue(sb.maximum())
            if "新增" in line and "条" in line:
                self._reload_live_data()
        except Exception:
            pass

    def _tail_scrape_log(self):
        """每 800ms 跑一次,读 scrape log 增量,append 到 self.log。
        子进程 stdout 直接写文件(不经过 Qt 信号),tail 完全解耦,主线程压力恒定。
        """
        path = getattr(self, "_scrape_log_path", "")
        if not path:
            return
        try:
            from pathlib import Path as _P
            p = _P(path)
            if not p.exists():
                return
            size = p.stat().st_size
            offset = getattr(self, "_scrape_log_offset", 0)
            if size <= offset:
                return
            with open(p, "rb") as f:
                f.seek(offset)
                chunk = f.read()
            self._scrape_log_offset = size
            text = chunk.decode("utf-8", errors="replace")
            # 按行 append,触发 reload_live_data 检测
            for line in text.splitlines():
                if not line:
                    continue
                if "[OK]" in line or "完成" in line:
                    self.log.appendHtml(f'<span style="color:#4ADE80">{_esc(line)}</span>')
                elif "[!]" in line or "失败" in line or "Error" in line:
                    self.log.appendHtml(f'<span style="color:#F87171">{_esc(line)}</span>')
                elif line.startswith("===") or "发现子类目" in line or "扫描:" in line:
                    self.log.appendHtml(f'<span style="color:#FBBF24;font-weight:bold">{_esc(line)}</span>')
                elif "第" in line and "页" in line:
                    self.log.appendHtml(f'<span style="color:#60A5FA">{_esc(line)}</span>')
                else:
                    self.log.appendPlainText(line)
                if "新增" in line and "条" in line:
                    try: self._reload_live_data()
                    except Exception: pass
            sb = self.log.verticalScrollBar()
            sb.setValue(sb.maximum())
        except Exception:
            pass

    def _reload_live_data(self):
        # throttle: 每 10 次调用才真正跑一次(避免每个类目都重读 disk + 重渲染表格
        # 导致主线程长时间高负载 → Windows 检测无响应关闭)
        self._live_reload_counter = getattr(self, "_live_reload_counter", 0) + 1
        if self._live_reload_counter < 10:
            return
        self._live_reload_counter = 0
        live = DATA_DIR / "products_live.json"
        if not live.exists():
            return
        try:
            with open(live, encoding="utf-8") as f:
                products = json.load(f)
            if products:
                self._all_prods = products
                self._update_filter_cats(products)
                self._apply_filters()
                self.status.showMessage(f"实时更新 — 目标月份商品 {len(products)} 条")
        except Exception:
            pass

    def _on_done(self, products):
        self._all_prods = products
        self._update_filter_cats(products)
        self._apply_filters()
        self._set_idle(f"完成 — 共 {len(products)} 条商品")
        # 注意：不再单独 _write_history_entry —— main.py 的 _finalize 已写过
        # 否则会产生重复条目（同 fn / 不同 ts）
        if products:
            self._reload_history_combo()

    def _on_error(self, msg):
        self.log.appendHtml(f'<span style="color:#F87171">[错误] {_esc(msg)}</span>')
        self._set_idle("出错，请查看日志")

    # ── 1688比价 ──────────────────────────────────────────────────────────
    def _on_table_context_menu(self, pos):
        row = self.table.rowAt(pos.y())
        if row < 0:
            return
        # 用稳定索引取商品（排序后也正确）
        prod, prod_idx = self._prod_from_row(row)
        if prod is None:
            return
        menu = QMenu(self)

        act_cmp = QAction("🔍 查1688比价", self)
        act_cmp.triggered.connect(
            lambda checked=False, idx=prod_idx: self._start_price_compare(idx))
        menu.addAction(act_cmp)

        act_pdd = QAction("🛒 查拼多多比价", self)
        act_pdd.triggered.connect(
            lambda checked=False, idx=prod_idx: self._start_pdd_compare(idx))
        menu.addAction(act_pdd)

        # 已有比价数据时显示编辑/清除选项
        has_1688 = bool(prod.get("cost_ref") or prod.get("supplier_link"))
        has_pdd  = bool(prod.get("pdd_price") or prod.get("pdd_link"))

        if has_1688 or has_pdd:
            menu.addSeparator()

        if has_1688:
            act_link = QAction("✏ 修改1688供货链接", self)
            act_link.triggered.connect(
                lambda checked=False, idx=prod_idx: self._edit_supplier_link(idx))
            menu.addAction(act_link)

            act_clear = QAction("🗑 清除1688比价数据", self)
            act_clear.triggered.connect(
                lambda checked=False, idx=prod_idx: self._clear_row_compare(idx))
            menu.addAction(act_clear)

        if has_pdd:
            act_pdd_clear = QAction("🗑 清除拼多多比价数据", self)
            act_pdd_clear.triggered.connect(
                lambda checked=False, idx=prod_idx: self._clear_row_pdd_compare(idx))
            menu.addAction(act_pdd_clear)

        # 有供货链接时显示资料下载选项
        if prod.get("supplier_link"):
            menu.addSeparator()
            act_dl = QAction("📦 下载供应商品资料", self)
            act_dl.triggered.connect(
                lambda checked=False, idx=prod_idx: self._start_supplier_download(idx))
            menu.addAction(act_dl)

            # 已有资料包时显示「打开文件夹」
            data_path = prod.get("data_path", "")
            if data_path and Path(data_path).exists():
                act_open = QAction("📁 打开资料文件夹", self)
                folder = data_path
                act_open.triggered.connect(lambda checked=False, f=folder: os.startfile(f))
                menu.addAction(act_open)

        menu.exec_(self.table.viewport().mapToGlobal(pos))

    def _edit_supplier_link(self, prod_idx: int):
        """弹出输入框修改供货链接（prod_idx 为 _all_prods 中的稳定索引）"""
        from PyQt5.QtWidgets import QInputDialog
        if prod_idx < 0 or prod_idx >= len(self._all_prods):
            return
        prod = self._all_prods[prod_idx]
        old = prod.get("supplier_link", "")
        new_url, ok = QInputDialog.getText(
            self, "修改供货链接", "请输入新的1688供货链接：", text=old)
        if not ok:
            return
        self._all_prods[prod_idx]["supplier_link"] = new_url.strip()
        self._save_current_data()
        self._apply_filters()
        self.status.showMessage(f"供货链接已更新：{prod.get('name','')[:20]}")

    def _clear_row_compare(self, prod_idx: int):
        """清除单行的1688比价数据（prod_idx 为 _all_prods 中的稳定索引）"""
        if prod_idx < 0 or prod_idx >= len(self._all_prods):
            return
        prod = self._all_prods[prod_idx]
        name = prod.get("name", "")
        if QMessageBox.question(
                self, "确认清除",
                f"清除【{name[:25]}】的1688比价数据？",
                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        for f in ("cost_ref", "cost_supplier", "cost_top3_str",
                  "supplier_link", "img_search_url"):
            self._all_prods[prod_idx][f] = ""
        self._save_current_data()
        self._apply_filters()
        self.status.showMessage(f"已清除：{name[:25]}")

    # ── 供应商资料下载 ────────────────────────────────────────────────────────
    def _start_supplier_download(self, prod_idx: int):
        """下载供应商资料（prod_idx 为 _all_prods 中的稳定索引）"""
        if prod_idx < 0 or prod_idx >= len(self._all_prods):
            return
        prod = self._all_prods[prod_idx]
        supplier_url = prod.get("supplier_link", "")
        if not supplier_url:
            QMessageBox.warning(self, "无法下载", "该商品无1688供货链接，请先进行比价获取供货链接")
            return
        name = prod.get("name", "product")
        # 已有资料包：询问是否重新下载
        existing = prod.get("data_path", "")
        if existing and Path(existing).exists():
            reply = QMessageBox.question(
                self, "已有资料包",
                f"【{name[:25]}】已有资料包：\n{existing}\n\n是否重新下载（会新建文件夹，不覆盖旧数据）？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply != QMessageBox.Yes:
                return
        self.status.showMessage(f"正在下载供应商品资料：{name[:20]}…（请稍候）")
        if not hasattr(self, "_supplier_dl_threads"):
            self._supplier_dl_threads = []
        t = SupplierDownloadThread(prod_idx, supplier_url, name)
        t.done_signal.connect(self._on_supplier_download_done)
        t.error_signal.connect(self._on_supplier_download_error)
        t.finished.connect(lambda thread=t: self._supplier_dl_threads.remove(thread)
                           if thread in self._supplier_dl_threads else None)
        self._supplier_dl_threads.append(t)
        t.start()

    def _on_supplier_download_done(self, prod_idx: int, result: dict):
        if "error" in result:
            self._on_supplier_download_error(prod_idx, result["error"])
            return
        if prod_idx < len(self._all_prods):
            prod = self._all_prods[prod_idx]
            prod["data_path"] = result.get("folder", "")
            self._save_current_data()
            self._apply_filters()
            name    = prod.get("name", "")
            summary = result.get("summary", "")
            self.status.showMessage(f"资料下载完成：{name[:20]}  {summary}")
            QMessageBox.information(
                self, "下载完成",
                f"✅ {name[:30]}\n\n"
                f"📁 保存路径：\n{result.get('folder', '')}\n\n"
                f"🖼 图片数量：{summary}\n\n"
                f"右键商品 → 「📁 打开资料文件夹」可查看")

    def _on_supplier_download_error(self, prod_idx: int, msg: str):
        if prod_idx < len(self._all_prods):
            name = self._all_prods[prod_idx].get("name", f"索引{prod_idx}")
        else:
            name = f"索引{prod_idx}"
        self.status.showMessage(f"资料下载失败：{name[:20]} — {msg[:60]}")
        QMessageBox.warning(self, "下载失败",
                            f"供应商品资料下载失败：\n\n{msg[:400]}")

    # ── 勾选辅助 ──────────────────────────────────────────────────────────
    def _get_checkbox(self, row: int):
        """返回第0列的 QCheckBox（从居中 wrapper 里取）"""
        w = self.table.cellWidget(row, 0)
        if isinstance(w, QCheckBox):
            return w
        if w is not None:
            cb = w.findChild(QCheckBox)
            return cb
        return None

    def _select_all_rows(self):
        for r in range(self.table.rowCount()):
            cb = self._get_checkbox(r)
            if cb:
                cb.setChecked(True)

    def _deselect_all_rows(self):
        for r in range(self.table.rowCount()):
            cb = self._get_checkbox(r)
            if cb:
                cb.setChecked(False)

    def _inlib_prod_ids(self) -> set:
        """商品库里已有的 prod_id 集合(已处理/已入库的品),用于去重/跳过。"""
        try:
            return {str(r.get("prod_id", "")) for r in product_library.load_library()
                    if r.get("prod_id")}
        except Exception:
            return set()

    def _xuanpin_auto_run(self):
        """🤖全自动跑品:智能选品(挑Top-N未入库)→ 一键跑品(走同一弹窗,跑哪几步含⑥开车看弹窗勾选:
        比价→核对→发布→换主图→补视频→自动推广开车)。一键到底、无人值守。"""
        if getattr(self, "_oc_running", False):
            QMessageBox.information(self, "全自动跑品", "已有一键跑品在跑,请等它完成或停止。")
            return
        self._auto_full = True
        self._auto_license_tried = False   # 本次全自动:允许自动核对一次备案号
        w = getattr(self, "pdd_pending_chk_auto", None)   # 同步勾上待发布页「全自动」开关
        if w is not None:
            try:
                w.setChecked(True)
            except Exception:
                pass
        if self._smart_pick() is False:        # 弹窗填N + 勾Top-N未入库;取消/没挑到 → 不跑
            return
        if not self._get_checked_rows():
            return
        self._xuanpin_oneclick_start()         # 进全自动链(比价→核对→发布→换主图→补视频)

    def _smart_pick(self):
        """智能选品:把当前(筛选后)列表按推荐分降序 + 自动勾选前 N 个【未入库】新品。
        已入商品库(处理过)的自动跳过,避免每次抓新表重复选。
        用 Python 排序+重渲染(不用 Qt sortItems,后者不动勾选框会错位)。"""
        base = getattr(self, "products", None) or self._all_prods
        if not base:
            QMessageBox.information(self, "智能选品", "请先加载选品数据")
            return
        from PyQt5.QtWidgets import QInputDialog
        n, ok = QInputDialog.getInt(
            self, "🎯 智能选品", "按推荐分从高到低,自动勾选前几个【未入库新品】?",
            min(30, len(base)), 1, len(base))
        if not ok:
            return False
        for p in base:
            if not isinstance(p.get("_reco"), dict):
                p["_reco"] = xuanpin_reco.score_product(p)
        ranked = sorted(base, key=lambda p: p["_reco"].get("score", 0), reverse=True)
        self.products = ranked
        self._fill_table(ranked)
        # 勾选前 N 个未入库的;已入库的跳过(不占名额)
        inlib = self._inlib_prod_ids()
        cnt = skipped = 0
        for r in range(self.table.rowCount()):
            if cnt >= n:
                break
            prod, _ = self._prod_from_row(r)
            if prod and str(prod.get("prod_id", "")) in inlib:
                skipped += 1
                continue
            cb = self._get_checkbox(r)
            if cb:
                cb.setChecked(True)
                cnt += 1
        msg = f"🎯 智能选品:按推荐分排序,勾选前 {cnt} 个未入库新品"
        if skipped:
            msg += f"(跳过 {skipped} 个已入商品库)"
        self.status.showMessage(msg + " · 可直接「批量比价」或「一键跑品」")
        return cnt > 0

    def _toggle_all_rows(self):
        """点表头☑列 → 如果全选则取消全选，否则全选"""
        cbs = [self._get_checkbox(r) for r in range(self.table.rowCount())]
        cbs = [cb for cb in cbs if cb]
        all_checked = all(cb.isChecked() for cb in cbs) if cbs else False
        for cb in cbs:
            cb.setChecked(not all_checked)

    def _get_checked_rows(self):
        """返回所有勾选行的行号列表"""
        return [r for r in range(self.table.rowCount())
                if (cb := self._get_checkbox(r)) and cb.isChecked()]

    def _xuanpin_add_to_library(self):
        """选品区【📚 加入商品库】:勾选商品 → 加入 PDD 商品库(按 prod_id 去重合并),不跑比价/发布。
        无图的也入库,只提示(后续比价前需补图);入库后自动跳到商品库页。"""
        rows = self._get_checked_rows()
        if not rows:
            QMessageBox.information(self, "加入商品库", "请先勾选要入库的商品(行左侧复选框 / 点【全选】)")
            return
        if not hasattr(self, "_pdd_lib_records") or self._pdd_lib_records is None:
            self._pdd_lib_records = product_library.load_library()
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        new_recs, no_img = [], 0
        for r in rows:
            prod, _idx = self._prod_from_row(r)
            if prod is None:
                continue
            if not prod.get("image"):
                no_img += 1
            img = (prod.get("image", "") or "").strip()
            img_local = img if img and Path(img).exists() else ""
            img_url = "" if img_local else img
            new_recs.append({
                "prod_id":      str(prod.get("prod_id") or prod.get("ID") or ""),
                "name":         prod.get("name", ""),
                "image":        img_url,
                "image_local":  img_local,
                "price_range":  prod.get("price_range", ""),
                "category":     prod.get("category_label") or prod.get("category") or "",
                "shop_name":    prod.get("store_name") or prod.get("shop_name") or "",
                "shop_id":      str(prod.get("shop_id") or ""),
                "pdd_link":     prod.get("link", ""),
                "first_listed": prod.get("first_online") or prod.get("first_listed") or "",
                "source":       "auto",
                "added_time":   now,
            })
        if not new_recs:
            QMessageBox.information(self, "加入商品库", "勾选的商品没有可入库的数据。")
            return
        try:
            self._pdd_lib_records, added, merged = product_library.bulk_add(
                self._pdd_lib_records, new_recs, merge=True)
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "加入商品库", f"写入商品库失败:\n{e}")
            return
        self._inlib_ids_cache = None
        # ★丝滑:入库本身只 ~47ms;不自动跳商品库(那会触发重建上百行库表=卡顿根源)。
        #   反馈用按钮短暂变文字(非阻塞),完整信息放 tooltip;想看库自己点过去。
        _b = self.btn_xuanpin_addlib
        _b.setText(f"✓ 已入库 {added}")
        _b.setToolTip(f"已加入商品库:新增 {added} 条,已在库(合并){merged} 条"
                      + (f";其中 {no_img} 条无图(比价前需补图)" if no_img else "")
                      + "。到「🛒 PDD自动上架 → 📚 商品库」查看。")
        QTimer.singleShot(2500, lambda: (_b.setText("📚 加入商品库"),
                                         _b.setToolTip("把勾选商品加入 PDD 商品库(按商品ID去重合并),不跑比价/发布。")))
        # 「🆕仅未入库」开启时:刷新选品表隐去刚入库的(选品表本身分批渲染,不冻);延后做
        if getattr(self, "_hide_in_library", False):
            QTimer.singleShot(0, self._apply_filters)

    def _xuanpin_oneclick_start(self):
        """选品区【🚀 一键跑品】:勾选商品 → 同步进商品库 → 复用商品库一键跑品引擎
        (比价→货品核对闸门→发布)。避免「选品比价 + 商品库再比价」重复比价。"""
        if getattr(self, "_oc_running", False):
            QMessageBox.information(self, "一键跑品", "已有一键跑品任务在进行中,请等它跑完或停止。")
            return
        rows = self._get_checked_rows()
        if not rows:
            QMessageBox.information(self, "一键跑品", "请先勾选要跑的商品(行左侧复选框 / 点【全选】)")
            return
        # 选品商品 → 商品库 record 格式(字段映射同 _pdd_library_sync_from_compared)
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        new_recs, skip_noimg = [], 0
        for r in rows:
            prod, _idx = self._prod_from_row(r)
            if prod is None:
                continue
            if not prod.get("image"):
                skip_noimg += 1
                continue
            img = (prod.get("image", "") or "").strip()
            img_local = img if img and Path(img).exists() else ""
            img_url = "" if img_local else img
            new_recs.append({
                "prod_id":      str(prod.get("prod_id") or prod.get("ID") or ""),
                "name":         prod.get("name", ""),
                "image":        img_url,
                "image_local":  img_local,
                "price_range":  prod.get("price_range", ""),
                "category":     prod.get("category_label") or prod.get("category") or "",
                "shop_name":    prod.get("store_name") or prod.get("shop_name") or "",
                "shop_id":      str(prod.get("shop_id") or ""),
                "pdd_link":     prod.get("link", ""),
                "first_listed": prod.get("first_online") or prod.get("first_listed") or "",
                "source":       "auto",
                "added_time":   now,
            })
        if not new_recs:
            QMessageBox.warning(self, "一键跑品", f"勾选的 {len(rows)} 件商品均无图片,无法以图搜款比价。")
            return
        # 同步进商品库(merge=True 去重)
        try:
            self._pdd_lib_records, added, merged = product_library.bulk_add(
                self._pdd_lib_records, new_recs, merge=True)
            product_library.save_library(self._pdd_lib_records)
        except Exception as e:
            QMessageBox.critical(self, "一键跑品", f"同步进商品库失败:\n{e}")
            return
        # 取出刚同步的这批库记录(按 prod_id 匹配),传给商品库一键跑品引擎
        want_pids = {rec["prod_id"] for rec in new_recs if rec["prod_id"]}
        run_recs = [r for r in self._pdd_lib_records if str(r.get("prod_id", "")) in want_pids]
        if not run_recs:
            QMessageBox.warning(self, "一键跑品", "同步后未能在商品库匹配到这批商品,请到商品库手动跑。")
            return
        tip = f"已同步 {added} 新增 / {merged} 更新 进商品库"
        if skip_noimg:
            tip += f",跳过 {skip_noimg} 件无图"
        self.status.showMessage(tip)
        # 复用商品库一键跑品引擎(它会再弹「选店铺+规则+份数」并逐条比价→闸门→发布)
        self._pdd_oneclick_start(records=run_recs)

    # ── 批量比价 ──────────────────────────────────────────────────────────
    def _start_bulk_compare(self):
        rows = self._get_checked_rows()
        if not rows:
            QMessageBox.information(self, "提示", "请先勾选要比价的商品（点击每行左侧复选框，或点【全选】按钮）")
            return

        tasks = []
        skip  = 0
        for r in rows:
            # 用稳定索引，排序后也能取到正确商品
            prod, prod_idx = self._prod_from_row(r)
            if prod is None:
                continue
            img = (prod.get("image", "") or "").strip()
            if not img:
                skip += 1
                continue
            img_path = img if Path(img).exists() else ""
            img_url = "" if img_path else img
            tasks.append((prod_idx, img_url, img_path, prod.get("name", "")))

        if not tasks:
            QMessageBox.warning(self, "无法比价", f"勾选的 {len(rows)} 件商品均无图片，无法以图搜图")
            return

        msg = f"即将批量比价 {len(tasks)} 件商品"
        if skip:
            msg += f"（跳过 {skip} 件无图商品）"
        msg += f"\n\n每次查询间隔 12~22 秒（防反爬），预计需要约 {len(tasks)*17//60+1} 分钟。\n\n确认开始？"
        if QMessageBox.question(self, "批量比价确认", msg,
                                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return

        mode = ask_compare_mode(self, "选品批量比价 — 选择比价方式")
        if not mode:
            return
        self._compare_mode = mode

        self._bulk_thread = BulkPriceCompareThread(
            tasks, show_browser=getattr(self, "_pdd_show_browser_flag", False), mode=mode)
        self._bulk_thread.progress.connect(self._on_bulk_progress)
        self._bulk_thread.item_done.connect(self._on_bulk_item_done)
        self._bulk_thread.item_error.connect(self._on_bulk_item_error)
        self._bulk_thread.all_done.connect(self._on_bulk_all_done)
        self._bulk_thread.start()

        self.btn_bulk_cmp.setEnabled(False)
        self.btn_bulk_stop.setEnabled(True)
        self.status.showMessage(f"批量比价已启动，共 {len(tasks)} 件…")

    def _stop_bulk_compare(self):
        t = getattr(self, "_bulk_thread", None)
        if t and t.isRunning():
            t.request_stop()
        self.btn_bulk_stop.setEnabled(False)
        self.status.showMessage("正在停止批量比价…")

    def _on_bulk_progress(self, done: int, total: int, name: str):
        self.status.showMessage(
            f"批量比价进度 {done}/{total}：正在查 {name[:20]}…")

    def _on_bulk_item_done(self, prod_idx: int, result: dict):
        prod = self._all_prods[prod_idx]
        prod["cost_ref"]       = result.get("cost_ref", "")
        prod["cost_supplier"]  = result.get("cost_supplier", "")
        prod["cost_top3_str"]  = result.get("cost_top3_str", "")
        prod["img_search_url"] = result.get("img_search_url", "")
        prod["supplier_link"]  = result.get("supplier_link", "")
        # 新增:候选列表+封面图+自动告警(供同款核对/手动比价用)
        cands = result.get("candidates", []) or []
        prod["candidates"]     = cands
        prod["cost_image"]     = (cands[0].get("image") if cands else "") or ""
        prod["auto_note"]      = result.get("auto_note", "")
        # 比价时视觉同款结论(同款/不确定/"")→ 随商品同步进库,免再人工核对
        prod["same_style"]        = result.get("same_style", "")
        prod["same_style_reason"] = result.get("same_style_reason", "")
        if result.get("same_style"):
            prod["same_style_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._save_current_data()
        _update_compared_store(prod)  # 独立存储
        self._apply_filters()

    def _on_bulk_item_error(self, prod_idx: int, msg: str):
        name = self._all_prods[prod_idx].get("name", f"索引{prod_idx}")
        self.status.showMessage(f"比价失败: {name[:20]} — {msg[:60]}")

    def _on_bulk_all_done(self, success: int, fail: int):
        self.btn_bulk_cmp.setEnabled(True)
        self.btn_bulk_stop.setEnabled(False)
        self._apply_filters()
        # 整批比价跑完 → 关掉比价 debug Chrome(中途复用保持快,跑完才关)
        try:
            self._pdd_close_compare_browser()
        except Exception as e:
            print(f"[批量比价] 关闭比价浏览器失败(不影响结果): {e}")
        QMessageBox.information(
            self, "批量比价完成",
            f"✅ 成功：{success} 件\n❌ 失败：{fail} 件\n\n数据已自动保存。")

    # ── 已比价切换筛选 ────────────────────────────────────────────────
    def _toggle_compared_filter(self):
        self._compared_only = self.btn_compared.isChecked()
        self.btn_del_compared.setEnabled(self._compared_only)
        self._apply_filters()
        if self._compared_only:
            n = len(self.products)
            self.status.showMessage(
                f"已比价模式：共 {n} 件  ·  勾选后可批量删除比价数据  "
                f"·  双击单元格可编辑")
        else:
            self.status.showMessage("已退出已比价模式，显示全部商品")

    def _toggle_inlib_filter(self):
        """切换"仅未入库":隐藏已进商品库(处理过)的品。打开时刷新一次商品库 id。"""
        self._hide_in_library = self.btn_inlib.isChecked()
        if self._hide_in_library:
            self._inlib_ids_cache = self._inlib_prod_ids()
        self._apply_filters()
        if self._hide_in_library:
            self.status.showMessage("🆕 仅未入库:已隐藏进过商品库的重复品,只看新品")
        else:
            self.status.showMessage("已退出「仅未入库」模式,显示全部")

    def _delete_selected_compared(self):
        """删除勾选行的比价数据（从 compared_products.json 移除，并清空当前 _all_prods 对应字段）"""
        rows = self._get_checked_rows()
        if not rows:
            QMessageBox.information(self, "提示", "请先勾选要删除比价数据的商品")
            return
        # 取真实 prod 列表
        prods_to_clean = []
        for r in rows:
            prod, _ = self._prod_from_row(r)
            if prod:
                prods_to_clean.append(prod)
        if not prods_to_clean:
            return
        names = "\n".join(f"  • {p.get('name','')[:30]}" for p in prods_to_clean[:8])
        more = f"\n…还有 {len(prods_to_clean)-8} 件" if len(prods_to_clean) > 8 else ""
        if QMessageBox.question(
                self, "确认删除比价数据",
                f"确定删除以下 {len(prods_to_clean)} 件商品的比价数据？\n\n{names}{more}\n\n"
                f"（仅清空 cost_ref/supplier_link/pdd_price 等字段，不删除商品本身）",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        # 从独立存储删除 + 清空内存对象字段
        store = _load_compared_store()
        removed = 0
        for p in prods_to_clean:
            pid = p.get("prod_id") or p.get("name", "")
            if pid and pid in store:
                del store[pid]
                removed += 1
            for f in COMPARED_FIELDS:
                if f in p:
                    p[f] = ""
        _save_compared_store(store)
        # 写回 products_*.json 保持一致
        self._save_current_data()
        self._apply_filters()
        QMessageBox.information(self, "完成",
            f"已删除 {removed} 件商品的比价数据\ncompared_products.json 剩余 {len(store)} 条")

    # ── 表格内联编辑回调 ──────────────────────────────────────────────
    def _on_table_item_changed(self, item):
        if self._editing_cell:
            return
        col = item.column()
        row = item.row()
        if col >= len(COLUMNS):
            return
        key = COLUMNS[col][1]
        if key not in self._EDITABLE_KEYS:
            return
        prods = getattr(self, "products", [])
        if row >= len(prods):
            return
        prod = prods[row]
        prod_idx = next((i for i, p in enumerate(self._all_prods) if p is prod), None)
        if prod_idx is None:
            return
        self._editing_cell = True
        self._all_prods[prod_idx][key] = item.text().strip()
        self._save_current_data()
        self._editing_cell = False
        self.status.showMessage(f"已保存：{prod.get('name','')[:20]} → {key} = {item.text()[:30]}")

    def _start_price_compare(self, prod_idx: int):
        """启动1688比价（prod_idx 为 _all_prods 中的稳定索引，排序后不变）"""
        try:
            if prod_idx < 0 or prod_idx >= len(self._all_prods):
                return
            prod = self._all_prods[prod_idx]

            img = (prod.get("image", "") or "").strip()
            if not img:
                QMessageBox.warning(self, "无法比价", "该商品没有图片，无法进行以图搜图")
                return
            image_path = img if Path(img).exists() else ""
            image_url = "" if image_path else img
            name = prod.get("name", "")
            mode = ask_compare_mode(self, "查 1688 比价 — 选择比价方式")
            if not mode:
                return
            self._compare_mode = mode
            self.status.showMessage(
                f"正在查1688比价: {name[:20]}... （首次使用请在弹出的Chrome中完成登录/验证）")
            if not hasattr(self, "_price_compare_threads"):
                self._price_compare_threads = []
            t = PriceCompareThread(prod_idx, image_url, name, image_path=image_path, mode=mode)
            t.done_signal.connect(self._on_price_compare_done)
            t.error_signal.connect(self._on_price_compare_error)
            t.finished.connect(lambda thread=t: self._price_compare_threads.remove(thread)
                               if thread in self._price_compare_threads else None)
            self._price_compare_threads.append(t)
            t.start()
        except Exception as e:
            self.status.showMessage(f"比价启动失败: {e}")

    def _on_price_compare_error(self, msg: str):
        self._close_browser_if_plugin()   # 插件模式跑完关掉可见浏览器
        self.status.showMessage(f"比价出错: {msg[:80]}")
        QMessageBox.warning(self, "1688比价出错", msg)

    def _on_price_compare_done(self, prod_idx: int, result: dict):
        if "error" in result:
            self._on_price_compare_error(result["error"])
            return
        self._close_browser_if_plugin()   # 插件模式跑完关掉可见浏览器
        prod = self._all_prods[prod_idx]
        prod["cost_ref"]       = result.get("cost_ref", "")
        prod["cost_supplier"]  = result.get("cost_supplier", "")
        prod["cost_top3_str"]  = result.get("cost_top3_str", "")
        prod["img_search_url"] = result.get("img_search_url", "")
        prod["supplier_link"]  = result.get("supplier_link", "")
        cands = result.get("candidates", []) or []
        prod["candidates"]     = cands
        prod["cost_image"]     = (cands[0].get("image") if cands else "") or ""
        prod["auto_note"]      = result.get("auto_note", "")
        # 比价时视觉同款结论 → 随商品同步进库,免再人工核对
        prod["same_style"]        = result.get("same_style", "")
        prod["same_style_reason"] = result.get("same_style_reason", "")
        if result.get("same_style"):
            prod["same_style_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._save_current_data()
        _update_compared_store(prod)
        self._apply_filters()
        note = result.get("auto_note", "")
        self.status.showMessage(
            f"1688比价完成 — 最优: {result.get('cost_ref','')}  供应商: {result.get('cost_supplier','')}"
            + (f"  {note}" if note else "")
        )

    # ── 手动比价 ──────────────────────────────────────────────────────────
    def _start_manual_compare(self):
        """对选中的(单条)商品启动手动比价:跑 1688 图搜 → 弹窗候选 → 用户选 → 写回"""
        # 已比价模式下,候选已存于 prod["candidates"],可跳过抓取直接弹窗
        # 普通模式或无 candidates 时,跑 PriceCompareThread 抓一次
        sel_idxs = self._collect_selected_indices()
        if len(sel_idxs) != 1:
            QMessageBox.information(self, "手动比价", "请只勾选 1 条商品(手动比价为单条操作)")
            return
        prod_idx = sel_idxs[0]
        prod = self._all_prods[prod_idx]
        cands = prod.get("candidates") or []
        if cands:
            ans = QMessageBox.question(self, "手动比价",
                f"该商品已有 {len(cands)} 个候选缓存,直接打开弹窗?\n"
                f"(选「否」会重新跑 1688 图搜抓取最新候选)",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if ans == QMessageBox.Yes:
                self._open_candidate_picker(prod_idx)
                return
        # 重新抓取
        img = (prod.get("image", "") or "").strip()
        if not img:
            QMessageBox.warning(self, "手动比价", "该商品没有图片,无法做以图搜款")
            return
        image_path = img if Path(img).exists() else ""
        image_url = "" if image_path else img
        name = prod.get("name", "")
        mode = ask_compare_mode(self, "手动比价 — 选择比价方式")
        if not mode:
            return
        self._compare_mode = mode
        self.status.showMessage(f"手动比价:正在抓 1688 候选 — {name[:20]}...")
        if not hasattr(self, "_price_compare_threads"):
            self._price_compare_threads = []
        t = PriceCompareThread(prod_idx, image_url, name, image_path=image_path, mode=mode)
        # 复用现有 done 信号,但绑定到手动处理流程
        t.done_signal.connect(self._on_manual_compare_done)
        t.error_signal.connect(self._on_price_compare_error)
        t.finished.connect(lambda thread=t: self._price_compare_threads.remove(thread)
                           if thread in self._price_compare_threads else None)
        self._price_compare_threads.append(t)
        t.start()

    def _on_manual_compare_done(self, prod_idx: int, result: dict):
        if "error" in result:
            self._on_price_compare_error(result["error"])
            return
        self._close_browser_if_plugin()   # 插件模式跑完关掉可见浏览器
        # 先把抓到的 candidates 缓存到 prod(无论是否选,都保留供下次直接打开)
        prod = self._all_prods[prod_idx]
        cands = result.get("candidates", []) or []
        prod["candidates"] = cands
        prod["auto_note"]  = result.get("auto_note", "")
        prod["img_search_url"] = result.get("img_search_url", "")
        # 注意:此时还没写回 supplier_link/cost_ref/cost_image,等用户从弹窗选定后写
        _update_compared_store(prod)
        if not cands:
            QMessageBox.warning(self, "手动比价", "未抓到任何候选,请检查 1688 登录/风控状态")
            return
        self._open_candidate_picker(prod_idx)

    def _open_candidate_picker(self, prod_idx: int):
        """打开候选选择弹窗,用户选定后写回 supplier_link/cost_ref/cost_image 等"""
        prod = self._all_prods[prod_idx]
        cands = prod.get("candidates") or []
        if not cands:
            QMessageBox.information(self, "手动比价", "无候选可选")
            return
        dlg = CandidatePickerDialog(
            source_name=prod.get("name", ""),
            source_image=prod.get("image", ""),
            candidates=cands,
            parent=self,
            selected_link=prod.get("supplier_link", ""),
        )
        dlg.exec_()
        # 用户点了「🔄 重新抓取」或「📤 上传新图重抓」:清空候选 + 重跑 1688
        if getattr(dlg, "_refetch_requested", False):
            mode = ask_compare_mode(self, "重新抓取 1688 — 选择比价方式")
            if not mode:
                return
            self._compare_mode = mode
            new_image_path = getattr(dlg, "_refetch_with_image", "") or ""
            prod["candidates"] = []
            _update_compared_store(prod)
            # 优先级:用户上传的新图 > 原 image URL
            if new_image_path and Path(new_image_path).exists():
                image_path = new_image_path
                image_url = ""
                self.status.showMessage(
                    f"用新图重抓 1688 候选 — {Path(new_image_path).name}...")
            else:
                img = (prod.get("image", "") or "").strip()
                image_path = img if img and Path(img).exists() else ""
                image_url = "" if image_path else img
                if not image_url and not image_path:
                    QMessageBox.warning(self, "手动比价", "该商品没有图片,无法重新抓取")
                    return
                self.status.showMessage(f"重新抓取 1688 候选 — {prod.get('name','')[:20]}...")
            if not hasattr(self, "_price_compare_threads"):
                self._price_compare_threads = []
            t = PriceCompareThread(prod_idx, image_url, prod.get("name", ""), image_path=image_path,
                                   mode=getattr(self, "_compare_mode", "auto"))
            t.done_signal.connect(self._on_manual_compare_done)
            t.error_signal.connect(self._on_price_compare_error)
            t.finished.connect(lambda thread=t: self._price_compare_threads.remove(thread)
                               if thread in self._price_compare_threads else None)
            self._price_compare_threads.append(t)
            t.start()
            return
        picked = dlg.selected()
        if not picked:
            self.status.showMessage("手动比价已取消")
            return
        # 写回:用所选 candidate 的字段覆盖
        total = picked.get("total", 0)
        price = picked.get("price", 0)
        shipping = picked.get("shipping", 0)
        prod["cost_ref"]      = f"¥{total} (¥{price}+运{shipping})"
        prod["cost_supplier"] = picked.get("shopName", "")
        prod["supplier_link"] = picked.get("link", "")
        prod["cost_image"]    = picked.get("image", "")
        # cost_top3_str 标注为手动选,跟自动模式区分
        prod["cost_top3_str"] = f"[手动选] {picked.get('shopName','')} ¥{total}({picked.get('fulfillment',0)}%)"
        prod["auto_note"]     = "✋ 手动比价"  # 标记来源
        self._save_current_data()
        _update_compared_store(prod)
        self._apply_filters()
        self.status.showMessage(
            f"✋ 手动比价已确认 — 供应商: {picked.get('shopName','')}  价格: ¥{total}")

    def _collect_selected_indices(self) -> list:
        """收集主表当前勾选行的 _all_prods 索引(name 列 UserRole 存的稳定 idx)"""
        _NAME_COL = next((i for i, (_, k, _) in enumerate(COLUMNS) if k == "name"), -1)
        out = []
        for r in self._get_checked_rows():
            item = self.table.item(r, _NAME_COL) if _NAME_COL >= 0 else None
            if item is None:
                continue
            pi = item.data(Qt.UserRole)
            if isinstance(pi, int):
                out.append(pi)
        return out

    # ── 拼多多比价 ────────────────────────────────────────────────────────────
    def _start_pdd_compare(self, prod_idx: int):
        """启动拼多多以图搜款（prod_idx 为 _all_prods 中的稳定索引）"""
        try:
            if prod_idx < 0 or prod_idx >= len(self._all_prods):
                return
            prod = self._all_prods[prod_idx]
            image_url = prod.get("image", "")
            if not image_url:
                QMessageBox.warning(self, "无法比价", "该商品没有图片，无法进行以图搜款")
                return
            name = prod.get("name", "")
            self.status.showMessage(
                f"正在查拼多多比价: {name[:20]}…（会弹出手机版浏览器，请勿关闭）")
            if not hasattr(self, "_pdd_compare_threads"):
                self._pdd_compare_threads = []
            t = PddCompareThread(prod_idx, image_url, name)
            t.done_signal.connect(self._on_pdd_compare_done)
            t.error_signal.connect(self._on_pdd_compare_error)
            t.finished.connect(
                lambda thread=t: self._pdd_compare_threads.remove(thread)
                if thread in self._pdd_compare_threads else None)
            self._pdd_compare_threads.append(t)
            t.start()
        except Exception as e:
            self.status.showMessage(f"拼多多比价启动失败: {e}")

    def _on_pdd_compare_error(self, msg: str):
        self.status.showMessage(f"拼多多比价出错: {msg[:80]}")
        QMessageBox.warning(self, "拼多多比价出错", msg)

    def _on_pdd_compare_done(self, prod_idx: int, result: dict):
        if "error" in result:
            self._on_pdd_compare_error(result["error"])
            return
        prod = self._all_prods[prod_idx]
        prod["pdd_price"]    = result.get("pdd_price", "")
        prod["pdd_shop"]     = result.get("pdd_shop", "")
        prod["pdd_top3_str"] = result.get("pdd_top3_str", "")
        prod["pdd_link"]     = result.get("pdd_link", "")
        prod["pdd_save_dir"] = result.get("save_dir", "")
        self._save_current_data()
        _update_compared_store(prod)  # 独立存储
        self._apply_filters()
        save_dir = result.get("save_dir", "")
        detail_err = result.get("detail_error", "")
        if save_dir:
            msg = (f"拼多多比价完成 — 最低: {result.get('pdd_price','')} "
                   f"| 详情已保存: {save_dir}")
        elif detail_err:
            msg = (f"拼多多比价完成 — 最低: {result.get('pdd_price','')} "
                   f"| 详情抓取失败: {detail_err[:40]}")
        else:
            msg = f"拼多多比价完成 — 最低: {result.get('pdd_price','')}  店铺: {result.get('pdd_shop','')}"
        self.status.showMessage(msg)

    def _clear_row_pdd_compare(self, prod_idx: int):
        """清除单行的拼多多比价数据"""
        if prod_idx < 0 or prod_idx >= len(self._all_prods):
            return
        prod = self._all_prods[prod_idx]
        name = prod.get("name", "")
        if QMessageBox.question(
                self, "确认清除",
                f"清除【{name[:25]}】的拼多多比价数据？",
                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        for f in ("pdd_price", "pdd_shop", "pdd_top3_str", "pdd_link"):
            self._all_prods[prod_idx][f] = ""
        self._save_current_data()
        self._apply_filters()
        self.status.showMessage(f"已清除拼多多数据：{name[:25]}")

    def _save_current_data(self):
        # 1) 同步独立存储：有比价 → upsert；无比价但 prod_id 仍在 store → 移除
        try:
            store = _load_compared_store()
            changed = False
            for p in self._all_prods:
                pid = p.get("prod_id") or p.get("name", "")
                if not pid:
                    continue
                has = any(p.get(f) for f in ["cost_ref", "supplier_link", "cost_supplier", "pdd_price", "pdd_link"])
                if has:
                    _update_compared_store(p)  # 内部已写盘
                elif pid in store:
                    del store[pid]
                    changed = True
            if changed:
                _save_compared_store(store)
        except Exception:
            pass
        # 2) 兼容：仍然写回最近一个 products_*.json（向后兼容）
        files = sorted(
            [f for f in DATA_DIR.glob("products_*.json")
             if _is_main_product_file(f)],
            key=lambda f: f.stat().st_mtime
        )
        if not files:
            return
        try:
            with open(files[-1], "w", encoding="utf-8") as f:
                json.dump(self._all_prods, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ── 图片回调 ──────────────────────────────────────────────────────────
    def _set_cell_image(self, label, data):
        try:
            pix = QPixmap()
            pix.loadFromData(data)
            pix = pix.scaled(IMG_SIZE, IMG_SIZE, Qt.KeepAspectRatio,
                             Qt.SmoothTransformation)
            label.setPixmap(pix)
            label.setText("")
        except RuntimeError:
            pass

    # ── 表格填充 ──────────────────────────────────────────────────────────
    # 可内联编辑的1688字段（已比价模式下双击可改）
    _EDITABLE_KEYS = {"cost_ref", "cost_supplier", "cost_top3_str",
                      "pdd_price", "pdd_shop", "pdd_top3_str"}

    def _fill_table(self, products):
        if self._img_loader and self._img_loader.isRunning():
            self._img_loader.quit()
            self._img_loader.wait(400)

        self.table.blockSignals(True)   # 防止填充期间 itemChanged 乱触发
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(products))
        self.table.verticalHeader().setDefaultSectionSize(IMG_SIZE + 4)
        # 填表提速/不冻:代次守卫(中途又触发填表就放弃旧的)+ all_prods id 映射(O(1) 反查)
        from PyQt5.QtWidgets import QApplication as _QA
        self._fill_gen = getattr(self, "_fill_gen", 0) + 1
        _gen = self._fill_gen
        _allidx = {id(ap): i for i, ap in enumerate(self._all_prods)}

        # 已比价模式：允许双击编辑1688字段；普通模式：禁止编辑
        if self._compared_only:
            self.table.setEditTriggers(QAbstractItemView.DoubleClicked)
        else:
            self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        POSITIVE = QColor("#D1FAE5")
        NEGATIVE = QColor("#FEE2E2")
        img_tasks = []

        _NAME_COL = next((i for i, (_, k, _) in enumerate(COLUMNS) if k == "name"), -1)

        for r, p in enumerate(products):
            for c, (_, key, _) in enumerate(COLUMNS):
                val = str(p.get(key, "") or "")

                # ── 勾选列：居中容器 ──
                if key == "_sel":
                    cb = QCheckBox()
                    cb.setStyleSheet("""
                        QCheckBox::indicator {
                            width: 16px; height: 16px;
                            border: 2px solid #C7D2FE;
                            border-radius: 4px;
                            background: white;
                        }
                        QCheckBox::indicator:hover {
                            border-color: #4F46C8;
                        }
                        QCheckBox::indicator:checked {
                            background: #4F46C8;
                            border-color: #4F46C8;
                            image: none;
                        }
                        QCheckBox::indicator:checked:hover {
                            background: #4338CA;
                        }
                    """)
                    wrapper = QWidget()
                    wl = QHBoxLayout(wrapper)
                    wl.setContentsMargins(0, 0, 0, 0)
                    wl.setAlignment(Qt.AlignCenter)
                    wl.addWidget(cb)
                    wrapper.setStyleSheet("background: transparent;")
                    self.table.setCellWidget(r, c, wrapper)
                    continue

                # ── 推荐列:算分(缓存到 p["_reco"])+ 标签上色 + 理由悬停 + 按分排序 ──
                if key == "_reco":
                    rc = p.get("_reco")
                    if not isinstance(rc, dict):
                        rc = xuanpin_reco.score_product(p)
                        p["_reco"] = rc
                    it = NumericTableWidgetItem(f"{rc['label']} {rc['score']:.0f}")
                    it.setData(NumericTableWidgetItem._SORT_ROLE, rc["score"])
                    _bg = {"🔥强推": "#FEE2E2", "👍可做": "#D1FAE5",
                           "⚠️谨慎": "#FEF3C7", "🚫衰退期": "#E5E7EB"}.get(rc["label"], "")
                    if _bg:
                        it.setBackground(QColor(_bg))
                    it.setToolTip(rc.get("reason", ""))
                    self.table.setItem(r, c, it)
                    continue

                if key in ("image", "cost_image"):
                    lbl = ClickableImageLabel()   # 左键点击放大预览 / 右键复制图片
                    lbl.setText("…" if val else "—")
                    lbl.setAlignment(Qt.AlignCenter)
                    lbl.setFixedSize(IMG_SIZE, IMG_SIZE)
                    lbl.setStyleSheet("background:transparent;color:#9CA3AF;")
                    local_img = ""
                    image_url = ""
                    if val:
                        if Path(val).exists():
                            local_img = val
                        else:
                            image_url = val
                        lbl.set_image_source(local_path=local_img, image_url=image_url,
                                             product_name=(p.get("name", "") + (" · 货品图" if key == "cost_image" else " · 商品图")))
                        if local_img:
                            pix = QPixmap(local_img)
                            if not pix.isNull():
                                lbl.setPixmap(pix.scaled(IMG_SIZE, IMG_SIZE, Qt.KeepAspectRatio, Qt.SmoothTransformation))
                                lbl.setText("")
                    lbl.setToolTip("供应商封面图(人工核对是否同款)· 点击放大" if key == "cost_image" and val
                                   else "点击放大查看")
                    self.table.setCellWidget(r, c, lbl)
                    if image_url:
                        img_tasks.append((lbl, image_url))
                    continue

                if key in _URL_COLS and val:
                    _btn_label = {"link": "商品链接", "insight_url": "单品洞察",
                                  "supplier_link": "供货链接"}.get(key, "链接")
                    btn = QPushButton(_btn_label)
                    _btn_color = "#16A34A" if key == "supplier_link" else "#4F46C8"
                    _btn_hover = "#15803D" if key == "supplier_link" else "#4338CA"
                    btn.setStyleSheet(
                        f"QPushButton{{background:{_btn_color};color:white;border-radius:4px;"
                        f"font-size:11px;padding:2px 6px;}}"
                        f"QPushButton:hover{{background:{_btn_hover};}}")
                    url = val
                    btn.clicked.connect(
                        lambda _, u=url: QDesktopServices.openUrl(QUrl(u)))
                    self.table.setCellWidget(r, c, btn)
                    continue

                # ── 供应商资料列：有资料包则显示「📁 查看」按钮 ──
                if key == "data_path":
                    if val and Path(val).exists():
                        btn = QPushButton("📁 查看")
                        btn.setStyleSheet(
                            "QPushButton{background:#F59E0B;color:white;border-radius:4px;"
                            "font-size:11px;padding:2px 6px;}"
                            "QPushButton:hover{background:#D97706;}")
                        folder = val
                        btn.clicked.connect(lambda _, f=folder: os.startfile(f))
                        self.table.setCellWidget(r, c, btn)
                    else:
                        itm = QTableWidgetItem("—")
                        itm.setTextAlignment(Qt.AlignCenter)
                        itm.setForeground(QColor("#9CA3AF"))
                        self.table.setItem(r, c, itm)
                    continue

                # 数值范围列(销量区间/价格区间/GMV区间等)用 NumericTableWidgetItem,
                # 按数值上限排序而不是字符串(否则 "100-120" 会排在 "10-12" 后面)
                if key in _STRIP_NUM_KEYS:
                    item = NumericTableWidgetItem(val)
                else:
                    item = QTableWidgetItem(val)
                item.setTextAlignment(
                    Qt.AlignLeft | Qt.AlignVCenter if c == _NAME_COL
                    else Qt.AlignCenter)
                # name 列存入 _all_prods 稳定索引，排序后也能正确取回商品
                if c == _NAME_COL:
                    all_idx = _allidx.get(id(p), r)
                    item.setData(Qt.UserRole, all_idx)
                # 已比价模式：可编辑字段加浅色背景提示
                if self._compared_only and key in self._EDITABLE_KEYS:
                    item.setBackground(QColor("#EFF6FF"))
                    item.setToolTip("双击可编辑")
                if key in ("gmv_mom", "order_mom") and val:
                    item.setBackground(NEGATIVE if val.startswith("-")
                                       else POSITIVE if re.search(r'\d', val)
                                       else QColor())
                self.table.setItem(r, c, item)
            if (r & 63) == 63:          # 每 64 行喘口气:界面可响应、不"未响应"
                _QA.processEvents()
                if _gen != self._fill_gen:
                    return              # 期间又触发了填表 → 放弃这次(防重入/重复渲染)

        self.table.setSortingEnabled(True)
        self.table.blockSignals(False)  # 恢复 itemChanged 监听
        self._update_count()

        if img_tasks:
            old = getattr(self, "_img_loader", None)
            if old is not None:
                try: old.stop()
                except Exception: pass
            self._img_loader = ImageBatchLoader(img_tasks, cache_original=False, cache_dir_name="img_xuanpin_thumb_cache")
            self._img_loader.image_ready.connect(self._set_cell_image)
            self._img_loader.start()

    def _update_count(self):
        self.count_label.setText(f"共 {self.table.rowCount()} 条")

    # ── 排序安全的行→商品查找 ────────────────────────────────────────────────
    _NAME_COL_IDX = next((i for i, (_, k, _) in enumerate(COLUMNS) if k == "name"), -1)

    def _prod_from_row(self, visual_row: int):
        """
        根据视觉行号返回 (prod_dict, all_prods_idx)。
        表格排序后仍能正确取到对应商品（通过 name 列存储的稳定索引）。
        """
        item = self.table.item(visual_row, self._NAME_COL_IDX)
        if item is not None:
            all_idx = item.data(Qt.UserRole)
            if isinstance(all_idx, int) and 0 <= all_idx < len(self._all_prods):
                return self._all_prods[all_idx], all_idx
        # 兜底：通过 products 列表（未排序时保持一致）
        prods = getattr(self, "products", [])
        if visual_row < len(prods):
            prod = prods[visual_row]
            all_idx = next(
                (i for i, ap in enumerate(self._all_prods) if ap is prod), visual_row)
            return prod, all_idx
        return None, -1

    # ── 选品表导入 ──────────────────────────────────────────────────────────
    def import_selection_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "导入选品表", "", "Excel 文件 (*.xlsx);;All Files (*)")
        if not path:
            return
        try:
            products, images_saved = self._parse_xuanpin_excel(path)
        except Exception as e:
            QMessageBox.critical(self, "导入失败", f"解析选品表失败:\n{e}\n\n{traceback.format_exc()[:500]}")
            return
        if not products:
            QMessageBox.warning(self, "导入失败", "未解析出任何商品,请确认文件是本程序导出的选品 Excel。")
            return

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        ts_compact = datetime.now().strftime("%Y%m%d_%H%M%S")
        ts_label = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        out_path = DATA_DIR / f"products_import_{ts_compact}.json"
        try:
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(products, f, ensure_ascii=False, indent=2)

            history = self._load_history()
            history.append({
                "timestamp": ts_label,
                "filename": out_path.name,
                "count": len(products),
                "source": "import_excel",
                "source_file": os.path.basename(path),
            })
            history = history[-60:]
            with open(HISTORY_PATH, "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2)
        except Exception as e:
            QMessageBox.critical(self, "导入失败", f"写入选品历史失败:\n{e}")
            return

        products = _merge_compared_into(products)
        self._all_prods = products
        self._compared_only = False
        if hasattr(self, "btn_compared"):
            self.btn_compared.setChecked(False)
        self._update_filter_cats(products)
        self._reload_history_combo()
        self._apply_filters()
        self.status.showMessage(f"已导入选品表: {out_path.name}  共 {len(products)} 条")
        QMessageBox.information(
            self, "导入完成",
            f"已导入 {len(products)} 条选品数据。\n"
            f"保存为: {out_path.name}\n"
            f"图片提取: {images_saved} 张")

    def _parse_xuanpin_excel(self, xlsx_path: str) -> tuple[list[dict], int]:
        from openpyxl import load_workbook
        wb = load_workbook(xlsx_path, data_only=False)
        ws = wb.active

        header_to_key = {}
        try:
            from report import COLUMNS as REPORT_COLUMNS
            header_to_key.update({str(header): key for header, key in REPORT_COLUMNS})
        except Exception:
            pass
        header_to_key.update({
            "商品ID": "prod_id",
            "商品图片": "image",
            "商品名称": "name",
            "商品链接": "link",
            "单品洞察": "insight_url",
            "货主店铺名称": "store_name",
            "货主ID": "store_id",
            "首次上架时间": "first_online",
            "价格区间": "price_range",
            "支付GMV区间": "gmv_range",
            "订单量区间": "order_range",
            "销量区间": "sales_range",
            "支付GMV环比": "gmv_mom",
            "支付订单量环比": "order_mom",
            "全站-当日累计GMV区间": "site_cumulative_gmv",
            "全站-直接ROI区间": "site_direct_roi",
            "广告花费区间": "ad_spend",
            "来源类目": "category_label",
            "1688图搜": "img_search_url",
            "1688参考成本": "cost_ref",
            "1688供应商": "cost_supplier",
            "1688前3价格": "cost_top3_str",
        })

        col_to_key = {}
        for c in range(1, ws.max_column + 1):
            header = str(ws.cell(1, c).value or "").strip()
            key = header_to_key.get(header)
            if key:
                col_to_key[c] = key
        if not col_to_key:
            raise ValueError("未找到可识别的选品表头。")

        image_col = next((c for c, key in col_to_key.items() if key == "image"), None)
        row_to_img_bytes: dict[int, bytes] = {}
        if image_col:
            for img in (getattr(ws, "_images", None) or []):
                try:
                    anchor = img.anchor
                    from_attr = getattr(anchor, "from_", None) or getattr(anchor, "_from", None)
                    row_idx = getattr(from_attr, "row", None)
                    col_idx = getattr(from_attr, "col", None)
                    if row_idx is None or col_idx is None or col_idx != image_col - 1:
                        continue
                    data = img._data() if hasattr(img, "_data") and callable(img._data) else None
                    if data:
                        row_to_img_bytes[row_idx] = data
                except Exception:
                    continue

        image_dir = DATA_DIR / "imported_selection_images"
        image_dir.mkdir(parents=True, exist_ok=True)
        products = []
        images_saved = 0
        for r_idx in range(2, ws.max_row + 1):
            prod = {}
            for c, key in col_to_key.items():
                cell = ws.cell(r_idx, c)
                val = cell.value
                if key in {"link", "insight_url", "img_search_url"} and cell.hyperlink:
                    val = cell.hyperlink.target
                if val is None:
                    val = ""
                prod[key] = str(val).strip()

            if not (prod.get("prod_id") or prod.get("name")):
                continue

            img_bytes = row_to_img_bytes.get(r_idx - 1)
            if img_bytes:
                ext = ".png" if img_bytes[:8].startswith(b"\x89PNG") else ".jpg"
                safe_id = re.sub(r"[^0-9A-Za-z_\-]+", "_", prod.get("prod_id") or f"row_{r_idx}").strip("_")
                img_path = image_dir / f"{safe_id or ('row_' + str(r_idx))}{ext}"
                with open(img_path, "wb") as f:
                    f.write(img_bytes)
                prod["image"] = str(img_path)
                images_saved += 1

            prod.setdefault("rank", "")
            prod.setdefault("image", "")
            prod.setdefault("name", "")
            prod.setdefault("category_label", "")
            prod["import_source"] = "selection_excel"
            prod["imported_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            products.append(prod)

        return products, images_saved
    # ── 导出 ──────────────────────────────────────────────────────────────
    def export_excel(self):
        if not self.products:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "导出 Excel",
            str(DATA_DIR / f"选品报表_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"),
            "Excel 文件 (*.xlsx)")
        if not path:
            return
        if getattr(self, "_export_thread", None) is not None:
            QMessageBox.information(self, "导出", "已有导出在进行,请稍候。")
            return
        self._ensure_reco_fields(self.products)   # 把推荐分/标签拍平(主线程,快)
        self.btn_export_excel.setEnabled(False)
        n = len(self.products)
        self.status.showMessage(f"导出中… 0/{n}(逐个下图较慢,请稍候,界面不会卡)")
        t = ExportExcelThread(list(self.products), path, self)
        t.progress.connect(lambda i, tot: self.status.showMessage(
            f"导出中… {i}/{tot}(逐个下图较慢,请稍候)"))
        t.done.connect(self._export_excel_done)
        t.failed.connect(lambda msg: QMessageBox.critical(self, "导出失败", msg))
        t.finished.connect(lambda: (setattr(self, "_export_thread", None),
                                    self.btn_export_excel.setEnabled(True)))
        self._export_thread = t
        t.start()

    def _export_excel_done(self, path):
        self.status.showMessage(f"已导出: {path}")
        try:
            os.startfile(path)
        except Exception:
            pass

    def _ensure_reco_fields(self, products):
        """给每个商品补 _reco_score / _reco_label 扁平字段(供 Excel/导出按 key 取)。"""
        for p in products:
            rc = p.get("_reco")
            if not isinstance(rc, dict):
                rc = xuanpin_reco.score_product(p)
                p["_reco"] = rc
            p["_reco_label"] = rc.get("label", "")
            p["_reco_score"] = rc.get("score", "")

    def export_html(self):
        if not self.products:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "导出 HTML",
            str(DATA_DIR / f"选品报表_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"),
            "HTML 文件 (*.html)")
        if not path:
            return
        try:
            from report import generate_html_report
            generate_html_report(self.products, Path(path))
            self.status.showMessage(f"已导出: {path}")
            os.startfile(path)
        except Exception as e:
            QMessageBox.critical(self, "导出失败", str(e))

    def clear_table(self):
        self.table.setRowCount(0)
        self.products = []
        self._all_prods = []
        self._update_count()
        for b in [self.btn_export_excel, self.btn_export_html, self.btn_clear]:
            b.setEnabled(False)

    # ── 🔄 刷新按钮:从 disk 重新加载数据(优先 live.json,如果它最新)──────────
    def _reload_from_disk(self):
        """重新从 disk 加载数据。优先 products_live.json(抓取实时),
        次选最新 products_<ts>.json(已完成报表)。这样抓取过程中点刷新能看到实时数据。
        """
        live = DATA_DIR / "products_live.json"
        files = sorted(
            [f for f in DATA_DIR.glob("products_*.json")
             if _is_main_product_file(f)],
            key=lambda f: f.stat().st_mtime
        )
        latest_report = files[-1] if files else None
        # 选 mtime 最大的(live 通常实时写,如果在跑抓取它会最新)
        src = None
        if live.exists() and (not latest_report or live.stat().st_mtime > latest_report.stat().st_mtime):
            src = live
            tag = "products_live.json (实时)"
        elif latest_report:
            src = latest_report
            tag = latest_report.name
        if not src:
            self.status.showMessage("无数据可加载")
            self._apply_filters()
            return
        try:
            with open(src, encoding="utf-8") as f:
                products = json.load(f)
            products = _merge_compared_into(products)
            self._all_prods = products
            self._update_filter_cats(products)
            self._apply_filters()
            self.status.showMessage(f"已刷新: {tag}  共 {len(products)} 条")
        except Exception as e:
            self.status.showMessage(f"刷新失败: {e}")

    # ── 检测上次抓取是否未完成 ─────────────────────────────────────────────
    def _check_unfinished_scrape(self):
        """启动时检测 data/scrape_progress.json:
        - 不存在 → 上次正常完成,正常启动
        - 存在 → 上次崩溃,弹窗问用户:继续 / 重新开始 / 忽略
        """
        prog_path = DATA_DIR / "scrape_progress.json"
        if not prog_path.exists():
            return
        try:
            with open(prog_path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return
        target = data.get("target_combos") or []
        completed = data.get("completed_combos") or []
        current = data.get("current_combo")
        started = data.get("started_at", "?")
        last = data.get("last_update", "?")
        remain = [c for c in target if c not in completed]
        if not target or not remain:
            # 没剩余可抓,直接删
            try: prog_path.unlink()
            except Exception: pass
            return
        cur_txt = ">".join(current) if current else "(未知)"
        msg = (f"检测到上次抓取未完成(可能软件崩溃 / 被关闭):\n\n"
               f"  开始时间: {started}\n"
               f"  最近更新: {last}\n"
               f"  进度: {len(completed)} / {len(target)} 个类目\n"
               f"  最后正在抓: {cur_txt}\n"
               f"  剩余未抓: {len(remain)} 个类目\n\n"
               f"如何处理?")
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle("上次抓取未完成")
        box.setText(msg)
        btn_cont = box.addButton(f"▶ 继续抓剩余 {len(remain)} 个", QMessageBox.AcceptRole)
        btn_restart = box.addButton("🔄 重新开始(清进度)", QMessageBox.DestructiveRole)
        btn_ignore = box.addButton("忽略", QMessageBox.RejectRole)
        box.exec_()
        clicked = box.clickedButton()
        if clicked is btn_cont:
            # 启动 ScraperThread 跑 remain。SELECTED_COMBOS env 用 "l1>l2>l3,..." 格式
            combos_str = ",".join(">".join(c) for c in remain)
            try:
                year = self.year_spin.value() if hasattr(self, "year_spin") else 2026
                month = self.month_spin.value() if hasattr(self, "month_spin") else 5
                period = self.period_combo.currentText() if hasattr(self, "period_combo") else "今天"
            except Exception:
                year, month, period = 2026, 5, "今天"
            self.log.appendPlainText(f"[续抓] 跳过已完成 {len(completed)} 个,继续抓剩余 {len(remain)} 个类目")
            self.thread = ScraperThread(combos_str.split(","), year, month, period)
            self.thread.log_signal.connect(self._on_log)
            self.thread.done_signal.connect(self._on_done)
            self.thread.error_signal.connect(self._on_error)
            self.thread.start()
        elif clicked is btn_restart:
            try: prog_path.unlink()
            except Exception: pass
            self.status.showMessage("已清除上次进度,可重新开始抓取")
        # 忽略 → 不动 progress 文件,用户可下次启动再决定

    # ── 启动加载已有数据 ──────────────────────────────────────────────────
    def _on_main_tab_changed(self, idx):
        """首次切到 PDD 标签页时，只创建当前子页；其它 PDD 页等点开再加载。"""
        if idx == 1 and not getattr(self, "_pdd_tab_loaded", False):
            self._pdd_tab_loaded = True
            try:
                cur = self.pdd_nav.currentRow() if hasattr(self, "pdd_nav") else 0
                cur = cur if cur >= 0 else 0
                created = self._ensure_pdd_page_built(cur)
                self.pdd_stack.setCurrentIndex(cur)
                if created:
                    self._pdd_schedule_initial_page_load(cur)
            except Exception as _e:
                print(f"[PDD懒加载] 当前页加载异常: {_e}")
    def _deferred_initial_load(self):
        """窗口显示后再做的重活:加载选品数据(渲染 ~1600 行)+ PDD 待发布/已发布列表。
        放进 QTimer.singleShot(0) → 先让空窗口画出来,主观上秒开,再填表(不改任何加载逻辑)。"""
        try:
            self._load_existing_data()
        except Exception as e:
            _crash_write("DEFERRED_LOAD_ERR", str(e))
        # PDD 表(待发布/已发布/视频)不在启动时渲染——启动时你在选品页,看不到它们,
        # 却会拖慢启动(已发布51行×多控件就要7秒,看门狗实锤)。改成首次切到 PDD 标签页才渲染
        # (见 _on_main_tab_changed)。启动只渲染选品表。

    def _load_existing_data(self):
        files = sorted(
            [f for f in DATA_DIR.glob("products_*.json")
             if _is_main_product_file(f)],
            key=lambda f: f.stat().st_mtime
        )
        if files:
            try:
                with open(files[-1], encoding="utf-8") as f:
                    products = json.load(f)
                products = _merge_compared_into(products)
                self._all_prods = products
                self._update_filter_cats(products)
                self._apply_filters()
                self.status.showMessage(f"已加载: {files[-1].name}  共 {len(products)} 条")
                return
            except Exception:
                pass
        # 兜底：没有 products_*.json，但 compared_products.json 有快照 → 独立重建
        rebuilt = _compared_store_to_products()
        if rebuilt:
            self._all_prods = rebuilt
            self._update_filter_cats(rebuilt)
            self._apply_filters()
            self.status.showMessage(
                f"无 products_*.json，从 compared_products.json 重建 {len(rebuilt)} 条已比价商品")


# ── 入口 ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    palette = QPalette()
    palette.setColor(QPalette.Window,          QColor("#F3F4F6"))
    palette.setColor(QPalette.WindowText,      QColor("#111827"))
    palette.setColor(QPalette.Base,            QColor("#FFFFFF"))
    palette.setColor(QPalette.AlternateBase,   QColor("#F9FAFB"))
    palette.setColor(QPalette.Highlight,       QColor("#4F46C8"))
    palette.setColor(QPalette.HighlightedText, QColor("#FFFFFF"))
    app.setPalette(palette)
    win = MainWindow()
    win.show()
    # ── 卡死诊断看门狗:主线程停>6s 把所有线程堆栈写到 data/client_hang.log(纯诊断,不改行为)──
    try:
        import faulthandler as _fh, threading as _th, time as _tt
        _hb = [_tt.time()]
        _hbtimer = QTimer()
        _hbtimer.timeout.connect(lambda: _hb.__setitem__(0, _tt.time()))
        _hbtimer.start(1000)
        def _watchdog():
            while True:
                _tt.sleep(2)
                _stall = _tt.time() - _hb[0]
                if _stall > 6:
                    try:
                        _f = open(r'D:/files/data/client_hang.log', 'a', encoding='utf-8')
                        _f.write('\n===== 卡死 %s 主线程停 %.1fs =====\n' % (_tt.strftime('%Y-%m-%d %H:%M:%S'), _stall))
                        _f.flush(); _fh.dump_traceback(file=_f); _f.flush(); _f.close()
                    except Exception:
                        pass
                    _tt.sleep(10)
        _th.Thread(target=_watchdog, daemon=True).start()
    except Exception:
        pass
    sys.exit(app.exec_())
