"""保本投产扫描桥接 —— 把"算账大脑"(roas_calc)接到真实 PDD 已发布链接。

干什么:对一批已发布在架商品,逐条打开后台编辑页,读每档 SKU 的【拼单价 + 规格名(→份数)】,
结合发布历史里的【单件货价/运费/防比价后缀】,算出每条链接的【保本投产 / 开车目标投产】。

★ 全程只读:只打开详情页/编辑页 read_edit_state 读数,**绝不点提交、绝不改价改库存**。
   本质是个探针,可安全在真实后台跑(导航路径与 pdd_inspect 核查完全一致,只是不整改)。

复用现成函数(不改它们):
  - pdd_publish: find_chrome / _load_stores / _profile_dir_for / PROFILE_DIR /
                 apply_window_mode / click_edit_goods / read_edit_state
  - pdd_inspect: read_detail_state / _units_of / _cloud_units_map
  - roas_calc:   load_history_costs / breakeven_for_goods

用法:
  python roas_scan.py --store 店铺名 [--goods-ids 123,456] --output-json out.json [--show-browser]
  不给 --goods-ids 时,扫该店铺发布历史里全部有 goods_id 的在架商品。

口径见 roas_calc(退款后投产 / 拼单价 / 扣点0.6% / 取最低毛利档 ×1.1)。
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from playwright.async_api import async_playwright

import roas_calc
from pdd_publish import (
    find_chrome, _load_stores, _profile_dir_for, PROFILE_DIR,
    apply_window_mode,
)
from pdd_inspect import read_detail_state, _units_of, _cloud_units_map


# ── 单条:打开已发布链接,只读抓每档 SKU(拼单价 + 份数) ───────────────────────

def _actual_price(activity_value, group_value):
    """Use a valid activity price; otherwise fall back to the group price."""
    for value, source in ((activity_value, "activity"), (group_value, "group")):
        try:
            price = float(value)
        except (TypeError, ValueError):
            continue
        if price > 0:
            return round(price, 2), source
    return None, ""


async def collect_skus(context, goods_id: str, name: str = "",
                       suffix: str = "", detail_url: str = "") -> dict:
    """只打开商品详情页(goods_detail)→ read_detail_state 读「规格与库存」静态表。

    返回 {"ok": bool, "skus": [{"name","price","units"}], "note": str}
    price = 拼单价(groups);units 用 _units_of(优先云端份数,回落正则)。
    不点「编辑商品」、不开编辑页 —— 详情页静态表已含规格名+拼单价,更快更稳。
    任何失败都返回 ok=False + note,绝不抛断整批。**只读,不整改。**
    """
    gid = str(goods_id or "").strip()
    detail_url = detail_url or (
        f"https://mms.pinduoduo.com/goods/goods_detail?goods_id={gid}" if gid else "")
    if not gid or not detail_url:
        return {"ok": False, "skus": [], "note": "缺 goods_id / detail_url"}

    page = await context.new_page()
    try:
        try:
            await page.goto(detail_url, wait_until="domcontentloaded", timeout=30000)
        except Exception as e:
            return {"ok": False, "skus": [], "note": f"详情页打开超时: {e}"}
        await asyncio.sleep(4)

        # 驳回 / 审核中 → 没有可信价格,跳过
        try:
            page_status = await page.evaluate("""() => {
                const t = document.body.innerText || '';
                if (t.includes('发布已驳回')) return 'rejected';
                if (t.includes('新商品发布中')) return 'pending';
                return 'ok';
            }""")
        except Exception:
            page_status = 'ok'
        if page_status == 'rejected':
            return {"ok": False, "skus": [], "note": "PDD 状态: 发布已驳回"}
        if page_status == 'pending':
            return {"ok": False, "skus": [], "note": "PDD 状态: 新商品发布中(审核未完成)"}

        try:
            state = await read_detail_state(page)
        except Exception as e:
            return {"ok": False, "skus": [], "note": f"读详情页规格表失败: {e}"}

        specs = state.get("specs", []) or []
        unit_specs = state.get("unit_specs", []) or specs   # 套餐(逐档,各行不同)
        activities = state.get("activities", []) or []      # activity price first
        groups = state.get("groups", []) or []              # group-price fallback
        if not unit_specs or not (activities or groups):
            return {"ok": False, "skus": [],
                    "note": f"详情页未抓到规格/拼单价(specs={len(specs)} groups={len(groups)})"}

        # 份数:和核查同判官 —— 先云端一次性判全部规格名,失败回落 _units_of(正则/7B)
        rec = {"goods_id": gid, "target_name": name, "suffix": suffix, "units_map": {}}
        try:
            rec["units_map"] = _cloud_units_map(unit_specs, rec) or {}
        except Exception:
            rec["units_map"] = {}

        n = min(len(unit_specs), max(len(activities), len(groups)))
        skus = []
        for i in range(n):
            nm = unit_specs[i]
            price, price_source = _actual_price(activities[i] if i < len(activities) else "", groups[i] if i < len(groups) else "")
            if price is None:
                continue
            units = _units_of(nm, rec)
            skus.append({"name": nm, "price": price, "price_source": price_source, "units": int(units)})

        if not skus:
            return {"ok": False, "skus": [], "note": "规格行拼单价均无法解析"}
        return {"ok": True, "skus": skus, "note": f"抓到 {len(skus)} 档"}
    finally:
        try:
            await page.close()
        except Exception:
            pass


# ── 主流程 ───────────────────────────────────────────────────────────────────

async def run(args):
    costs = roas_calc.load_history_costs()
    if not costs:
        print("[扫描] 发布历史为空,没有可算账的商品", file=sys.stderr)

    # 选要扫的 goods_id
    if args.goods_ids:
        gids = [g.strip() for g in args.goods_ids.split(",") if g.strip()]
    else:
        # 该店铺历史里全部有成本的 goods_id
        gids = [gid for gid, c in costs.items()
                if (args.store in c.get("store", "") or c.get("store", "") in args.store)]
    if not gids:
        print(f"[扫描] store={args.store!r} 没有可扫的 goods_id", file=sys.stderr)
        Path(args.output_json).write_text("[]", encoding="utf-8")
        print(json.dumps({"total": 0, "ok": 0, "output_json": args.output_json}, ensure_ascii=False))
        return

    print(f"[扫描] store={args.store!r} 待扫 {len(gids)} 条", file=sys.stderr)

    # 选 profile(与 pdd_inspect 一致)
    stores = _load_stores()
    matched = next((k for k in stores if args.store in k or k in args.store), None)
    profile_dir = (PROFILE_DIR / stores[matched]) if matched else _profile_dir_for(args.store)
    chrome_exe = find_chrome()
    print(f"[profile] {profile_dir}", file=sys.stderr)
    print(f"[Chrome] {chrome_exe}", file=sys.stderr)

    _win_args = ["--start-maximized"] if args.show_browser \
        else ["--window-position=-32000,-32000", "--window-size=1920,1080"]

    results: list[dict] = []
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            executable_path=chrome_exe,
            headless=False,
            args=_win_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        _ip = context.pages[0] if context.pages else await context.new_page()
        await apply_window_mode(context, _ip, args.show_browser)

        for i, gid in enumerate(gids, 1):
            info = costs.get(gid, {})
            nm = info.get("name", "")
            suffix = info.get("suffix", "")
            print(f"\n[扫描 {i}/{len(gids)}] goods_id={gid}  {nm[:30]}", file=sys.stderr)
            try:
                got = await collect_skus(context, gid, name=nm, suffix=suffix)
            except Exception as e:
                got = {"ok": False, "skus": [], "note": f"扫描异常: {e}"}
            if not got["ok"]:
                results.append({"goods_id": gid, "name": nm, "ok": False,
                                "note": got["note"], "target_roas": None})
                print(f"  ✗ {got['note']}", file=sys.stderr)
                continue
            calc = roas_calc.breakeven_for_goods(gid, got["skus"], costs=costs,
                                                 fee_rate=args.fee_rate,
                                                 refund_rate=args.refund_rate)
            calc["name"] = nm
            results.append(calc)
            if calc.get("ok"):
                tgt = "  ".join(f"{t['label']}={t['roas']:.2f}" for t in calc.get("targets", []))
                print(f"  ✓ 实际保本={calc['real_breakeven_roas']:.2f}  档位[{tgt}]  "
                      f"(最低毛利档「{calc['worst']['name'][:16]}」{calc['worst']['margin']*100:.1f}%)",
                      file=sys.stderr)
            else:
                print(f"  ⚠ {calc.get('note','')}", file=sys.stderr)

        try:
            await asyncio.wait_for(context.close(), timeout=3)
        except Exception:
            pass

    out_path = Path(args.output_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    ok_n = sum(1 for r in results if r.get("ok"))
    print(f"\n[OK] 结果写入 {out_path}", file=sys.stderr)
    print(json.dumps({"total": len(results), "ok": ok_n,
                      "fail": len(results) - ok_n, "output_json": str(out_path)},
                     ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description="保本投产扫描(只读,不改价)")
    parser.add_argument("--store", required=True, help="店铺名(模糊匹配)")
    parser.add_argument("--goods-ids", default="", help="逗号分隔的 goods_id;省略=扫该店铺历史全部")
    parser.add_argument("--output-json", default="data/pdd/roas_scan_result.json", help="输出结果 JSON")
    parser.add_argument("--fee-rate", type=float, default=roas_calc.DEFAULT_FEE_RATE, help="平台扣点率,默认0.006")
    parser.add_argument("--refund-rate", type=float, default=roas_calc.DEFAULT_REFUND_RATE,
                        help="退款率,实际保本=名义÷(1−退款率),默认0.20")
    parser.add_argument("--show-browser", action="store_true", help="显示浏览器(调试用),默认屏幕外静默")
    parser.add_argument("--auto-close", action="store_true", help="完成后自动退出(供 client 调用)")
    args = parser.parse_args()
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        sys.exit(130)
    finally:
        if args.auto_close:
            os._exit(0)


if __name__ == "__main__":
    main()
