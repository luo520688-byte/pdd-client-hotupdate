"""PDD 已发布未对齐核查 —— 批量打开商品编辑页对比期望/实际,输出差异原因。

输入: --store + --records-json (含 goods_id, supplier_cost, shipping, margin,
       single_buy_extra, suffix, stock, target_name 的记录列表)
输出: --output-json (每条 {goods_id, name, ok, reasons[]})

复用 pdd_publish.py 里的 read_edit_state / _parse_spec_units / find_chrome / _load_stores。
"""
from __future__ import annotations

import asyncio
import json
import argparse
import sys
import os
from pathlib import Path

# 复用 pdd_publish.py 的工具
sys.path.insert(0, str(Path(__file__).resolve().parent))
from pdd_publish import (  # noqa: E402
    find_chrome, _profile_dir_for, _load_stores, PROFILE_DIR,
    read_edit_state, _parse_spec_units, click_edit_goods, _strip_banned_words,
    append_spec_suffix, fill_prices, set_new_stock, click_edit_submit,
    scrape_spec_values, _ceil_to_9, read_pdd_product_name, fill_spec_codes,
    read_supplier_offer_title,
)
from playwright.async_api import async_playwright  # noqa: E402


def _units_of(name: str, rec: dict) -> int:
    """统一份数判断。**智能SKU:rec 带 units_map(云端份数)时优先用云端份数**
    (按规格名/去后缀/子串匹配),避免核查用本地份数把云端定的价改错。
    否则双判(LLM+正则,方案甲),Ollama 不可用回落正则。
    """
    um = (rec or {}).get("units_map") or {}
    if um:
        suf = (rec or {}).get("suffix", "") or ""
        nm = (name or "").strip()
        nm2 = nm.replace(suf, "").strip() if suf else nm
        for k in (nm, nm2):
            if k and k in um:
                return int(um[k])
        for key, u in um.items():        # 子串兜底(detail名可能带后缀/微差)
            if key and (key in nm or key in nm2):
                return int(u)
    try:
        from spec_units import judge_units
        return int(judge_units(name, (rec or {}).get("suffix", "") or "")["units"])
    except Exception:
        return _parse_spec_units(name)


def _cloud_units_map(names, rec) -> dict:
    """核查也用云端 DeepSeek 一次性判全部 SKU 份数 → {名: units}(和智能SKU发布同一判官,
    不抠搜:既然核查就用最准的)。名先剥发布后缀(后缀=赠品不算份数);按"回传名 + 末层名"建键
    (对齐 smart_sku.cloud_judge)。云端不可用 → 返回 {},_units_of 自动回落正则(含共N)+7B。"""
    names = [n for n in (names or []) if n]
    if not names:
        return {}
    suf = (rec or {}).get("suffix", "") or ""
    clean = [(n.replace(suf, "").strip() if suf else n) for n in names]
    try:
        import smart_sku
        gate = smart_sku.llm_gate(clean, (rec or {}).get("target_name", "") or "")
        um = {}
        for r in (gate.get("rows") or []):
            nm = (r.get("name") or "").strip()
            try:
                u = int(r.get("units") or 1)
            except Exception:
                u = 1
            if nm and u >= 1:
                um[nm] = u
                um[nm.split("/")[-1].strip()] = u   # 末层名(2层时定位用)
        print(f"[核查·云端] DeepSeek 判份数: {um}", file=sys.stderr)
        return um
    except Exception as e:
        print(f"[核查·云端] 调用失败,回落正则(共N)+7B: {e}", file=sys.stderr)
        return {}


async def _capture_price_rows(edit_page) -> dict:
    """列头法抓编辑页价格表所有行(健壮,不受 SKU 数/换行/虚拟列表影响)。
    找列头(款式/改后库存/拼单价/单买价)→ 每个 input 按 x 归列、y 归行 →
    每行返回 {y, group_idx, single_idx, stock_idx(可空)}。按 y 升序。
    返回 {rows:[...], err?}。
    """
    return await edit_page.evaluate(r"""() => {
        const findHdr = (txt) => {
            for (const el of document.querySelectorAll('th, span, div, label')) {
                const d = Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (d === txt || d === '*'+txt) {
                    const r = el.getBoundingClientRect();
                    if (r.width>0 && r.height>0) return {cx: r.x + r.width/2, y: r.y};
                }
            }
            return null;
        };
        const stockH  = findHdr('改后库存') || findHdr('库存');
        const groupH  = findHdr('拼单价(元)') || findHdr('拼单价');
        const singleH = findHdr('单买价(元)') || findHdr('单买价');
        if (!groupH || !singleH) return {err:'no_price_header'};
        const cols = [];
        if (stockH)  cols.push({name:'stock',  cx:stockH.cx});
        cols.push({name:'group',  cx:groupH.cx});
        cols.push({name:'single', cx:singleH.cx});
        const hdrY = groupH.y;
        const rowsByY = {};
        document.querySelectorAll('input').forEach((inp, idx) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 30 || r.height < 4) return;
            if (r.y < hdrY + 5) return;                 // 表头以下才是数据行
            const cx = r.x + r.width/2;
            let best=null, bd=99999;
            for (const c of cols){ const d=Math.abs(cx-c.cx); if(d<bd){bd=d;best=c;} }
            if (!best || bd > 80) return;               // 离列头太远 → 不是价格表列
            const ykey = Math.round(r.y/12)*12;
            rowsByY[ykey] = rowsByY[ykey] || {};
            rowsByY[ykey][best.name] = {idx, disabled:!!(inp.disabled||inp.readOnly),
                                        v:(inp.value||'').trim(), y:Math.round(r.y)};
        });
        const rows = Object.keys(rowsByY).map(k=>({y:+k, ...rowsByY[k]}))
                           .sort((a,b)=>a.y-b.y)
                           .filter(r => r.group && r.single);  // 至少有拼单/单买
        return {rows, hdrY};
    }""")


async def _fix_prices_via_cluster(edit_page, rec: dict, spec_names: list) -> dict:
    """价格/库存修复(列头法 + 详情页有序规格名 1:1 对应)。

    策略(由 test_rowcapture 验证,健壮于多 SKU / 换行 / 库存为0 / 款式列是文本):
      1. spec_names = 详情页 read_detail_state 读到的有序规格名(rowspan 已处理)
      2. 列头法抓编辑页价格表所有行(拼单价/单买价/库存 input 索引),按 y 升序
      3. 行数核对:编辑页行数 == 详情页规格数 才写(对不上 abort,绝不写错行)
      4. 第 i 行 ← 第 i 个规格名 → _units_of 算份数 → native setter 写拼单价/单买价/库存
    返回 {ok, fixed, total, log[]}。
    """
    out = {"ok": False, "fixed": 0, "total": 0, "log": []}
    supplier_cost = float(rec.get("supplier_cost", 0) or 0)
    shipping      = float(rec.get("shipping", 4.0) or 4.0)
    margin        = float(rec.get("margin", 0.9) or 0.9)
    single_extra  = float(rec.get("single_buy_extra", 2.0) or 2.0)
    stock_expect  = int(rec.get("stock", 0) or 0)
    if supplier_cost <= 0:
        out["log"].append("supplier_cost<=0,无法算价")
        return out
    names = [n for n in (spec_names or []) if n]
    if not names:
        out["log"].append("详情页规格名为空,无法对应,放弃")
        return out

    # 滚整页确保所有行渲染(多 SKU 时编辑页要滚到底)
    try:
        await edit_page.evaluate(
            """async()=>{for(let y=0;y<document.body.scrollHeight;y+=500){window.scrollTo(0,y);await new Promise(r=>setTimeout(r,200));}}""")
        await asyncio.sleep(1)
    except Exception:
        pass

    cap = await _capture_price_rows(edit_page)
    if cap.get("err"):
        out["log"].append(f"抓价格表列头失败: {cap['err']}")
        return out
    rows = cap.get("rows", [])

    # ★ 行数核对闸刀:编辑页价格行数 必须 == 详情页规格数,否则 abort(防写错行)
    if len(rows) != len(names):
        out["log"].append(f"编辑页价格行 {len(rows)} ≠ 详情页规格 {len(names)},映射不安全,放弃")
        return out

    safe_y_min = (cap.get("hdrY") or 0)  # 表头 y;写入必须在表头以下

    out["total"] = len(rows) * 2   # 每行 group+single,有库存再 +1
    for i, row in enumerate(rows):
        spec_name = names[i]
        units = _units_of(spec_name, rec)
        cost = supplier_cost * units + shipping
        group_price = _ceil_to_9(cost / (1 - margin))
        single_price = _ceil_to_9(group_price + single_extra)
        write_specs = [
            ("拼单价", row["group"]["idx"], group_price),
            ("单买价", row["single"]["idx"], single_price),
        ]
        if row.get("stock") and not row["stock"].get("disabled"):
            write_specs.append(("库存", row["stock"]["idx"], stock_expect))
            out["total"] += 1
        for label, dom_idx, value in write_specs:
            res = await edit_page.evaluate(f"""() => {{
                const inp = document.querySelectorAll('input')[{dom_idx}];
                if (!inp) return {{err: 'no_input_at_idx'}};
                const r = inp.getBoundingClientRect();
                if (r.y < {safe_y_min} + 5) return {{err: 'unsafe_y', y: r.y}};
                if (inp.disabled || inp.readOnly) return {{err: 'readonly'}};
                const before = inp.value;
                const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                setter.call(inp, String({value!r}));
                inp.dispatchEvent(new Event('input', {{bubbles: true}}));
                inp.dispatchEvent(new Event('change', {{bubbles: true}}));
                return {{ok: true, before, after: inp.value}};
            }}""")
            if res.get("ok"):
                out["fixed"] += 1
                out["log"].append(f"[{i}] {spec_name[:16]} {label} {res['before']} -> {res['after']}")
            else:
                out["log"].append(f"[{i}] {spec_name[:16]} {label} 失败: {res}")
        await asyncio.sleep(0.3)

    out["ok"] = out["fixed"] > 0
    return out


async def _save_debug_screenshot(page, goods_id: str, tag: str) -> str:
    """失败时保存截图到 data/pdd/publish_logs/inspect_<goods_id>_<tag>.png。返回路径。"""
    out_dir = Path(r"D:/files/data/pdd/publish_logs")
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"inspect_{goods_id}_{tag}.png"
    try:
        await asyncio.wait_for(page.screenshot(path=str(path), full_page=False), timeout=5)
        print(f"[inspect] 调试截图: {path}", file=sys.stderr)
    except Exception as e:
        print(f"[inspect] 截图失败 {path}: {e}", file=sys.stderr)
    return str(path)


def _compare_with_fixes(rec: dict, state: dict) -> tuple[list[str], list[dict]]:
    """对比期望与实际,返回 (reasons 字符串列表, fixes 结构化修复指令)。
    fixes 每项 = {spec_name, field, value} field ∈ {'spec_suffix', 'stock', 'group_price', 'single_price'}
    """
    reasons: list[str] = []
    fixes: list[dict] = []
    suffix = (rec.get("suffix") or "").strip()
    stock_expect = int(rec.get("stock", 0) or 0)
    supplier_cost = float(rec.get("supplier_cost", 0) or 0)
    shipping = float(rec.get("shipping", 4.0) or 4.0)
    margin = float(rec.get("margin", 0.9) or 0.9)
    single_extra = float(rec.get("single_buy_extra", 2.0) or 2.0)
    specs = state.get("specs", []) or []
    unit_specs = state.get("unit_specs", []) or specs   # 份数靠"套餐"列(最后一层),没有就退回 specs
    stocks = state.get("stocks", []) or []
    groups = state.get("groups", []) or []
    singles = state.get("singles", []) or []
    if not specs:
        reasons.append("⚠ 未抓到任何规格 input(可能编辑页没加载完整或商品被删)")
        return reasons, fixes
    # 1) 后缀(防比价搭配)——加在 SKU 变体名「套餐/最后一层」(unit_specs)上,不是款式!
    #    款式是合并的基础款,加上去没意义且会污染;套餐才是逐个 SKU 的可编辑规格名。
    if suffix:
        miss = [(i + 1, s) for i, s in enumerate(unit_specs) if suffix not in s]
        if miss:
            reasons.append(f"❌ 规格缺搭配「{suffix}」({len(miss)}/{len(unit_specs)} 行):"
                           + "、".join(f"行{i}「{s[:24]}」" for i, s in miss[:3])
                           + ("…" if len(miss) > 3 else ""))
            # 套餐通常各不相同(各有独立 input);仍对相同 spec_name 去重,防极端重复产生虚假失败。
            _seen_suffix = set()
            for i, s in miss:
                if s in _seen_suffix:
                    continue
                _seen_suffix.add(s)
                # 补后缀时顺手清「赠品」违禁词(否则含"无赠品"的名编辑会被 PDD 驳回 → 改不动)
                fixes.append({"spec_name": s, "field": "spec_suffix", "value": _strip_banned_words(s) + suffix})
    # 2) 库存
    if stock_expect > 0:
        for i, st in enumerate(stocks):
            try:
                actual = int(str(st).strip() or "0")
            except ValueError:
                continue
            if actual != stock_expect:
                name = (unit_specs[i] if i < len(unit_specs)
                        else (specs[i] if i < len(specs) else ""))  # 用套餐(各行不同)定位
                fixes.append({"spec_name": name, "field": "stock", "value": stock_expect, "actual": actual})
        mis_stock = [f for f in fixes if f["field"] == "stock"]
        if mis_stock:
            reasons.append(f"❌ 库存差异({len(mis_stock)} 行):期望={stock_expect}")
    # 3) 价格
    if supplier_cost > 0 and margin < 0.99:
        n = min(len(specs), len(groups), len(singles))
        mis_group, mis_single = [], []
        for i in range(n):
            # 定位名用套餐(unit_specs,各行不同):款式是合并的、3行相同 → fix_row_field 区分不了会写错行
            name = unit_specs[i] if i < len(unit_specs) else specs[i]
            units = _units_of(name, rec)  # 份数也取套餐(后缀会被 rec.suffix 剥离)
            cost = supplier_cost * units + shipping
            exp_group = _ceil_to_9(cost / (1 - margin))
            exp_single = _ceil_to_9(exp_group + single_extra)
            try: act_group = float(groups[i])
            except (ValueError, TypeError): act_group = 0
            try: act_single = float(singles[i])
            except (ValueError, TypeError): act_single = 0
            if abs(act_group - exp_group) > 0.01:
                mis_group.append((i + 1, name[:20], act_group, exp_group))
                fixes.append({"spec_name": name, "field": "group_price", "value": exp_group, "actual": act_group})
            if abs(act_single - exp_single) > 0.01:
                mis_single.append((i + 1, name[:20], act_single, exp_single))
                fixes.append({"spec_name": name, "field": "single_price", "value": exp_single, "actual": act_single})
        if mis_group:
            reasons.append(f"❌ 拼单价差异({len(mis_group)} 行):"
                           + "、".join(f"行{i}「{nm}」实际{a}/期望{e}" for i, nm, a, e in mis_group[:3])
                           + ("…" if len(mis_group) > 3 else ""))
        if mis_single:
            reasons.append(f"❌ 单买价差异({len(mis_single)} 行):"
                           + "、".join(f"行{i}「{nm}」实际{a}/期望{e}" for i, nm, a, e in mis_single[:3])
                           + ("…" if len(mis_single) > 3 else ""))
    # 顺序很重要:先修价格/库存(按套餐名定位,此刻套餐名还没被后缀改动),最后才补后缀。
    # 补后缀会把套餐名改成「…+冻膜一小包」,若先补则价格/库存按旧套餐名找不到行 → 打乱。
    fixes.sort(key=lambda f: 1 if f.get("field") == "spec_suffix" else 0)
    return reasons, fixes


def _compare(rec: dict, state: dict) -> list[str]:
    """旧接口,只返回 reasons。新代码用 _compare_with_fixes。"""
    reasons, _ = _compare_with_fixes(rec, state)
    return reasons


def _compare_old(rec: dict, state: dict) -> list[str]:
    """对比期望 (rec) 与实际 (state),返回差异原因列表(空 = OK)。已被 _compare_with_fixes 替换,保留 import 兼容。"""
    reasons: list[str] = []
    suffix = (rec.get("suffix") or "").strip()
    stock_expect = int(rec.get("stock", 0) or 0)
    supplier_cost = float(rec.get("supplier_cost", 0) or 0)
    shipping = float(rec.get("shipping", 4.0) or 4.0)
    margin = float(rec.get("margin", 0.9) or 0.9)
    single_extra = float(rec.get("single_buy_extra", 2.0) or 2.0)

    specs = state.get("specs", []) or []
    unit_specs = state.get("unit_specs", []) or specs   # 份数靠"套餐"列(最后一层)
    stocks = state.get("stocks", []) or []
    groups = state.get("groups", []) or []
    singles = state.get("singles", []) or []

    if not specs:
        reasons.append("⚠ 未抓到任何规格 input(可能编辑页没加载完整或商品被删)")
        return reasons

    # 1) 规格名是否含搭配后缀
    if suffix:
        miss = [(i + 1, s) for i, s in enumerate(specs) if suffix not in s]
        if miss:
            reasons.append(
                f"❌ 规格缺搭配「{suffix}」({len(miss)}/{len(specs)} 行):"
                + "、".join(f"行{i}「{s[:24]}」" for i, s in miss[:3])
                + ("…" if len(miss) > 3 else "")
            )

    # 2) 库存
    if stock_expect > 0:
        mis_stock = []
        for i, st in enumerate(stocks):
            try:
                actual = int(str(st).strip() or "0")
            except ValueError:
                continue
            if actual != stock_expect:
                mis_stock.append((i + 1, actual))
        if mis_stock:
            reasons.append(
                f"❌ 库存差异({len(mis_stock)} 行):"
                + "、".join(f"行{i}={a}" for i, a in mis_stock[:3])
                + ("…" if len(mis_stock) > 3 else "")
                + f"  期望={stock_expect}"
            )

    # 3) 价格(只核对常规规格行 = min(specs, groups, singles))
    if supplier_cost > 0 and margin < 0.99:
        n = min(len(specs), len(groups), len(singles))
        mis_group, mis_single = [], []
        for i in range(n):
            # 定位名用套餐(unit_specs,各行不同):款式是合并的、3行相同 → fix_row_field 区分不了会写错行
            name = unit_specs[i] if i < len(unit_specs) else specs[i]
            units = _units_of(name, rec)  # 份数也取套餐(后缀会被 rec.suffix 剥离)
            cost = supplier_cost * units + shipping
            exp_group = _ceil_to_9(cost / (1 - margin))
            exp_single = _ceil_to_9(exp_group + single_extra)
            try:
                act_group = float(groups[i])
            except (ValueError, TypeError):
                act_group = 0
            try:
                act_single = float(singles[i])
            except (ValueError, TypeError):
                act_single = 0
            if abs(act_group - exp_group) > 0.01:
                mis_group.append((i + 1, name[:20], act_group, exp_group))
            if abs(act_single - exp_single) > 0.01:
                mis_single.append((i + 1, name[:20], act_single, exp_single))
        if mis_group:
            reasons.append(
                f"❌ 拼单价差异({len(mis_group)} 行):"
                + "、".join(f"行{i}「{n}」实际{a}/期望{e}"
                            for i, n, a, e in mis_group[:3])
                + ("…" if len(mis_group) > 3 else "")
            )
        if mis_single:
            reasons.append(
                f"❌ 单买价差异({len(mis_single)} 行):"
                + "、".join(f"行{i}「{n}」实际{a}/期望{e}"
                            for i, n, a, e in mis_single[:3])
                + ("…" if len(mis_single) > 3 else "")
            )

    return reasons


async def read_detail_state(detail_page) -> dict:
    """从商品详情页(goods_detail)底部「规格与库存」静态表读规格行。

    用作 read_edit_state 的对照/兜底:编辑页 input 数量可能因 PDD 提示文字、
    disabled 行、groupInps 大于实际行数等情况误判,而详情页表是静态渲染的
    最终发布态,更稳。

    返回结构对齐 read_edit_state:
        {"specs": [str], "stocks": [str], "groups": [str], "singles": [str]}
    详情页可能没拼单/单买两列价(只有一列价或不显示价),缺的就给空列表。
    任何环节失败都返回 {}（不抛异常,旁路对照不应阻塞主流程）。
    """
    try:
        # 先滚到底部触发懒加载
        try:
            await detail_page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await asyncio.sleep(1)
            await detail_page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await asyncio.sleep(1)
        except Exception:
            pass

        data = await detail_page.evaluate(r"""() => {
            // 策略:找包含「规格与库存」/「SKU信息」/「规格列表」的标题节点 →
            //   从该节点向上找最近 section 容器 → 在容器内找 table 或 grid 行
            const TITLES = ['规格与库存', 'SKU信息', '规格列表', '规格信息'];
            const STOCK_HDRS = ['库存', '可售库存', '剩余库存'];
            const GROUP_HDRS = ['拼单价', '团购价', '拼团价'];
            const SINGLE_HDRS = ['单买价', '单买', '直购价'];
            // 款式列名:严格等于(不用 includes 因为 "规格编码"/"规格预览图" 也含"规格"会撞)
            // 优先"区分 SKU 的名字列"(颜色/款式/型号),不含净含量/包装规格(那是容量维度)
            const NAME_HDRS_EXACT = ['款式', '色号', '颜色', '型号', '规格', '规格名', 'SKU', '型号/颜色',
                '规格说明', '规格类型', '型号规格', '名称', '商品名称'];
            // 容量维度,优先级低:只在没有上面那些时才当 spec(多维规格里净含量是合并列,不区分行)
            const NAME_HDRS_FALLBACK = ['净含量', '包装规格', '商品规格'];
            // 表头排除列(避免被 NAME_HDRS includes 误匹配)
            const NAME_EXCLUDE = ['规格编码', '规格预览图', '规格图', '规格预览', '编码'];

            // 找标题节点
            const all = Array.from(document.querySelectorAll('div,section,h1,h2,h3,h4,span,p'));
            let titleEl = null;
            for (const el of all) {
                const t = (el.innerText || '').trim();
                if (t.length > 50) continue;
                if (TITLES.some(k => t === k || t.startsWith(k))) { titleEl = el; break; }
            }
            if (!titleEl) return {found:false, reason:'未找到标题节点'};

            // 向上爬最多 6 层找一个 section 容器
            let container = titleEl;
            for (let i = 0; i < 6; i++) {
                if (container.parentElement) container = container.parentElement;
                if (container.querySelector('table') || container.querySelectorAll('[role="row"]').length >= 2)
                    break;
            }

            // PDD beast-core-table 会渲染多个 <table>(sticky 表头 + body 数据各一份)。
            // 不能用 querySelector('table') 拿第一个 —— sticky 表头那个 tbody 是空的。
            // 选 tbody tr 最多的 table 作为「数据表」;再用同容器内第一个有 thead 的 table 解析列头。
            const allTbls = Array.from(container.querySelectorAll('table'));
            let tbl = null, tblHead = null, maxBodyRows = 0;
            for (const t of allTbls) {
                const n = t.querySelectorAll('tbody tr').length;
                if (n > maxBodyRows) { maxBodyRows = n; tbl = t; }
            }
            for (const t of allTbls) {
                if (t.querySelector('thead')) { tblHead = t; break; }
            }
            if (!tbl) tbl = tblHead;             // 没数据表,降级用表头那张(空结果)
            if (!tblHead) tblHead = tbl;          // 没独立表头,数据表内可能就有 thead
            const specs=[], unit_specs=[], stocks=[], groups=[], singles=[];
            let colSpec=-1, colSpecFb=-1, colStock=-1, colGroup=-1, colSingle=-1;
            // rowspan/colspan 感知:把表格展开成完整网格(合并格向下/向右复制单元格文本)。
            // 多维规格(如 净含量×颜色)时净含量是跨行合并列,不展开会导致非首行列号错位 → 规格名读成库存"0"。
            const expand = (rows) => {
                const grid = [];
                const carry = {};   // col -> {text, left}
                rows.forEach((tr, r) => {
                    grid[r] = [];
                    let c = 0, ti = 0;
                    const cells = Array.from(tr.querySelectorAll('td,th'));
                    while (true) {
                        if (carry[c] && carry[c].left > 0) {   // 上方 rowspan 落下来
                            grid[r][c] = carry[c].text; carry[c].left--; c++; continue;
                        }
                        if (ti >= cells.length) break;
                        const td = cells[ti++];
                        const text = (td.innerText||'').trim();
                        const rs = parseInt(td.getAttribute('rowspan')||'1');
                        const cs = parseInt(td.getAttribute('colspan')||'1');
                        for (let k=0;k<cs;k++){
                            grid[r][c] = text;
                            if (rs>1) carry[c] = {text, left: rs-1};
                            c++;
                        }
                    }
                });
                return grid;
            };
            if (tbl) {
                const headRows = Array.from(tblHead.querySelectorAll('thead tr'));
                const headGrid = expand(headRows.length ? headRows
                                        : [tbl.querySelector('tr')].filter(Boolean));
                const headCells = headGrid.length ? headGrid[headGrid.length-1] : [];
                headCells.forEach((tt,i) => {
                    const t=(tt||'').trim();
                    if (NAME_EXCLUDE.some(k=>t.includes(k))) return;  // 跳过"规格编码"等
                    if (colSpec<0 && NAME_HDRS_EXACT.includes(t)) colSpec=i;
                    else if (colSpecFb<0 && NAME_HDRS_FALLBACK.includes(t)) colSpecFb=i;
                    if (colStock<0 && STOCK_HDRS.some(k=>t.includes(k))) colStock=i;
                    else if (colGroup<0 && GROUP_HDRS.some(k=>t.includes(k))) colGroup=i;
                    else if (colSingle<0 && SINGLE_HDRS.some(k=>t.includes(k))) colSingle=i;
                });
                if (colSpec < 0) colSpec = colSpecFb;   // 没有颜色/款式 → 退回净含量/包装规格
                // 兜底:白名单都没匹到 → 默认第 0 列是 spec(只要它不在 NAME_EXCLUDE)
                if (colSpec < 0 && headCells.length > 0) {
                    const t0 = (headCells[0]||'').trim();
                    if (!NAME_EXCLUDE.some(k=>t0.includes(k))) colSpec = 0;
                }
                // 份数列(套餐=最后一层变体列):库存列左边那列;仅真2层(在 colSpec 右侧)时用它,否则用 colSpec。
                // 与发布端 fill_prices「取最右规格列」同一把尺子,避免核查把多份价改回 1 份。
                const colVariant = (colStock > 0 && colStock - 1 > colSpec) ? colStock - 1 : colSpec;
                const bodyRows = Array.from(tbl.querySelectorAll('tbody tr'));
                const grid = expand(bodyRows.length ? bodyRows
                                    : Array.from(tbl.querySelectorAll('tr')).slice(1));
                const grab = (row, idx) => idx>=0 && idx<row.length ? (row[idx]||'').trim() : '';
                grid.forEach(row => {
                    if (!row || row.length < 2) return;
                    const name = grab(row, colSpec) || grab(row, 0);
                    if (!name) return;
                    specs.push(name);
                    unit_specs.push(grab(row, colVariant) || name);   // 份数靠这列(套餐)
                    stocks.push(grab(row, colStock));
                    groups.push(grab(row, colGroup));
                    singles.push(grab(row, colSingle));
                });
                return {found:true, mode:'table', specs, unit_specs, stocks, groups, singles,
                        cols:{spec:colSpec, variant:colVariant, stock:colStock, group:colGroup, single:colSingle}};
            }

            // 兜底:role=row grid
            const rrows = container.querySelectorAll('[role="row"]');
            if (rrows.length >= 2) {
                // 第一行当 header
                const hcells = rrows[0].querySelectorAll('[role="columnheader"],[role="cell"]');
                hcells.forEach((c,i)=>{
                    const t=(c.innerText||'').trim();
                    if (NAME_EXCLUDE.some(k=>t.includes(k))) return;
                    if (colSpec<0 && NAME_HDRS_EXACT.includes(t)) colSpec=i;
                    else if (colStock<0 && STOCK_HDRS.some(k=>t.includes(k))) colStock=i;
                    else if (colGroup<0 && GROUP_HDRS.some(k=>t.includes(k))) colGroup=i;
                    else if (colSingle<0 && SINGLE_HDRS.some(k=>t.includes(k))) colSingle=i;
                });
                const colVariantG = (colStock > 0 && colStock - 1 > colSpec) ? colStock - 1 : colSpec;
                for (let i=1;i<rrows.length;i++){
                    const cells=rrows[i].querySelectorAll('[role="cell"],[role="gridcell"]');
                    if (cells.length<2) continue;
                    const grab=(idx)=>idx>=0&&idx<cells.length?(cells[idx].innerText||'').trim():'';
                    const name=grab(colSpec)||(cells[0].innerText||'').trim();
                    if (!name) continue;
                    specs.push(name); unit_specs.push(grab(colVariantG)||name);
                    stocks.push(grab(colStock));
                    groups.push(grab(colGroup)); singles.push(grab(colSingle));
                }
                return {found:true, mode:'grid', specs, unit_specs, stocks, groups, singles,
                        cols:{spec:colSpec, variant:colVariantG, stock:colStock, group:colGroup, single:colSingle}};
            }

            return {found:false, reason:'容器内无 table / role=row'};
        }""")
        if not data or not data.get("found"):
            print(f"[detail-state] 未抽到表 reason={data.get('reason') if data else 'eval返回空'}",
                  file=sys.stderr)
            return {}
        # 库存/价格里数字提取(去掉 "件"/"￥" 等单位)
        import re as _re
        def _num(s: str) -> str:
            if not s: return ""
            m = _re.search(r"[\d.]+", s)
            return m.group(0) if m else ""
        stocks = [_num(x) for x in data.get("stocks", [])]
        groups = [_num(x) for x in data.get("groups", [])]
        singles = [_num(x) for x in data.get("singles", [])]
        print(f"[detail-state] mode={data.get('mode')} rows={len(data.get('specs',[]))} "
              f"cols={data.get('cols')}", file=sys.stderr)
        print(f"[detail-state] specs(款式/匹配)={data.get('specs', [])[:4]}", file=sys.stderr)
        print(f"[detail-state] unit_specs(套餐/份数)={data.get('unit_specs', [])[:4]}", file=sys.stderr)
        return {"specs": data.get("specs", []), "unit_specs": data.get("unit_specs", []),
                "stocks": stocks, "groups": groups, "singles": singles}
    except Exception as e:
        print(f"[detail-state] 异常: {e}", file=sys.stderr)
        return {}


async def inspect_one(context, rec: dict) -> dict:
    """打开商品详情页 → 点编辑商品按钮 → 读编辑页状态,对比 → 返回结果。

    不能直接 goto goods_edit?goods_id=X (PDD 没这个直链,会重定向到列表),
    必须按用户路径:detail_url → click 编辑商品 → 新 tab(edit page)。
    """
    goods_id = str(rec.get("goods_id", "")).strip()
    name = rec.get("target_name", "") or rec.get("name", "")
    detail_url = rec.get("detail_url") or (
        f"https://mms.pinduoduo.com/goods/goods_detail?goods_id={goods_id}" if goods_id else "")
    if not goods_id or not detail_url:
        return {"goods_id": goods_id, "name": name, "ok": False,
                "reasons": ["⚠ 缺 goods_id / detail_url,无法核查"]}

    detail_page = await context.new_page()
    edit_page = None
    try:
        try:
            await detail_page.goto(detail_url, wait_until="domcontentloaded", timeout=30000)
        except Exception as e:
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": [f"⚠ 商品详情页打开超时: {e}"], "url": detail_url}
        await asyncio.sleep(4)

        # 检测页面状态(驳回 / 审核中)→ 不进编辑直接返回
        try:
            page_status = await detail_page.evaluate("""() => {
                const t = document.body.innerText || '';
                if (t.includes('发布已驳回')) return 'rejected';
                if (t.includes('新商品发布中')) return 'pending';
                return 'ok';
            }""")
        except Exception:
            page_status = 'ok'
        if page_status == 'rejected':
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": ["⚠ PDD 状态: 发布已驳回(需先排查驳回原因)"], "url": detail_url}
        if page_status == 'pending':
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": ["⚠ PDD 状态: 新商品发布中(审核未完成,无法核查)"], "url": detail_url}

        # === 详情页静态表预检(首要判定源)===
        # 详情页底部「规格与库存」表是 PDD 最终对外发布态,比编辑页 input 更稳。
        # 若已对齐 → 直接 return ok,不点击「编辑商品」,不开新 tab,不整改。
        detail_state = await read_detail_state(detail_page)
        # 核查也用云端 DeepSeek 判份数(和智能SKU发布同判官),注入 rec.units_map → 下面所有
        # _compare/_units_of 优先用云端份数,避免本地正则/7B 盲区误判价 + 列头法毁价(踩过 966765928983)。
        if not rec.get("units_map"):
            _nm = (detail_state or {}).get("unit_specs") or (detail_state or {}).get("specs") or []
            if _nm:
                rec["units_map"] = _cloud_units_map(_nm, rec)
        reasons_detail = None
        if detail_state and detail_state.get("specs"):
            reasons_detail = _compare(rec, detail_state)
            if not reasons_detail:
                print(f"[inspect] 详情页表已对齐,跳过编辑页核查 "
                      f"specs={len(detail_state['specs'])}", file=sys.stderr)
                return {"goods_id": goods_id, "name": name, "ok": True,
                        "reasons": [], "url": detail_url,
                        "specs_count": len(detail_state.get("specs", []) or []),
                        "source": "detail"}
            print(f"[inspect] 详情页表显示 {len(reasons_detail)} 处差异 → 进编辑页整改",
                  file=sys.stderr)
        else:
            print(f"[inspect] 详情页表抓取失败,回落到编辑页核查", file=sys.stderr)

        # 点编辑商品 → 拿到 edit page
        # 不依赖 click_edit_goods 返回值(8s expect_event 常误判 fallback);
        # 自己记录 click 前 pages,click 后轮询 context.pages 找新增的 goods_add tab
        pages_before = set(id(p) for p in detail_page.context.pages)
        try:
            await click_edit_goods(detail_page)  # 只用它的「找按钮+点击」逻辑,忽略返回值
        except Exception as e:
            await _save_debug_screenshot(detail_page, goods_id, "click_fail")
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": [f"⚠ 点击「编辑商品」失败: {e}  (截图 inspect_{goods_id}_click_fail.png)"],
                    "url": detail_url}
        # 轮询最多 12s,等新 tab 出现 + 加载完成
        edit_page = None
        for poll in range(12):
            await asyncio.sleep(1)
            try:
                new_pages = [p for p in detail_page.context.pages
                             if id(p) not in pages_before
                             and p is not detail_page
                             and "goods_add" in (p.url or "")]
            except Exception:
                new_pages = []
            if new_pages:
                edit_page = new_pages[-1]  # 取最新一个
                break
        if not edit_page:
            # 也许 click 没开新 tab,但 detail_page 自己跳到了 edit URL
            try:
                if "goods_add" in (detail_page.url or ""):
                    edit_page = detail_page
                    print(f"[inspect] detail_page 自身已跳到 edit URL: {detail_page.url[:80]}",
                          file=sys.stderr)
            except Exception:
                pass
        if not edit_page:
            await _save_debug_screenshot(detail_page, goods_id, "no_edit_tab")
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": [
                        "⚠ 12s 内未捕获到新 edit tab(按钮可能被遮 / 商品冻结 / context 隔离)",
                        f"  截图: inspect_{goods_id}_no_edit_tab.png"
                    ],
                    "url": detail_url}
        # 等 edit_page 加载完成
        try:
            await edit_page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            pass
        await asyncio.sleep(3)
        print(f"[inspect] edit_page url: {(edit_page.url or '')[:120]}", file=sys.stderr)

        # 兜底:扫一下「存在已驳回审核详情」弹窗
        try:
            rejected_dlg = await edit_page.evaluate("""() => (document.body.innerText||'').includes('存在已驳回审核详情')""")
        except Exception:
            rejected_dlg = False
        if rejected_dlg:
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": ["⚠ 检测到「存在已驳回审核详情」弹窗(需先在 PDD 后台处理驳回)"], "url": detail_url}

        try:
            state = await read_edit_state(edit_page)
        except Exception as e:
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": [f"⚠ 读取编辑页状态失败: {e}"], "url": detail_url}

        # 详情页没抓到规格(units_map 还没建)→ 用编辑页规格名兜底再判一次云端
        if not rec.get("units_map"):
            _nm = state.get("unit_specs") or state.get("specs") or []
            if _nm:
                rec["units_map"] = _cloud_units_map(_nm, rec)

        # reasons 主源:已在详情页预检过且抓到表 → 用 reasons_detail;
        # 否则(详情页表抓取失败) → 用编辑页 state
        if reasons_detail is not None:
            reasons = reasons_detail
            # 顺便记录编辑页读出的差异作为对照
            try:
                rsn_edit = _compare(rec, state)
                if rsn_edit != reasons_detail:
                    print(f"[detail-vs-edit] DIFF reasons "
                          f"detail={len(reasons_detail)} edit={len(rsn_edit)}", file=sys.stderr)
            except Exception:
                pass
        else:
            reasons = _compare(rec, state)
        if not reasons:
            return {"goods_id": goods_id, "name": name, "ok": True,
                    "reasons": [], "url": detail_url,
                    "specs_count": len(state.get("specs", []) or []),
                    "source": "edit" if reasons_detail is None else "detail"}

        # 自动整改:对结构性差异(规格/库存/价格)在 edit_page 上重跑二次提交流程
        # 不修复的:商品状态异常(驳回/审核中,reasons 含"PDD 状态")
        fixable = all(("PDD 状态" not in r and "未能进入编辑页" not in r
                       and "点击「编辑商品」失败" not in r
                       and "存在已驳回审核详情" not in r
                       and "读取编辑页状态失败" not in r) for r in reasons)
        if not fixable:
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": reasons, "fixed": False, "fix_skipped_reason": "不可自动修复的状态异常",
                    "url": detail_url, "specs_count": len(state.get("specs", []) or [])}

        print(f"[inspect-fix] 检测到 {len(reasons)} 处差异 → 启动自动整改", file=sys.stderr)
        fix_log: list[str] = []
        try:
            # 用 detail_state 的真值再算一次 fixes(结构化修复指令)
            # fixes 每项 = {spec_name, field('spec_suffix'/'stock'/'group_price'/'single_price'), value}
            _reasons2, fixes = _compare_with_fixes(rec, detail_state or {})
            print(f"[inspect-fix] {len(fixes)} 条精准修复指令", file=sys.stderr)
            from pdd_publish import fix_row_field
            ok_count = 0
            fail_count = 0
            price_failures = 0    # 价格类(group/single)主路径失败计数
            stock_failures = 0    # 库存类失败计数(cluster 现在也能补)
            suffix_failures = 0   # 规格名后缀失败计数(只能靠 fix_row_field 键盘输入)
            for fix in fixes:
                ok = await fix_row_field(edit_page, fix["spec_name"], fix["field"], fix["value"], actual_value=fix.get("actual"))
                if ok:
                    ok_count += 1
                else:
                    fail_count += 1
                    if fix["field"] in ("group_price", "single_price"):
                        price_failures += 1
                    elif fix["field"] == "stock":
                        stock_failures += 1
                    elif fix["field"] == "spec_suffix":
                        suffix_failures += 1
            fix_log.append(f"按规格名精准修复:{ok_count} 成功 / {fail_count} 失败 / {len(fixes)} 总")

            # 主路径有价格类失败 → 启用 y 聚类兜底(fix_oneshot_prices 验证过的策略)
            # 这一招对所有"一维多规格"商品都有效,不限于"拍一发X"开头。
            # 任何匹配不上的边界 case(单 SKU / 多维规格 / 列变)都会自动 abort,不写任何 input。
            # 主路径有价格类或库存类失败 → 启用 y 聚类兜底(同时修拼单价/单买价/库存)
            cluster_full_ok = False
            if price_failures > 0 or stock_failures > 0:
                print(f"[inspect-fix] 价格失败{price_failures}/库存失败{stock_failures} → 启用 y 聚类兜底",
                      file=sys.stderr)
                _names = ((detail_state or {}).get("unit_specs") or (detail_state or {}).get("specs", [])) if 'detail_state' in dir() else []  # 份数取套餐列
                cluster_res = await _fix_prices_via_cluster(edit_page, rec, _names)
                fix_log.append(f"列头法兜底: ok={cluster_res['ok']} "
                               f"fixed={cluster_res['fixed']}/{cluster_res['total']}")
                for ln in cluster_res.get("log", []):
                    print(f"  [cluster] {ln}", file=sys.stderr)
                cluster_full_ok = (cluster_res.get("ok")
                                   and cluster_res.get("fixed") == cluster_res.get("total"))
            if ok_count == 0 and not cluster_full_ok:
                fix_log.append("未安全写入任何字段,跳过提交")
                print("[inspect-fix] 未安全写入任何字段且兜底未全成功 → 跳过提交", file=sys.stderr)
                return {"goods_id": goods_id, "name": name, "ok": False,
                        "reasons": reasons + ["❌ 自动整改未能定位到可安全写入的 SKU 行,已跳过提交"],
                        "fixed": False, "fix_log": fix_log,
                        "fix_skipped_reason": "no_safe_write",
                        "url": detail_url,
                        "specs_count": len(state.get("specs", []) or [])}

            # 4) 提交
            submit_ok = await click_edit_submit(edit_page)
            fix_log.append(f"提交={'OK' if submit_ok else 'FAIL'}")
            if not submit_ok:
                await _save_debug_screenshot(edit_page, goods_id, "fix_submit_fail")
                return {"goods_id": goods_id, "name": name, "ok": False,
                        "reasons": reasons + [f"❌ 自动整改提交失败 (截图 inspect_{goods_id}_fix_submit_fail.png)"],
                        "fixed": False, "fix_log": fix_log,
                        "url": detail_url}

            # 短路:修复全成功 + 提交 OK → 直接判 ok,跳过会读到旧数据的二次校验。
            # 原因:PDD 提交后详情页可能还在处理(read_detail_state 读不到表),
            # 回落读 edit 页时 edit 已跳到 success 页 → 读到旧值 → 误报 mismatch。
            #   - fail_count==0:所有 fix_row_field 都成功
            #   - 或 cluster 全成功(已覆盖 价格+库存)且 后缀没失败(后缀只能靠键盘 fix_row_field)
            if submit_ok and (fail_count == 0 or (cluster_full_ok and suffix_failures == 0)):
                print(f"[inspect] 修复全成功(fix {ok_count}/{len(fixes)}, "
                      f"cluster_full={cluster_full_ok}, suffix_fail={suffix_failures})"
                      f"+ 提交 OK → 判 ok,跳过二次校验", file=sys.stderr)
                return {"goods_id": goods_id, "name": name, "ok": True,
                        "reasons": reasons, "reasons2": [], "fixed": True,
                        "fix_log": fix_log, "url": detail_url,
                        "specs_count": len(state.get("specs", []) or [])}

            # 5) 重读核对 —— 优先 reload 详情页用静态表判定(比编辑页 input 稳)
            await asyncio.sleep(3)
            state2_detail = {}
            try:
                await detail_page.reload(wait_until="domcontentloaded", timeout=20000)
                await asyncio.sleep(3)
                state2_detail = await read_detail_state(detail_page)
            except Exception as _re:
                print(f"[inspect] 整改后 detail reload 失败,回落 edit: {_re}", file=sys.stderr)
            if state2_detail and state2_detail.get("specs"):
                state2 = state2_detail
                verify_source = "detail"
            else:
                try:
                    state2 = await read_edit_state(edit_page)
                except Exception:
                    state2 = {}
                verify_source = "edit"
            reasons2 = _compare(rec, state2)
            print(f"[inspect] 整改后校验 source={verify_source} 剩余差异={len(reasons2)}",
                  file=sys.stderr)
            return {"goods_id": goods_id, "name": name,
                    "ok": len(reasons2) == 0,
                    "reasons":  reasons,        # 原差异
                    "reasons2": reasons2,       # 修复后还剩的
                    "fixed": len(reasons2) == 0,
                    "fix_log": fix_log,
                    "url": detail_url,
                    "specs_count": len(state.get("specs", []) or []),
                    "verify_source": verify_source}
        except Exception as e:
            await _save_debug_screenshot(edit_page, goods_id, "fix_exception")
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "reasons": reasons + [f"❌ 自动整改异常: {e} (截图 inspect_{goods_id}_fix_exception.png)"],
                    "fixed": False, "fix_log": fix_log,
                    "url": detail_url}
    finally:
        for p in (edit_page, detail_page):
            if p:
                try: await p.close()
                except Exception: pass
async def _read_detail_spec_code_values(page) -> list[str]:
    try:
        return await page.evaluate(r"""() => {
          const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0};
          for(const table of [...document.querySelectorAll('table')].filter(visible)){
            const rows=[...table.querySelectorAll('tr')]; if(!rows.length)continue;
            const head=rows.map(r=>({r,n:r.querySelectorAll('th,td').length})).sort((a,b)=>b.n-a.n)[0]?.r;
            if(!head)continue;
            const cells=[...head.querySelectorAll('th,td')]; const idx=cells.findIndex(c=>(c.innerText||c.textContent||'').trim()==='规格编码');
            if(idx<0)continue;
            return rows.filter(r=>r!==head).map(r=>{const c=r.querySelectorAll('td,th')[idx];return c?(c.innerText||c.textContent||'').trim():'';});
          }
          return [];
        }""")
    except Exception:
        return []

async def repair_spec_code_one(context, rec: dict) -> dict:
    """Open one published item's edit page and submit only newly filled spec codes."""
    goods_id = str(rec.get("goods_id") or "").strip()
    name = rec.get("target_name") or ""
    detail_url = rec.get("detail_url") or (
        f"https://mms.pinduoduo.com/goods/goods_detail?goods_id={goods_id}" if goods_id else "")
    if not goods_id or not detail_url:
        return {"goods_id": goods_id, "name": name, "ok": False,
                "submitted": False, "reasons": ["missing-goods-id-or-detail-url"]}

    detail_page = await context.new_page()
    edit_page = None
    try:
        try:
            await detail_page.goto(detail_url, wait_until="domcontentloaded", timeout=30000)
        except Exception as exc:
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "submitted": False, "reasons": [f"detail-open-failed:{exc}"], "url": detail_url}
        await asyncio.sleep(3)
        try:
            detail_state = await read_detail_state(detail_page)
            known_styles = list(detail_state.get("specs") or [])
        except Exception:
            known_styles = []
        pages_before = set(id(p) for p in detail_page.context.pages)
        try:
            await click_edit_goods(detail_page)
        except Exception as exc:
            await _save_debug_screenshot(detail_page, goods_id, "spec_code_click_fail")
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "submitted": False, "reasons": [f"edit-click-failed:{exc}"], "url": detail_url}
        for _ in range(12):
            await asyncio.sleep(1)
            new_pages = [p for p in detail_page.context.pages
                         if id(p) not in pages_before and p is not detail_page
                         and "goods_add" in (p.url or "")]
            if new_pages:
                edit_page = new_pages[-1]
                break
        if not edit_page and "goods_add" in (detail_page.url or ""):
            edit_page = detail_page
        if not edit_page:
            await _save_debug_screenshot(detail_page, goods_id, "spec_code_no_edit_tab")
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "submitted": False, "reasons": ["edit-tab-not-found"], "url": detail_url}
        try:
            await edit_page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            pass
        await asyncio.sleep(2)
        if not rec.get("units_map") and known_styles:
            rec["units_map"] = _cloud_units_map(known_styles, rec)
        pdd_name = await read_pdd_product_name(edit_page)
        supplier_title = ""
        supplier_url = (rec.get("supplier_url") or "").strip()
        if not pdd_name and supplier_url:
            try:
                supplier_title = await read_supplier_offer_title(context, supplier_url)
            except Exception as exc:
                print(f"[spec-code] supplier title fallback failed (non-blocking): {exc}")
        result = await fill_spec_codes(
            edit_page, pdd_name, supplier_title, rec.get("suffix", "") or "",
            correct_existing=True, confirmed_units_map=rec.get("units_map") or {}, known_styles=known_styles)
        if result.get("written", 0) <= 0:
            already_complete = result.get("status") == "ok" and result.get("existing", 0) > 0
            reason = "all-spec-codes-already-exist" if already_complete else result.get("reason", "no-spec-codes-written")
            return {"goods_id": goods_id, "name": name, "ok": already_complete,
                    "submitted": False, "verified": already_complete, "spec_code": result,
                    "reasons": [reason], "url": detail_url}
        if result.get("status") != "ok" or not result.get("write_verified"):
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "submitted": False, "verified": False, "spec_code": result,
                    "reasons": [result.get("reason", "spec-code-write-not-verified")], "url": detail_url}

        submitted = await click_edit_submit(edit_page)
        if not submitted:
            await _save_debug_screenshot(edit_page, goods_id, "spec_code_submit_fail")
            return {"goods_id": goods_id, "name": name, "ok": False,
                    "submitted": False, "spec_code": result,
                    "reasons": ["spec-code-submit-failed"], "url": detail_url}
        await asyncio.sleep(4)
        try:
            # When PDD keeps editing in the original detail tab, submitting navigates
            # that tab to a success page. Reloading it would then verify the success
            # page rather than the product detail table.
            if edit_page is detail_page:
                await detail_page.goto(detail_url, wait_until="domcontentloaded", timeout=20000)
            else:
                await detail_page.reload(wait_until="domcontentloaded", timeout=20000)
            await asyncio.sleep(2)
        except Exception:
            pass
        values = await _read_detail_spec_code_values(detail_page)
        expected_codes = result.get("expected_codes") or []
        verified = bool(expected_codes) and values == expected_codes
        if not verified:
            result = dict(result)
            result["status"] = "partial"
            result["reason"] = "detail-readback-failed"
        return {"goods_id": goods_id, "name": name, "ok": verified,
                "submitted": True, "verified": verified, "spec_code": result,
                "reasons": [] if verified else ["spec-code-detail-readback-failed"], "url": detail_url}
    except Exception as exc:
        if edit_page:
            await _save_debug_screenshot(edit_page, goods_id, "spec_code_exception")
        return {"goods_id": goods_id, "name": name, "ok": False,
                "submitted": False, "reasons": [f"spec-code-repair-error:{exc}"], "url": detail_url}
    finally:
        for page in (edit_page, detail_page):
            if page:
                try:
                    await page.close()
                except Exception:
                    pass

async def run(args):
    # 读 records
    records = json.loads(Path(args.records_json).read_text(encoding="utf-8"))
    if not isinstance(records, list):
        print("ERROR: records-json 顶层应为 list", file=sys.stderr)
        sys.exit(2)
    print(f"[核查] 共 {len(records)} 条待核查 store={args.store!r}", file=sys.stderr)

    # 选 profile
    stores = _load_stores()
    matched = next((k for k in stores if args.store in k or k in args.store), None)
    if matched:
        profile_dir = PROFILE_DIR / stores[matched]
        print(f"[profile] 匹配到: {matched}", file=sys.stderr)
    else:
        profile_dir = _profile_dir_for(args.store)
    print(f"[profile] {profile_dir}", file=sys.stderr)

    chrome_exe = find_chrome()
    print(f"[Chrome] {chrome_exe}", file=sys.stderr)

    results: list[dict] = []
    # 浏览器显隐:默认静默(屏幕外+大尺寸),--show-browser 时最大化
    _win_args = ["--start-maximized"] if getattr(args, "show_browser", False) \
        else ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            executable_path=chrome_exe,
            headless=False,
            args=_win_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        # 强制窗口模式(复用同 profile 旧窗口时启动参数可能不生效)
        _ip = context.pages[0] if context.pages else await context.new_page()
        from pdd_publish import apply_window_mode
        await apply_window_mode(context, _ip, getattr(args, "show_browser", False))
        for i, rec in enumerate(records, 1):
            print(f"\n[核查 {i}/{len(records)}] goods_id={rec.get('goods_id')}  name={(rec.get('target_name') or '')[:30]}",
                  file=sys.stderr)
            try:
                result = await (repair_spec_code_one(context, rec) if args.repair_spec_code else inspect_one(context, rec))
                results.append(result)
                if result.get("ok"):
                    print(f"  ✓ OK", file=sys.stderr)
                else:
                    for r in result.get("reasons", []):
                        print(f"  {r}", file=sys.stderr)
            except Exception as e:
                print(f"  异常: {e}", file=sys.stderr)
                results.append({
                    "goods_id": rec.get("goods_id"),
                    "name":     rec.get("target_name", ""),
                    "ok":       False,
                    "reasons":  [f"⚠ 核查异常: {e}"],
                })
        try:
            await asyncio.wait_for(context.close(), timeout=3)
        except Exception:
            pass

    # 写输出
    out_path = Path(args.output_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n[OK] 结果写入 {out_path}", file=sys.stderr)
    # 摘要到 stdout
    ok_n = sum(1 for r in results if r.get("ok"))
    fail_n = len(results) - ok_n
    print(json.dumps({
        "total": len(results),
        "ok":    ok_n,
        "fail":  fail_n,
        "output_json": str(out_path),
    }, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", required=True, help="店铺名(模糊匹配)")
    parser.add_argument("--records-json", required=True, help="待核查记录 JSON 文件")
    parser.add_argument("--output-json", required=True, help="输出结果 JSON 文件")
    parser.add_argument("--auto-close", action="store_true", help="完成后自动退出(供 client 调用)")
    parser.add_argument("--repair-spec-code", action="store_true", help="修复或纠正规格编码；有变更后才提交")
    parser.add_argument("--show-browser", action="store_true", help="显示浏览器（调试用）；默认屏幕外静默")
    args = parser.parse_args()

    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        sys.exit(130)
    finally:
        if args.auto_close:
            os._exit(0)


if __name__ == "__main__":
    main()
