"""PDD 商品状态同步：
逐个 goods_id 在「商品列表 / 在售中」搜索，
- 找到 → status='ok' (在售)
- 找不到 → status='taken_down' (已下架)
更新 D:/files/data/pdd/pdd_publish_history.json；没有本地记录时会扫描并导入该店在售老品。

用法：
  python pdd_sync_status.py --store 元气少女美妆馆 [--goods-ids id1,id2] [--auto-close]
  不传 --goods-ids 则同步该 store 下所有 history 记录
"""
import argparse
import asyncio
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from playwright.async_api import async_playwright
from pdd_takedown import (
    _profile_dir_for, find_chrome, load_history, save_history,
    GOODS_LIST_URL,
)


BATCH_SIZE = 50  # PDD 商品ID 搜索框单次最大数
RECYCLE_URL = "https://mms.pinduoduo.com/goods/goods_recycle"  # 已删除商品(回收站)


async def _click_all_tab(page):
    """点商品列表「全部」tab(一次显示所有状态:在售/已下架/已售罄/驳回…),区别于商品分类的「全部」。"""
    try:
        await page.evaluate(r"""() => {
            for (const el of document.querySelectorAll('a,span,div,li')) {
                if ((el.innerText || '').trim() !== '全部') continue;
                const r = el.getBoundingClientRect();
                const p = el.parentElement;
                if (p && (p.innerText || '').includes('在售中') && r.width > 10 && r.width < 140 && r.height > 8) {
                    el.click(); return;
                }
            }
        }""")
        await asyncio.sleep(2)
    except Exception:
        pass


async def _set_page_size_100(page):
    """把结果每页数量设为100(beast-core select)→ 一批≤50个ID的结果一页装下,免翻页漏行。
    ★必须在【搜索前】设(改每页会清空搜索)。"""
    try:
        # ★先滚到分页栏(每页控件在结果底部,视口外时直接点下拉头不稳)——同步引擎之前缺这步,加上更稳(同下架引擎)
        await page.evaluate(r"""() => {
            const el = document.querySelector('[class*=PGT_sizeChanger]')
                    || document.querySelector('li[class*=PGT_pagerItem]')
                    || document.querySelector('[class*=PGT_outerWrapper]');
            if (el) el.scrollIntoView({block: 'center'});
        }""")
        await asyncio.sleep(0.8)
        opened = await page.evaluate(r"""() => {
            const sc = document.querySelector('[class*=PGT_sizeChanger]');
            if (!sc) return false;
            const hd = sc.querySelector('[data-testid="beast-core-select-header"]') || sc.querySelector('[class*=ST_head]');
            if (!hd) return false;
            hd.click(); return true;
        }""")
        if not opened:
            return False
        await asyncio.sleep(0.9)
        # ★只点 beast-core select 下拉里的选项 li(ul[role=listbox].ST_dropdownPanel > li[role=option] > span「100」)
        #   绝不用泛 li/div/[class*=option](页面底部"机会商品"卡片的热度值也是100,会误触跳发布页)
        clicked = await page.evaluate(r"""() => {
            const lis = document.querySelectorAll(
                '[class*=ST_dropdownPanel] li[role="option"], [data-testid="beast-core-portal"] li[role="option"]');
            for (const el of lis) {
                if ((el.innerText || '').trim() === '100') {
                    const r = el.getBoundingClientRect();
                    if (r.width > 4 && r.height > 4) { el.click(); return true; }
                }
            }
            return false;
        }""")
        await asyncio.sleep(2)
        # 安全网:万一不慎跳离商品列表(误触发布页等),退回列表再点全部 tab(翻页选择器已修,仍能正常同步)
        if "goods_list" not in (page.url or ""):
            try:
                await page.goto(GOODS_LIST_URL, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(3)
                await _click_all_tab(page)
            except Exception:
                pass
            return False
        return clicked
    except Exception:
        return False


async def batch_search_ids(page, ids: list) -> dict:
    """一次性把多个 goods_id 填入搜索框查询。返回 {gid: 状态}(ok=在售 / taken_down=已下架 / sold_out=售罄)。
    需先点「全部」tab + 设100/页,在售/下架/售罄都在结果里,逐行读状态。"""
    if not ids:
        return {}
    # 1) 定位「商品ID」输入框（用 label 锚定）
    info = await page.evaluate("""() => {
        let labelEl = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品ID') { labelEl = el; break; }
        }
        if (!labelEl) return {err: 'no_label'};
        const lr = labelEl.getBoundingClientRect();
        const labelCenterY = lr.y + lr.height/2;
        const labelRight = lr.x + lr.width;
        let best = null, bestDist = Infinity;
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 80) return;
            const cy = r.y + r.height/2;
            if (Math.abs(cy - labelCenterY) > 25) return;
            const dx = r.x - labelRight;
            if (dx < -10 || dx > 400) return;
            if (dx < bestDist) { bestDist = dx; best = {i, x: r.x, y: r.y, w: r.width}; }
        });
        return best || {err: 'no_input'};
    }""")
    if info.get("err"):
        print(f"  [!] 未找到「商品ID」输入框: {info}")
        return {}
    # 2) 用空格分隔（PDD 支持空格/逗号），fill 一次性填入
    joined = " ".join(ids)
    inputs_loc = page.locator('input')
    await inputs_loc.nth(info["i"]).fill(joined)
    await asyncio.sleep(0.5)
    print(f"  [批量] 已填入 {len(ids)} 个 ID")
    # 3) 点击查询
    clicked = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('button, a, [role="button"]')) {
            const txt = (el.innerText || '').trim();
            if (txt === '查询' || txt === '搜索') {
                const r = el.getBoundingClientRect();
                if (r.width >= 30 && r.width <= 200 && r.height >= 20 && r.height <= 70 && el.tagName === 'BUTTON') {
                    el.click();
                    return {x: Math.round(r.x), y: Math.round(r.y)};
                }
            }
        }
        return null;
    }""")
    if not clicked:
        print(f"  [!] 未找到查询按钮")
        return {}
    print(f"  [批量] 已点击查询，等待结果加载...")
    await asyncio.sleep(6)
    # 4) 翻页逐行读状态:每页对未命中的 id,爬到「操作列(含预览)」那行,读 售罄/已下架 → 映射状态。
    #    点 PGT_next 翻到禁用为止(搜索过滤翻页时保留)。
    found = {}   # gid -> ok(在售) / taken_down(已下架) / sold_out(售罄)
    pno = 0
    for pno in range(1, 21):
        remaining = [g for g in ids if g not in found]
        page_map = await page.evaluate(r"""(ids) => {
            const out = {};
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            let node;
            while (node = walker.nextNode()) {
                const tx = node.textContent;
                for (const gid of ids) {
                    if (out[gid] || !tx.includes(gid)) continue;
                    let el = node.parentElement, row = null;
                    for (let i = 0; i < 14 && el; i++) {           // 爬到含「预览」(每行操作列都有)的祖先=整行
                        const t = el.innerText || '';
                        if (t.includes('预览') && t.includes(gid)) { row = el; break; }
                        el = el.parentElement;
                    }
                    const t = (row ? row.innerText : (node.parentElement ? node.parentElement.innerText : '')) || '';
                    let st = 'ok';
                    if (t.includes('售罄')) st = 'sold_out';
                    else if (t.includes('已下架')) st = 'taken_down';   // 注:在售行的操作按钮是「下架」,不含「已」,不会误判
                    out[gid] = st;
                }
            }
            return out;
        }""", remaining)
        for gid, st in page_map.items():
            found[gid] = st
        if len(found) >= len(ids):
            break                                   # 全找到了,提前停
        nxt = await page.evaluate(r"""() => {
            const el = document.querySelector('[data-testid="beast-core-pagination-next"]');
            if (!el) return 'none';
            if ((el.className || '').toString().includes('PGT_disabled')) return 'disabled';
            el.scrollIntoView({block:'center'}); el.click(); return 'clicked';
        }""")
        if nxt != 'clicked':
            break
        await asyncio.sleep(2.5)                     # 等下一页渲染
    from collections import Counter
    print(f"  [批量] 命中 {len(found)}/{len(ids)} 个(扫了 {pno} 页) 状态={dict(Counter(found.values()))}")
    return found


async def _dismiss_popups(page):
    """关掉登录后弹的「新消息(N)」通知面板等浮层(浮在右侧会盖住操作列「恢复」)。多策略,非致命。"""
    for _ in range(3):
        closed = await page.evaluate(r"""() => {
            let did = false;
            for (const el of document.querySelectorAll('div, section')) {
                const t = el.innerText || '';
                if (t.includes('新消息') && t.includes('查看全部') && t.length < 3000) {
                    const ics = el.querySelectorAll(
                        '.anticon-close, [class*=close], [class*=Close], [aria-label*=close], svg');
                    for (const ic of ics) {
                        const r = ic.getBoundingClientRect();
                        if (r.width > 6 && r.width < 60 && r.height > 6 && r.height < 60) {
                            ic.dispatchEvent(new MouseEvent('click', {bubbles: true}));
                            did = true; break;
                        }
                    }
                }
            }
            return did;
        }""")
        try:
            await page.keyboard.press("Escape")
        except Exception:
            pass
        await asyncio.sleep(0.5)
        if not closed:
            break


async def _recycle_set_page_size_100(page):
    """回收站每页设100(beast-core 分页)。★不带 goods_list 安全网(那是给商品列表用的,会把回收站误导走)。非致命。"""
    try:
        await page.evaluate(r"""() => {
            const el = document.querySelector('[class*=PGT_sizeChanger]')
                    || document.querySelector('[class*=PGT_outerWrapper]');
            if (el) el.scrollIntoView({block: 'center'});
        }""")
        await asyncio.sleep(0.6)
        opened = await page.evaluate(r"""() => {
            const sc = document.querySelector('[class*=PGT_sizeChanger]');
            if (!sc) return false;
            const hd = sc.querySelector('[data-testid="beast-core-select-header"]') || sc.querySelector('[class*=ST_head]');
            if (!hd) return false;
            hd.click(); return true;
        }""")
        if not opened:
            return
        await asyncio.sleep(0.8)
        await page.evaluate(r"""() => {
            const lis = document.querySelectorAll(
                '[class*=ST_dropdownPanel] li[role="option"], [data-testid="beast-core-portal"] li[role="option"]');
            for (const el of lis) {
                if ((el.innerText || '').trim() === '100') {
                    const r = el.getBoundingClientRect();
                    if (r.width > 4 && r.height > 4) { el.click(); return; }
                }
            }
        }""")
        await asyncio.sleep(1.5)
    except Exception:
        pass


async def _recycle_fill_search(page, joined: str) -> bool:
    """回收站:把 ID(空格分隔)填进「商品ID」框并点查询。查询按钮不限定 BUTTON 标签(PDD 常是 div/span)。"""
    info = await page.evaluate("""() => {
        let labelEl = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品ID') { labelEl = el; break; }
        }
        if (!labelEl) return {err: 'no_label'};
        const lr = labelEl.getBoundingClientRect();
        const labelCenterY = lr.y + lr.height/2;
        const labelRight = lr.x + lr.width;
        let best = null, bestDist = Infinity;
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 80) return;
            const cy = r.y + r.height/2;
            if (Math.abs(cy - labelCenterY) > 25) return;
            const dx = r.x - labelRight;
            if (dx < -10 || dx > 400) return;
            if (dx < bestDist) { bestDist = dx; best = {i}; }
        });
        return best || {err: 'no_input'};
    }""")
    if info.get("err"):
        print(f"  [回收站] 未找到「商品ID」搜索框: {info}")
        return False
    await page.locator('input').nth(info["i"]).fill(joined)
    await asyncio.sleep(0.5)
    clicked = await page.evaluate("""() => {
        const cands = [];
        for (const el of document.querySelectorAll('button, a, [role="button"], div, span')) {
            const t = (el.innerText || '').trim();
            if (t !== '查询' && t !== '搜索') continue;
            const r = el.getBoundingClientRect();
            if (r.width >= 30 && r.width <= 200 && r.height >= 20 && r.height <= 70) {
                cands.push({el, score: el.tagName === 'BUTTON' ? 0 : 1});
            }
        }
        if (!cands.length) return false;
        cands.sort((a, b) => a.score - b.score);
        cands[0].el.click();
        return true;
    }""")
    if not clicked:
        print("  [回收站] 未找到查询按钮")
        return False
    await asyncio.sleep(5)
    return True


async def _read_recycle_rows(page, ids: list) -> set:
    """回收站【真实结果行】:gid 的文本祖先里同时含「恢复/还原/彻底删除」(操作列)才算命中=已删除。
    翻页扫到 PGT_next 禁用为止。★只认真实行,不认搜索框回显(抗误判,探针正反验证过)。返回命中 gid 集合。"""
    found = set()
    for _pno in range(1, 21):
        remaining = [g for g in ids if g not in found]
        if not remaining:
            break
        page_hits = await page.evaluate(r"""(ids) => {
            const out = [];
            const seen = {};
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            let node;
            while (node = walker.nextNode()) {
                const tx = node.textContent;
                for (const gid of ids) {
                    if (seen[gid] || !tx.includes(gid)) continue;
                    let el = node.parentElement;
                    for (let i = 0; i < 14 && el; i++) {
                        const t = el.innerText || '';
                        if (t.includes(gid) && (t.includes('恢复') || t.includes('还原') || t.includes('彻底删除'))) {
                            seen[gid] = true; out.push(gid); break;
                        }
                        el = el.parentElement;
                    }
                }
            }
            return out;
        }""", remaining)
        for gid in page_hits:
            found.add(gid)
        nxt = await page.evaluate(r"""() => {
            const el = document.querySelector('[data-testid="beast-core-pagination-next"]');
            if (!el) return 'none';
            if ((el.className || '').toString().includes('PGT_disabled')) return 'disabled';
            el.scrollIntoView({block:'center'}); el.click(); return 'clicked';
        }""")
        if nxt != 'clicked':
            break
        await asyncio.sleep(2.5)
    return found


async def check_recycle(page, ids: list) -> set:
    """对"全部 tab 没查到的失踪 ID",去回收站核查哪些真在回收站(=已删除)。分批≤50。返回已删除 gid 集合。"""
    deleted = set()
    chunks = [ids[i:i+BATCH_SIZE] for i in range(0, len(ids), BATCH_SIZE)]
    for ci, chunk in enumerate(chunks, 1):
        print(f"  [回收站核查 {ci}/{len(chunks)}] {len(chunk)} 个失踪ID")
        await page.goto(RECYCLE_URL, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(3)
        await _dismiss_popups(page)                    # 关「新消息」面板,免遮挡操作列
        await _recycle_set_page_size_100(page)
        if not await _recycle_fill_search(page, " ".join(chunk)):
            continue
        await _dismiss_popups(page)                    # 搜后弹窗可能再冒
        hits = await _read_recycle_rows(page, chunk)
        deleted |= hits
    print(f"  [回收站核查] 命中(判 deleted): {len(deleted)}/{len(ids)}")
    return deleted


async def _click_insale_tab(page) -> bool:
    """点「在售中」tab(实际文字带计数,如「在售中(67)」)。默认本就在该 tab,这步是保险。"""
    clicked = await page.evaluate(r"""() => {
        for (const el of document.querySelectorAll('a, span, div, li')) {
            const t = (el.innerText || '').trim();
            if (t === '在售中' || t.startsWith('在售中(') || t.startsWith('在售中（')) {
                const r = el.getBoundingClientRect();
                if (r.width > 10 && r.width < 160 && r.height > 8 && r.height < 60) { el.click(); return true; }
            }
        }
        return false;
    }""")
    await asyncio.sleep(2)
    return clicked


async def _collect_insale(page) -> dict:
    """翻页收集「在售中」真实商品行:返回 {gid: {name, image, price, stock, ctime}}。
    真实行锚定:12位 gid 的文本祖先里含「下架」或「编辑」=我的在售商品。字段解析见各注释。"""
    out = {}
    for _pno in range(1, 30):
        page_rows = await page.evaluate(r"""() => {
            const res = [];
            const seen = {};
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            let node;
            while (node = walker.nextNode()) {
                const tx = node.textContent || '';
                const mm = tx.match(/\b(\d{11,13})\b/);
                if (!mm) continue;
                const gid = mm[1];
                if (gid.length !== 12 || seen[gid]) continue;     // 只认12位 goods_id,排除电话/通知号噪音
                let el = node.parentElement, row = null;
                for (let i = 0; i < 14 && el; i++) {
                    const t = el.innerText || '';
                    if (t.includes(gid) && (t.includes('下架') || t.includes('编辑'))) { row = el; break; }
                    el = el.parentElement;
                }
                if (!row) continue;
                const lines = (row.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
                const SKIP = ['优惠券','促销','报名','大促','健康商品','机会商品','问题商品','待修改',
                              '销售中','暂无','修改价格','修改库存','编辑','下架','预览','发布相似品','商品编码'];
                let name = '';
                for (const ln of lines) {
                    if (!/[一-龥]/.test(ln)) continue;
                    if (SKIP.some(k => ln.includes(k))) continue;
                    if (ln.length > name.length) name = ln;
                }
                let price = '';                                    // 「修改价格」上一行=价格区间
                // ① 有「活动价」优先取活动价(大促等;划线原价不取)
                for (const ln of lines) {
                    const am = ln.match(/活动价[:：]\s*¥?\s*(\d+(?:\.\d+)?(?:\s*[～~-]\s*\d+(?:\.\d+)?)?)/);
                    if (am) { price = am[1].trim(); break; }
                }
                // ② 否则「修改价格」上一行
                if (!price) for (let i = 0; i < lines.length; i++) {
                    if (lines[i].includes('修改价格') && i > 0) {
                        const cand = lines[i-1].replace(/\t.*/, '').trim();
                        if (!/\d{4}-\d{2}-\d{2}/.test(cand)) price = cand;   // 防把日期当价格
                        break;
                    }
                }
                if (!price) {
                    // 无「修改价格」(如大促锁价的皙颜):只认"带小数/区间"的整行价格;库存销量是整数、日期带-,都排除
                    for (const ln of lines) {
                        if (/\d{4}-\d{2}-\d{2}/.test(ln)) continue;
                        const pm = ln.match(/^¥?\s*(\d+(?:\.\d+)?\s*[～~-]\s*\d+(?:\.\d+)?|\d+\.\d+)\s*$/);
                        if (pm) { price = pm[1].trim(); break; }
                    }
                }
                let stock = '';                                    // 「修改库存」上一行的整数
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i].includes('修改库存') && i > 0) { const sm = lines[i-1].match(/^\d+$/); if (sm) stock = sm[0]; break; }
                }
                let ctime = '';                                    // 上架时间 2026-06-03 21:28
                for (const ln of lines) { const cm = ln.match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?/); if (cm) { ctime = cm[0]; break; } }
                let image = '';
                const im = row.querySelector('img');
                if (im && im.src) image = im.src.split('?')[0];
                seen[gid] = true;
                res.push([gid, {name, image, price, stock, ctime}]);
            }
            return res;
        }""")
        before = len(out)
        for gid, info in page_rows:
            out.setdefault(gid, info)
        nxt = await page.evaluate(r"""() => {
            const el = document.querySelector('[data-testid="beast-core-pagination-next"]');
            if (!el) return 'none';
            if ((el.className || '').toString().includes('PGT_disabled')) return 'disabled';
            el.scrollIntoView({block:'center'}); el.click(); return 'clicked';
        }""")
        if nxt != 'clicked':
            break
        await asyncio.sleep(2.5)
    return out


async def discover_unknown(page, store, history) -> tuple:
    """扫该店「在售中」整页:软件没有的在售品 → 导入(打🚩+补全 价格/库存/上架时间/图片);
    已是导入品 → 刷新字段;程序自己发的 → 绝不碰。返回 (新增数, 刷新数)。"""
    by_gid = {}
    for r in history:
        if r.get("store") == store and r.get("goods_id"):
            by_gid.setdefault(r["goods_id"], r)
    await page.goto(GOODS_LIST_URL, wait_until="domcontentloaded", timeout=30000)
    await asyncio.sleep(3)
    await _dismiss_popups(page)
    await _click_insale_tab(page)
    await asyncio.sleep(1.5)
    await _set_page_size_100(page)
    insale = await _collect_insale(page)
    now = time.strftime("%Y-%m-%d %H:%M:%S")

    def _mk(g):
        d = insale[g]
        stock = int(d["stock"]) if (d["stock"] or "").isdigit() else (d["stock"] or "")
        return {
            "time": d["ctime"] or now, "status": "ok", "store": store,
            "target_name": d["name"], "goods_id": g, "stock": stock,
            "pdd_price": d["price"], "published_main_image": d["image"],
            "detail_url": f"https://mms.pinduoduo.com/goods/goods_detail?goods_id={g}",
            "source": "pdd_import", "external": True, "note": "非本程序上架",
            "imported_at": now, "last_synced": now,
        }

    added = updated = 0
    for g in insale:
        rec = by_gid.get(g)
        if rec is None:
            history.append(_mk(g)); added += 1
        elif rec.get("source") == "pdd_import" or rec.get("external"):
            f = _mk(g)
            rec.update({k: f[k] for k in
                        ("status", "target_name", "stock", "pdd_price",
                         "published_main_image", "detail_url", "source", "external", "note", "last_synced")})
            updated += 1
        # else: 程序自己发的记录,状态已由「全部 tab」环节维护,这里不碰
    print(f"  [导入未知在售品] 在售中共 {len(insale)} 个 → 新增 {added}、刷新 {updated}")
    return added, updated


async def run(args):
    chrome_exe = find_chrome()
    profile_dir = _profile_dir_for(args.store)
    if not profile_dir.exists():
        print(f"[!] profile 不存在: {profile_dir}")
        return 2

    history = load_history()
    if args.goods_ids:
        wanted = {gid.strip() for gid in args.goods_ids.split(",") if gid.strip()}
        records = [r for r in history if r.get("store") == args.store and r.get("goods_id") in wanted]
    else:
        records = [r for r in history if r.get("store") == args.store and r.get("goods_id")]
    print(f"[同步] 店铺={args.store}  待核查 {len(records)} 条")
    if not records:
        print("[同步] 本地无记录：跳过按 ID 核验，扫描并导入该店在售老品")

    _win_args = ["--start-maximized"] if getattr(args, "show_browser", False) \
        else ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            executable_path=chrome_exe,
            headless=False,
            args=_win_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        page = context.pages[0] if context.pages else await context.new_page()
        from pdd_publish import apply_window_mode
        await apply_window_mode(context, page, getattr(args, "show_browser", False))
        await page.goto(GOODS_LIST_URL, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(4)

        # 收集所有 ids 分批
        all_ids = [r["goods_id"] for r in records]
        id_to_rec = {r["goods_id"]: r for r in records}
        chunks = [all_ids[i:i+BATCH_SIZE] for i in range(0, len(all_ids), BATCH_SIZE)]
        print(f"[同步] 共 {len(all_ids)} 个 ID，分 {len(chunks)} 批，每批最多 {BATCH_SIZE}")

        # 查【全部 tab】活动状态:在售=ok / 已下架=taken_down / 售罄=sold_out
        all_status = {}
        for ci, chunk in enumerate(chunks, 1):
            print(f"\n[批次 {ci}/{len(chunks)}] 查询 {len(chunk)} 个 ID")
            # 每批前重置到列表页(清空上批搜索)+ 点「全部」tab(显示所有状态)
            await page.goto(GOODS_LIST_URL, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            await _click_all_tab(page)
            await _set_page_size_100(page)                 # ★搜前设100/页,免翻页漏行(治"在售误判已下架")
            found = await batch_search_ids(page, chunk)    # {gid: ok/taken_down/sold_out}
            all_status.update(found)

        # 回收站核查:全部 tab 没查到的"失踪"ID,转回收站看是否已删除(只认真实行,探针正反验证过)
        recycle_deleted = set()
        if getattr(args, "check_recycle", True):
            missing = [g for g in all_ids if g not in all_status]
            if missing:
                print(f"\n[回收站] 全部 tab 未命中 {len(missing)} 个,转回收站核查是否已删除")
                recycle_deleted = await check_recycle(page, missing)

        # 更新 status:
        #   ① 全部 tab 查到 → 读到的真实状态(在售/已下架/售罄)
        #   ② 全部 tab 没查到、但回收站真实行命中 → deleted
        #   ③ 两处都没查到 → 【不动】(可能漏抓/网络/30天清除,绝不瞎判,避免误删在售品)
        changed = 0
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for gid, rec in id_to_rec.items():
            old_status = rec.get("status", "")
            if gid in all_status:
                new_status = all_status[gid]
            elif gid in recycle_deleted:
                new_status = "deleted"                 # 回收站真实行命中 → 已删除
            else:
                continue                               # 哪都没查到 → 不动它(不瞎判)
            if new_status != old_status:
                rec["status"] = new_status
                rec["last_synced"] = now
                changed += 1
                print(f"  {gid}: {old_status} → {new_status}")

        # 导入未知在售品:扫该店「在售中」整页,把软件没有的在售品自动抓进来(打🚩)。所有店、每次同步都自动跑。
        if getattr(args, "import_unknown", True):
            print(f"\n[导入] 扫「在售中」整页,自动导入软件没有的在售品...")
            try:
                await discover_unknown(page, args.store, history)
            except Exception as e:
                print(f"  [!] 导入未知在售品出错(跳过,不影响同步): {e}")

        save_history(history)
        print(f"\n[OK] 同步完成：{changed}/{len(records)} 条状态变更")

        if args.auto_close:
            print("[OK] 自动关闭浏览器")
            try:
                await asyncio.wait_for(context.close(), timeout=5)
            except Exception:
                pass
        else:
            print("[OK] 浏览器保持开启")
            try:
                await page.wait_for_event("close", timeout=0)
            except Exception:
                pass
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", required=True)
    ap.add_argument("--goods-ids", default="")
    ap.add_argument("--auto-close", action="store_true")
    ap.add_argument("--show-browser", action="store_true", help="显示浏览器（调试用）；默认屏幕外静默")
    ap.add_argument("--check-recycle", dest="check_recycle", action="store_true", default=True,
                    help="全部tab没查到的ID再去回收站核查是否已删除(默认开)")
    ap.add_argument("--no-check-recycle", dest="check_recycle", action="store_false",
                    help="关闭回收站核查(只查全部tab,旧行为)")
    ap.add_argument("--import-unknown", dest="import_unknown", action="store_true", default=True,
                    help="扫在售中整页,自动导入软件没有的在售品(打🚩,默认开)")
    ap.add_argument("--no-import-unknown", dest="import_unknown", action="store_false",
                    help="关闭自动导入未知在售品")
    args = ap.parse_args()
    raise SystemExit(asyncio.run(run(args)))
