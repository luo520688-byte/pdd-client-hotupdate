"""Selected-goods rejected-video cleanup. No business files are read or written.

The controller is independent of browser selectors so deletion guards can be
tested without opening a store. A browser adapter must return settled, scoped
first-page snapshots and recheck the target immediately before confirmation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Protocol
import re


MANAGEMENT_URL = "https://live.pinduoduo.com/n-creator/video/mall-goods-video?from=mms"
REJECTED = "审核失败"


class CleanupSafetyError(RuntimeError):
    """Missing or ambiguous evidence; do not perform another deletion."""


class CleanupStopped(RuntimeError):
    pass


def require_id(value: str) -> str:
    value = str(value or "").strip()
    if not re.fullmatch(r"[0-9]+", value):
        raise CleanupSafetyError("商品/视频 ID 必须是完整数字")
    return value


@dataclass(frozen=True)
class VideoRow:
    video_id: str
    status: str


@dataclass(frozen=True)
class FailedVideoPage:
    goods_id: str
    filter_status: str
    total: int
    rows: tuple[VideoRow, ...]
    page_number: int = 1
    settled: bool = True


def validate_page(snapshot: FailedVideoPage, goods_id: str) -> None:
    if snapshot.goods_id != require_id(goods_id):
        raise CleanupSafetyError("弹窗商品 ID 与选中商品不一致")
    if snapshot.filter_status != REJECTED:
        raise CleanupSafetyError("未确认审核失败筛选")
    if not snapshot.settled or snapshot.page_number != 1:
        raise CleanupSafetyError("列表尚未稳定或不在第一页")
    if type(snapshot.total) is not int or snapshot.total < 0:
        raise CleanupSafetyError("无法确认筛选后总数")
    ids = []
    for row in snapshot.rows:
        ids.append(require_id(row.video_id))
        if row.status != REJECTED:
            raise CleanupSafetyError("列表含非审核失败视频，停止该商品")
    if len(ids) != len(set(ids)) or len(ids) > snapshot.total:
        raise CleanupSafetyError("列表 ID 重复或数量异常")
    if snapshot.total == 0 and snapshot.rows:
        raise CleanupSafetyError("空列表计数与视频行冲突")


class CleanupPage(Protocol):
    async def read_first_page(self, goods_id: str, *, refresh: bool = False) -> FailedVideoPage: ...

    async def delete_video(self, goods_id: str, video_id: str,
                           should_stop: Callable[[], bool]) -> None: ...


@dataclass
class CleanupResult:
    goods_id: str
    mode: str
    found: int | None = None
    deleted: int = 0
    remaining: int | None = None
    failed: int = 0
    stopped: bool = False
    complete: bool = False
    message: str = ""
    preview_ids: list[str] = field(default_factory=list)
    deleted_ids: list[str] = field(default_factory=list)


async def cleanup_goods(adapter: CleanupPage, goods_id: str, *, execute: bool = False,
                        should_stop: Callable[[], bool] = lambda: False,
                        on_progress: Callable[[str], None] = lambda message: None,
                        limit: int | None = None) -> CleanupResult:
    """Preview by default. A timed-out delete is inspected once, never resubmitted.

    ``limit=1`` supports an explicitly authorized single-video probe. Completion
    requires a second freshly filtered empty list, not just a missing DOM row.
    Remaining is unknown after ambiguous outcomes rather than inventing zero.
    """
    result = CleanupResult(str(goods_id), "execute" if execute else "preview")
    if limit is not None and (type(limit) is not int or limit < 1):
        raise ValueError("limit must be a positive integer")
    seen: set[str] = set()

    def check_stop():
        if should_stop():
            raise CleanupStopped("已停止；未继续删除")

    async def read(*, refresh=False):
        check_stop()
        snapshot = await adapter.read_first_page(goods_id, refresh=refresh)
        validate_page(snapshot, goods_id)
        return snapshot

    try:
        goods_id = require_id(goods_id)
        current = await read()
        if current.total and not current.rows:
            current = await read(refresh=True)
            if current.total and not current.rows:
                raise CleanupSafetyError("第一页为空但分页仍有视频，不能报告清理完成")
        result.found = result.remaining = current.total
        result.preview_ids = [row.video_id for row in current.rows]
        if not execute:
            result.message = f"只读预览：审核失败 {current.total} 条（列出首页 ID）"
            return result
        while current.total:
            check_stop()
            if not current.rows:
                raise CleanupSafetyError("列表异常为空，停止该商品")
            video_id = current.rows[0].video_id
            if video_id in seen:
                raise CleanupSafetyError("重复出现已删除视频，停止以避免死循环")
            deletion_error = None
            try:
                await adapter.delete_video(goods_id, video_id, should_stop)
            except CleanupStopped:
                raise
            except Exception as exc:
                deletion_error = exc
            # Do not let a stop hide the outcome of an already submitted delete.
            result.remaining = None
            after = await adapter.read_first_page(goods_id, refresh=False)
            validate_page(after, goods_id)
            result.remaining = after.total
            ids = {row.video_id for row in after.rows}
            if video_id in ids or after.total != current.total - 1:
                reason = "删除结果未确认：目标仍在或总数未减少一条"
                if deletion_error:
                    reason += "（操作异常，已复核且未重复提交）"
                raise CleanupSafetyError(reason)
            seen.add(video_id)
            result.deleted += 1
            result.deleted_ids.append(video_id)
            on_progress(f"{goods_id}：发现 {result.found}，已删 {result.deleted}，剩余 {after.total}")
            current = after
            if limit is not None and result.deleted >= limit:
                result.message = "已达到本次单条/限量验证上限"
                return result
        # Reapply the rejected filter and return to page 1 before accepting empty.
        verified_empty = await read(refresh=True)
        result.remaining = verified_empty.total
        if verified_empty.total or verified_empty.rows:
            raise CleanupSafetyError("重新筛选后仍有审核失败视频，未确认完成")
        result.complete = True
        result.message = "已复核：该商品审核失败视频为空"
    except CleanupStopped as exc:
        result.stopped = True
        result.message = str(exc)
    except Exception as exc:
        result.failed = 1
        result.message = str(exc) if isinstance(exc, CleanupSafetyError) else "页面操作失败，未继续删除"
    return result
