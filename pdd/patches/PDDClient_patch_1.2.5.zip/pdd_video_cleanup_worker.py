"""Serial store worker for rejected-video preview/cleanup; no core data writes."""
from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import threading

from PyQt5.QtCore import QThread, pyqtSignal

from pdd_video_cleanup import CleanupResult, CleanupSafetyError, MANAGEMENT_URL, cleanup_goods, require_id
from pdd_video_cleanup_browser import BrowserCleanupPage, assert_management_url, observed_selectors, open_goods_modal


ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class CleanupStoreGroup:
    store: str
    profile: str
    goods_ids: tuple[str, ...]


def freeze_cleanup_groups(records, stores, profile_root=None):
    """Exact name/profile mapping only; never fall back to a default store."""
    root = Path(profile_root or ROOT / "pdd_profiles").resolve()
    if not isinstance(stores, dict):
        raise CleanupSafetyError("无法读取店铺映射")
    grouped = {}
    for record in records:
        store = str(record.get("store") or "").strip()
        goods_id = require_id(record.get("goods_id"))
        name = stores.get(store)
        if not store or not isinstance(name, str) or not name or Path(name).name != name:
            raise CleanupSafetyError(f"商品 {goods_id} 无精确匹配的店铺登录档案，未开始")
        profile = (root / name).resolve()
        if profile.parent != root or not profile.is_dir():
            raise CleanupSafetyError(f"店铺「{store}」登录档案不存在或路径异常")
        key = (store, str(profile))
        ids = grouped.setdefault(key, [])
        if goods_id not in ids:
            ids.append(goods_id)
    profiles = [profile for store, profile in grouped]
    if len(profiles) != len(set(profiles)):
        raise CleanupSafetyError("不同店铺共用同一登录档案，请先核对店铺映射")
    return tuple(CleanupStoreGroup(store, profile, tuple(ids))
                 for (store, profile), ids in grouped.items())


def check_frozen_mapping(groups):
    root = ROOT / "pdd_profiles"
    stores = json.loads((root / "stores.json").read_text(encoding="utf-8-sig"))
    records = [{"store": group.store, "goods_id": gid}
               for group in groups for gid in group.goods_ids]
    if freeze_cleanup_groups(records, stores, root) != tuple(groups):
        raise CleanupSafetyError("等待期间店铺映射发生变化，请重新选择并确认")


def local_chrome():
    for path in (Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
                 Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
                 Path.home() / "AppData/Local/Google/Chrome/Application/chrome.exe"):
        if path.is_file():
            return str(path)
    raise CleanupSafetyError("未找到本地 Chrome")


class VideoCleanupThread(QThread):
    progress = pyqtSignal(str)
    finished_summary = pyqtSignal(dict)
    is_video_cleanup = True

    def __init__(self, groups, parent=None, *, execute=False, show_browser=True):
        super().__init__(parent)
        self.groups = tuple(groups)
        self.execute = bool(execute)
        self.show_browser = bool(show_browser)
        self._stop_requested = threading.Event()

    def stop(self):
        self._stop_requested.set()

    def run(self):
        results = []

        def add_result(store, result):
            results.append({"store": store, **asdict(result)})
            remaining = "未知" if result.remaining is None else str(result.remaining)
            found = "未知" if result.found is None else str(result.found)
            self.progress.emit(f"{store}/{result.goods_id}：发现 {found}，删除 {result.deleted}，"
                               f"剩余 {remaining}；{result.message}")

        async def work():
            from playwright.async_api import async_playwright

            check_frozen_mapping(self.groups)
            chrome = local_chrome()
            async with async_playwright() as pw:
                for group in self.groups:
                    if self._stop_requested.is_set():
                        break
                    self.progress.emit(f"打开店铺「{group.store}」；{'删除' if self.execute else '只读预览'}审核失败视频…")
                    try:
                        check_frozen_mapping((group,))
                        args = (["--start-maximized"] if self.show_browser else
                                ["--window-position=-32000,-32000", "--window-size=1700,1000"])
                        context = await pw.chromium.launch_persistent_context(
                            user_data_dir=group.profile, executable_path=chrome, headless=False,
                            viewport=None, args=args + ["--disable-blink-features=AutomationControlled"],
                            ignore_default_args=["--enable-automation"], timeout=25000,
                        )
                    except Exception as exc:
                        message = str(exc) if isinstance(exc, CleanupSafetyError) else "浏览器启动失败，请检查该店铺浏览器是否被占用"
                        for gid in group.goods_ids:
                            add_result(group.store, CleanupResult(gid, "execute" if self.execute else "preview",
                                                                failed=1, message=message))
                        continue
                    try:
                        page = await context.new_page()
                        for gid in group.goods_ids:
                            if self._stop_requested.is_set():
                                break
                            try:
                                await page.goto(MANAGEMENT_URL, wait_until="domcontentloaded", timeout=40000)
                                assert_management_url(page.url)
                                await page.locator("span[class*='header_name__']").wait_for(state="visible", timeout=15000)
                                if self._stop_requested.is_set():
                                    break
                                await open_goods_modal(page, group.store, gid)
                                adapter = BrowserCleanupPage(page, observed_selectors(), group.store,
                                    authorized_goods_ids={gid} if self.execute else ())
                                result = await cleanup_goods(adapter, gid, execute=self.execute,
                                    should_stop=self._stop_requested.is_set,
                                    on_progress=lambda text, store=group.store: self.progress.emit(f"{store}/{text}"))
                                add_result(group.store, result)
                            except Exception as exc:
                                message = str(exc) if isinstance(exc, CleanupSafetyError) else "页面操作失败，该商品已停止"
                                add_result(group.store, CleanupResult(gid, "execute" if self.execute else "preview",
                                                                    failed=1, message=message))
                    finally:
                        await context.close()

        error = ""
        try:
            asyncio.run(work())
        except Exception as exc:
            error = str(exc) if isinstance(exc, CleanupSafetyError) else "视频清理任务异常中止"
        completed = {(row["store"], row["goods_id"]) for row in results}
        for group in self.groups:
            for gid in group.goods_ids:
                if (group.store, gid) not in completed:
                    add_result(group.store, CleanupResult(gid, "execute" if self.execute else "preview",
                        stopped=self._stop_requested.is_set(), failed=0 if self._stop_requested.is_set() else 1,
                        message="已停止，尚未处理" if self._stop_requested.is_set() else error or "未开始处理"))
        self.finished_summary.emit({
            "mode": "execute" if self.execute else "preview", "results": results,
            "products": len(results), "found": sum(row["found"] or 0 for row in results),
            "deleted": sum(row["deleted"] for row in results),
            "remaining": sum(row["remaining"] or 0 for row in results),
            "remaining_unknown": sum(row["remaining"] is None for row in results),
            "failed": sum(row["failed"] for row in results),
            "stopped": self._stop_requested.is_set(), "error": error,
        })
