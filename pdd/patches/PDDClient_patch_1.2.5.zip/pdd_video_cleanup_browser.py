"""Scoped Playwright adapter for rejected-video preview and cleanup.

No profile lookup, browser startup, persistence or direct service API calls.
The caller supplies validated locators and explicit goods authorization.
Merely constructing this adapter never permits deletion.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import re
from urllib.parse import urlsplit

from pdd_video_cleanup import (
    CleanupSafetyError, CleanupStopped, FailedVideoPage, REJECTED, VideoRow,
    require_id, validate_page,
)


def assert_management_url(url: str) -> None:
    try:
        parsed = urlsplit(url)
        valid = (parsed.scheme == "https" and parsed.hostname == "live.pinduoduo.com"
                 and parsed.port in (None, 443) and not parsed.username
                 and not parsed.password
                 and parsed.path == "/n-creator/video/mall-goods-video")
    except (TypeError, ValueError):
        valid = False
    if not valid:
        raise CleanupSafetyError("当前网址不是已确认的商家带货视频页，可能需要登录/验证")


def parse_labeled_id(text: str) -> str:
    match = re.fullmatch(r"\s*ID\s*[:：]\s*([0-9]+)\s*", text, re.I)
    if not match:
        raise CleanupSafetyError("无法完整核对商品/视频 ID")
    return require_id(match.group(1))


def parse_filtered_total(text: str) -> int:
    # Only the supplied pagination count element is accepted. Never the heading
    # “该商品共677条视频”, which is the unfiltered count in the user's screenshot.
    match = re.fullmatch(r"\s*共\s*有?\s*([0-9]+(?:,[0-9]{3})*)\s*条\s*", text)
    if not match:
        raise CleanupSafetyError("无法确认分页中的筛选后总数")
    return int(match.group(1).replace(",", ""))


@dataclass(frozen=True)
class CleanupSelectors:
    store_badge: str                 # page scope
    modal: str                       # page scope, exactly one visible large modal
    modal_goods_id: str              # all following row/filter fields: modal scope
    status_control: str
    status_option: str               # page scope (may be a portalled dropdown)
    filter_button: str
    rows: str
    row_video_id: str                # row scope
    row_status: str
    row_delete: str
    filtered_total: str              # pagination only
    current_page: str
    loading: str                    # modal scope
    confirm_modal: str              # page scope, exactly one visible small modal
    confirm_title: str              # confirm modal scope
    confirm_button: str
    cancel_button: str
    filter_response_path: str = ""


def observed_selectors() -> CleanupSelectors:
    """Locators verified on TMQ's real page, including a single deletion.

    This factory cannot authorize a deletion; callers must separately freeze
    the allowed IDs.
    """
    return CleanupSelectors(
        store_badge="span[class*='header_name__']",
        modal="div[class*='MDL_inner_']:has(> div[class*='MDL_header_']:text-is('查看全部视频'))",
        modal_goods_id="div[class*='Item_goodsID__']",
        status_control="div[class*='GoodsVideoModal_searchItem__']:has(> span:text-is('视频审核状态')) input",
        status_option="[class*='ST_dropdownPanel_'] > li:has(> span:text-is('审核失败'))",
        filter_button="div[class*='GoodsVideoModal_search__'] > button:has(> span:text-is('筛选'))",
        rows="div[class*='TB_body_'] tbody > tr",
        row_video_id="div[class*='Item_auditId__']",
        row_status="div[class*='Item_right__'] > div:nth-of-type(4) > span",
        row_delete="a:has(> span:text-is('删除'))",
        filtered_total="li[class*='TB_pgtTotalText_']",
        current_page="li[class*='PGT_pagerItemActive_']",
        loading="[class*='TB_loading_']:visible",
        confirm_modal="div[class*='MDL_alert_']:visible div[class*='MDL_inner_']",
        confirm_title="div[class*='MDL_noHeader_']",
        confirm_button="button[class*='MDL_okBtn_']",
        cancel_button="button[class*='MDL_closeBtn_']",
        filter_response_path="/api/backbone/goods/consumer/video/list",
    )


async def open_goods_modal(page, store: str, goods_id: str) -> None:
    """Only query/filter/navigation. Never clicks delete or a confirmation."""
    assert_management_url(page.url)
    goods_id = require_id(goods_id)
    badge = page.locator("span[class*='header_name__']")
    try:
        await badge.filter(has_text=re.compile(r"^" + re.escape(store) + r"$")).wait_for(
            state="visible", timeout=15000)
    except Exception as exc:
        raise CleanupSafetyError("真实页面店铺名无法确认，可能登录信息未加载或店铺不匹配") from exc
    if await badge.count() != 1 or (await badge.inner_text()).strip() != store:
        raise CleanupSafetyError("真实页面店铺名与指定店铺不一致")
    if await page.locator("div[class*='MDL_inner_']:visible").count():
        raise CleanupSafetyError("请先关闭已有弹窗，再查询下一个商品")
    search = page.locator("textarea[class*='TAA_input']")
    if await search.count() != 1:
        raise CleanupSafetyError("外层商品 ID 输入框不唯一")
    await search.fill(goods_id)
    async with page.expect_response(
            lambda response: urlsplit(response.url).path == "/api/backbone/goods/consumer/goods/list"
            and response.request.method == "POST") as query:
        await page.get_by_role("button", name="筛选", exact=True).click()
    response = await query.value
    if response.status != 200:
        raise CleanupSafetyError("商品查询响应失败")
    await response.body()
    await asyncio.sleep(0.3)
    marker = page.locator("div[class*='Item_goodsID__']").filter(
        has_text=re.compile(r"^ID:" + re.escape(goods_id) + r"$"))
    rows = page.locator("table tbody tr").filter(has=marker)
    if await rows.count() != 1 or await marker.count() != 1:
        raise CleanupSafetyError("查询结果未唯一匹配完整商品 ID")
    async with page.expect_response(
            lambda response: urlsplit(response.url).path == "/api/backbone/goods/consumer/video/list"
            and response.request.method == "POST") as query:
        await rows.get_by_role("button", name=re.compile(r"^管理全部\d+个视频$")).click()
    response = await query.value
    if response.status != 200:
        raise CleanupSafetyError("商品视频列表响应失败")
    await response.body()
    await asyncio.sleep(0.3)


class BrowserCleanupPage:
    def __init__(self, page, selectors: CleanupSelectors, store: str, *,
                 authorized_goods_ids=(), authorized_video_ids=None,
                 timeout_seconds=12, stable_seconds=0.6):
        self.page = page
        self.s = selectors
        self.store = str(store).strip()
        if not self.store:
            raise ValueError("store is required")
        self.authorized_goods_ids = frozenset(require_id(gid) for gid in authorized_goods_ids)
        self.authorized_video_ids = (None if authorized_video_ids is None else
                                     frozenset(require_id(vid) for vid in authorized_video_ids))
        self.timeout_seconds = float(timeout_seconds)
        self.stable_seconds = float(stable_seconds)
        if self.timeout_seconds <= 0 or self.stable_seconds <= 0:
            raise ValueError("positive timing limits are required")
        self._filtered_goods = None
        self._last = None

    async def _one(self, locator, description):
        if await locator.count() != 1 or not await locator.is_visible():
            raise CleanupSafetyError(f"{description}缺失、不唯一或不可见")
        return locator

    async def _scope(self, goods_id):
        assert_management_url(self.page.url)
        badge = await self._one(self.page.locator(self.s.store_badge), "店铺标识")
        if (await badge.inner_text()).strip() != self.store:
            raise CleanupSafetyError("页面店铺名称与确认店铺不一致")
        modal = await self._one(self.page.locator(self.s.modal), "查看全部视频弹窗")
        id_field = await self._one(modal.locator(self.s.modal_goods_id), "弹窗商品 ID")
        if parse_labeled_id(await id_field.inner_text()) != require_id(goods_id):
            raise CleanupSafetyError("弹窗商品 ID 与选中商品不一致")
        return modal

    async def _selected_status(self, modal):
        control = await self._one(modal.locator(self.s.status_control), "视频审核状态")
        tag = await control.evaluate("el => el.tagName.toLowerCase()")
        if tag == "select":
            return (await control.locator("option:checked").inner_text()).strip()
        if tag == "input":
            return (await control.input_value()).strip() or str(await control.get_attribute("placeholder") or "").strip()
        return (await control.inner_text()).strip()

    async def _apply_filter(self, goods_id):
        modal = await self._scope(goods_id)
        control = await self._one(modal.locator(self.s.status_control), "视频审核状态")
        if await self._selected_status(modal) != REJECTED:
            if await control.evaluate("el => el.tagName.toLowerCase()") == "select":
                await control.select_option(label=REJECTED)
            else:
                await control.click()
                option = await self._one(self.page.locator(self.s.status_option), "审核失败选项")
                if (await option.inner_text()).strip() != REJECTED:
                    raise CleanupSafetyError("审核失败选项文字异常")
                await option.click()
        modal = await self._scope(goods_id)
        if await self._selected_status(modal) != REJECTED:
            raise CleanupSafetyError("审核失败筛选未选中")
        button = await self._one(modal.locator(self.s.filter_button), "弹窗内筛选按钮")
        if (await button.inner_text()).strip() != "筛选":
            raise CleanupSafetyError("筛选按钮文字异常")
        if self.s.filter_response_path:
            async with self.page.expect_response(
                    lambda response: urlsplit(response.url).hostname == "live.pinduoduo.com"
                    and urlsplit(response.url).path == self.s.filter_response_path
                    and response.request.method == "POST",
                    timeout=int(self.timeout_seconds * 1000)) as query:
                await button.click()
            response = await query.value
            if response.status != 200:
                raise CleanupSafetyError("审核失败筛选响应失败")
            await response.body()
            await asyncio.sleep(0.3)
        else:
            await button.click()
        self._filtered_goods = goods_id

    async def _snapshot(self, goods_id):
        modal = await self._scope(goods_id)
        if self._filtered_goods != goods_id:
            raise CleanupSafetyError("尚未为该商品应用审核失败筛选")
        if await self._selected_status(modal) != REJECTED:
            raise CleanupSafetyError("审核状态筛选被改变")
        loading = modal.locator(self.s.loading)
        if any([await loading.nth(i).is_visible() for i in range(await loading.count())]):
            raise CleanupSafetyError("列表正在加载")
        count = await self._one(modal.locator(self.s.filtered_total), "筛选后分页总数")
        total = parse_filtered_total(await count.inner_text())
        active = modal.locator(self.s.current_page)
        rows = modal.locator(self.s.rows)
        data = []
        for index in range(await rows.count()):
            row = rows.nth(index)
            if not await row.is_visible():
                raise CleanupSafetyError("视频行不可见")
            id_field = await self._one(row.locator(self.s.row_video_id), "行内视频 ID")
            state = await self._one(row.locator(self.s.row_status), "行内审核状态")
            data.append(VideoRow(parse_labeled_id(await id_field.inner_text()),
                                 (await state.inner_text()).strip()))
        if await active.count() == 0 and len(data) == total:
            # PDD omits page-number buttons for a single page (also observed on
            # the outer one-product search). All records are present here.
            number = "1"
        else:
            active = await self._one(active, "当前页码")
            number = (await active.inner_text()).strip()
            if not re.fullmatch(r"[0-9]+", number):
                raise CleanupSafetyError("当前页码不可识别")
        snapshot = FailedVideoPage(goods_id, REJECTED, total, tuple(data), int(number))
        validate_page(snapshot, goods_id)
        # Recheck store, URL and product after reading the asynchronous row fields.
        await self._scope(goods_id)
        return snapshot

    async def read_first_page(self, goods_id, *, refresh=False):
        goods_id = require_id(goods_id)
        if refresh or self._filtered_goods != goods_id:
            await self._apply_filter(goods_id)
        deadline = asyncio.get_running_loop().time() + self.timeout_seconds
        previous = None
        stable_since = 0
        last_error = None
        while asyncio.get_running_loop().time() < deadline:
            try:
                current = await self._snapshot(goods_id)
                now = asyncio.get_running_loop().time()
                if current != previous:
                    previous, stable_since = current, now
                elif now - stable_since >= self.stable_seconds:
                    self._last = current
                    return current
                last_error = None
            except CleanupSafetyError as exc:
                # Only an explicit loading indicator is transient. Scope failures
                # (store, goods, filter, page) must stop immediately.
                if str(exc) != "列表正在加载":
                    raise
                previous = None
                last_error = exc
            await asyncio.sleep(0.1)
        raise CleanupSafetyError("列表加载或稳定性检查超时") from last_error

    async def _target_row(self, modal, video_id):
        pattern = re.compile(r"^\s*ID\s*[:：]\s*" + re.escape(video_id) + r"\s*$", re.I)
        marker = self.page.locator(self.s.row_video_id).filter(has_text=pattern)
        row = await self._one(modal.locator(self.s.rows).filter(has=marker), "待删除视频行")
        state = await self._one(row.locator(self.s.row_status), "待删除视频状态")
        if (await state.inner_text()).strip() != REJECTED:
            raise CleanupSafetyError("待删除视频不是审核失败")
        return row

    @staticmethod
    def _deletion_observed(before, after, video_id):
        return (after.goods_id == before.goods_id
                and after.total == before.total - 1
                and (after.total == 0 or bool(after.rows))
                and video_id not in {row.video_id for row in after.rows})

    async def _wait_for_automatic_delete_update(self, goods_id, video_id, before):
        """Read the platform's automatic update only; never click or re-filter.

        Accept the exact-ID/count evidence only after it remains stable. Scope
        and filter changes stop immediately. Other transient list inconsistencies
        get one fresh query, with all row/status checks applied again.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + min(3.0, self.timeout_seconds)
        candidate = None
        stable_since = 0
        while loop.time() < deadline:
            try:
                after = await asyncio.wait_for(self._snapshot(goods_id),
                                               timeout=max(0.001, deadline - loop.time()))
            except TimeoutError:
                return None
            except CleanupSafetyError as exc:
                if str(exc) != "列表正在加载":
                    modal = await self._scope(goods_id)
                    if await self._selected_status(modal) != REJECTED:
                        raise
                    return None
                candidate = None
            else:
                if self._deletion_observed(before, after, video_id):
                    if candidate != after:
                        candidate, stable_since = after, loop.time()
                    elif loop.time() - stable_since >= self.stable_seconds:
                        self._last = after
                        return after
                else:
                    candidate = None
                    if after.total != before.total:
                        # A changed but inconsistent count merits a fresh query,
                        # never another deletion submission.
                        return None
            await asyncio.sleep(0.1)
        return None

    async def open_delete_dialog(self, goods_id, video_id, should_stop=lambda: False):
        """Inspect the second layer only; this method never confirms deletion."""
        goods_id, video_id = require_id(goods_id), require_id(video_id)
        current = await self._snapshot(goods_id)
        if current != self._last or not current.rows or current.rows[0].video_id != video_id:
            raise CleanupSafetyError("删除前列表或目标已变化，请重新预览")
        if should_stop():
            raise CleanupStopped("已停止；尚未点击删除")
        modal = await self._scope(goods_id)
        row = await self._target_row(modal, video_id)
        delete = await self._one(row.locator(self.s.row_delete), "行内删除按钮")
        if (await delete.inner_text()).strip() != "删除":
            raise CleanupSafetyError("行内删除按钮文字异常")
        await delete.click()
        return current

    async def delete_video(self, goods_id, video_id, should_stop):
        goods_id, video_id = require_id(goods_id), require_id(video_id)
        if goods_id not in self.authorized_goods_ids:
            raise CleanupSafetyError("本适配器为只读预览，未授权删除该商品视频")
        if self.authorized_video_ids is not None and video_id not in self.authorized_video_ids:
            raise CleanupSafetyError("该视频不在本次明确确认的删除范围内")
        if should_stop():
            raise CleanupStopped("已停止；尚未点击删除")
        current = await self.open_delete_dialog(goods_id, video_id, should_stop)
        confirm = self.page.locator(self.s.confirm_modal)
        try:
            await confirm.wait_for(state="visible", timeout=int(self.timeout_seconds * 1000))
            confirm = await self._one(confirm, "删除确认小弹窗")
            title = await self._one(confirm.locator(self.s.confirm_title), "删除确认标题")
            if not re.fullmatch(r"确认删除此视频[?？]", (await title.inner_text()).strip()):
                raise CleanupSafetyError("删除确认弹窗内容异常")
            # Recheck everything after the second layer opens, immediately before
            # its destructive button. No unscoped “确定” clicks.
            before_confirm = await self._snapshot(goods_id)
            if before_confirm != current:
                raise CleanupSafetyError("确认前商品/列表/视频状态发生变化")
            await self._target_row(await self._scope(goods_id), video_id)
            if should_stop():
                raise CleanupStopped("已停止；未确认删除")
            button = await self._one(confirm.locator(self.s.confirm_button), "确定删除按钮")
            if (await button.inner_text()).strip() != "确定删除":
                raise CleanupSafetyError("确定删除按钮文字异常")
            await button.click()
            await confirm.wait_for(state="hidden", timeout=int(self.timeout_seconds * 1000))
        except Exception:
            # Cancel only the exact scoped small dialog; never a generic page
            # button. Cancellation failures do not trigger another delete.
            try:
                if await confirm.count() == 1 and await confirm.is_visible():
                    cancel = confirm.locator(self.s.cancel_button)
                    if (await cancel.count() == 1 and await cancel.is_visible()
                            and (await cancel.inner_text()).strip() == "取消"):
                        await cancel.click()
            except Exception:
                pass
            raise
        # Prefer PDD's automatic list update. Only a timeout or inconsistent
        # list triggers an extra filter request; never resubmit the deletion.
        after = await self._wait_for_automatic_delete_update(goods_id, video_id, current)
        if after is None:
            after = await self.read_first_page(goods_id, refresh=True)
        if self._deletion_observed(current, after, video_id):
            return
        raise TimeoutError("删除后未确认目标消失及总数递减")
