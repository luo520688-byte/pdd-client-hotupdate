"""保本投产算账模块 —— 自动推广(PDD 全站推广)的"算账大脑"。

职责单一:给定一条已发布链接的【各档 SKU 售价 + 份数】和【单件货价/运费/防比价赠品】,
算出每档毛利率、每档保本投产,取**毛利率最低档**定链接级保本,再换算成**多个开车档位**的目标投产。

口径(2026-06-20 与用户确认,见 handoff §自动推广):
  - 单档毛利 g = 售价 − 单件货价×份数 − 防比价赠品(默认0.2,有则加) − 运费 − 售价×扣点率
  - 扣点率默认 0.6%;售价用「拼单价」;多 SKU 取毛利率最低那档(最保险)。
  - 名义保本投产(退款后口径) = 1 / 毛利率
  - 实际保本投产(成交/含退款口径,开车时盯的就是这个) = 名义保本 ÷ (1 − 退款率)
  - 退款率默认 20%
  - 开车档位 = 实际保本投产 × 档位系数:
        实际保本档 ×1.0、10%盈利档 ×1.1 …(可自定义扩展)

本文件纯计算,不联网、不开浏览器、不改任何生产数据。
抓真实 SKU 价(复用 pdd_inspect)是 roas_scan.py 的事,这里只接收算好的输入。
路径基于 __file__,可整体迁移。
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

_BASE_DIR = Path(__file__).resolve().parent
HISTORY_PATH = _BASE_DIR / "data" / "pdd" / "pdd_publish_history.json"
CALC_CACHE_PATH = _BASE_DIR / "data" / "pdd" / "roas_calc_cache.json"   # 算账结果持久缓存(开车/抓数据共写,页面读)
COST_OVERRIDE_PATH = _BASE_DIR / "data" / "pdd" / "roas_cost_overrides.json"  # 人工修正单件货价;不改发布历史

# ── 默认参数(与用户确认) ───────────────────────────────────────────────────
DEFAULT_FEE_RATE     = 0.006   # 平台扣点率(技术服务费),多数类目 0.6%
DEFAULT_GIFT_COST    = 0.2     # 防比价赠品默认成本(元/单),仅在该 SKU 带防比价后缀时计入
DEFAULT_REFUND_RATE  = 0.20    # 退款率;实际保本投产 = 名义保本 ÷ (1 − 退款率)
# 开车档位:(档位名, 在实际保本投产上乘的系数)。可自定义扩展。
DEFAULT_PRESETS = [
    ("实际保本", 1.0),
    ("10%盈利", 1.1),
    ("20%盈利", 1.2),
]


# ── 单档计算 ─────────────────────────────────────────────────────────────────

def sku_economics(price: float, units: int, unit_cost: float, shipping: float,
                  *, gift_cost: float = 0.0, fee_rate: float = DEFAULT_FEE_RATE,
                  refund_rate: float = DEFAULT_REFUND_RATE) -> dict:
    """算单个 SKU 的成本/毛利/毛利率/保本投产(名义+实际)。

    price     该档售价(拼单价)
    units     份数(几件真货;"共N件"已含在内)
    unit_cost 单件货价(1688 进货单价)
    shipping  运费(每单 1 个,不随份数翻倍)
    gift_cost 防比价赠品成本(有防比价后缀就传 DEFAULT_GIFT_COST,否则 0)
    fee_rate  平台扣点率
    refund_rate 退款率

    毛利率 ≤ 0(售价盖不住成本)时 breakeven=None,loss=True。
    """
    price = float(price or 0)
    units = int(units or 1)
    goods_cost = float(unit_cost or 0) * units
    fee = price * fee_rate
    cost = goods_cost + float(gift_cost or 0) + float(shipping or 0) + fee
    profit = price - cost
    margin = (profit / price) if price > 0 else 0.0
    loss = margin <= 0
    if loss or refund_rate >= 1:
        breakeven = real_breakeven = None
    else:
        breakeven = round(1.0 / margin, 4)                       # 名义(退款后口径)
        real_breakeven = round(breakeven / (1 - refund_rate), 4)  # 实际(含退款口径)
    return {
        "price":          round(price, 2),
        "units":          units,
        "goods_cost":     round(goods_cost, 4),
        "gift_cost":      round(float(gift_cost or 0), 4),
        "shipping":       round(float(shipping or 0), 4),
        "fee":            round(fee, 4),
        "total_cost":     round(cost, 4),
        "profit":         round(profit, 4),
        "margin":         round(margin, 4),       # 毛利率(小数,0.43 = 43%)
        "breakeven_roas":      breakeven,         # 名义保本投产 = 1/毛利率
        "real_breakeven_roas": real_breakeven,    # 实际保本投产 = 名义 ÷ (1−退款率)
        "loss":           loss,
    }


def make_targets(real_breakeven: float, presets=None) -> list[dict]:
    """把实际保本投产按各档位系数换算成开车目标投产。
    返回 [{"label","factor","roas"}],roas 保留两位(投产比设置精度)。
    """
    presets = presets or DEFAULT_PRESETS
    if real_breakeven is None:
        return []
    return [{"label": lb, "factor": f, "roas": round(real_breakeven * f, 2)}
            for lb, f in presets]


# ── 链接级计算(取毛利率最低档) ───────────────────────────────────────────────

def link_economics(skus: list[dict], unit_cost: float, shipping: float, *,
                   has_gift: bool = False,
                   gift_cost: float = DEFAULT_GIFT_COST,
                   fee_rate: float = DEFAULT_FEE_RATE,
                   refund_rate: float = DEFAULT_REFUND_RATE,
                   presets=None) -> dict:
    """给一条链接的全部 SKU 算保本/各档位目标投产。

    skus: [{"name": 规格名, "price": 拼单价, "units": 份数}, ...]
    has_gift: 该链接 SKU 是否带防比价赠品(history 的 suffix 非空即 True)。

    返回:
      rows                每档明细
      worst               毛利率最低那档(决定链接保本)
      refund_rate         本次用的退款率
      breakeven_roas      名义保本投产(退款后口径)= 最低档 1/毛利率
      real_breakeven_roas 实际保本投产(含退款口径)= 名义 ÷ (1−退款率)
      targets             各开车档位 [{"label","factor","roas"}]
      ok / note
    """
    g_cost = gift_cost if has_gift else 0.0
    rows = []
    for s in (skus or []):
        rows.append({
            "name": str(s.get("name", "") or ""),
            **sku_economics(s.get("price", 0), s.get("units", 1),
                            unit_cost, shipping, gift_cost=g_cost,
                            fee_rate=fee_rate, refund_rate=refund_rate),
        })

    if not rows:
        return {"rows": [], "worst": None, "refund_rate": refund_rate,
                "breakeven_roas": None, "real_breakeven_roas": None,
                "targets": [], "ok": False, "note": "无 SKU 数据"}

    worst = min(rows, key=lambda r: r["margin"])   # 毛利率最低档(亏本档 margin 为负,自然入选)

    if worst["loss"]:
        return {"rows": rows, "worst": worst, "refund_rate": refund_rate,
                "breakeven_roas": None, "real_breakeven_roas": None, "targets": [],
                "ok": False,
                "note": f"存在亏本档「{worst['name'][:20]}」(毛利率{worst['margin']*100:.1f}%),"
                        f"售价盖不住成本,不能开车,需先调价/调货源"}

    breakeven = worst["breakeven_roas"]
    real_breakeven = worst["real_breakeven_roas"]
    targets = make_targets(real_breakeven, presets)
    return {
        "rows": rows,
        "worst": worst,
        "refund_rate": refund_rate,
        "breakeven_roas": breakeven,
        "real_breakeven_roas": real_breakeven,
        "targets": targets,
        "ok": True,
        "note": f"按最低毛利档「{worst['name'][:20]}」(毛利率{worst['margin']*100:.1f}%)定保本",
    }


# ── 从发布历史读成本(单件货价/运费/防比价后缀) ──────────────────────────────

def load_cost_overrides(override_path: Optional[Path] = None) -> dict:
    """Read local manual unit-cost overrides without mutating publish history."""
    path = Path(override_path) if override_path else COST_OVERRIDE_PATH
    if not path.exists():
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    out = {}
    for goods_id, item in raw.items():
        value = item.get("unit_cost") if isinstance(item, dict) else item
        try:
            cost = float(value)
        except (TypeError, ValueError):
            continue
        gid = str(goods_id or "").strip()
        if gid and cost > 0:
            out[gid] = {
                "unit_cost": cost,
                "updated_at": str(item.get("updated_at") or "") if isinstance(item, dict) else "",
            }
    return out


def set_cost_override(goods_id: str, unit_cost: Optional[float], override_path: Optional[Path] = None) -> dict:
    """Set a positive manual cost, or clear it with None. Returns normalized overrides."""
    gid = str(goods_id or "").strip()
    if not gid:
        raise ValueError("goods_id-empty")
    path = Path(override_path) if override_path else COST_OVERRIDE_PATH
    overrides = load_cost_overrides(path)
    if unit_cost is None:
        overrides.pop(gid, None)
    else:
        cost = float(unit_cost)
        if cost <= 0:
            raise ValueError("unit-cost-must-be-positive")
        overrides[gid] = {"unit_cost": cost, "updated_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(overrides, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
    return overrides


def load_history_costs(history_path: Optional[Path] = None, override_path: Optional[Path] = None) -> dict:
    """读 pdd_publish_history.json,按 goods_id 汇成本信息。

    返回 {goods_id(str): {"unit_cost", "shipping", "has_gift", "suffix",
                          "store", "name", "time"}}
    同一 goods_id 多条记录取最新(写历史是 insert(0,...),靠前=新)。
    """
    path = Path(history_path) if history_path else HISTORY_PATH
    out: dict[str, dict] = {}
    hist = []
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                hist = json.load(f)
        except (OSError, json.JSONDecodeError):
            hist = []
    if not isinstance(hist, list):
        hist = []
    for h in hist:               # 从新到旧;首次见到的 goods_id 即最新,不覆盖
        if not isinstance(h, dict):
            continue
        gid = str(h.get("goods_id", "") or "").strip()
        if not gid or gid == "-" or gid in out:
            continue
        suffix = str(h.get("suffix", "") or "").strip()
        out[gid] = {
            "unit_cost": float(h.get("supplier_cost", 0) or 0),
            "shipping":  float(h.get("shipping", 0) or 0),
            "suffix":    suffix,
            "has_gift":  bool(suffix),     # 带防比价后缀 → 计 0.2 赠品成本
            "store":     str(h.get("store", "") or ""),
            "name":      str(h.get("target_name", "") or ""),
            "time":      str(h.get("time", "") or ""),
            "status":    str(h.get("status", "") or ""),   # ok/mismatch/need_price=在架;deleted/not_listed=已下架/回收站
        }
    for gid, override in load_cost_overrides(override_path).items():
        info = out.setdefault(gid, {
            "unit_cost": 0.0, "shipping": 0.0, "suffix": "", "has_gift": False,
            "store": "", "name": "", "time": "", "status": "",
        })
        info["history_unit_cost"] = float(info.get("unit_cost", 0) or 0)
        info["unit_cost"] = float(override["unit_cost"])
        info["cost_overridden"] = True
        info["cost_override_updated_at"] = override.get("updated_at", "")
    return out


def load_calc_cache() -> dict:
    """读算账缓存 {goods_id: {unit_cost, price_range, margin, real_breakeven, targets, skus, at}}。"""
    if CALC_CACHE_PATH.exists():
        try:
            d = json.loads(CALC_CACHE_PATH.read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}
    return {}


def invalidate_calc_cache(goods_id: str) -> bool:
    """Remove one stale calculation after its manual cost changes."""
    gid = str(goods_id or "").strip()
    cache = load_calc_cache()
    if not gid or gid not in cache:
        return False
    cache.pop(gid, None)
    try:
        CALC_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = CALC_CACHE_PATH.with_name(CALC_CACHE_PATH.name + ".tmp")
        tmp.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(CALC_CACHE_PATH)
        return True
    except OSError:
        return False


def recalculate_cached_cost(goods_id: str) -> bool:
    """Recalculate cached margin/breakeven from cached SKU prices after a cost edit."""
    gid = str(goods_id or "").strip()
    cached = load_calc_cache().get(gid) or {}
    skus = cached.get("skus") or []
    if not skus:
        invalidate_calc_cache(gid)
        return False
    calc = breakeven_for_goods(gid, skus)
    if not calc.get("ok"):
        invalidate_calc_cache(gid)
        return False
    save_calc_cache(gid, calc, skus, live_tp=str(cached.get("live_tp") or ""))
    return True


def save_calc_cache(goods_id: str, calc: dict, skus: list[dict], live_tp: str = "") -> None:
    """把一条算账结果写进持久缓存(开车时算完顺手写,页面/抓数据直接读,省得再扫一遍详情)。
    live_tp:本次抓数据时「推广中心列表现价」,供下次比对——现价没变就不再开详情重算(省扫描)。"""
    import time as _t
    gid = str(goods_id).strip()
    if not gid or not calc or not calc.get("ok"):
        return
    cache = load_calc_cache()
    prices = [s.get("price") for s in (skus or []) if isinstance(s.get("price"), (int, float))]
    pr = ""
    if prices:
        pr = f"{min(prices):g}" if min(prices) == max(prices) else f"{min(prices):g}~{max(prices):g}"
    cache[gid] = {
        "unit_cost":      (calc.get("cost_info") or {}).get("unit_cost"),
        "price_range":    pr,
        "margin":         (calc.get("worst") or {}).get("margin"),
        "real_breakeven": calc.get("real_breakeven_roas"),
        "targets":        calc.get("targets"),
        "skus":           [{"name": str(s.get("name", ""))[:24], "price": s.get("price"), "units": s.get("units")}
                           for s in (skus or [])],
        "at":             _t.strftime("%Y-%m-%d %H:%M"),
        "live_tp":        str(live_tp or ""),   # 上次抓数据看到的列表现价,供下次比对(价没变就不重扫详情)
    }
    try:
        CALC_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        CALC_CACHE_PATH.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def breakeven_for_goods(goods_id: str, skus: list[dict], *,
                        costs: Optional[dict] = None,
                        history_path: Optional[Path] = None,
                        fee_rate: float = DEFAULT_FEE_RATE,
                        refund_rate: float = DEFAULT_REFUND_RATE,
                        presets=None) -> dict:
    """给定 goods_id + 已抓到的 SKU(售价/份数),自动从历史取成本并算保本/各档目标投产。

    costs: 可传入 load_history_costs() 的结果复用;不传则自动读。
    SKU 价/份数由上游(pdd_inspect 抓真实在架链接)提供,本函数不联网。
    成本缺失(历史无此 goods_id 或单件货价为 0)→ ok=False 并说明。
    """
    gid = str(goods_id or "").strip()
    if costs is None:
        costs = load_history_costs(history_path)
    info = costs.get(gid)
    if not info:
        return {"goods_id": gid, "ok": False, "note": "发布历史无此 goods_id,取不到单件货价",
                "rows": [], "worst": None, "breakeven_roas": None,
                "real_breakeven_roas": None, "targets": []}
    if info["unit_cost"] <= 0:
        return {"goods_id": gid, "ok": False, "note": "历史里单件货价为 0(未比价/未记录),无法算保本",
                "rows": [], "worst": None, "breakeven_roas": None,
                "real_breakeven_roas": None, "targets": [], "cost_info": info}
    res = link_economics(skus, info["unit_cost"], info["shipping"],
                         has_gift=info["has_gift"], fee_rate=fee_rate,
                         refund_rate=refund_rate, presets=presets)
    res["goods_id"] = gid
    res["cost_info"] = info
    return res


# ── 自测:跑与用户确认过的示例,核对数字一致 ─────────────────────────────────

def _demo():
    print("=" * 70)
    print("保本投产算账自测(单件8 / 运费3 / 扣点0.6% / 防比价赠品0.2 / 退款率20%)")
    print("=" * 70)
    skus = [
        {"name": "1支", "price": 19.9, "units": 1},
        {"name": "2支", "price": 35.0, "units": 2},
        {"name": "3支", "price": 49.0, "units": 3},
    ]
    res = link_economics(skus, unit_cost=8.0, shipping=3.0, has_gift=True)
    print(f"{'档':<5}{'售价':>7}{'货成本':>8}{'毛利':>8}{'毛利率':>8}"
          f"{'名义保本':>9}{'实际保本':>9}")
    for r in res["rows"]:
        print(f"{r['name']:<5}{r['price']:>7.2f}{r['goods_cost']:>8.2f}"
              f"{r['profit']:>8.2f}{r['margin']*100:>7.1f}%"
              f"{r['breakeven_roas']:>9.2f}{r['real_breakeven_roas']:>9.2f}")
    print("-" * 70)
    w = res["worst"]
    print(f"最低毛利档: {w['name']}  毛利率={w['margin']*100:.1f}%")
    print(f"名义保本投产 = {res['breakeven_roas']:.2f}  →  "
          f"实际保本投产(÷{1-res['refund_rate']:.2f}) = {res['real_breakeven_roas']:.2f}")
    print("开车档位:")
    for t in res["targets"]:
        print(f"  · {t['label']:<8} ×{t['factor']:<4} → 目标投产 {t['roas']:.2f}")


if __name__ == "__main__":
    _demo()
