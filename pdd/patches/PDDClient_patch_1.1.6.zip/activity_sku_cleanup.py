"""Safely rebuild activity-compared PDD SKU names with one replacement gift."""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import re
import sys
import unicodedata
from pathlib import Path

from playwright.async_api import async_playwright
from pdd_publish import (
    PROFILE_DIR, _load_stores, _profile_dir_for, _read_spec_code_rows,
    _locate_spec_code_input_for_row, apply_window_mode, click_edit_goods,
    click_edit_submit, fill_spec_codes, find_chrome, read_pdd_product_name,
)

RESULT_PREFIX = "ACTIVITY_SKU_CLEAN_RESULT="
LOG = logging.getLogger("activity_sku_cleanup")


def _trace(event: str, **fields) -> None:
    LOG.info("%s %s", event, json.dumps(fields, ensure_ascii=False, default=str, sort_keys=True))


def _configure_logging(log_path: str) -> None:
    LOG.handlers.clear(); LOG.setLevel(logging.INFO); LOG.propagate = False
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    if log_path:
        path = Path(log_path); path.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(path, encoding="utf-8")
        handler.setFormatter(formatter); LOG.addHandler(handler)
    stream = logging.StreamHandler(sys.stdout); stream.setFormatter(formatter); LOG.addHandler(stream)


def display_sku_name(value: str) -> str:
    return str(value or "").strip()

def activity_sku_match_candidates(value: str) -> list[str]:
    """Return the editable SKU value, excluding a non-editable net-content layer."""
    raw = str(value or "").strip()
    layers = [part.strip() for part in re.split(r"[;\uFF1B]", raw) if part.strip()]
    if len(layers) == 2:
        editable = [part for part in layers if normalize_sku_name(activity_sku_prefix_label(part)) != normalize_sku_name("净含量")]
        if len(editable) == 1:
            parts = re.split(r"[:\uFF1A]", editable[0], maxsplit=1)
            if len(parts) == 2 and parts[1].strip():
                return [parts[1].strip()]
    parts = re.split(r"[:\uFF1A]", raw, maxsplit=1)
    if len(parts) == 2 and parts[1].strip():
        return [parts[1].strip()]
    return [raw] if raw else []


def primary_sku_key(value: str) -> str:
    """Use the main SKU segment before appended gifts only as a unique-match fallback."""
    return normalize_sku_name(re.split(r"[+\uFF0B]", str(value or ""), maxsplit=1)[0])


def sku_row_matches_candidate(row_style: str, candidate: str) -> bool:
    """Match a target against one column of a multi-spec SKU table row."""
    wanted = normalize_sku_name(candidate)
    values = [part.strip() for part in re.split(r"\s*/\s*", str(row_style or "")) if part.strip()]
    return bool(wanted) and any(normalize_sku_name(value) == wanted for value in values)


def sku_row_primary_matches_candidate(row_style: str, candidate: str) -> bool:
    wanted = primary_sku_key(candidate)
    values = [part.strip() for part in re.split(r"\s*/\s*", str(row_style or "")) if part.strip()]
    return bool(wanted) and any(primary_sku_key(value) == wanted for value in values)


def activity_sku_prefix_label(value: str) -> str:
    parts = re.split(r"[:\uFF1A]", str(value or "").strip(), maxsplit=1)
    return parts[0].strip() if len(parts) == 2 else ""


def activity_sku_has_net_content_layer(value: str) -> bool:
    layers = [part.strip() for part in re.split(r"[;\uFF1B]", str(value or "")) if part.strip()]
    return len(layers) == 2 and any(normalize_sku_name(activity_sku_prefix_label(layer)) == normalize_sku_name("净含量") for layer in layers)


def normalize_sku_name(value: str) -> str:
    value = unicodedata.normalize("NFKC", display_sku_name(value)).lower()
    return re.sub(r"\s+", "", value).replace("\u4e00", "1")


def sku_edit_row_identity(row_no, current_name: str, current_code: str) -> tuple[str, str, str]:
    """Identify one physical editor row even when activity results reference it repeatedly."""
    return (
        str(row_no or ""), normalize_sku_name(current_name), normalize_visible_value(current_code),
    )


def append_spec_code(original_code: str, gift_code: str) -> str:
    """Keep the existing PDD spec code and append the selected gift code."""
    original_code = str(original_code or "").strip()
    gift_code = str(gift_code or "").strip()
    return f"{original_code}+{gift_code}" if original_code and gift_code else original_code or gift_code


def apply_verified_spec_code_repair(rows: list[dict], repair: dict) -> str:
    """Reuse the repair flow's direct readback instead of rescanning a scrolled table header."""
    if repair.get("status") != "ok" or repair.get("written", 0) <= 0 or not repair.get("write_verified"):
        return f"spec-code-auto-repair-failed:{repair.get('reason', 'not-verified')}"
    expected_codes = [str(value or "").strip() for value in repair.get("expected_codes") or []]
    if len(expected_codes) != len(rows) or any(not value for value in expected_codes):
        return "spec-code-auto-repair-verified-codes-invalid"
    for row, code in zip(rows, expected_codes):
        row["value"] = code
    return ""


def _select_product_gift(gifts: list[dict], selection_key: str) -> dict:
    """Choose one stable candidate per product, shared by all of its target SKUs."""
    digest = hashlib.sha256(str(selection_key or "").encode("utf-8")).digest()
    return gifts[int.from_bytes(digest[:8], "big") % len(gifts)]


def gift_presence_key(value: str) -> str:
    """Compare gift categories without quantities, such as mask1pack and mask2pack."""
    value = normalize_sku_name(value)
    return re.sub(r"(?:\d+)?(?:\u5305|\u7247|\u652f|\u6761|\u76d2|\u74f6|\u888b|\u5957|\u4e2a|\u679a|\u8d34)$", "", value)


def original_sku_gift_keys(value: str) -> set[str]:
    parts = re.split(r"[+\uFF0B]", str(value or ""))
    return {gift_presence_key(part) for part in parts[1:] if gift_presence_key(part)}


def select_replacement_gift(candidates: list[dict], existing_gift_values: list[str], selection_key: str) -> dict:
    """Choose a candidate whose gift category is absent from every current editor row."""
    gifts, seen = [], set()
    for item in candidates or []:
        name = str((item or {}).get("name") or "").strip()
        code = str((item or {}).get("spec_code") or "").strip()
        key = gift_presence_key(name)
        if name and code and key and key not in seen:
            gifts.append({"name": name, "spec_code": code})
            seen.add(key)
    existing_keys = {gift_presence_key(value) for value in existing_gift_values or [] if gift_presence_key(value)}
    eligible = [gift for gift in gifts if gift_presence_key(gift["name"]) not in existing_keys]
    return _select_product_gift(eligible, selection_key) if eligible else {}


def split_sku_segments(value: str) -> list[str]:
    return [part.strip() for part in re.split(r"[+\uFF0B]", str(value or ""))]


def strip_sku_tail_segments(value: str, count: int) -> str:
    """Remove trailing plus-delimited segments while preserving the main code text."""
    raw = str(value or "").strip()
    count = int(count or 0)
    if count <= 0:
        return raw
    separators = list(re.finditer(r"[+\uFF0B]", raw))
    if count > len(separators):
        return ""
    return raw[:separators[-count].start()].rstrip()


def _gift_alias_keys(gift_library: list[dict], *, for_code: bool) -> tuple[set[str], set[str]]:
    exact, categories = set(), set()
    for item in gift_library or []:
        values = [str((item or {}).get("name") or "")]
        if for_code:
            values.append(str((item or {}).get("spec_code") or ""))
        for value in values:
            key = normalize_sku_name(value)
            category = gift_presence_key(value)
            if key:
                exact.add(key)
            if category:
                categories.add(category)
    return exact, categories


def strip_known_gift_suffixes(value: str, gift_library: list[dict], *, for_code: bool = False) -> tuple[str, list[str]]:
    """Repeatedly remove every known trailing gift, not just the last one."""
    raw = str(value or "").strip()
    parts = split_sku_segments(raw)
    exact, categories = _gift_alias_keys(gift_library, for_code=for_code)
    remove_count = 0
    for part in reversed(parts[1:]):
        key = normalize_sku_name(part)
        category = gift_presence_key(part)
        if key in exact or (category and category in categories):
            remove_count += 1
            continue
        break
    if not remove_count:
        return raw, []
    return strip_sku_tail_segments(raw, remove_count), parts[-remove_count:]


GENERIC_ACTIVITY_SKU_MARKETING_POINTS = frozenset({
    "\u7d27\u81f4\u6297\u76b1",
    "\u6ecb\u6da6\u4fee\u62a4",
    "\u8865\u6c34\u4fdd\u6e7f",
    "\u63d0\u4eae\u80a4\u8272",
    "\u906e\u76d6\u7455\u75b5",
    "\u5747\u5300\u80a4\u8d28",
    "\u4fee\u9970\u8f6e\u5ed3",
    "\u5f3a\u97e7\u6ecb\u517b",
    "\u7fd8\u5377\u6d53\u5bc6",
    "\u6ecb\u517b\u4fee\u62a4",
    "\u6d53\u5bc6\u7ea4\u957f",
    "\u65b9\u4fbf\u5b9e\u7528",
    "\u54c1\u8d28\u4e4b\u9009",
})

FORBIDDEN_ACTIVITY_SKU_MEDICAL_TERMS = frozenset({
    "\u7597\u7a0b",
    "\u6cbb\u7597",
    "\u7597\u6548",
    "\u836f\u7528",
    "\u533b\u7528",
    "\u6cbb\u6108",
    "\u6839\u6cbb",
    "\u836f\u6548",
    "\u6025\u6551",
})

FORBIDDEN_ACTIVITY_SKU_PACKAGE_TERMS = frozenset({
    "\u4f53\u9a8c\u88c5",
    "\u8bd5\u7528\u88c5",
    "\u5c0f\u6837",
    "\u52a0\u91cf\u88c5",
    "\u589e\u91cf\u88c5",
    "\u5927\u5bb9\u91cf",
    "\u8d85\u5927\u5bb9\u91cf",
    "\u5468\u671f\u88c5",
})


def validate_code_tail_classification(request_rows: list[dict], ai_rows: list[dict]) -> tuple[dict[str, int], str]:
    """Validate AI classification of only the exposed trailing code segments."""
    if not request_rows:
        return {}, ""
    requests = {str(item.get("row_id")): item for item in request_rows or [] if isinstance(item, dict)}
    valid_responses = [item for item in ai_rows or [] if isinstance(item, dict)]
    responses = {str(item.get("row_id")): item for item in valid_responses}
    if (
        len(requests) != len(request_rows or [])
        or len(valid_responses) != len(ai_rows or [])
        or len(responses) != len(valid_responses)
        or set(responses) != set(requests)
    ):
        return {}, "ai-code-tail-row-mismatch"
    counts = {}
    for row_id, request in requests.items():
        raw_count = responses[row_id].get("unknown_code_gift_tail_count", 0)
        if isinstance(raw_count, bool):
            return {}, f"ai-code-tail-count-invalid:{row_id}"
        try:
            count = int(raw_count or 0)
        except (TypeError, ValueError):
            return {}, f"ai-code-tail-count-invalid:{row_id}"
        if isinstance(raw_count, float) and raw_count != count:
            return {}, f"ai-code-tail-count-invalid:{row_id}"
        tail_segments = request.get("tail_segments") or []
        if count < 0 or count > len(tail_segments):
            return {}, f"ai-code-tail-count-invalid:{row_id}"
        counts[row_id] = count
    return counts, ""


def validate_ai_rewrite_rows(request_rows: list[dict], ai_rows: list[dict]) -> tuple[list[dict], str]:
    """Validate AI names and AI gift classification without letting AI rewrite warehouse codes."""
    requests = {str(item.get("row_id")): item for item in request_rows or []}
    valid_responses = [item for item in ai_rows or [] if isinstance(item, dict)]
    responses = {str(item.get("row_id")): item for item in valid_responses}
    if (
        not requests
        or len(requests) != len(request_rows or [])
        or len(valid_responses) != len(ai_rows or [])
        or len(responses) != len(valid_responses)
        or set(responses) != set(requests)
    ):
        return [], "ai-rewrite-row-mismatch"
    resolved, seen_names, seen_codes = [], set(), set()
    for row_id, request in requests.items():
        response = responses[row_id]
        main_name = str(response.get("main_name") or "").strip()
        known_main_name = str(request.get("known_main_name") or "").strip().lower()
        warehouse_tokens = re.findall(r"[A-Za-z][A-Za-z0-9]{3,}", str(request.get("code_after_known") or ""))
        copied_code_token = next(
            (token for token in warehouse_tokens if token.lower() in main_name.lower() and token.lower() not in known_main_name), ""
        )
        if copied_code_token:
            return [], f"ai-main-name-copied-code:{row_id}"
        if any(term in main_name for term in FORBIDDEN_ACTIVITY_SKU_MEDICAL_TERMS):
            return [], f"ai-medical-wording-forbidden:{row_id}"
        if any(term in main_name for term in FORBIDDEN_ACTIVITY_SKU_PACKAGE_TERMS):
            return [], f"ai-package-wording-forbidden:{row_id}"
        marketing_match = re.search(r"\u3010([\u4e00-\u9fff]{4,8})\u3011", main_name)
        if not marketing_match:
            return [], f"ai-marketing-point-missing:{row_id}"
        if marketing_match.group(1) in GENERIC_ACTIVITY_SKU_MARKETING_POINTS:
            return [], f"ai-marketing-point-too-generic:{row_id}"
        gift_name = str(request.get("gift_name") or "").strip()
        if normalize_sku_name(gift_name) and normalize_sku_name(gift_name) in normalize_sku_name(main_name):
            return [], f"ai-main-name-contains-selected-gift:{row_id}"
        raw_tail_count = response.get("unknown_code_gift_tail_count", 0)
        if isinstance(raw_tail_count, bool):
            return [], f"ai-code-tail-count-invalid:{row_id}"
        try:
            unknown_tail_count = int(raw_tail_count or 0)
        except (TypeError, ValueError):
            return [], f"ai-code-tail-count-invalid:{row_id}"
        if isinstance(raw_tail_count, float) and raw_tail_count != unknown_tail_count:
            return [], f"ai-code-tail-count-invalid:{row_id}"
        code_segments = split_sku_segments(request.get("code_after_known") or "")
        if unknown_tail_count < 0 or unknown_tail_count >= len(code_segments):
            return [], f"ai-code-tail-count-invalid:{row_id}"
        main_code = strip_sku_tail_segments(request.get("code_after_known") or "", unknown_tail_count)
        if not main_code:
            return [], f"main-spec-code-empty:{row_id}"
        gift_code = str(request.get("gift_code") or "").strip()
        new_name = f"{main_name}+{gift_name}" if gift_name else main_name
        new_spec_code = append_spec_code(main_code, gift_code)
        main_name_max = int(request.get("main_name_max") or 0)
        name_hard_max = int(request.get("name_hard_max") or 40)
        code_max = int(request.get("code_max") or 0)
        if not main_name or (main_name_max > 0 and len(main_name) > main_name_max) or len(new_name) > name_hard_max:
            return [], f"ai-sku-name-too-long:{row_id}"
        if code_max > 0 and len(new_spec_code) > code_max:
            return [], f"spec-code-too-long:{row_id}"
        name_key = normalize_sku_name(new_name)
        code_key = normalize_visible_value(new_spec_code)
        if name_key in seen_names:
            return [], f"ai-sku-name-duplicate:{row_id}"
        if code_key in seen_codes:
            return [], f"spec-code-duplicate:{row_id}"
        seen_names.add(name_key); seen_codes.add(code_key)
        resolved.append({
            "row_id": row_id,
            "main_name": main_name,
            "main_code": main_code,
            "new_name": new_name,
            "new_spec_code": new_spec_code,
            "unknown_code_gift_tail_count": unknown_tail_count,
        })
    return resolved, ""
def build_cleanup_plan(compared_skus: list[dict], candidates: list[dict], current_names: dict | None = None, selection_key: str = "") -> dict:
    """Select one replacement gift per product; no PDD state is touched here."""
    current_names = current_names or {}
    targets, seen = [], set()
    for sku in compared_skus or []:
        source = str((sku or {}).get("name") or "").strip()
        key = normalize_sku_name(source)
        if not key:
            return {"ok": False, "reason": "compared-sku-name-empty", "assignments": []}
        if key in seen:
            return {"ok": False, "reason": "compared-sku-duplicate", "assignments": []}
        seen.add(key); targets.append(source)
    if not targets:
        return {"ok": False, "reason": "no-compared-skus", "assignments": []}
    gifts, seen_gifts = [], set()
    for item in candidates or []:
        name = str((item or {}).get("name") or "").strip()
        code = str((item or {}).get("spec_code") or "").strip()
        key = normalize_sku_name(name)
        if name and code and key and key not in seen_gifts:
            gifts.append({"name": name, "spec_code": code}); seen_gifts.add(key)
    if not gifts:
        return {"ok": False, "reason": "gift-candidates-empty-or-duplicate", "assignments": []}
    existing_gift_keys = set().union(*(original_sku_gift_keys(source) for source in targets))
    eligible_gifts = [
        gift for gift in gifts
        if gift_presence_key(gift["name"]) not in existing_gift_keys
    ]
    gift = _select_product_gift(eligible_gifts or gifts, selection_key)
    assignments = []
    for source in targets:
        base = display_sku_name(source)
        assignments.append({
            "source_name": source,
            "current_name": str(current_names.get(source) or source).strip(),
            "gift_name": gift["name"],
            "new_name": base + "+" + gift["name"],
            "spec_code": gift["spec_code"],
        })
    return {"ok": True, "reason": "", "assignments": assignments}

def normalize_visible_value(value: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(value or "")).lower())


def verify_detail_sku_rows(assignments: list[dict], rows: list[dict]) -> str:
    """Return an empty string only when the PDD detail table matches every expected SKU."""
    for item in assignments:
        expected_name = str(item.get("new_name") or "")
        matches = [row for row in rows if any(normalize_sku_name(value) == normalize_sku_name(expected_name) for value in (row.get("sku_values") or [row.get("style", "")]))]
        if len(matches) != 1:
            return f"detail-sku-name-not-unique:{expected_name}:{len(matches)}"
        actual_code = normalize_visible_value(matches[0].get("spec_code", ""))
        expected_code = normalize_visible_value(item.get("new_spec_code", ""))
        if actual_code != expected_code:
            return f"detail-spec-code-mismatch:{expected_name}"
    return ""


_DETAIL_SKU_ROWS_JS = r"""arg => {
 const HEADER='\u89c4\u683c\u7f16\u7801';
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0};
 const text=e=>(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();
 const direct=e=>Array.from(e.childNodes||[]).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').replace(/\s+/g,' ').trim();
 const norm=s=>(s||'').normalize('NFKC').toLowerCase().replace(/\s+/g,'').replace(/\u4e00/g,'1');
 const expected=(arg.expected||[]).map(norm).filter(Boolean), candidates=[];
 for(const table of document.querySelectorAll('table')){
  if(!visible(table))continue;
  const trs=[...table.querySelectorAll('tr')];
  const header=trs.map(tr=>({tr,cells:[...tr.querySelectorAll('th,td')]})).filter(x=>x.cells.length).find(x=>x.cells.some(c=>text(c).replace(/^\*/, '')===HEADER));
  if(!header)continue;
  const codeIndex=header.cells.findIndex(c=>text(c).replace(/^\*/, '')===HEADER), rows=[];
  for(const tr of trs){if(tr===header.tr)continue;const cells=[...tr.querySelectorAll('td')];if(cells.length<=codeIndex)continue;const skuValues=cells.slice(0,codeIndex).map(text).filter(Boolean),specCode=text(cells[codeIndex]);if(skuValues.length)rows.push({sku_values:skuValues,spec_code:specCode});}
  if(rows.length)candidates.push(rows);
 }
 if(candidates.length){candidates.sort((a,b)=>b.length-a.length);return{ok:true,reason:'',rows:candidates[0],layout:'table'};}
 const all=[...document.querySelectorAll('div,span,td,p')].filter(visible);
 const headerEl=all.filter(e=>direct(e).replace(/^\*/, '')===HEADER).sort((a,b)=>a.getBoundingClientRect().y-b.getBoundingClientRect().y)[0];
 if(!headerEl)return{ok:false,reason:'detail-spec-code-header-not-found',rows:[]};
 const hr=headerEl.getBoundingClientRect(), rows=[];
 for(const target of expected){
  const nameCandidates=all.map(e=>({e,t:text(e),r:e.getBoundingClientRect()})).filter(x=>norm(x.t)===target).sort((a,b)=>(a.r.width*a.r.height)-(b.r.width*b.r.height));
  const name=nameCandidates[0];if(!name)return{ok:false,reason:'detail-sku-name-not-found',rows:[]};
  const cy=name.r.y+name.r.height/2, codeCandidates=all.map(e=>({e,t:direct(e)||text(e),r:e.getBoundingClientRect()})).filter(x=>x.t&&norm(x.t)!==target&&x.t!==HEADER&&Math.abs((x.r.y+x.r.height/2)-cy)<55).map(x=>({x,score:Math.abs((x.r.x+x.r.width/2)-(hr.x+hr.width/2))+Math.abs((x.r.y+x.r.height/2)-cy)*3})).sort((a,b)=>a.score-b.score);
  if(!codeCandidates.length)return{ok:false,reason:'detail-spec-code-value-not-found',rows:[]};
  rows.push({sku_values:[name.t],spec_code:codeCandidates[0].x.t});
 }
 return{ok:true,reason:'',rows,layout:'grid'};
}"""


async def _refresh_detail_for_sku_read(detail_page, detail_url: str, attempt: int) -> None:
    if attempt == 1:
        await detail_page.goto(detail_url, wait_until="domcontentloaded", timeout=30000)
    else:
        await detail_page.reload(wait_until="domcontentloaded", timeout=30000)
    await asyncio.sleep(1)
    await detail_page.evaluate("""async () => {
      const height=Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
      window.scrollTo(0, Math.round(height * 0.8));
      window.dispatchEvent(new Event('scroll'));
      await new Promise(r=>setTimeout(r,900));
    }""")
    await asyncio.sleep(0.3)


async def _read_detail_sku_rows(detail_page, expected_names: list[str]) -> dict:
    try:
        return await detail_page.evaluate(_DETAIL_SKU_ROWS_JS, {"expected": expected_names})
    except Exception as exc:
        return {"ok": False, "reason": f"detail-sku-row-read-error:{exc}", "rows": []}
_PRODUCT_SPEC_TYPE_JS = r"""arg => {
 const EXPECTED=(arg.expected_type||'').normalize('NFKC').toLowerCase().replace(/\s+/g,'');
 const LABEL='\u5546\u54c1\u89c4\u683c';
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0};
 const direct=e=>Array.from(e.childNodes||[]).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
 const norm=s=>(s||'').normalize('NFKC').toLowerCase().replace(/\s+/g,'');
 const label=[...document.querySelectorAll('label,span,div,p')].find(e=>visible(e)&&direct(e)===LABEL);
 if(!label||!EXPECTED)return{ok:false,reason:'product-spec-label-or-expected-type-not-found'};
 const lr=label.getBoundingClientRect();
 const matches=[...document.querySelectorAll('input,select,button,[role="combobox"]')].filter(visible).map(el=>{const r=el.getBoundingClientRect();return{value:(el.value||direct(el)||el.innerText||'').trim(),r};}).filter(x=>norm(x.value)===EXPECTED&&x.r.y>=lr.y-20).sort((a,b)=>(a.r.y-lr.y)-(b.r.y-lr.y));
 if(!matches.length)return{ok:false,reason:'product-spec-type-control-not-found'};
 return{ok:true,spec_type:matches[0].value};
}"""


async def _read_product_spec_type(edit_page, expected_type: str) -> dict:
    try:
        return await edit_page.evaluate(_PRODUCT_SPEC_TYPE_JS, {"expected_type": expected_type})
    except Exception as exc:
        return {"ok": False, "reason": f"product-spec-read-error:{exc}"}
def _add_row_keys(rows: list[dict]) -> None:
    seen = {}
    for row in rows:
        style = str(row.get("style") or "").strip()
        ordinal = seen.get(style, 0); seen[style] = ordinal + 1
        row["rowOrdinal"] = ordinal; row["rowKey"] = f"{style}\x1f{ordinal}"


async def _find_name_input(edit_page, current_name: str, allow_source_prefix: bool = False, include_textarea: bool = False):
    token = "activity-sku-name-" + normalize_sku_name(current_name)
    state = await edit_page.evaluate(r"""arg => {
      const norm=s=>(s||'').normalize('NFKC').toLowerCase().replace(/\s+/g,'').replace(/\u4e00/g,'1');
      const visible=e=>{const r=e.getBoundingClientRect();return r.width>20&&r.height>4};
      const selector=arg.include_textarea ? 'input,textarea' : 'input';
      const editable=[...document.querySelectorAll(selector)].filter(input => !input.disabled && !input.readOnly && !input.hasAttribute('data-activity-sku-code') && visible(input));
      let matches=editable.filter(input => norm(input.value)===arg.current), match_mode='exact';
      if(matches.length!==1 && arg.allow_source_prefix){
        matches=editable.filter(input => {const value=norm(input.value);return value && arg.current.startsWith(value)});
        match_mode='source-prefix';
      }
      if(matches.length!==1)return {ok:false,reason:'sku-name-input-not-unique:'+matches.length,editable_values:editable.map(input=>String(input.value||'').trim()).filter(Boolean).slice(0,80)};
      matches[0].setAttribute('data-activity-sku-name',arg.token); return {ok:true,match_mode};
    }""", {"current": normalize_sku_name(current_name), "token": token, "allow_source_prefix": allow_source_prefix, "include_textarea": include_textarea})
    if not state.get("ok"):
        _trace("spec-name-locate-candidates", current_name=current_name, state=state)
        return None, state.get("reason", "sku-name-input-not-found")
    selector = f'input[data-activity-sku-name="{token}"],textarea[data-activity-sku-name="{token}"]' if include_textarea else f'input[data-activity-sku-name="{token}"]'
    loc = edit_page.locator(selector).first
    return (loc, "") if await loc.count() else (None, "sku-name-marker-not-found")


async def _locate_spec_code_input_by_marked_row(edit_page, row: dict):
    """Use the table row marker when a multi-spec row was matched by one column."""
    row_no = str(row.get("rowNo") or "").strip()
    if not row_no:
        return None, {"ok": False, "reason": "spec-code-row-number-missing"}
    locator = edit_page.locator(f'input[data-spec-code-row="{row_no}"],textarea[data-spec-code-row="{row_no}"]')
    count = await locator.count()
    if count != 1:
        return None, {"ok": False, "reason": f"spec-code-row-marker-not-unique:{row_no}:{count}"}
    loc = locator.first
    try:
        return loc, {
            "ok": True,
            "locator": "marked-row",
            "value": (await loc.input_value()).strip(),
            "disabled": await loc.is_disabled(),
            "readonly": await loc.evaluate("el => !!el.readOnly"),
            "maxLength": int(await loc.evaluate("el => Number(el.maxLength || 0)")),
        }
    except Exception as exc:
        return None, {"ok": False, "reason": f"spec-code-row-marker-read-error:{exc}"}


async def _prepare_assignments(edit_page, assignments: list[dict], gift_candidates: list[dict] | None = None, gift_library: list[dict] | None = None, title: str = "", selection_key: str = "") -> tuple[list[dict], str]:
    gift_candidates = gift_candidates or []
    gift_library = gift_library or []
    mark_rows = any(activity_sku_has_net_content_layer(item.get("current_name") or item.get("source_name") or "") for item in assignments)
    state = await _read_spec_code_rows(edit_page, mark=mark_rows); rows = state.get("rows") or []
    _trace("spec-code-rows", state_ok=bool(state.get("ok")), state_reason=state.get("reason", ""), rows=rows)
    if not state.get("ok") or not rows:
        return [], state.get("reason", "spec-code-rows-not-found")
    if any(not str(row.get("value") or "").strip() for row in rows):
        try:
            pdd_name = await read_pdd_product_name(edit_page)
            repair = await fill_spec_codes(
                edit_page, pdd_name, title, "", correct_existing=True,
                known_styles=[str(row.get("style") or "").strip() for row in rows],
            )
        except Exception as exc:
            _trace("spec-code-auto-repair-error", error=repr(exc))
            return [], f"spec-code-auto-repair-failed:{exc}"
        _trace("spec-code-auto-repair", result=repair)
        repair_reason = apply_verified_spec_code_repair(rows, repair)
        if repair_reason:
            return [], repair_reason
        _trace("spec-code-rows-after-repair", source="verified-direct-readback", rows=rows)
    _add_row_keys(rows); located, seen_edit_rows = [], set()
    for item in assignments:
        source_current_name = item.get("current_name") or item["source_name"]
        expected_spec_type = activity_sku_prefix_label(source_current_name)
        spec_state = await _read_product_spec_type(edit_page, expected_spec_type) if expected_spec_type else {"ok": False, "reason": "activity-sku-prefix-not-present"}
        _trace("product-spec-type", expected_type=expected_spec_type, state=spec_state)
        is_net_content_two_layer = activity_sku_has_net_content_layer(source_current_name)
        candidates = activity_sku_match_candidates(source_current_name)
        current_name, matches, match_mode = source_current_name, [], "none"
        for candidate in candidates:
            if is_net_content_two_layer:
                found = [row for row in rows if sku_row_matches_candidate(row.get("style", ""), candidate)]
                if len(found) == 1:
                    current_name, matches, match_mode = candidate, found, "net-content-column-full"
                    break
                if len(found) > 1:
                    current_name, matches, match_mode = candidate, found, "net-content-column-full-ambiguous"
                    break
                primary_found = [row for row in rows if sku_row_primary_matches_candidate(row.get("style", ""), candidate)]
                if len(primary_found) == 1:
                    current_name, matches, match_mode = candidate, primary_found, "net-content-column-primary"
                    break
                if len(primary_found) > 1:
                    current_name, matches, match_mode = candidate, primary_found, "net-content-column-primary-ambiguous"
                    break
            else:
                found = [row for row in rows if normalize_sku_name(row.get("style", "")) == normalize_sku_name(candidate)]
                if len(found) == 1:
                    current_name, matches, match_mode = candidate, found, "full"
                    break
                if len(found) > 1:
                    current_name, matches, match_mode = candidate, found, "full-ambiguous"
                    break
                primary_key = primary_sku_key(candidate)
                primary_found = [row for row in rows if primary_sku_key(row.get("style", "")) == primary_key]
                if len(primary_found) == 1:
                    current_name, matches, match_mode = candidate, primary_found, "primary"
                    break
                if len(primary_found) > 1:
                    current_name, matches, match_mode = candidate, primary_found, "primary-ambiguous"
                    break
        _trace("target-row-match", source_name=item["source_name"], candidates=candidates, current_name=current_name, match_mode=match_mode, matched_styles=[r.get("style", "") for r in matches], match_count=len(matches))
        if len(matches) != 1:
            return [], f"target-sku-row-not-unique:{current_name}:{len(matches)}"
        row = matches[0]
        if is_net_content_two_layer and match_mode.startswith("net-content-column-"):
            code_loc, code_state = await _locate_spec_code_input_by_marked_row(edit_page, row)
        else:
            code_loc, code_state = await _locate_spec_code_input_for_row(edit_page, row)
        _trace("spec-code-locate", current_name=current_name, match_mode=match_mode, locate_state=code_state)
        if not code_loc:
            return [], code_state.get("reason", "spec-code-locate-failed")
        await code_loc.evaluate("e => e.setAttribute(\"data-activity-sku-code\", \"1\")")
        current_code = (await code_loc.input_value()).strip()
        code_max = int(row.get("maxLength") or 0)
        if row.get("disabled") or row.get("readonly"):
            return [], f"spec-code-readonly:{current_name}"
        name_lookup = current_name if is_net_content_two_layer else str(row.get("style") or "").strip()
        name_loc, reason = await _find_name_input(edit_page, name_lookup, allow_source_prefix=is_net_content_two_layer, include_textarea=is_net_content_two_layer)
        editable_name = (await name_loc.input_value()).strip() if name_loc else ""
        actual_name = editable_name if is_net_content_two_layer else name_lookup
        _trace("spec-name-locate", current_name=current_name, editable_name=editable_name, net_content_two_layer=is_net_content_two_layer, found=bool(name_loc), reason=reason)
        if not name_loc or not actual_name:
            return [], reason or "sku-name-input-empty"
        edit_row_key = sku_edit_row_identity(row.get("rowNo"), actual_name, current_code)
        if edit_row_key in seen_edit_rows:
            _trace("duplicate-editor-row-skipped", row_no=row.get("rowNo"), current_name=actual_name, current_code=current_code, source_name=item.get("source_name", ""))
            continue
        seen_edit_rows.add(edit_row_key)
        try:
            name_input_max = int(await name_loc.evaluate("el => Number(el.maxLength || 0)"))
        except Exception:
            name_input_max = 0
        name_hard_max = min(40, name_input_max) if name_input_max > 0 else 40
        known_main_name, removed_name_gifts = strip_known_gift_suffixes(actual_name, gift_library)
        code_after_known, removed_code_gifts = strip_known_gift_suffixes(current_code, gift_library, for_code=True)
        if not known_main_name:
            return [], f"main-sku-name-empty:{current_name}"
        if not code_after_known:
            return [], f"main-spec-code-empty:{current_name}"
        located.append({
            **item,
            "row_id": str(len(located)),
            "current_name": actual_name,
            "known_main_name": known_main_name,
            "removed_name_gifts": removed_name_gifts,
            "original_spec_code": current_code,
            "code_after_known": code_after_known,
            "removed_code_gifts": removed_code_gifts,
            "code_max": code_max,
            "name_hard_max": name_hard_max,
            "code_locator": code_loc,
            "name_locator": name_loc,
        })
    existing_gifts = [
        value
        for item in located
        for value in (item.get("removed_name_gifts") or []) + (item.get("removed_code_gifts") or [])
    ]
    gift = select_replacement_gift(gift_candidates, existing_gifts, selection_key)
    if not gift:
        return [], "gift-candidates-all-already-present"
    _trace("replacement-gift-selected", existing_gifts=existing_gifts, gift=gift)
    for item in located:
        item["gift_name"] = gift["name"]
        item["spec_code"] = gift["spec_code"]
        item["main_name_max"] = min(34, item["name_hard_max"]) - len(gift["name"]) - 1
        if item["main_name_max"] < 4:
            return [], f"gift-leaves-no-main-name-room:{item['current_name']}"
    validation_request = [{
        "row_id": item["row_id"],
        "known_main_name": item["known_main_name"],
        "code_after_known": item["code_after_known"],
        "gift_name": item["gift_name"],
        "gift_code": item["spec_code"],
        "main_name_max": item["main_name_max"],
        "name_hard_max": item["name_hard_max"],
        "code_max": item["code_max"],
    } for item in located]
    name_request = [{
        "row_id": item["row_id"],
        "current_name": item["current_name"],
        "known_main_name": item["known_main_name"],
        "known_removed_name_gifts": item["removed_name_gifts"],
        "selected_gift_name": item["gift_name"],
        "main_name_max": item["main_name_max"],
        "name_hard_max": item["name_hard_max"],
    } for item in located]
    code_request = []
    unknown_tail_counts = {item["row_id"]: 0 for item in located}
    for item in located:
        code_segments = split_sku_segments(item["code_after_known"])
        tail_segments = code_segments[1:]
        if tail_segments:
            code_request.append({
                "row_id": item["row_id"],
                "tail_segments": tail_segments,
                "current_sku_name": item["current_name"],
                "known_main_name": item["known_main_name"],
                "known_removed_name_gifts": item["removed_name_gifts"],
                "known_removed_code_gifts": item["removed_code_gifts"],
            })
    try:
        from smart_sku import classify_activity_sku_code_tails, rewrite_activity_sku_rows
    except Exception as exc:
        _trace("ai-rewrite-import-error", error=repr(exc))
        return [], f"ai-main-name-rewrite-failed:{exc}"
    if code_request:
        code_reason, code_ai_rows = "", []
        for code_attempt in range(1, 4):
            try:
                code_ai_rows = await asyncio.to_thread(classify_activity_sku_code_tails, code_request, title, gift_library)
            except Exception as exc:
                _trace("ai-code-tail-error", attempt=code_attempt, error=repr(exc), request=code_request)
                return [], f"ai-code-tail-classification-failed:{exc}"
            classified_counts, code_reason = validate_code_tail_classification(code_request, code_ai_rows)
            _trace("ai-code-tail-result", attempt=code_attempt, request=code_request, response=code_ai_rows, reason=code_reason)
            if not code_reason:
                unknown_tail_counts.update(classified_counts)
                break
        if code_reason:
            return [], code_reason
    name_ai_rows, resolved, reason = [], [], ""
    retryable_prefixes = (
        "ai-rewrite-row-mismatch",
        "ai-marketing-point-missing:",
        "ai-marketing-point-too-generic:",
        "ai-medical-wording-forbidden:",
        "ai-package-wording-forbidden:",
        "ai-main-name-copied-code:",
        "ai-main-name-contains-selected-gift:",
        "ai-sku-name-too-long:",
        "ai-sku-name-duplicate:",
    )
    previous_by_id = {}
    for ai_attempt in range(1, 4):
        attempt_request = [{
            **item,
            **({
                "previous_main_name": previous_name,
                "previous_main_name_length": len(previous_name),
                "required_main_name_max": item["main_name_max"],
                "minimum_characters_to_remove": max(0, len(previous_name) - item["main_name_max"]),
                "previous_validation_error": reason,
                "previous_forbidden_terms": sorted({
                    term for term in (
                        FORBIDDEN_ACTIVITY_SKU_MEDICAL_TERMS | FORBIDDEN_ACTIVITY_SKU_PACKAGE_TERMS
                    ) if term in previous_name
                }),
            } if ai_attempt > 1 else {}),
        } for item in name_request
          for previous_name in [str((previous_by_id.get(item["row_id"]) or {}).get("main_name") or "")]]
        try:
            name_ai_rows = await asyncio.to_thread(rewrite_activity_sku_rows, attempt_request, title, None)
        except Exception as exc:
            _trace("ai-rewrite-error", attempt=ai_attempt, error=repr(exc), request=attempt_request)
            return [], f"ai-main-name-rewrite-failed:{exc}"
        combined_rows = [
            {**item, "unknown_code_gift_tail_count": unknown_tail_counts.get(str(item.get("row_id")), 0)}
            for item in name_ai_rows or [] if isinstance(item, dict)
        ]
        resolved, reason = validate_ai_rewrite_rows(validation_request, combined_rows)
        _trace("ai-rewrite-result", attempt=ai_attempt, request=attempt_request, response=name_ai_rows, reason=reason)
        if not reason:
            break
        if not any(reason == prefix or reason.startswith(prefix) for prefix in retryable_prefixes):
            break
        previous_by_id = {str(item.get("row_id")): item for item in name_ai_rows or [] if isinstance(item, dict)}
    if reason:
        return [], reason
    resolved_by_id = {item["row_id"]: item for item in resolved}
    prepared = []
    for item in located:
        rewrite = resolved_by_id[item["row_id"]]
        prepared.append({
            **item,
            "main_name": rewrite["main_name"],
            "main_code": rewrite["main_code"],
            "new_name": rewrite["new_name"],
            "new_spec_code": rewrite["new_spec_code"],
            "unknown_code_gift_tail_count": rewrite["unknown_code_gift_tail_count"],
        })
    return prepared, ""


async def _write_and_verify(prepared: list[dict]) -> tuple[bool, str]:
    for item in prepared:
        try:
            await item["name_locator"].click(timeout=5000)
            await item["name_locator"].press("Control+A")
            await item["name_locator"].press("Delete")
            await item["name_locator"].type(item["new_name"], delay=25)
            await item["name_locator"].press("Tab")
            await item["code_locator"].fill(item["new_spec_code"], timeout=5000)
            await item["code_locator"].press("Tab")
            await asyncio.sleep(0.4)
            actual_name = (await item["name_locator"].input_value()).strip()
            actual_code = (await item["code_locator"].input_value()).strip()
            _trace("edit-readback", current_name=item["current_name"], expected_name=item["new_name"], actual_name=actual_name, expected_code=item["new_spec_code"], actual_code=actual_code)
            if actual_name != item["new_name"]:
                _trace("edit-name-retry-fill", current_name=item["current_name"], expected_name=item["new_name"], actual_name=actual_name)
                await item["name_locator"].fill(item["new_name"], timeout=5000)
                await item["name_locator"].press("Tab")
                await asyncio.sleep(0.4)
                actual_name = (await item["name_locator"].input_value()).strip()
                actual_code = (await item["code_locator"].input_value()).strip()
                _trace("edit-readback-retry", current_name=item["current_name"], expected_name=item["new_name"], actual_name=actual_name, expected_code=item["new_spec_code"], actual_code=actual_code)
            if actual_name != item["new_name"] or actual_code != item["new_spec_code"]:
                return False, f"edit-readback-failed:{item['current_name']}"
        except Exception as exc:
            return False, f"edit-write-failed:{item['current_name']}:{exc}"
    return True, ""

async def _verify_submitted_changes(detail_page, detail_url: str, prepared: list[dict], wait_seconds: int, max_refreshes: int) -> tuple[bool, str]:
    """Read the SKU table on the product detail page; never open edit on a successful check."""
    last_reason = "not-checked"
    for attempt in range(1, max(1, max_refreshes) + 1):
        await asyncio.sleep(max(1, wait_seconds))
        try:
            await _refresh_detail_for_sku_read(detail_page, detail_url, attempt)
            state = await _read_detail_sku_rows(detail_page, [str(item.get("new_name") or "") for item in prepared])
            last_reason = state.get("reason", "detail-sku-table-not-found")
            if state.get("ok"):
                last_reason = verify_detail_sku_rows(prepared, state.get("rows") or [])
        except Exception as exc:
            last_reason = f"detail-open-error:{exc}"
        _trace("post-submit-detail-check", attempt=attempt, reason=last_reason)
        if not last_reason:
            return True, ""
    if last_reason.startswith(("detail-sku-name-not-unique:", "detail-spec-code-mismatch:")):
        problem_page = None
        try:
            problem_page = await click_edit_goods(detail_page)
            _trace("post-submit-problem-editor-opened", reason=last_reason)
        except Exception as exc:
            last_reason = f"{last_reason}:editor-open-error:{exc}"
        finally:
            if problem_page and problem_page is not detail_page:
                try: await problem_page.close()
                except Exception: pass
    return False, f"post-submit-detail-mismatch:{last_reason}"


async def clean_one(context, rec: dict, verify_wait_seconds: int, verify_max_refreshes: int) -> dict:
    goods_id = str(rec.get("goods_id") or "").strip()
    plan = build_cleanup_plan(rec.get("compared_skus") or [], rec.get("gift_candidates") or [], rec.get("current_names") or {}, goods_id)
    result = {"goods_id": goods_id, "submitted": False, "ok": False, "reason": plan["reason"], "assignments": plan["assignments"]}
    _trace("product-plan", goods_id=goods_id, plan=plan)
    if not goods_id or not plan["ok"]:
        return result
    detail_url = str(rec.get("detail_url") or f"https://mms.pinduoduo.com/goods/goods_detail?goods_id={goods_id}")
    detail_page = await context.new_page(); edit_page = verify_page = None
    try:
        await detail_page.goto(detail_url, wait_until="domcontentloaded", timeout=30000)
        edit_page = await click_edit_goods(detail_page)
        prepared, reason = await _prepare_assignments(
            edit_page,
            plan["assignments"],
            rec.get("gift_candidates") or [],
            rec.get("gift_library") or rec.get("gift_candidates") or [],
            str(rec.get("title") or ""),
            goods_id,
        )
        if not prepared:
            result["reason"] = reason; _trace("product-blocked", goods_id=goods_id, stage="prepare", reason=reason); return result
        result["assignments"] = [{
            "source_name": item.get("source_name", ""),
            "current_name": item.get("current_name", ""),
            "main_name": item.get("main_name", ""),
            "gift_name": item.get("gift_name", ""),
            "new_name": item.get("new_name", ""),
            "original_spec_code": item.get("original_spec_code", ""),
            "main_code": item.get("main_code", ""),
            "gift_spec_code": item.get("spec_code", ""),
            "new_spec_code": item.get("new_spec_code", ""),
            "removed_name_gifts": item.get("removed_name_gifts", []),
            "removed_code_gifts": item.get("removed_code_gifts", []),
            "unknown_code_gift_tail_count": item.get("unknown_code_gift_tail_count", 0),
        } for item in prepared]
        ok, reason = await _write_and_verify(prepared)
        if not ok:
            result["reason"] = reason; _trace("product-blocked", goods_id=goods_id, stage="write", reason=reason); return result
        if not await click_edit_submit(edit_page):
            result["reason"] = "submit-failed"; _trace("product-blocked", goods_id=goods_id, stage="submit", reason="submit-failed"); return result
        result["submitted"] = True
        ok, reason = await _verify_submitted_changes(detail_page, detail_url, prepared, verify_wait_seconds, verify_max_refreshes)
        if not ok:
            result["reason"] = reason; _trace("product-blocked", goods_id=goods_id, stage="post-submit", reason=reason); return result
        result.update({"ok": True, "reason": ""}); _trace("product-success", goods_id=goods_id, assignments=result["assignments"]); return result
    except Exception as exc:
        result["reason"] = f"cleanup-error:{exc}"; _trace("product-exception", goods_id=goods_id, error=repr(exc)); return result
    finally:
        for page in (verify_page, edit_page, detail_page):
            if page:
                try: await page.close()
                except Exception: pass


async def run(args) -> list[dict]:
    records = json.loads(Path(args.records_json).read_text(encoding="utf-8"))
    _trace("run-start", store=args.store, record_count=len(records), records_json=args.records_json)
    stores = _load_stores(); matched = next((key for key in stores if args.store in key or key in args.store), None)
    profile = PROFILE_DIR / stores[matched] if matched else _profile_dir_for(args.store)
    window_args = ["--start-maximized"] if args.show_browser else ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(str(profile), executable_path=find_chrome(), headless=False, args=window_args + ["--disable-blink-features=AutomationControlled"], ignore_default_args=["--enable-automation"], viewport=None)
        page = context.pages[0] if context.pages else await context.new_page(); await apply_window_mode(context, page, args.show_browser)
        results = [await clean_one(context, rec, args.verify_wait_seconds, args.verify_max_refreshes) for rec in records]
        await context.close()
    for result in results: result["log_path"] = args.log_path
    _trace("run-finish", results=results); return results


def main() -> int:
    parser = argparse.ArgumentParser(description="洗活动比价 SKU；全部回读成功才提交")
    parser.add_argument("--store", required=True); parser.add_argument("--records-json", required=True); parser.add_argument("--output-json", required=True); parser.add_argument("--log-path", default=""); parser.add_argument("--show-browser", action="store_true")
    parser.add_argument("--verify-wait-seconds", type=int, default=8, help="提交后首次及每次刷新前等待秒数")
    parser.add_argument("--verify-max-refreshes", type=int, default=2, help="提交后最多回检刷新次数")
    args = parser.parse_args(); _configure_logging(args.log_path)
    try:
        results = asyncio.run(run(args)); Path(args.output_json).write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        print(RESULT_PREFIX + json.dumps(results, ensure_ascii=False, separators=(",", ":"))); return 0
    except Exception as exc:
        _trace("run-exception", error=repr(exc)); print(RESULT_PREFIX + json.dumps({"error": str(exc)}, ensure_ascii=False)); return 1


if __name__ == "__main__":
    raise SystemExit(main())