"""Read PDD activity suggested prices without submitting a registration.

The activity page only exposes full SKU suggested prices after the products have
been selected and the page has advanced to step 2.  This tool deliberately
stops there: it never locates or clicks the page's final ``确认提交`` button.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Iterable


APP_DIR = Path(__file__).resolve().parent
PROFILE_ROOT = APP_DIR / "pdd_profiles"
MAX_GOODS_PER_QUERY = 200
RESULT_PREFIX = "ACTIVITY_COMPARE_RESULT="
DIRECT_PRICE_ACTIVITY_IDS = {"22496", "21374"}
DIRECT_PRICE_PAGE_URLS = {
    "21374": "https://mms.pinduoduo.com/act/goods_manage",
}
PRICE_PAGE_HEADERS = re.compile(r"建议价格|大促报名价")
GOODS_MANAGE_PRICE_HEADERS = re.compile(r"潜力商品报名|活动价\s*[（(]元[）)]|基于建议价降价")


def is_goods_manage_price_page_ready(url: str, body_text: str) -> bool:
    """Recognize 21374 by its fixed URL and price column shown in page text."""
    normalized = re.sub(r"\s+", "", str(body_text or ""))
    return (
        "/act/goods_manage" in str(url or "")
        and ("活动价(元)" in normalized or "活动价（元）" in normalized)
    )


def activity_entry_url(activity_id: str) -> str:
    """Return the exact first page for an activity price lookup."""
    activity_id = str(activity_id or "").strip()
    direct_url = DIRECT_PRICE_PAGE_URLS.get(activity_id)
    if direct_url:
        return direct_url
    return (
        "https://mms.pinduoduo.com/act/detail?"
        f"id={activity_id}&SourceType=PROMO-OwnHome&SceneType=ActivityCard"
    )


def normalize_goods_ids(raw: str | Iterable[str]) -> list[str]:
    """Return unique numeric goods IDs in their first-seen order."""
    values = re.split(r"[\s,，、]+", raw) if isinstance(raw, str) else raw
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        goods_id = str(value or "").strip()
        if goods_id.isdigit() and goods_id not in seen:
            seen.add(goods_id)
            result.append(goods_id)
    return result


def is_not_compared(suggested_price: float | None, discount: float | None) -> bool:
    """Business rule confirmed from the activity-price review workflow."""
    if isinstance(suggested_price, (int, float)) and suggested_price < 0.5:
        return True
    return isinstance(discount, (int, float)) and discount >= 6.5


def apply_reference_price(sku: dict, reference_price: float | None) -> dict:
    """Re-evaluate an activity SKU against the current local PDD group price."""
    item = dict(sku or {})
    if not isinstance(reference_price, (int, float)) or reference_price <= 0:
        item["compared"] = None
        item["price_source"] = "未匹配自动推广当前拼单价"
        return item

    activity_page_price = item.get("current_price")
    suggested_price = item.get("suggested_price")
    item["activity_page_price"] = activity_page_price
    item["current_price"] = float(reference_price)
    item["price_source"] = "自动推广当前拼单价"
    if not isinstance(suggested_price, (int, float)):
        item["discount"] = None
        item["compared"] = None
    else:
        discount = round(float(suggested_price) / float(reference_price) * 10, 2)
        item["discount"] = discount
        item["compared"] = not is_not_compared(float(suggested_price), discount)
    return item


def extract_goods_id(cells: list[str], last_goods_id: str = "") -> str:
    """Read product IDs from legacy and compact activity-table labels."""
    combined = "\n".join(str(cell or "").strip() for cell in cells)
    found = re.search(r"(?:商品\s*)?ID\s*[:：]?\s*(\d{6,})", combined, flags=re.I)
    if found:
        return found.group(1)

    long_numbers = list(dict.fromkeys(re.findall(r"(?<!\d)(\d{10,})(?!\d)", combined)))
    return long_numbers[0] if len(long_numbers) == 1 else last_goods_id


def parse_sku_row(cells: list[str], last_goods_id: str = "") -> tuple[str, dict | None]:
    """Extract one SKU from either supported activity-price table layout."""
    clean = [str(cell or "").strip() for cell in cells]
    goods_id = extract_goods_id(clean, last_goods_id)
    price_label = r"(?:当前价|拼单价)"
    spec_cell = next((cell for cell in clean if re.search(price_label, cell)), "")
    if not goods_id or not spec_cell:
        return goods_id, None
    current_match = re.search(price_label + r"\s*[:：]?\s*¥?\s*([0-9]+(?:\.[0-9]+)?)", spec_cell)
    if not current_match:
        return goods_id, None
    spec_name = re.split(price_label + r"\s*[:：]?", spec_cell, maxsplit=1)[0].strip()
    suggestion_cell = next(
        (cell for cell in clean if ("折" in cell or "报名价" in cell)
         and re.search(r"[0-9]+(?:\.[0-9]+)?", cell)),
        "",
    )
    suggested_match = re.search(r"([0-9]+(?:\.[0-9]+)?)", suggestion_cell)
    discount_match = re.search(r"约?\s*(?:拼单价)?\s*([0-9]+(?:\.[0-9]+)?)\s*折", suggestion_cell)
    suggested = float(suggested_match.group(1)) if suggested_match else None
    discount = float(discount_match.group(1)) if discount_match else None
    sku = {
        "name": spec_name or "未命名规格",
        "current_price": float(current_match.group(1)),
        "suggested_price": suggested,
        "discount": discount,
    }
    if suggested is None:
        sku["compared"] = None
    elif suggested < 0.5:
        sku["compared"] = False
    elif discount is None:
        sku["compared"] = None
    else:
        sku["compared"] = not is_not_compared(suggested, discount)
    return goods_id, sku


def build_products(requested_ids: Iterable[str], rows: Iterable[list[str]]) -> dict[str, dict]:
    """Build product-level results; any compared SKU marks its product."""
    products = {
        goods_id: {"status": "unavailable", "skus": [], "compared_skus": []}
        for goods_id in normalize_goods_ids(requested_ids)
    }
    last_goods_id = ""
    for cells in rows:
        goods_id, sku = parse_sku_row(cells, last_goods_id)
        if goods_id:
            last_goods_id = goods_id
        if sku and goods_id in products:
            products[goods_id]["skus"].append(sku)
    for product in products.values():
        skus = product["skus"]
        if not skus:
            continue
        classified = [sku for sku in skus if isinstance(sku.get("compared"), bool)]
        compared = [sku for sku in classified if sku["compared"]]
        product["compared_skus"] = compared
        if compared:
            product["status"] = "compared"
        elif len(classified) == len(skus):
            product["status"] = "not_compared"
    return products


async def _click_first_visible(page, selectors: list[str], label: str) -> None:
    for selector in selectors:
        locator = page.locator(selector)
        for index in range(await locator.count()):
            candidate = locator.nth(index)
            if await candidate.is_visible():
                await candidate.scroll_into_view_if_needed()
                await candidate.click()
                return
    raise RuntimeError(f"找不到「{label}」控件")


async def _dismiss_message_float(page) -> None:
    """Close PDD's non-security ``新消息`` floating panel when it blocks the page.

    The panel is incidental site chrome, not part of the comparison workflow.
    The title check is intentionally strict, so no verification/captcha dialog is
    dismissed or interacted with.
    """
    titles = page.get_by_text(re.compile(r"^新消息\s*[（(]\d+[)）]$"))
    for index in range(await titles.count()):
        title = titles.nth(index)
        if not await title.is_visible():
            continue
        closed = await page.evaluate(
            """title => {
                let panel = title;
                while (panel && panel !== document.body) {
                    const style = getComputedStyle(panel);
                    const rect = panel.getBoundingClientRect();
                    if ((style.position === 'fixed' || style.position === 'absolute') && panel.querySelector('[aria-label*="关闭"],[title*="关闭"],[class*="close"],[class*="Close"]')
                        && rect.width >= 240 && rect.height >= 100) break;
                    panel = panel.parentElement;
                }
                if (!panel || panel === document.body) return false;
                const panelRect = panel.getBoundingClientRect();
                const controls = [...panel.querySelectorAll(
                    'button,[role="button"],[aria-label*="关闭"],[title*="关闭"],[class*="close"],[class*="Close"]'
                )].filter(el => {
                    const rect = el.getBoundingClientRect();
                    return rect.width > 0 && rect.height > 0 && rect.top >= panelRect.top
                        && rect.right <= panelRect.right + 2;
                });
                const close = controls.find(el => /关闭|×|x/i.test(
                    `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.textContent || ''}`
                )) || controls.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right)[0];
                if (!close) return false;
                close.click();
                return true;
            }""",
            await title.element_handle(),
        )
        if closed:
            print("ACTIVITY_MESSAGE_FLOAT=closed")
            await page.wait_for_timeout(250)
            return
        close_target = await page.evaluate(
            """title => {
                let panel = title.parentElement;
                while (panel && panel !== document.body) {
                    const r = panel.getBoundingClientRect();
                    if (r.width >= 300 && r.width <= 650 && r.height >= 180 && r.height <= 650) {
                        return {x: Math.max(12, Math.min(window.innerWidth - 12, r.right)), y: Math.max(12, r.top)};
                    }
                    panel = panel.parentElement;
                }
                return null;
            }""",
            await title.element_handle(),
        )
        if close_target:
            await page.mouse.click(close_target["x"], close_target["y"])
            await page.wait_for_timeout(300)
            if not await title.is_visible():
                print("ACTIVITY_MESSAGE_FLOAT=closed mouse=" + json.dumps(close_target, ensure_ascii=False))
                return
        print("ACTIVITY_MESSAGE_FLOAT=close_failed target=" + json.dumps(close_target, ensure_ascii=False))
        return

    print("ACTIVITY_MESSAGE_FLOAT=not_present")

async def _wait_for_activity_grid(page) -> None:
    images = page.locator("img")
    deadline = time.monotonic() + 60
    previous_count = -1
    stable_at = 0.0
    while True:
        visible_count = 0
        for index in range(await images.count()):
            if await images.nth(index).is_visible():
                visible_count += 1
        now = time.monotonic()
        if visible_count >= 3 and visible_count == previous_count and now - stable_at >= 3:
            return
        if visible_count != previous_count:
            previous_count = visible_count
            stable_at = now
        if now >= deadline:
            raise RuntimeError("活动商品图片未在 60 秒内稳定加载")
        await page.wait_for_timeout(400)


async def _ensure_search_modal(page):
    await _dismiss_message_float(page)
    await _wait_for_activity_grid(page)
    await _dismiss_message_float(page)
    main_search = page.locator("input[placeholder*='ID搜索商品']")
    await main_search.wait_for(state="visible", timeout=15000)
    click_wait_seconds = float(os.environ.get("PDD_ACTIVITY_SEARCH_CLICK_TIMEOUT", "300"))
    deadline = time.monotonic() + click_wait_seconds
    last_click_error = ""
    while True:
        try:
            await main_search.scroll_into_view_if_needed()
            await main_search.click(timeout=1000)
            break
        except Exception as exc:
            last_click_error = str(exc).replace("\n", " ")[:800]
            if time.monotonic() >= deadline:
                raise RuntimeError("活动搜索框无法普通点击：" + last_click_error)
            await page.wait_for_timeout(500)
    query_input = page.locator("input[placeholder*='最多200个ID']")
    while True:
        if await query_input.count() == 1:
            if await query_input.is_visible():
                return query_input
        if time.monotonic() >= deadline:
            raise RuntimeError("活动商品搜索弹窗未在验证完成后出现")
        await page.wait_for_timeout(500)


async def _wait_for_search_results(page, modal) -> None:
    boxes = modal.locator("input[type='checkbox']")
    deadline = time.monotonic() + 300
    while True:
        # The table header has one checkbox; a returned product adds another.
        if await boxes.count() >= 2:
            return
        if time.monotonic() >= deadline:
            raise RuntimeError("等待商品查询结果或人工验证超过 5 分钟")
        await page.wait_for_timeout(500)
async def _load_all_search_results(page, modal) -> None:
    """Load every eligible-product result before selecting the table header checkbox."""
    load_more_clicks = 0
    for _ in range(100):
        await modal.evaluate("""root => {
            const targets = [root, ...root.querySelectorAll('*')]
                .filter(el => el.scrollHeight > el.clientHeight + 4 && el.querySelector('input[type=checkbox]'))
                .sort((a, b) => a.clientHeight - b.clientHeight);
            const target = targets[0];
            if (!target) return false;
            target.scrollTop = target.scrollHeight;
            target.dispatchEvent(new Event('scroll'));
            return true;
        }""")
        await page.wait_for_timeout(300)
        no_more = modal.get_by_text(re.compile(r"\u6ca1\u6709\u66f4\u591a\u4e86"))
        for index in range(await no_more.count()):
            if await no_more.nth(index).is_visible():
                print(f"ACTIVITY_SEARCH_LOAD_MORE_CLICKS={load_more_clicks}")
                return
        links = modal.get_by_text(re.compile(r"\u70b9\u51fb\u52a0\u8f7d\u66f4\u591a"))
        load_more = None
        for index in range(await links.count()):
            candidate = links.nth(index)
            if await candidate.is_visible():
                load_more = candidate
                break
        if load_more is None:
            raise RuntimeError("eligible-product list reached bottom without an explicit end marker")
        before_count = await modal.locator("input[type='checkbox']").count()
        await load_more.click()
        load_more_clicks += 1
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            await page.wait_for_timeout(250)
            if await modal.locator("input[type='checkbox']").count() > before_count:
                break
    raise RuntimeError("eligible-product load-more exceeded safety limit")

async def _probe_signup_candidate(page):
    records = []
    controls = page.locator("button,a,[role='button']")
    for index in range(await controls.count()):
        candidate = controls.nth(index)
        if not await candidate.is_visible():
            continue
        text = (await candidate.inner_text()).strip()
        if "报名" not in text:
            continue
        records.append({"index": index, "tag": await candidate.evaluate("el => el.tagName"), "text": text[:100]})
        if "立即报名" in text:
            return candidate, records
    return None, records


async def _enter_activity_selection(page):
    deadline = time.monotonic() + 30
    last_records = []
    while True:
        signup, last_records = await _probe_signup_candidate(page)
        if signup is not None:
            print("ACTIVITY_SIGNUP_PROBE=" + json.dumps(last_records, ensure_ascii=False))
            await signup.click()
            selection_deadline = time.monotonic() + 30
            while True:
                for candidate_page in page.context.pages:
                    selection_tab = candidate_page.get_by_text("可参与活动的商品", exact=True)
                    if "/act/choose_goods/" in candidate_page.url or await selection_tab.is_visible():
                        print("ACTIVITY_SELECTION=ready url=" + candidate_page.url)
                        return candidate_page
                if time.monotonic() >= selection_deadline:
                    urls = [candidate_page.url for candidate_page in page.context.pages]
                    raise RuntimeError("已点击“立即报名”，但 30 秒内未进入活动选品页；标签页=" + json.dumps(urls, ensure_ascii=False))
                await page.wait_for_timeout(250)
        if time.monotonic() >= deadline:
            raise RuntimeError("活动详情页未发现精确“立即报名”按钮；候选=" + json.dumps(last_records, ensure_ascii=False))
        await page.wait_for_timeout(500)


async def _click_visible_checkbox(page, checkbox, label: str) -> None:
    target = await checkbox.evaluate("""el => { for (let node = el.parentElement; node; node = node.parentElement) { const r = node.getBoundingClientRect(); if (r.width >= 12 && r.width <= 80 && r.height >= 12 && r.height <= 80) { node.scrollIntoView({block: 'nearest'}); const p = node.getBoundingClientRect(); return {x: p.left + p.width / 2, y: p.top + p.height / 2}; } } return null; }""")
    if not target:
        raise RuntimeError(f"无法定位{label}的可见复选框")
    await page.mouse.click(target["x"], target["y"])
    await page.wait_for_timeout(150)
    if not await checkbox.is_checked():
        raise RuntimeError(f"{label}点击后未选中")

async def _open_search_and_select(page, goods_ids: list[str]) -> int:
    query_input = await _ensure_search_modal(page)
    await query_input.click()
    await query_input.press("Control+A")
    await query_input.press("Backspace")
    # Keep real key events for the activity page, but do not make a 200-ID
    # query wait 90ms for every character. The override is available for a
    # temporarily slow/unstable page without changing normal behaviour.
    input_delay_ms = max(0, float(os.environ.get("PDD_ACTIVITY_SEARCH_INPUT_DELAY_MS", "5")))
    await query_input.press_sequentially(",".join(goods_ids), delay=input_delay_ms)
    await page.wait_for_timeout(700)
    modal = query_input.locator(
        "xpath=ancestor::div[.//button[contains(normalize-space(.), '确认')]][1]"
    )
    if await modal.count() != 1:
        raise RuntimeError("无法唯一定位活动商品搜索弹窗")
    await _click_first_visible(modal, ["button:has-text('查询')", "text=查询"], "查询")
    await _wait_for_search_results(page, modal)
    await _load_all_search_results(page, modal)

    boxes = modal.locator("input[type='checkbox']")
    if await boxes.count() < 2:
        raise RuntimeError("查询结果没有可勾选商品")
    select_all_box = boxes.nth(0)
    if not await select_all_box.is_checked():
        await _click_visible_checkbox(page, select_all_box, "搜索结果全选框")
    product_count = await boxes.count() - 1
    for index in range(1, product_count + 1):
        if not await boxes.nth(index).is_checked():
            raise RuntimeError(f"搜索结果全选后第 {index} 个商品仍未勾选")
    print(f"ACTIVITY_SEARCH_SELECTED={product_count}")
    await _click_first_visible(modal, ["button:has-text('确认')", "text=确认"], "搜索弹窗确认")
    try:
        await modal.wait_for(state="hidden", timeout=10000)
    except Exception as exc:
        raise RuntimeError(f"搜索弹窗确认后未关闭：{exc}")
    # PDD commits the selected rows asynchronously after the dialog closes.
    await page.wait_for_timeout(1000)
    await _click_first_visible(page, ["button:has-text('确认选择')", "text=确认选择"], "确认选择")
    await page.wait_for_timeout(800)
    return product_count


async def _expand_all_specs(page) -> None:
    """Expand SKU rows throughout the whole price page, not only its first viewport."""
    stalled_scrolls = 0
    for _ in range(800):
        links = page.get_by_text(re.compile(r"展开更多规格"))
        visible = None
        for index in range(await links.count()):
            candidate = links.nth(index)
            if await candidate.is_visible():
                visible = candidate
                break
        if visible is not None:
            await visible.scroll_into_view_if_needed()
            await visible.click()
            await page.wait_for_timeout(180)
            stalled_scrolls = 0
            continue

        # The activity price page lazy-renders products below the viewport.
        # Advance in overlapping viewport steps so variable-height virtual rows are not skipped.
        moved = await page.evaluate("""() => {
            const root = document.scrollingElement || document.documentElement;
            const before = root.scrollTop;
            root.scrollTop = Math.min(root.scrollHeight - root.clientHeight,
                before + Math.max(260, Math.round(root.clientHeight * 0.45)));
            window.dispatchEvent(new Event('scroll'));
            return root.scrollTop > before + 2;
        }""")
        await page.wait_for_timeout(250)
        if moved:
            stalled_scrolls = 0
            continue
        stalled_scrolls += 1
        if stalled_scrolls >= 2:
            return
    raise RuntimeError("展开规格次数超过安全上限")


async def _collect_all_price_rows(page) -> list[list[str]]:
    """Read every virtualized table row by scanning the price page from top to bottom."""
    await page.evaluate("""() => {
        const root = document.scrollingElement || document.documentElement;
        root.scrollTop = 0;
        window.dispatchEvent(new Event('scroll'));
    }""")
    await page.wait_for_timeout(400)
    collected: list[list[str]] = []
    seen: set[tuple[str, ...]] = set()
    stalled_scrolls = 0
    for _ in range(800):
        visible_rows = await page.locator("tr").evaluate_all(
            """rows => rows.map(row => Array.from(row.cells).map(cell => {
                const values = Array.from(cell.querySelectorAll(
                    'input[type=text],input[type=number],input:not([type])'
                )).filter(input => input.offsetParent !== null)
                  .map(input => String(input.value || '').trim()).filter(Boolean);
                return [...values, cell.innerText].filter(Boolean).join('\\n');
            }))"""
        )
        for cells in visible_rows:
            clean = [str(cell or "") for cell in cells]
            key = tuple(clean)
            if key and key not in seen:
                seen.add(key)
                collected.append(clean)
        moved = await page.evaluate("""() => {
            const root = document.scrollingElement || document.documentElement;
            const before = root.scrollTop;
            root.scrollTop = Math.min(root.scrollHeight - root.clientHeight,
                before + Math.max(260, Math.round(root.clientHeight * 0.45)));
            window.dispatchEvent(new Event('scroll'));
            return root.scrollTop > before + 2;
        }""")
        await page.wait_for_timeout(250)
        if moved:
            stalled_scrolls = 0
            continue
        stalled_scrolls += 1
        if stalled_scrolls >= 2:
            return collected
    raise RuntimeError("读取活动建议价表次数超过安全上限")


async def _load_all_direct_products(page) -> int:
    """Click a direct activity page's load-more control until all products appear."""
    clicks = 0
    for _ in range(100):
        links = page.get_by_text(re.compile(r"^\s*点击加载更多商品\s*$"))
        visible = None
        for index in range(await links.count()):
            candidate = links.nth(index)
            if await candidate.is_visible():
                visible = candidate
                break
        if visible is None:
            print(f"ACTIVITY_DIRECT_LOAD_MORE_CLICKS={clicks}")
            return clicks
        before_rows = await page.locator("tr").count()
        await visible.scroll_into_view_if_needed()
        await visible.click()
        clicks += 1
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            await page.wait_for_timeout(250)
            if await page.locator("tr").count() > before_rows or not await visible.is_visible():
                break
    raise RuntimeError("直达活动加载更多商品次数超过安全上限")


async def _enter_activity_direct_price(page):
    """Click the activity entry and wait for a price table that needs no ID search."""
    deadline = time.monotonic() + 30
    last_records = []
    while True:
        signup, last_records = await _probe_signup_candidate(page)
        if signup is not None:
            print("ACTIVITY_SIGNUP_PROBE=" + json.dumps(last_records, ensure_ascii=False))
            await signup.click()
            price_page = await _wait_for_price_info_page(page)
            print("ACTIVITY_DIRECT_PRICE=ready url=" + price_page.url)
            return price_page
        if time.monotonic() >= deadline:
            raise RuntimeError("活动详情页未发现精确“立即报名”按钮；候选=" + json.dumps(last_records, ensure_ascii=False))
        await page.wait_for_timeout(500)


async def _wait_for_price_info_page(page, header_pattern=PRICE_PAGE_HEADERS, ready_label="建议价格页"):
    deadline = time.monotonic() + 30
    while True:
        for candidate_page in page.context.pages:
            headers = candidate_page.get_by_text(header_pattern)
            if await headers.count() and await headers.first.is_visible():
                print("ACTIVITY_STEP2=ready url=" + candidate_page.url)
                return candidate_page
        if time.monotonic() >= deadline:
            urls = [candidate_page.url for candidate_page in page.context.pages]
            raise RuntimeError(f"{ready_label}未就绪；标签页=" + json.dumps(urls, ensure_ascii=False))
        await page.wait_for_timeout(250)


async def _wait_for_goods_manage_price_page(page):
    deadline = time.monotonic() + 30
    last_probe = []
    while True:
        last_probe = []
        for candidate_page in page.context.pages:
            try:
                body_text = await candidate_page.locator("body").inner_text(timeout=1000)
            except Exception as exc:
                last_probe.append({
                    "url": candidate_page.url,
                    "error": str(exc).replace("\n", " ")[:200],
                })
                continue
            ready = is_goods_manage_price_page_ready(candidate_page.url, body_text)
            last_probe.append({
                "url": candidate_page.url,
                "potential_signup": "潜力商品报名" in body_text,
                "activity_price": bool(re.search(r"活动价\s*[（(]\s*元\s*[）)]", body_text)),
            })
            if ready:
                print("ACTIVITY_GOODS_MANAGE=ready url=" + candidate_page.url)
                return candidate_page
        if time.monotonic() >= deadline:
            raise RuntimeError(
                "21374 商品管理价格页未就绪；探测="
                + json.dumps(last_probe, ensure_ascii=False)
            )
        await page.wait_for_timeout(250)


async def check_activity_prices(store: str, goods_ids: list[str], activity_id: str, show_browser: bool, open_only: bool = False, enter_only: bool = False) -> dict:
    if not (open_only or enter_only) and (not goods_ids or len(goods_ids) > MAX_GOODS_PER_QUERY):
        raise ValueError(f"每批商品 ID 必须为 1 至 {MAX_GOODS_PER_QUERY} 个")
    stores_path = PROFILE_ROOT / "stores.json"
    stores = json.loads(stores_path.read_text(encoding="utf-8")) if stores_path.exists() else {}
    profile_name = stores.get(store)
    if not profile_name:
        raise RuntimeError(f"店铺「{store}」没有可用登录 profile")
    profile_dir = PROFILE_ROOT / str(profile_name)
    if not profile_dir.exists():
        raise RuntimeError(f"店铺「{store}」profile 目录不存在")

    from pdd_publish import find_chrome
    from playwright.async_api import async_playwright

    chrome = find_chrome()
    if not chrome:
        raise RuntimeError("未找到本机 Chrome")
    detail_url = activity_entry_url(activity_id)
    selection_url = (
        "https://mms.pinduoduo.com/act/choose_goods/v2?"
        f"id={activity_id}&SourceType=PROMO-OwnHome&SceneType=ActivityCard"
    )
    incomplete = None
    ineligible_ids: list[str] = []
    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir), executable_path=chrome,
            headless=not show_browser, viewport=None,
            args=["--start-maximized", "--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
        )
        try:
            page = context.pages[0] if context.pages else await context.new_page()
            await page.goto(selection_url if enter_only else detail_url, wait_until="domcontentloaded", timeout=60000)
            if open_only:
                await page.wait_for_timeout(60000); return {"activity_id": str(activity_id), "store": store, "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"), "products": {}, "probe": True}
            if enter_only:
                await page.get_by_text("可参与活动的商品", exact=True).wait_for(state="visible", timeout=30000)
                print("ACTIVITY_SELECTION=ready url=" + page.url)
                await page.wait_for_timeout(60000)
                return {"activity_id": str(activity_id), "store": store, "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"), "products": {}, "probe": "entered_selection"}
            if str(activity_id) in DIRECT_PRICE_ACTIVITY_IDS:
                if str(activity_id) in DIRECT_PRICE_PAGE_URLS:
                    page = await _wait_for_goods_manage_price_page(page)
                    print("ACTIVITY_DIRECT_PRICE=ready url=" + page.url)
                else:
                    page = await _enter_activity_direct_price(page)
                selected_count = len(goods_ids)
                await _load_all_direct_products(page)
            else:
                page = await _enter_activity_selection(page)
                selected_count = await _open_search_and_select(page, goods_ids)
                page = await _wait_for_price_info_page(page)
            # Intentional hard boundary: this tool reads step 2 only and never
            # accesses the final registration submit control.
            await _expand_all_specs(page)
            rows = await _collect_all_price_rows(page)

            print("ACTIVITY_STEP2_PROBE=" + json.dumps({"url": page.url, "table_rows": len(rows)}, ensure_ascii=False))
            products = build_products(goods_ids, rows)
            received_count = sum(1 for product in products.values() if product["skus"])
            if received_count != selected_count:
                missing_ids = [goods_id for goods_id, product in products.items() if not product["skus"]]
                if str(activity_id) in DIRECT_PRICE_ACTIVITY_IDS:
                    # A direct list contains only items eligible for that activity.
                    ineligible_ids = missing_ids
                    print("ACTIVITY_DIRECT_NOT_ELIGIBLE=" + json.dumps(ineligible_ids, ensure_ascii=False))
                else:
                    raw_rows = {}
                    for cells in rows:
                        row_goods_id = extract_goods_id(cells)
                        if row_goods_id in missing_ids:
                            raw_rows.setdefault(row_goods_id, []).append(cells)
                    probe = {
                        "expected_selected": selected_count, "received": received_count,
                        "missing_ids": missing_ids,
                    }
                    print("ACTIVITY_STEP2_PARTIAL_RESULT=" + json.dumps(products, ensure_ascii=False))
                    print("ACTIVITY_STEP2_INCOMPLETE=" + json.dumps(probe, ensure_ascii=False))
                    print("ACTIVITY_STEP2_MISSING_ROWS=" + json.dumps(raw_rows, ensure_ascii=False))
                    raise RuntimeError("活动建议价页商品不完整：" + json.dumps(probe, ensure_ascii=False))
        finally:
            await context.close()
    return {
        "activity_id": str(activity_id), "store": store,
        "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"), "products": products,
        "incomplete": incomplete, "ineligible_ids": ineligible_ids,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="批量读取 PDD 活动建议价；不提交报名")
    parser.add_argument("--store", required=True)
    parser.add_argument("--goods-ids", default="", help="批量查活动价时的商品 ID；--open-only/--enter-only 时无需提供")
    parser.add_argument("--activity-id", default="21365")
    parser.add_argument("--show-browser", action="store_true")
    parser.add_argument("--open-only", action="store_true", help="仅打开活动页供人工确认浏览器状态")
    parser.add_argument("--enter-only", action="store_true", help="只点击报名活动并停在选品页")
    args = parser.parse_args()
    goods_ids = normalize_goods_ids(args.goods_ids)
    try:
        result = asyncio.run(check_activity_prices(args.store, goods_ids, args.activity_id, args.show_browser, args.open_only, args.enter_only))
        print(RESULT_PREFIX + json.dumps(result, ensure_ascii=False, separators=(",", ":")))
        return 0
    except Exception as exc:
        print(f"活动比价检查失败: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
