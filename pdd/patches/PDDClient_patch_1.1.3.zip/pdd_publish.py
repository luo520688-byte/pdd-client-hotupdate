"""
拼多多机会商品 - 上传图片识别同款并发布
用法：
  python pdd_publish.py --store 元气少女美妆馆 --image D:/path/to/img.jpg
  python pdd_publish.py --store 元气少女美妆馆   (无图片，探查页面结构)
  python pdd_publish.py --list                   (列出已有店铺)
  python pdd_publish.py --new                    (新店铺登录)
"""
import argparse
import asyncio
import hashlib
import json
import re
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding='utf-8')
except (AttributeError, Exception):
    pass  # client.py 无控制台启动时 sys.stdout 是 None,跳过

from playwright.async_api import async_playwright

APP_DIR = Path(__file__).resolve().parent
PROFILE_DIR = APP_DIR / "pdd_profiles"
STORES_JSON  = PROFILE_DIR / "stores.json"   # { display_name: profile_dir_name }
TARGET_URL   = "https://mms.pinduoduo.com/goods/goods_list/chance"

CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    str(Path.home() / "AppData/Local/Google/Chrome/Application/chrome.exe"),
]

PROFILE_DIR.mkdir(exist_ok=True)


# ── 店铺 / profile 管理 ──────────────────────────────────────────────────────

def _load_stores() -> dict:
    if STORES_JSON.exists():
        with open(STORES_JSON, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_stores(stores: dict):
    with open(STORES_JSON, "w", encoding="utf-8") as f:
        json.dump(stores, f, ensure_ascii=False, indent=2)


def _profile_dir_for(display_name: str) -> Path:
    """返回该店铺对应的 ASCII profile 目录（不存在时自动创建并注册）"""
    stores = _load_stores()
    if display_name in stores:
        return PROFILE_DIR / stores[display_name]
    # 新建：用名称 MD5 前8位作目录名（纯 ASCII）
    dir_name = "pdd_" + hashlib.md5(display_name.encode()).hexdigest()[:8]
    stores[display_name] = dir_name
    _save_stores(stores)
    (PROFILE_DIR / dir_name).mkdir(exist_ok=True)
    return PROFILE_DIR / dir_name


def find_chrome() -> str:
    for p in CHROME_PATHS:
        if Path(p).exists():
            return p
    raise FileNotFoundError("未找到本地 Chrome")


def list_stores():
    stores = _load_stores()
    if not stores:
        print("暂无已登录店铺")
        return
    print("已登录店铺：")
    for name, dir_name in stores.items():
        d = PROFILE_DIR / dir_name
        age_h = (time.time() - d.stat().st_mtime) / 3600 if d.exists() else -1
        print(f"  {name}  →  {dir_name}  （{age_h:.0f}小时前使用）")


# ── 页面操作 ─────────────────────────────────────────────────────────────────

async def detect_store_name(page) -> str:
    for sel in [".user-name-name", ".user-name-text", "[class*='mall-name']",
                "[class*='MallName']", ".mall_name"]:
        try:
            el = page.locator(sel).first
            if await el.is_visible(timeout=2000):
                t = (await el.inner_text()).strip()
                if t and len(t) < 50:
                    return t
        except Exception:
            pass
    return ""


async def open_page(context, page, wait_for_login: bool = False) -> bool:
    """打开 PDD 商品列表页。
    wait_for_login=True(--new 扫码登录场景):URL 在登录页时等最多 300s
    wait_for_login=False(批量发布场景):URL 在登录页时立刻返回 False(店铺掉线快速失败)
    """
    await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
    await asyncio.sleep(3)

    is_login = any(k in page.url.lower() for k in ["login", "passport", "sso"])
    if is_login:
        if not wait_for_login:
            # 批量发布场景:店铺 cookies 过期,客户端要立刻知道,不要闷等 300s
            print(f"[!!] 店铺已掉线,需要重新扫码登录  url={page.url[:80]}")
            print("[LOGIN_REQUIRED] 店铺 cookie 过期 → 客户端应提示用户到「店铺管理 → 重新登录」")
            return False
        print("[登录] 请在浏览器中扫码，等待最多 300 秒...")
        for i in range(300):
            await asyncio.sleep(1)
            if not any(k in page.url.lower() for k in ["login", "passport", "sso"]):
                print(f"[OK] 登录成功 ({i+1}s)")
                await asyncio.sleep(3)
                break
            if i % 30 == 29:
                print(f"  等待中... ({i+1}s)")
        else:
            print("[!] 登录超时"); return False

    if "goods_list/chance" not in page.url:
        await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(3)

    print(f"[OK] 已在目标页: {page.url[:80]}")
    return True


async def find_and_click_camera(page):
    """
    点击搜索框右侧的相机按钮（local-image_container），
    等待 input[type=file] 出现，返回该 file input。
    """
    # 精确定位：搜索框 suffix 区域的图片上传容器
    cam_selectors = [
        "[class*='local-image_container']",
        "[class*='localImage']",
        "[class*='imageSearch']",
        "[class*='ImageSearch']",
    ]
    cam_el = None
    for sel in cam_selectors:
        el = await page.query_selector(sel)
        if el:
            box = await el.bounding_box()
            if box and box["width"] > 0:
                cam_el = el
                print(f"[相机] 找到: {sel}  pos=({box['x']:.0f},{box['y']:.0f})")
                break

    if cam_el:
        await cam_el.click()
    else:
        print("[相机] 兜底坐标点击 (784, 88)")
        await page.mouse.click(784, 88)

    await asyncio.sleep(1.5)

    # 弹出「上传图片搜同款」对话框，点击其中的「上传图片」按钮
    upload_btn = None
    for _ in range(6):
        for sel in ["text=上传图片", "[class*='upload'][class*='btn']", "[class*='uploadBtn']"]:
            try:
                el = page.locator(sel).first
                if await el.is_visible(timeout=500):
                    upload_btn = el
                    break
            except Exception:
                pass
        if upload_btn:
            break
        await asyncio.sleep(0.5)

    if upload_btn:
        print("[相机] 点击对话框「上传图片」按钮")
        await upload_btn.click()
        await asyncio.sleep(1)
    else:
        print("[相机] 未检测到上传对话框，直接等待 file input")

    # 等 file input 出现（最多 5 秒）
    for _ in range(10):
        fi = await page.query_selector('input[type="file"]')
        if fi:
            print("[相机] file input 已出现，准备上传")
            return fi
        await asyncio.sleep(0.5)

    await page.screenshot(path="D:/files/pdd_after_click.png", full_page=True)
    print("[!] 未出现 file input，截图: pdd_after_click.png")
    return None


async def click_query_button(page):
    """上传图片后点击弹出面板内缩略图下方的「查询」按钮，返回新打开的 Tab page（无新 Tab 时返回原 page）"""
    await asyncio.sleep(3)
    btn = await page.evaluate("""() => {
        let found = null;
        document.querySelectorAll('*').forEach(el => {
            if (found) return;
            const txt = (el.innerText || '').trim();
            const r = el.getBoundingClientRect();
            if (txt === '查询' && r.width > 0 && r.y > 100)
                found = {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
        });
        return found;
    }""")
    if not btn:
        await page.screenshot(path="D:/files/pdd_after_upload.png", full_page=True)
        print("[!] 未找到弹出面板查询按钮，截图: pdd_after_upload.png")
        return None
    print(f"[查询] 点击弹出面板查询按钮 ({btn['x']},{btn['y']})  等待新 Tab...")
    try:
        async with page.context.expect_event("page", timeout=10000) as new_page_info:
            await page.mouse.click(btn['x'], btn['y'])
        new_page = await new_page_info.value
        await new_page.wait_for_load_state("domcontentloaded", timeout=15000)
        print(f"[查询] 新 Tab 已打开: {new_page.url[:100]}")
        return new_page
    except Exception as e:
        print(f"[!] 未捕获到新 Tab ({e})，使用原 page")
        return page


async def verify_image_search_results(page) -> bool:
    """确认页面已跳转到图片搜索结果页"""
    url = page.url
    url_ok = ("chance_list" in url) and ("imgSearch" in url)
    text_ok = False
    try:
        text_ok = await page.locator("text=根据上传的图片").first.is_visible(timeout=2000)
    except Exception:
        pass
    if url_ok or text_ok:
        print(f"[验证] 已进入图片搜索结果页  url_ok={url_ok} text_ok={text_ok}")
        return True
    print(f"[!] 当前不在图片搜索结果页  url={url[:100]}  text_ok={text_ok}")
    return False


async def upload_and_parse(page, image_path: str) -> list:
    print(f"\n[上传] {image_path}")
    file_inputs = await page.query_selector_all('input[type="file"]')
    if file_inputs:
        print(f"  找到 {len(file_inputs)} 个 file input，直接上传...")
        await file_inputs[0].set_input_files(image_path)
        ok = await click_query_button(page)
        if not ok:
            return []
        print("  等待识别结果...")
        await asyncio.sleep(6)
        return await parse_results(page)
    print("  [!] 未找到 file input")
    return []


async def parse_results(page) -> list:
    await asyncio.sleep(2)
    result = await page.evaluate("""() => {
        const items = [];
        const cards = document.querySelectorAll('[class*="card"],[class*="Card"],[class*="item"],[class*="Item"],[class*="goods"],[class*="Goods"]');
        cards.forEach(card => {
            const txt = card.innerText || '';
            const priceM = txt.match(/¥([\\d.]+)/);
            const heatM  = txt.match(/热度\\s*(\\d+)/);
            if (!priceM || !heatM) return;
            let btnPos = null;
            card.querySelectorAll('button,[role="button"],span,div').forEach(b => {
                if ((b.innerText||'').trim() === '发布同款' && !btnPos) {
                    const br = b.getBoundingClientRect();
                    if (br.width > 0) btnPos = {x: Math.round(br.x+br.width/2), y: Math.round(br.y+br.height/2)};
                }
            });
            // 候选商品主图(卡片内面积最大的 http 图)——给 VLM 同款核对用
            let img = null, imgArea = 0;
            card.querySelectorAll('img').forEach(im => {
                const s = im.currentSrc || im.src || '';
                if (!/^https?:/.test(s)) return;
                const r = im.getBoundingClientRect(); const a = r.width * r.height;
                if (a > imgArea) { imgArea = a; img = s; }
            });
            items.push({
                name: txt.split('\\n')[0].trim().slice(0,60),
                price: parseFloat(priceM[1]),
                heat: parseInt(heatM[1]),
                btnPos,
                img,
            });
        });
        return items;
    }""")
    # 去重：同一商品因嵌套 card 元素会被匹配多次
    seen = set()
    deduped = []
    for item in result:
        key = (round(item['price'], 2), item['name'][:20])
        if key not in seen:
            seen.add(key)
            deduped.append(item)

    print(f"[解析] 共 {len(deduped)} 条（去重前 {len(result)} 条），热度100: {sum(1 for x in deduped if x['heat']==100)} 条")
    for it in sorted(deduped, key=lambda x: -x['price'])[:5]:
        print(f"  ¥{it['price']:8.2f}  热度{it['heat']}  {it['name'][:35]}  btn={it['btnPos']}")
    return deduped


async def dismiss_benign_popups(form_page) -> int:
    """非提交阶段也可能弹「重置规格」「知道了」对话框,这里只处理这种"良性"弹窗,
    不处理「价格预警」(那是致命的,留给 handle_post_submit_popups 处理)。
    返回处理的弹窗数。
    """
    dismissed = 0
    for _ in range(3):
        await asyncio.sleep(0.5)
        try:
            clicked = await form_page.evaluate("""() => {
                const all = document.querySelectorAll('div, span, button');
                for (const el of all) {
                    const t = (el.innerText || '').trim();
                    if (!t || t.length > 50) continue;
                    if (t === '暂不重置' || t === '知道了') {
                        let p = el;
                        for (let i = 0; i < 5 && p; i++) {
                            if (p.tagName === 'BUTTON' || p.tagName === 'A') { p.click(); return t; }
                            p = p.parentElement;
                        }
                        el.click();
                        return t;
                    }
                }
                return null;
            }""")
        except Exception:
            clicked = None
        if not clicked:
            break
        dismissed += 1
        print(f"[弹窗-兜底] 已点「{clicked}」关闭")
    return dismissed


async def detect_form_errors(form_page) -> int:
    """检测 PDD 表单校验错误:① 底部「X个错误项未处理」② 顶部校验toast红字
    (如"属性[净含量]校验错误：50g格式错误，需是数值类型")。返回 >0=有错(智能SKU据此触发重建)。"""
    try:
        n = await form_page.evaluate("""() => {
            const t = document.body.innerText || '';
            const m = t.match(/(\\d+)个错误项未处理/);
            if (m) return parseInt(m[1]);
            // 顶部校验toast(提交被拒但不显示"X个错误项")—— 这类多半是SKU/属性不规范,智能SKU应重建
            if (/校验错误|格式错误|需是数值|需为数值|格式不正确|请填写正确/.test(t)) return 1;
            return 0;
        }""")
        return int(n or 0)
    except Exception:
        return 0


# ── 抓全貌:发布失败时把"为什么失败"完整记录下来(红字错误+截图+上下文)──────────────
# 目的:① 不再笼统"发布失败",看清真实失败分布,数据驱动决定先修哪个;
#       ② 抓到的红字错误文字,就是将来喂大模型出"修复计划"的输入。
async def capture_form_errors(form_page) -> list:
    """读 PDD 表单上所有红字/校验错误文字(如"产品类型不能为空""单买价至少比拼单价高1元")。
    叶子节点 + 红色/错误class/错误关键词 三选一命中即收;去重返回。读不到返回 []。"""
    try:
        return await form_page.evaluate(r"""() => {
            const out = [], seen = new Set();
            const KW = /(不能为空|请选择|请输入|至少|不符合|格式不|格式错误|校验错误|需是|需为|不正确|超过|必填|已存在|不得|需大于|需小于|不能小于|不能大于|不能超过|未处理|无效|重复)/;
            const isRed = (c) => {
                const m = (c||'').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
                if (!m) return false;
                const r=+m[1], g=+m[2], b=+m[3];
                return r > 150 && g < 115 && b < 115;   // 红/橙红系
            };
            for (const el of document.querySelectorAll('span,div,p,label,em,i')) {
                if (el.children && el.children.length > 0) continue;   // 只取叶子,避免父节点重复整段
                const txt = (el.innerText||'').trim();
                if (!txt || txt.length < 2 || txt.length > 60) continue;
                let color=''; try { color = getComputedStyle(el).color; } catch(e){}
                const cls = (el.className||'').toString().toLowerCase();
                if (!(KW.test(txt) || isRed(color) || cls.includes('error') || cls.includes('danger'))) continue;
                if (seen.has(txt)) continue;
                seen.add(txt); out.push(txt);
            }
            return out;
        }""")
    except Exception:
        return []


def _log_publish_failure(stage: str, reason: str, cand, args,
                         error_texts=None, screenshot_path: str = ""):
    """把一条发布失败追加到 data/pdd/publish_failures.json(供分析失败分布 / 将来喂大模型)。"""
    path = APP_DIR / "data" / "pdd" / "publish_failures.json"
    try:
        data = json.load(open(path, encoding="utf-8")) if path.exists() else []
    except Exception:
        data = []
    entry = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "stage": stage,                          # 失败阶段(submit_validation/special_cosmetic/…)
        "reason": reason,                        # 短原因
        "name": (cand.get("name", "") if cand else "") or getattr(args, "name", "") or "",
        "supplier_url": getattr(args, "supplier_url", "") or "",
        "store": getattr(args, "store", "") or "",
        "errors": error_texts or [],             # ★ PDD 红字错误原文(喂大模型用)
        "screenshot": screenshot_path or "",
    }
    data.insert(0, entry)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data[:2000], f, ensure_ascii=False, indent=2)   # 留最近2000条
    except Exception as e:
        print(f"[失败记录] 写 publish_failures.json 失败: {e}", file=sys.stderr)
    print(f"[失败记录] stage={stage} reason={reason} errors={error_texts}", file=sys.stderr)


async def _capture_failure(form_page, stage: str, reason: str, cand, args):
    """抓全貌:读红字错误 + 截图,再落盘。全程 best-effort,不影响发布流程。"""
    errs = []
    try:
        errs = await capture_form_errors(form_page)
    except Exception:
        pass
    shot = ""
    try:
        shot = str(APP_DIR / "data" / "pdd" / "publish_logs" / f"failshot_{time.strftime('%Y%m%d_%H%M%S')}_{stage}.png")
        # full_page=True 截整页:长表单往下滚才看得到的报错也能拍进来(视口只截一屏常看不到真正出错处)。
        # 整页渲染较慢,超时放宽到 15s;失败仍回退不影响发布。
        await asyncio.wait_for(form_page.screenshot(path=shot, full_page=True), timeout=15)
    except Exception:
        shot = ""
    try:
        _log_publish_failure(stage, reason, cand, args, errs, shot)
    except Exception as e:
        print(f"[失败记录] 异常: {e}", file=sys.stderr)


async def handle_post_submit_popups(form_page, max_rounds: int = 5) -> dict:
    """点「提交并上架」后扫描并处理 PDD 拦截弹窗。

    弹窗类型:
    - 价格预警(价差>3倍) → 致命,return ok=False(让主流程跳过此候选)
    - 重置规格 → 点「暂不重置」继续
    - 轮播图描述与发货时间不一致 → 点「确认已删除,继续提交」继续
    - 知道了 → 关闭继续
    无更多匹配弹窗 → ok=True
    """
    for r in range(max_rounds):
        await asyncio.sleep(1.5)
        items = await form_page.evaluate("""() => {
            const out = [];
            const all = document.querySelectorAll('div, span, button');
            for (const el of all) {
                const t = (el.innerText || '').trim();
                if (!t || t.length > 200) continue;
                if (t === '价格预警' || t === '重置规格'
                    || t.includes('48小时发货') || t.includes('轮播图')
                    || t === '知道了' || t === '暂不重置'
                    || t === '确认已删除，继续提交' || t === '确认已删除,继续提交'
                    || t === '修改拼单价' || t === '清空规格重置') {
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0
                        && r.y >= 0 && r.y < window.innerHeight
                        && r.width < 400) {
                        out.push({t: t.slice(0,100),
                            x: Math.round(r.x + r.width/2),
                            y: Math.round(r.y + r.height/2)});
                    }
                }
            }
            return out;
        }""")
        if not items:
            return {"ok": True, "reason": ""}
        # 价格预警是致命的(强行绕过=提交错价)
        if any("价格预警" in i["t"] for i in items):
            print("[弹窗] ❌ 价格预警(规格间价差>3倍) → 放弃此候选")
            return {"ok": False, "reason": "PDD价格预警(规格间价差>3倍)"}
        # 重置规格 → 暂不重置
        handled = False
        for i in items:
            if i["t"] == "暂不重置":
                await form_page.mouse.click(i["x"], i["y"])
                print(f"[弹窗] 重置规格 → 点「暂不重置」({i['x']},{i['y']})")
                handled = True
                break
        if handled:
            continue
        # 轮播图发货不一致 → 确认已删除,继续提交
        for i in items:
            if "确认已删除" in i["t"]:
                await form_page.mouse.click(i["x"], i["y"])
                print(f"[弹窗] 轮播图发货不一致 → 点「确认已删除,继续提交」")
                handled = True
                break
        if handled:
            continue
        # 知道了
        for i in items:
            if i["t"] == "知道了":
                await form_page.mouse.click(i["x"], i["y"])
                print(f"[弹窗] 点「知道了」")
                handled = True
                break
        if handled:
            continue
        # 走到这说明只有 title 类元素(价格预警 标题但已处理 / 修改拼单价 按钮),无可点击操作
        print(f"[弹窗] 仅检测到信息元素但无可操作按钮: {[i['t'] for i in items[:5]]}")
        return {"ok": True, "reason": ""}
    print("[弹窗] 处理轮次用完,强行继续")
    return {"ok": True, "reason": ""}


async def close_publish_dialog(page) -> bool:
    """关闭发布表单的「机会商品发布提示」弹窗（可能连续弹多次）"""
    await asyncio.sleep(2)
    closed_count = 0
    for attempt in range(5):
        # 在 JS 里直接找蓝色「知道了」按钮并点击，避免 locator 匹配错元素
        clicked = await page.evaluate("""() => {
            const btns = document.querySelectorAll('button, [role="button"]');
            for (const b of btns) {
                const txt = (b.innerText || b.textContent || '').trim();
                const r = b.getBoundingClientRect();
                if (txt === '知道了' && r.width > 0 && r.height > 0) {
                    b.click();
                    return {x: Math.round(r.x), y: Math.round(r.y)};
                }
            }
            return null;
        }""")
        if clicked:
            closed_count += 1
            print(f"[表单] 已点击「知道了」按钮 ({clicked['x']},{clicked['y']})  第{closed_count}次")
            await asyncio.sleep(1.5)
        else:
            break
    if closed_count == 0:
        print("[表单] 未发现「知道了」按钮弹窗")
    else:
        print(f"[表单] 共关闭 {closed_count} 个弹窗")
    return closed_count > 0


async def locate_special_cosmetic_field(page):
    """滚动整页定位「是否特殊用途化妆品」字段，匹配关键字「特殊用途化妆品」"""
    await asyncio.sleep(2)
    # 先把整页滚一遍，触发懒加载
    page_height = await page.evaluate("() => document.body.scrollHeight")
    print(f"[属性] 页面总高度: {page_height}px, 滚动加载...")
    step = 600
    y = 0
    while y < page_height:
        await page.evaluate(f"window.scrollTo(0, {y})")
        await asyncio.sleep(0.3)
        y += step
    await page.evaluate("window.scrollTo(0, 0)")
    await asyncio.sleep(1)

    # 用 JS 找包含「特殊用途化妆品」的元素（用直接子文本节点排除父级嵌套命中）
    info = await page.evaluate("""() => {
        const matches = [];
        document.querySelectorAll('*').forEach(el => {
            const direct = Array.from(el.childNodes)
                .filter(n => n.nodeType === 3)
                .map(n => n.textContent)
                .join('');
            if (direct.includes('特殊用途化妆品')) {
                const r = el.getBoundingClientRect();
                matches.push({
                    tag: el.tagName,
                    cls: (el.className || '').slice(0,60),
                    text: direct.trim().slice(0, 80),
                    x: Math.round(r.x), y: Math.round(r.y),
                    w: Math.round(r.width), h: Math.round(r.height),
                });
            }
        });
        return matches;
    }""")
    print(f"[属性] 包含「特殊用途化妆品」的元素共 {len(info)} 个")
    for m in info[:8]:
        print(f"  {m['tag']}  位置=({m['x']},{m['y']}) {m['w']}x{m['h']}  text={m['text']!r}")

    if info:
        # 滚到第一个匹配处
        await page.evaluate(f"""() => {{
            const all = document.querySelectorAll('*');
            for (const el of all) {{
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('');
                if (direct.includes('特殊用途化妆品')) {{ el.scrollIntoView({{block:'center'}}); break; }}
            }}
        }}""")
        await asyncio.sleep(1.5)

    await page.screenshot(path="D:/files/pdd_special_cosmetic.png", full_page=True)
    print("[属性] 截图: pdd_special_cosmetic.png")
    return info[0] if info else None


async def click_publish(page, target: dict):
    """点击目标商品的「发布同款」按钮,返回新打开的发布表单 Tab。

    Race 防护:PDD 网页有时反应慢,新 tab 在 expect_event 超时后才弹出 →
    程序判失败 → 外层 loop 点下一个候选 → 两个 tab 同时弹出导致页面错乱。
    修复:超时后多等 3s,扫 context.pages 找新增的 goods_add tab 兜底使用。
    额外兜底:若坐标点击没有触发新页,再在原坐标附近定位「发布同款」元素执行 DOM click。
    """
    if not target or not target.get('btnPos'):
        print("[!] 未找到发布按钮坐标"); return None
    bx, by = target['btnPos']['x'], target['btnPos']['y']
    form_page = None

    async def _find_goods_add_page(pages_before=None):
        pages_before = pages_before or set()
        # 优先新增页,再扫全部页;兼容 PDD 偶尔同页跳转。
        ordered = [p for p in page.context.pages if id(p) not in pages_before]
        ordered += [p for p in page.context.pages if id(p) in pages_before]
        for p in ordered:
            try:
                if "goods_add" in (p.url or ""):
                    return p
            except Exception:
                pass
        try:
            if "goods_add" in (page.url or ""):
                return page
        except Exception:
            pass
        return None

    async def _click_and_wait(label, click_coro_factory):
        pages_before = set(id(p) for p in page.context.pages)
        try:
            async with page.context.expect_event("page", timeout=15000) as page_info:
                await click_coro_factory()
            p = await page_info.value
            return p, pages_before
        except Exception as e:
            print(f"[!] {label} 未捕获到新 Tab: {e}")
            await asyncio.sleep(3)
            p = await _find_goods_add_page(pages_before)
            new_pages = [x for x in page.context.pages if id(x) not in pages_before]
            print(f"[发布] {label}超时兜底扫描:新增 tab {len(new_pages)} 个")
            if p:
                print(f"[发布] {label}兜底命中 goods_add: {p.url[:80]}")
                return p, pages_before
            for x in new_pages:
                try:
                    await x.close()
                except Exception:
                    pass
            return None, pages_before

    async def _mouse_click():
        await page.mouse.click(bx, by)
        print(f"[发布] 已点击发布同款 ({bx},{by})")

    form_page, _pages_before = await _click_and_wait("坐标点击", _mouse_click)

    if not form_page:
        async def _dom_click_nearby():
            hit = await page.evaluate("""({x,y}) => {
                const visible = el => {
                    const r = el.getBoundingClientRect();
                    return r.width > 0 && r.height > 0 && r.bottom >= 0 && r.top <= window.innerHeight;
                };
                const candidates = [...document.querySelectorAll('button,[role="button"],span,div,a')]
                    .filter(el => (el.innerText || '').trim() === '发布同款' && visible(el))
                    .map(el => {
                        const r = el.getBoundingClientRect();
                        const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
                        return {el, x: Math.round(cx), y: Math.round(cy), d: Math.hypot(cx - x, cy - y)};
                    })
                    .sort((a,b) => a.d - b.d);
                const hit = candidates[0];
                if (!hit || hit.d > 260) return null;
                hit.el.scrollIntoView({block:'center', inline:'center'});
                hit.el.click();
                return {x: hit.x, y: hit.y, d: Math.round(hit.d)};
            }""", {"x": bx, "y": by})
            if hit:
                print(f"[发布] DOM兜底点击「发布同款」({hit['x']},{hit['y']}) dist={hit['d']}")
            else:
                print("[发布][!] DOM兜底未找到附近「发布同款」按钮")
        form_page, _ = await _click_and_wait("DOM兜底点击", _dom_click_nearby)

    if not form_page:
        return None

    # 正常流程(无论是 event 路径还是兜底路径,form_page 都已确定)
    try:
        await form_page.wait_for_load_state("domcontentloaded", timeout=15000)
    except Exception:
        pass
    await asyncio.sleep(3)
    if "goods_add" in (form_page.url or ""):
        print("[OK] 已进入发布表单页")
    else:
        print(f"[!] URL 不含 goods_add: {form_page.url[:120]}")
    await close_publish_dialog(form_page)
    await form_page.screenshot(path="D:/files/pdd_publish_form.png", full_page=True)
    print(f"[发布] 发布表单截图: pdd_publish_form.png")
    await locate_special_cosmetic_field(form_page)
    return form_page

async def _find_input_right_of_label(form_page, label_text: str, kind: str = "input"):
    """找到指定 label 右侧 200px、同一水平线上的输入框/下拉。
    kind='input' 找 input，'any' 找任意可点击的输入控件（包括 PDD 自定义下拉）
    """
    return await form_page.evaluate(f"""() => {{
        // 先找精确匹配 label_text 的元素（直接子文本节点）
        let label = null;
        for (const el of document.querySelectorAll('label, span, div')) {{
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n => n.textContent).join('').trim();
            if (direct === {label_text!r}) {{
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0) {{ label = el; break; }}
            }}
        }}
        if (!label) return null;
        label.scrollIntoView({{block: 'center'}});
        const lr = label.getBoundingClientRect();
        const labelCenterY = lr.y + lr.height / 2;
        const labelRight = lr.x + lr.width;
        // 遍历所有候选，挑同水平线（y 中心相差 < 20）、x 在 label 右侧 < 350px 的最近一个
        const candidates = document.querySelectorAll(
            {'input:not([readonly]):not([type=hidden])' if kind == 'input' else '[class*="select"], [class*="Select"], input, [class*="dropdown"]'!r}
        );
        let best = null, bestDist = Infinity;
        for (const c of candidates) {{
            const r = c.getBoundingClientRect();
            if (r.width < 30 || r.height < 10) continue;
            const cy = r.y + r.height / 2;
            const dy = Math.abs(cy - labelCenterY);
            const dx = r.x - labelRight;
            if (dy < 25 && dx > -10 && dx < 350 && dx < bestDist) {{
                best = c; bestDist = dx;
            }}
        }}
        if (!best) return null;
        const br = best.getBoundingClientRect();
        return {{x: Math.round(br.x + br.width/2), y: Math.round(br.y + br.height/2), tag: best.tagName, cls: (best.className||'').slice(0,80)}};
    }}""")




async def fill_special_cosmetic(form_page, is_special: str, license_no: str) -> bool:
    """填写「是否为特殊用途化妆品」下拉 + 「化妆品批准文号」输入框。
    返回 True 表示页面展示的关键字段已处理;字段未展示时跳过,不阻断后续发布。
    """
    if not is_special and not license_no:
        print("[填表] 无供应商数据可填(scrape 没抓到)")
        return False

    special_ok = True  # 单字段成功标记

    # ── 1) 「是否为特殊用途化妆品」下拉(元素捕捉 + 面板内找选项,不靠坐标) ──
    #   依据真实弹层 DOM(dropdown_dump 实测):选项是面板 UL.ST_dropdownPanel 内的普通 div,
    #   文字「否/是」、高≈18、宽≈487。旧逻辑 width<400 把这宽选项误滤掉 →"弹层未出现"。
    #   故:① 控件用元素捕捉点开;② 选项在下拉面板内按 文字精确+高<60+可见 找,不限宽度。
    if is_special in ("是", "否"):
        print(f"[填表] 设置「是否为特殊用途化妆品」= {is_special}")
        special_ok = False
        opened = False
        trigger = await form_page.evaluate_handle("""() => {
            const want='是否为特殊用途化妆品';
            let label=null;
            for (const el of document.querySelectorAll('label,span,div')) {
                const d=Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (d===want || d==='*'+want) { const r=el.getBoundingClientRect(); if(r.width>0&&r.height>0){label=el;break;} }
            }
            if(!label) return null;
            let node=label;
            for(let i=0;i<6&&node;i++){
                const cs=node.querySelectorAll('[class*="select"],[class*="Select"],[class*="dropdown"],[class*="Dropdown"]');
                for(const c of cs){const r=c.getBoundingClientRect(); if(r.width>40&&r.height>10) return c;}
                node=node.parentElement;
            }
            return null;
        }""")
        tel = trigger.as_element() if trigger else None
        if tel:
            try: await tel.scroll_into_view_if_needed(timeout=3000)
            except Exception: pass
            try:
                await tel.click(timeout=5000); opened = True
            except Exception:
                try: await tel.evaluate("e=>e.click()"); opened = True
                except Exception as e: print(f"[!] 下拉控件点击失败: {e}")
            if opened:
                print("[填表] 已捕捉并点开「是否为特殊用途化妆品」下拉")
        else:
            # 兜底:老坐标法(单列布局仍可用)
            dd = await _find_input_right_of_label(form_page, "是否为特殊用途化妆品", kind="any")
            if dd:
                print(f"[填表] (兜底)按位置找到下拉框 pos=({dd['x']},{dd['y']})")
                await asyncio.sleep(0.4)
                await form_page.mouse.click(dd['x'], dd['y'])
                opened = True
            else:
                print("[填表] 当前类目无「是否为特殊用途化妆品」字段,跳过")
                special_ok = True
        if opened:
            await asyncio.sleep(1.2)
            # 在下拉面板内找 文字精确等于 是/否 的选项(普通 div,无 class),不限宽度
            opt = await form_page.evaluate_handle("""(want) => {
                const panels = document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"],[class*="portalMain"],[class*="ST_dropdown"]');
                const scopes = panels.length ? Array.from(panels) : [document];
                for (const sc of scopes) {
                    for (const o of sc.querySelectorAll('div,li,span')) {
                        const d=Array.from(o.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
                        if (d===want) {
                            const r=o.getBoundingClientRect();
                            if (r.width>0 && r.height>0 && r.height<60 && r.top>=0 && r.top<window.innerHeight) return o;
                        }
                    }
                }
                return null;
            }""", is_special)
            oel = opt.as_element() if opt else None
            if oel:
                try: await oel.click(timeout=5000)
                except Exception:
                    try: await oel.evaluate("e=>e.click()")
                    except Exception: pass
                await asyncio.sleep(0.8)
                special_ok = True
                # 读回(仅记录):控件显示值应已变成所选
                try: txt=(await tel.inner_text()).strip() if tel else ""
                except Exception: txt=""
                print(f"[填表] 已选「{is_special}」(面板内捕捉点击,读回='{txt[:20]}')")
            else:
                print(f"[!] 下拉面板内未找到选项「{is_special}」 → 下拉填写失败")

    # ── 2) 批准文号输入框 ──
    if license_no:
        print(f"[填表] 填批准文号: {license_no}")
        inp = await _find_input_right_of_label(form_page, "化妆品批准文号", kind="input")
        if inp:
            print(f"[填表] 找到输入框 {inp['tag']} pos=({inp['x']},{inp['y']}) class={inp['cls']!r}")
            await form_page.mouse.click(inp['x'], inp['y'])
            await asyncio.sleep(0.3)
            await form_page.keyboard.type(license_no, delay=30)
            print(f"[填表] 已填入批准文号")
            await form_page.keyboard.press("Enter")
            await form_page.evaluate("""() => {
                const el = document.activeElement;
                if (!el) return false;
                try {
                    el.dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', code: 'Enter', bubbles: true, cancelable: true}));
                    el.dispatchEvent(new KeyboardEvent('keyup', {key: 'Enter', code: 'Enter', bubbles: true, cancelable: true}));
                    el.dispatchEvent(new Event('change', {bubbles: true}));
                    el.blur();
                    return true;
                } catch (e) {
                    return false;
                }
            }""")
            print("[填表] 批准文号输入后已 Enter + change + blur，等待页面刷新属性状态...")
            await asyncio.sleep(2.5)
        else:
            print("[!] 未找到「化妆品批准文号」输入框")

    # ── 3) 字号类型 ── 已挪到独立函数 fill_font_type()(无条件调用),原因:牙膏/日化等非化妆品也必填
    #    「字号类型」,藏在本函数里对非化妆品不跑会漏填(实测牙膏报"字号类型不能为空"上不了架);
    #    且规则改为"有『其他』选其他、否则按品判定",不再写死「妆字号」。

    await form_page.screenshot(path="D:/files/pdd_form_filled.png", full_page=True)
    print("[填表] 填写后截图: pdd_form_filled.png")
    # 关键字段填写状态:只要"是否特殊化妆品"在该填时填上了即视为可继续提交
    return special_ok


def _ask_ollama_pick(title: str, options: list):
    """调本地 Ollama(7B),从 options 里挑最符合 title 的一项。返回选项原文或 None。"""
    import urllib.request as _u
    try:
        from spec_units import _OLLAMA_URL, _OLLAMA_MODEL, _OLLAMA_TIMEOUT
    except Exception:
        _OLLAMA_URL = "http://localhost:11434/api/chat"
        _OLLAMA_MODEL = "qwen2.5:7b"; _OLLAMA_TIMEOUT = 30
    try:
        sys_p = ("你是电商上架助手。下面给你一个商品标题和若干「产品类型」选项,"
                 "选出最符合该商品的一个选项。只输出选项原文,不要解释、不要标点。")
        usr = f"商品标题:{title}\n选项:{' / '.join(options)}\n最符合的选项="
        body = json.dumps({
            "model": _OLLAMA_MODEL,
            "messages": [{"role": "system", "content": sys_p},
                         {"role": "user", "content": usr}],
            "stream": False, "options": {"temperature": 0},
        }).encode()
        req = _u.Request(_OLLAMA_URL, data=body, headers={"Content-Type": "application/json"})
        resp = json.load(_u.urlopen(req, timeout=_OLLAMA_TIMEOUT))
        text = ((resp.get("message", {}) or {}).get("content", "") or "").strip()
        if not text:
            return None
        for o in options:          # 先精确等于
            if o == text:
                return o
        for o in options:          # 再包含
            if o and o in text:
                return o
        return None
    except Exception:
        return None


def _pick_product_type(title: str, options: list):
    """从 options 里挑最符合 title 的产品类型(混合策略,2026-06-16 调整)。返回 (选中文字, 来源)。
    来源 ∈ {'keyword'(唯一命中,权威), 'deepseek'(云端判), 'llm'(本地7B兜底), 'uncertain', 'none'}。
    - 只有**恰好一个**选项是标题子串 → 关键词(确定、免费、零幻觉)。
    - 0个或多个命中(歧义,如"洗发皂液洗发水"同时含洗发皂/洗发水)→ 云端DeepSeek 判(强模型)。
    - 云端不可用 → 本地7B → 都不行选第一项存疑。
    旧版"有命中就 max(len)"对多命中是瞎 tie-break,且兜底用弱7B,故改(用户拍板)。"""
    title = (title or "").strip()
    opts = [o.strip() for o in (options or []) if o and o.strip()]
    if not opts:
        return "", "none"
    # ① 关键词:标题里出现的选项。**只有恰好命中一个才算权威**
    hit = [o for o in opts if o in title]
    if len(hit) == 1:
        return hit[0], "keyword"
    # ② 0个或多个命中(歧义) → 云端 DeepSeek(复用智能SKU 那套 key;强模型,已不再用本地7B兜底)
    try:
        import smart_sku
        pick = smart_sku.cloud_pick(title, opts, what="产品类型")
        if pick:
            return pick, "deepseek"
    except Exception as e:
        print(f"[产品类型] 云端选型失败: {e}")
    # ③ 云端没定/不可用 → 选第一项 + 标记存疑(宁可上架后改,不卡整批;不再依赖本地 Ollama)
    return opts[0], "uncertain"


async def fill_product_type(form_page, title: str) -> str:
    """部分类目必填「产品类型」(请选择):检测到就按商品标题智能选一项;没有该字段则跳过。
    返回 'skipped'/'keyword'/'llm'/'uncertain'/'failed'。存疑时写 globals()['_PRODUCT_TYPE_UNCERTAIN']。"""
    dd = await _find_input_right_of_label(form_page, "产品类型", kind="any")
    if not dd:
        print("[填表] 当前类目无「产品类型」字段,跳过")
        return "skipped"
    print(f"[产品类型] 检测到字段 pos=({dd['x']},{dd['y']}),打开下拉读选项…")
    await asyncio.sleep(0.4)
    await form_page.mouse.click(dd['x'], dd['y'])
    await asyncio.sleep(1.5)
    # 读选项:**只在刚弹出的下拉浮层里读**(锚定 dropdownPanel/dropdownMain,取离字段最近的那个),
    # 排除底部「没有合适属性值?点击反馈」行。class 后缀(_5-188-0)随版本变,用子串匹配(§9.9)。
    # ⚠ 旧版用 [class*=item],li 扫全文档,把页面顶部导航/菜单项当选项 → 洗护类红字"产品类型不能为空"
    #   (2026-06-16 真实页面 dump 确认:真实选项在 UL.ST_dropdownPanel 里的 LI.ST_itemRendererLabel)。
    options = await form_page.evaluate("""(dd) => {
        const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"]')]
          .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
        if(!ps.length) return [];
        ps.sort((a,b)=>{const ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
          return (Math.abs(ra.top-dd.y)+Math.abs(ra.left-dd.x))-(Math.abs(rb.top-dd.y)+Math.abs(rb.left-dd.x));});
        const out=[];
        for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"]')){
          const t=(it.innerText||'').trim();
          if(!t||t.length>20) continue;
          if(/没有合适|点击反馈|反馈/.test(t)) continue;
          out.push(t);
        }
        return [...new Set(out)];
    }""", {"x": dd['x'], "y": dd['y']})
    options = [o for o in (options or []) if o]
    if not options:
        print("[产品类型][!] 下拉未读到选项 → 可能字段结构变化,需人工")
        return "failed"
    print(f"[产品类型] 选项: {options}")
    chosen, src = _pick_product_type(title, options)
    if not chosen:
        print("[产品类型][!] 没选出 → 跳过")
        return "failed"
    print(f"[产品类型] 标题={title[:30]!r} → 选「{chosen}」(来源={src})")
    opt_pos = await form_page.evaluate("""(a) => {
        const {want, dd}=a;
        const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"]')]
          .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
        if(!ps.length) return null;
        ps.sort((x,y)=>{const ra=x.getBoundingClientRect(),rb=y.getBoundingClientRect();
          return (Math.abs(ra.top-dd.y)+Math.abs(ra.left-dd.x))-(Math.abs(rb.top-dd.y)+Math.abs(rb.left-dd.x));});
        for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"]')){
          if((it.innerText||'').trim()===want){
            const r=it.getBoundingClientRect();
            if(r.width>0&&r.height>0) return {x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};
          }
        }
        return null;
    }""", {"want": chosen, "dd": {"x": dd['x'], "y": dd['y']}})
    if not opt_pos:
        print(f"[产品类型][!] 找不到选项「{chosen}」的点击位置 → 未选,可能发布失败")
        return "failed"
    await form_page.mouse.click(opt_pos['x'], opt_pos['y'])
    await asyncio.sleep(0.8)
    print(f"[产品类型] 已选「{chosen}」({opt_pos['x']},{opt_pos['y']})")
    if src == "uncertain":
        globals()['_PRODUCT_TYPE_UNCERTAIN'] = {"title": title[:40], "options": options, "picked": chosen}
        print("[产品类型][存疑] 标题没匹配上、7B也没定 → 选了第一项,已标记存疑留人工复核")
    return src


async def fix_net_content(form_page) -> int:
    """净含量属性值被发布同款复制成"100g/50mL"(数字+单位粘在一起)→ PDD 报
    「属性[净含量]校验错误:100g格式错误,需是数值类型」拒提交(handoff §14.8)。
    修法:把值框改成纯数字(100),单位交给右侧下拉选(best-effort)。返回修了几个;
    无该问题返回 0;全程 best-effort,异常不抛、不挡发布。"""
    try:
        info = await form_page.evaluate(r"""() => {
            const UNIT=/^\s*(\d+(?:\.\d+)?)\s*(g|mg|kg|ml|mL|ML|l|L|片|G|KG|MG)\s*$/;
            const out=[];
            const all=[...document.querySelectorAll('input')];
            all.forEach((inp,i)=>{
                const v=(inp.value||'').trim();
                const m=v.match(UNIT);
                if(!m) return;
                const r=inp.getBoundingClientRect();
                if(r.width<=0||r.height<=0) return;
                // 诊断:把值框所在容器的结构 dump 一段(确认单位下拉怎么选)
                let html='';
                try{ let n=inp; for(let k=0;k<4;k++){ if(n.parentElement) n=n.parentElement; } html=n.outerHTML.slice(0,1600); }catch(e){}
                out.push({idx:i, value:v, num:m[1], unit:m[2],
                          x:Math.round(r.x+r.width/2), y:Math.round(r.y+r.height/2),
                          right:Math.round(r.x+r.width), cy:Math.round(r.y+r.height/2), html});
            });
            return out;
        }""")
        targets = info or []
        if not targets:
            return 0
        print(f"[净含量] 检出 {len(targets)} 个'数字+单位'值框: {[t['value'] for t in targets]}")
        for t in targets:    # 诊断 dump,确认单位下拉控件结构
            print(f"[净含量][dump] {t['value']} 容器: {t.get('html','')[:300]}")
        setter_js = """(a)=>{
            const inp=document.querySelectorAll('input')[a.idx];
            if(!inp) return false;
            const set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
            set.call(inp, a.num);
            inp.dispatchEvent(new Event('input',{bubbles:true}));
            inp.dispatchEvent(new Event('change',{bubbles:true}));
            return true;
        }"""
        fixed = 0
        for t in targets:
            ok = await form_page.evaluate(setter_js, {"idx": t["idx"], "num": t["num"]})
            if not ok:
                continue
            fixed += 1
            print(f"[净含量] {t['value']} → 值改纯数字 {t['num']}(单位 {t['unit']})")
            # best-effort 选单位:点值框右侧紧邻的下拉(约 input 右边 +25px),用 dropdownPanel 选项匹配
            try:
                await form_page.mouse.click(t["right"] + 25, t["cy"])
                await asyncio.sleep(0.9)
                # 诊断:点单位区后,把页面上"看着像下拉/选项列表"的可见元素 dump 出来(确认单位控件)
                try:
                    _dbg = await form_page.evaluate(r"""()=>{
                        const out=[];
                        for(const p of document.querySelectorAll('[class*="dropdown"],[class*="Select"],[class*="option"],[class*="Option"],[role="listbox"],[role="option"],ul,li')){
                            const r=p.getBoundingClientRect();
                            if(r.width<=0||r.height<=0||r.top<0||r.top>900) continue;
                            const t=(p.innerText||'').replace(/\s+/g,' ').trim();
                            if(!t||t.length>40) continue;
                            if(/^(g|mg|kg|ml|mL|L|片)$/i.test(t) || /g.{0,3}mL/i.test(t))
                                out.push({cls:(p.className||'').toString().slice(0,70), txt:t});
                        }
                        return out.slice(0,12);
                    }""")
                    print(f"[净含量][dump-panel] 点单位后疑似下拉/选项: {_dbg}")
                except Exception:
                    pass
                pos = await form_page.evaluate(r"""(a)=>{
                    const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"],[class*="optionList"],[class*="ST_dropdown"]')]
                      .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
                    if(!ps.length) return null;
                    ps.sort((x,y)=>{const ra=x.getBoundingClientRect(),rb=y.getBoundingClientRect();
                      return (Math.abs(ra.top-a.cy)+Math.abs(ra.left-a.right))-(Math.abs(rb.top-a.cy)+Math.abs(rb.left-a.right));});
                    for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"],[role="option"]')){
                        if((it.innerText||'').trim()===a.unit){
                            const r=it.getBoundingClientRect();
                            if(r.width>0&&r.height>0) return {x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};
                        }
                    }
                    return null;
                }""", {"unit": t["unit"], "right": t["right"], "cy": t["cy"]})
                if pos:
                    await form_page.mouse.click(pos["x"], pos["y"])
                    await asyncio.sleep(0.4)
                    print(f"[净含量] 已在下拉选单位「{t['unit']}」({pos['x']},{pos['y']})")
                else:
                    print(f"[净含量][!] 没在下拉里找到单位「{t['unit']}」选项(看上面 dump 调整选择器);先靠值数字试提交")
            except Exception as _ue:
                print(f"[净含量][!] 选单位异常(跳过): {_ue}")
        return fixed
    except Exception as e:
        print(f"[净含量][!] 修复异常(跳过,不挡发布): {e}")
        return 0


async def fill_font_type(form_page, title: str) -> str:
    """部分类目必填「字号类型」(请选择:其他/妆字号/消字号/育字号 等)。规则(用户定):
    有「其他」选项 → 选「其他」;没有「其他」→ 按商品标题云端判定;再不行回落。无该字段则跳过。
    ★牙膏/日化等非化妆品也必填它(不填报「字号类型不能为空」上不了架),故独立、无条件调用。"""
    dd = await _find_input_right_of_label(form_page, "字号类型", kind="any")
    if not dd:
        print("[填表] 当前类目无「字号类型」字段,跳过")
        return "skipped"
    print(f"[字号类型] 检测到字段 pos=({dd['x']},{dd['y']}),打开下拉读选项…")
    await asyncio.sleep(0.4)
    await form_page.mouse.click(dd['x'], dd['y'])
    await asyncio.sleep(1.5)
    # 锚定刚弹出的下拉浮层读选项(同 fill_product_type,§13.H 验证过,排除"点击反馈"行)
    options = await form_page.evaluate("""(dd) => {
        const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"]')]
          .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
        if(!ps.length) return [];
        ps.sort((a,b)=>{const ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
          return (Math.abs(ra.top-dd.y)+Math.abs(ra.left-dd.x))-(Math.abs(rb.top-dd.y)+Math.abs(rb.left-dd.x));});
        const out=[];
        for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"]')){
          const t=(it.innerText||'').trim();
          if(!t||t.length>20) continue;
          if(/没有合适|点击反馈|反馈/.test(t)) continue;
          out.push(t);
        }
        return [...new Set(out)];
    }""", {"x": dd['x'], "y": dd['y']})
    options = [o for o in (options or []) if o]
    if not options:
        print("[字号类型][!] 下拉未读到选项 → 需人工")
        return "failed"
    print(f"[字号类型] 选项: {options}")
    # ★规则:有「其他」选「其他」;否则按商品云端判定;再不行回落
    if "其他" in options:
        chosen, src = "其他", "其他"
    else:
        chosen, src = "", ""
        try:
            import smart_sku
            chosen = smart_sku.cloud_pick(title, options, what="字号类型") or ""
            src = "deepseek"
        except Exception as e:
            print(f"[字号类型] 云端选型失败: {e}")
        if not chosen:
            chosen = "妆字号" if "妆字号" in options else options[0]
            src = "fallback"
    print(f"[字号类型] 标题={title[:30]!r} → 选「{chosen}」(来源={src})")
    opt_pos = await form_page.evaluate("""(a) => {
        const {want, dd}=a;
        const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"]')]
          .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
        if(!ps.length) return null;
        ps.sort((x,y)=>{const ra=x.getBoundingClientRect(),rb=y.getBoundingClientRect();
          return (Math.abs(ra.top-dd.y)+Math.abs(ra.left-dd.x))-(Math.abs(rb.top-dd.y)+Math.abs(rb.left-dd.x));});
        for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"]')){
          if((it.innerText||'').trim()===want){
            const r=it.getBoundingClientRect();
            if(r.width>0&&r.height>0) return {x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};
          }
        }
        return null;
    }""", {"want": chosen, "dd": {"x": dd['x'], "y": dd['y']}})
    if not opt_pos:
        print(f"[字号类型][!] 找不到选项「{chosen}」点击位置 → 未选,可能失败")
        return "failed"
    await form_page.mouse.click(opt_pos['x'], opt_pos['y'])
    await asyncio.sleep(0.8)
    print(f"[字号类型] 已选「{chosen}」({opt_pos['x']},{opt_pos['y']})")
    return src


async def scrape_spec_values(form_page) -> list:
    """抓取「颜色」(或类似规格名)下的所有规格值文字。
    通常这些是 input 元素，value 形如 '真我盈润焕能香体乳500ml*1瓶'
    """
    print("\n[规格] 抓取商品规格值...")
    # 先滚动一下确保规格区已加载
    await form_page.evaluate("""async () => {
        for (let y = 0; y < document.body.scrollHeight; y += 600) {
            window.scrollTo(0, y);
            await new Promise(r => setTimeout(r, 200));
        }
    }""")
    await asyncio.sleep(1)

    # 先滚到「商品规格」区，再抓取该区域内所有非空 input 的 value
    spec_anchor = await form_page.evaluate("""() => {
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品规格') {
                el.scrollIntoView({block: 'start'});
                const r = el.getBoundingClientRect();
                return {x: Math.round(r.x), y: Math.round(r.y)};
            }
        }
        return null;
    }""")
    if not spec_anchor:
        print("[!] 未找到「商品规格」锚点")
        return []
    print(f"[规格] 找到「商品规格」锚点 ({spec_anchor['x']},{spec_anchor['y']})")
    await asyncio.sleep(1)
    # 在「商品规格」label 之下、上方 1000px 范围内，找带值的 input
    raw = await form_page.evaluate("""() => {
        let anchor = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品规格') { anchor = el; break; }
        }
        if (!anchor) return [];
        const ar = anchor.getBoundingClientRect();
        const out = [];
        document.querySelectorAll('input').forEach(inp => {
            if (inp.type && inp.type !== 'text') return;
            const v = (inp.value || '').trim();
            if (!v || v.length < 3) return;
            const r = inp.getBoundingClientRect();
            // 仅在锚点右侧、下方 800px 内
            if (r.y < ar.y - 20 || r.y > ar.y + 800) return;
            if (r.width < 50) return;
            out.push({v, x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width)});
        });
        return out;
    }""")
    specs = {'anchor': True, 'values': raw}
    print(f"[规格] 共抓到 {len(specs['values'])} 个规格值:")
    for i, item in enumerate(specs['values'], 1):
        print(f"  {i}. ({item['x']},{item['y']}) {item['v']}")
    await form_page.screenshot(path="D:/files/pdd_specs.png", full_page=True)
    print("[规格] 截图: pdd_specs.png")
    return specs['values']


def _is_sellable_spec_value(value: str) -> bool:
    """Return whether a scraped spec value should have a price/inventory row."""
    s = (value or "").strip()
    if not s:
        return False
    noise_exact = {
        "全部", "全部规格", "全部色号", "全部颜色", "全色号", "全套色号",
        "请选择", "默认", "无",
    }
    if s in noise_exact:
        return False
    return True


def _expected_sellable_spec_count(spec_values) -> int:
    """Count unique sellable spec values from scrape_spec_values output."""
    seen = set()
    for item in spec_values or []:
        if isinstance(item, dict):
            val = item.get("v") or item.get("value") or ""
        else:
            val = str(item or "")
        val = val.strip()
        if not _is_sellable_spec_value(val):
            continue
        if val in seen:
            continue
        seen.add(val)
    return len(seen)


def _sku_row_count_risk(spec_values, price_rows: int) -> tuple[bool, int, int]:
    """Detect when the price table missed sellable SKU rows."""
    expected = _expected_sellable_spec_count(spec_values)
    actual = int(price_rows or 0)
    return bool(expected and actual and actual < expected), expected, actual


async def zero_out_stock(form_page) -> int:
    """把「价格及库存」表里所有库存列的值改成 0。
    定位策略：库存列在「商品规格」锚点下方 200-1000px，x 约 280-380，value 是纯整数。
    """
    print("\n[库存归零] 把所有库存改成 0")
    target_indices = await form_page.evaluate("""() => {
        let anchor = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品规格') { anchor = el; break; }
        }
        if (!anchor) return [];
        const ar = anchor.getBoundingClientRect();
        const out = [];
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const v = (inp.value || '').trim();
            if (!v) return;
            // 库存：纯整数（不含小数点）
            if (!/^\\d+$/.test(v)) return;
            const r = inp.getBoundingClientRect();
            // 在锚点下方 200-1200px 范围内，x 在库存列 280-400
            if (r.y < ar.y + 200 || r.y > ar.y + 1200) return;
            if (r.x < 280 || r.x > 400) return;
            if (r.width < 40) return;
            out.push(i);
        });
        return out;
    }""")
    print(f"[库存归零] 找到 {len(target_indices)} 个库存 input,索引={target_indices}")
    # JS 直接写值,不走 Playwright click → 避免 PDD「重置规格」对话框
    count = await form_page.evaluate("""(indices) => {
        const setter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value').set;
        const all = document.querySelectorAll('input');
        let n = 0;
        for (const idx of indices) {
            if (idx >= all.length) continue;
            const inp = all[idx];
            try {
                setter.call(inp, '0');
                inp.dispatchEvent(new Event('input', {bubbles:true}));
                inp.dispatchEvent(new Event('change', {bubbles:true}));
                n += 1;
            } catch(e) {}
        }
        return n;
    }""", target_indices)
    await asyncio.sleep(0.5)
    print(f"[库存归零] 成功写 {count} 个库存=0 (JS set value)")
    await form_page.screenshot(path="D:/files/pdd_stock_zero.png", full_page=True)
    print("[库存归零] 截图: pdd_stock_zero.png")
    return count


async def set_reference_price(edit_page) -> bool:
    """填「商品参考价」= 单买价列最大值 + 2。

    两个硬约束(实测复现):
      1. 必须用**真键盘输入**:native setter 写的值只改 DOM,React state 仍是 0,
         重渲染/提交校验时回滚成默认 0 → PDD 报「参考价不能小于等于0」。
      2. 必须在 **zero_out_stock 之后、提交之前**调用:库存归零会触发价格表重渲染,
         早于它写的参考价会被冲回 0。
    """
    # 扫单买价列当前最大值(按最近列头归属,绕开拼单价列)
    actual_max_single = await edit_page.evaluate("""() => {
        const findH = (txt) => {
            for (const el of document.querySelectorAll('th, span, div, label')) {
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (direct === txt) {
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0) return {x: r.x, y: r.y, w: r.width};
                }
            }
            return null;
        };
        const singleHdr = findH('单买价(元)') || findH('*单买价(元)');
        if (!singleHdr) return 0;
        const HDR_NAMES = ['款式','色号','库存','*库存','拼单价(元)','*拼单价(元)','单买价(元)','*单买价(元)',
                           '规格编码','规格预览图','状态','操作'];
        const allHdrs = [];
        for (const el of document.querySelectorAll('th, span, div, label')) {
            const t = Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (HDR_NAMES.includes(t)) {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0 && r.y < singleHdr.y + 60 && r.y > singleHdr.y - 60)
                    allHdrs.push({name: t, cx: r.x + r.width/2});
            }
        }
        const isSingle = (n) => n === '单买价(元)' || n === '*单买价(元)';
        let m = 0;
        document.querySelectorAll('input').forEach(inp => {
            if (inp.type && inp.type !== 'text') return;
            if (inp.disabled || inp.readOnly) return;
            const r = inp.getBoundingClientRect();
            if (r.width < 30 || r.height < 10) return;
            if (r.y < singleHdr.y + 10) return;
            const cx = r.x + r.width / 2;
            let best = null, bestD = 9999;
            for (const h of allHdrs) {
                const d = Math.abs(cx - h.cx);
                if (d < bestD) { bestD = d; best = h; }
            }
            if (!best || !isSingle(best.name)) return;
            const v = parseFloat((inp.value || '').trim());
            if (!isNaN(v) && v > m) m = v;
        });
        return m;
    }""")
    max_single = float(actual_max_single or 0)
    if max_single <= 0:
        print(f"[参考价] [!!] 单买价列扫描最大值=0,无法判定参考价,跳过(提交可能失败)")
        return False
    ref_price = round(max_single + 2, 2)

    # 锚点:商品参考价 input 的 placeholder 是唯一的「应大于商品最大单买价」(含「应大于」)。
    # 不能用 label 邻近法(实测在某些布局会挑到隔壁「满件折扣」input,把价格写进折扣框污染);
    # 也不能只匹配「单买价」(SKU 单买价列 input 的 placeholder 就是「单买价」)。
    # 只认 placeholder 含「应大于」+「单买价」的那个 → 全页唯一,物理上排除折扣/SKU 价格列。
    ANCHOR_FIND = """() => {
        for (const inp of document.querySelectorAll('input')) {
            const ph = inp.placeholder || '';
            if (ph.includes('应大于') && ph.includes('单买价')) return inp;
        }
        return null;
    }"""
    # 安全写入:用 Playwright 元素句柄,把每一次按键都绑定到「参考价」这个**确切的 input
    # 元素**上(el.click()/el.type() 每次先聚焦该元素本身)。物理上不会打到相邻的
    # 「满件折扣」等字段——杜绝之前 page.keyboard 焦点漂移把 2044 写进折扣框的事故。
    # 写后用 el.input_value() 读回校验,不符重试最多 3 次;3 次都写不进就放弃(不污染别处,
    # 顶多 PDD 拒、换候选)。
    ok = False
    rb = None
    for attempt in range(1, 4):
        jh = await edit_page.evaluate_handle("""() => { const find = %s; return find(); }""" % ANCHOR_FIND)
        el = jh.as_element()
        if el is None:
            await jh.dispose()
            diag = await edit_page.evaluate("""() => {
                const txtOf = (el) => Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                const out = [];
                for (const el of document.querySelectorAll('label, span, div')) {
                    const d = txtOf(el);
                    if (d && d.includes('参考价') && d.length < 20) {
                        const r = el.getBoundingClientRect();
                        out.push({txt:d, x:Math.round(r.x), y:Math.round(r.y), w:Math.round(r.width)});
                    }
                }
                return out.slice(0,10);
            }""")
            print(f"[参考价] [!!] 第{attempt}次未定位到「商品参考价」input  诊断={diag}")
            await asyncio.sleep(0.5)
            continue
        # 防错栅栏:敲键盘前再确认这个 input 的 placeholder 确含「应大于」(参考价独有)。
        # 万一句柄不是参考价,绝不敲键盘 → 杜绝污染满件折扣/SKU 价格列。
        ph = await el.get_attribute("placeholder")
        if not (ph and "应大于" in ph):
            print(f"[参考价] [!!] 第{attempt}次句柄非参考价(placeholder={ph!r}),跳过不敲键盘")
            await jh.dispose()
            await asyncio.sleep(0.5)
            continue
        try:
            await el.scroll_into_view_if_needed(timeout=3000)
            await el.click(timeout=3000)              # 聚焦到这个确切的 input(元素级,不会跑到别的字段)
            await el.press("Control+a")
            await el.press("Delete")
            await el.type(str(ref_price), delay=40)   # 每个键都打到这个元素上
            await el.press("Enter")                   # 回车确认,提交进 React state
            await asyncio.sleep(0.4)
            await el.evaluate("e => e.blur()")        # 失焦触发校验(只 blur 它自己)
            await asyncio.sleep(0.4)
            rb = await el.input_value()
        except Exception as e:
            print(f"[参考价] 第{attempt}次写入异常: {e}")
            rb = None
        finally:
            await jh.dispose()
        try:
            ok = (abs(float(str(rb).strip()) - ref_price) < 0.01)
        except (TypeError, ValueError):
            ok = False
        print(f"[参考价] 第{attempt}次: 商品参考价 = max单买价({max_single}) + 2 = {ref_price}  读回={rb!r}  ok={ok}")
        if ok:
            break
        await asyncio.sleep(0.5)
    if not ok:
        print(f"[参考价] [!!] 重试 3 次仍写不进,读回={rb!r} 与期望 {ref_price} 不符 → 放弃(提交会被 PDD 拒,换候选,不污染其它字段)")
    await edit_page.screenshot(path="D:/files/pdd_ref_price.png", full_page=True)
    return ok


async def click_submit_publish(form_page) -> bool:
    """点击「提交并上架」按钮"""
    print("\n[提交] 点击「提交并上架」按钮")
    # 滚到底部确保按钮可见
    await form_page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
    await asyncio.sleep(1)
    btn = await form_page.evaluate("""() => {
        for (const el of document.querySelectorAll('button, [role="button"], span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '提交并上架') {
                const r = el.getBoundingClientRect();
                if (r.width > 30 && r.height > 10)
                    return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2), w: Math.round(r.width)};
            }
        }
        return null;
    }""")
    if not btn:
        print("[!] 未找到「提交并上架」按钮")
        return False
    print(f"[提交] 找到按钮 ({btn['x']},{btn['y']})")
    await form_page.mouse.click(btn['x'], btn['y'])
    print("[提交] 已点击，等待响应...")
    await asyncio.sleep(5)
    await form_page.screenshot(path="D:/files/pdd_after_submit.png", full_page=True)
    print(f"[提交] 当前 URL: {form_page.url[:120]}")
    print("[提交] 截图: pdd_after_submit.png")
    return True


async def read_edit_state(edit_page) -> dict:
    """读取编辑页当前规格名 + 拼单价/单买价/库存(用于验证 & inspect)。

    重写策略(2026-05-26):跟 fill_prices 一致 — 按 y 行配对,从「款式」列读规格名,
    不再扫顶部"商品规格"input(那个会把 PDD 提示文字误扫为规格)。
    库存列在编辑页是「库存」(发布表单是「改后库存」),两个都试。
    """
    # 滚到规格区
    await edit_page.evaluate("""async () => {
        for (let y = 0; y < document.body.scrollHeight; y += 600) {
            window.scrollTo(0, y); await new Promise(r => setTimeout(r, 200));
        }
    }""")
    await asyncio.sleep(1)
    state = await edit_page.evaluate("""() => {
        const findHdr = (txt) => {
            for (const el of document.querySelectorAll('th, span, div, label')) {
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (direct === txt) {
                    const r = el.getBoundingClientRect();
                    if (r.width > 0) return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width)};
                }
            }
            return null;
        };
        const groupHdr  = findHdr('拼单价(元)') || findHdr('*拼单价(元)');
        const singleHdr = findHdr('单买价(元)') || findHdr('*单买价(元)');
        const styleHdr  = findHdr('款式');
        // 兼容编辑页 / 发布表单 两种列头名
        const stockHdr  = findHdr('库存') || findHdr('*库存') || findHdr('改后库存');
        if (!groupHdr || !singleHdr)
            return {specs: [], stocks: [], groups: [], singles: [], error: 'no_price_headers'};

        // 全部列头(用于最近邻归属判断)
        const HDR_NAMES = ['款式','色号','库存','*库存','改后库存','拼单价(元)','*拼单价(元)',
                           '单买价(元)','*单买价(元)','规格编码','规格预览图','状态','操作'];
        const allHdrs = [];
        for (const el of document.querySelectorAll('th, span, div, label')) {
            const t = Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (HDR_NAMES.includes(t)) {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0 && r.y < groupHdr.y + 60 && r.y > groupHdr.y - 60)
                    allHdrs.push({name: t, cx: r.x + r.width/2});
            }
        }
        const isGroup  = (n) => n === '拼单价(元)' || n === '*拼单价(元)';
        const isSingle = (n) => n === '单买价(元)' || n === '*单买价(元)';
        const isStock  = (n) => n === '库存' || n === '*库存' || n === '改后库存';

        // 扫表格内可编辑 input,按最近列头归属
        const groupInps = [], singleInps = [], stockInps = [];
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            if (inp.disabled || inp.readOnly) return;
            const r = inp.getBoundingClientRect();
            if (r.width < 30 || r.height < 10) return;
            if (r.y < groupHdr.y + 10) return;
            const cx = r.x + r.width / 2;
            let bestH = null;
            let bestD = 9999;
            for (const h of allHdrs) {
                const d = Math.abs(cx - h.cx);
                if (d < bestD) { bestD = d; bestH = h; }
            }
            if (!bestH) return;
            const v = (inp.value || '').trim();
            const it = {i, v, y: Math.round(r.y)};
            if (isGroup(bestH.name)) groupInps.push(it);
            else if (isSingle(bestH.name)) singleInps.push(it);
            else if (isStock(bestH.name)) stockInps.push(it);
        });
        groupInps.sort((a,b) => a.y - b.y);

        // 噪声过滤(同 fill_prices)
        const NOISE = /版本|V\\d+\\.\\d|最新|操作|删除|已启用|已停用|已上架|已下架|未上架|系统自动|商品参考价|总库存|拼单价|单买价/;
        const styleCx = styleHdr ? (styleHdr.x + styleHdr.w / 2) : (groupHdr.x - 200);
        const findStyleAtY = (yRow) => {
            const candidates = [];
            for (const el of document.querySelectorAll('div, span, p, a')) {
                const r = el.getBoundingClientRect();
                if (r.height < 4 || r.height > 80) continue;
                if (r.width < 20 || r.width > 400) continue;
                if (Math.abs(r.y + r.height/2 - yRow) > 30) continue;
                if (Math.abs(r.x + r.width/2 - styleCx) > 120) continue;
                let txt = (el.innerText || '').trim();
                if (!txt) continue;
                txt = txt.split('\\n').map(s => s.trim()).find(s => s) || '';
                if (!txt || txt.length < 2 || txt.length > 120) continue;
                if (NOISE.test(txt)) continue;
                if (/^\\d+(\\.\\d+)?$/.test(txt)) continue;
                if (!/[\\u4e00-\\u9fa5A-Za-z]/.test(txt)) continue;
                let score = txt.length;
                if (/[【\\[].+[】\\]]/.test(txt)) score += 50;
                if (/\\+/.test(txt)) score += 10;
                candidates.push({txt, score});
            }
            if (!candidates.length) return '';
            candidates.sort((a,b) => b.score - a.score);
            return candidates[0].txt;
        };

        // 按 y 配对 group ↔ single ↔ stock,得到每行
        const specs = [], groups = [], singles = [], stocks = [];
        const used_s = new Set(), used_k = new Set();
        for (const g of groupInps) {
            // 单买价
            let bestS = null, bestSD = 9999;
            for (const s of singleInps) {
                if (used_s.has(s.i)) continue;
                const dy = Math.abs(s.y - g.y);
                if (dy <= 12 && dy < bestSD) { bestSD = dy; bestS = s; }
            }
            if (!bestS) continue;
            used_s.add(bestS.i);
            // 库存
            let bestK = null, bestKD = 9999;
            for (const k of stockInps) {
                if (used_k.has(k.i)) continue;
                const dy = Math.abs(k.y - g.y);
                if (dy <= 12 && dy < bestKD) { bestKD = dy; bestK = k; }
            }
            if (bestK) used_k.add(bestK.i);
            // 规格名
            const name = findStyleAtY(g.y);
            specs.push(name);
            groups.push(g.v);
            singles.push(bestS.v);
            stocks.push(bestK ? bestK.v : '');
        }
        return {specs, stocks, groups, singles};
    }""")
    return state


async def verify_published(form_page, supplier_cost: float, suffix: str, stock_value: int,
                           shipping: float = 4.0, margin: float = 0.9, single_extra: float = 2.0,
                           max_rounds: int = 3, units_map: dict = None) -> bool:
    """发布后验证(方案 A,2026-05-26 重构):用详情页静态表(read_detail_state)做首要判定源,
    不再每轮强制 click_edit_goods + read_edit_state(后者在多规格场景会误读 0 → 触发错误修复)。

    流程:
      1) click_view_detail 拿 detail_page(必须,PDD 提交后需等后端处理)
      2) read_detail_state(detail_page) + _compare(rec, state)
         - 无差异 → return True(正常 case 在此短路,省 30-60s)
         - 有差异且 round < max → click_edit_goods → 修复 → 提交 → reload detail_page → 下一轮
      3) detail_state 抓不到表(罕见) → 一轮内回落到 read_edit_state 兼容旧路径
    """
    # 延迟 import 避免循环(pdd_inspect 顶层 import pdd_publish)
    from pdd_inspect import read_detail_state, _compare

    print(f"\n[验证] 开始发布后核对(方案 A 详情页表),最多 {max_rounds} 轮")
    rec_like = {
        "suffix": suffix or "",
        "stock": int(stock_value),
        "supplier_cost": float(supplier_cost),
        "shipping": float(shipping),
        "margin": float(margin),
        "single_buy_extra": float(single_extra),
        "units_map": units_map or {},   # 智能SKU:核查用云端份数算期望价(别用本地份数把价改错)
    }
    print(f"[验证] 期望: suffix={suffix!r}  stock={stock_value}  "
          f"cost={supplier_cost}  margin={margin}  single_extra={single_extra}"
          f"{'  云端份数=' + str(units_map) if units_map else ''}")

    print(f"\n[验证] 进入商品详情...")
    detail_page = await click_view_detail(form_page)
    # 上架成功回检:从商品详情页抓真实上架主图(比 form 页轮播稳),抓到就覆盖 form 页兜底值
    try:
        _mi = await _detail_main_image_url(detail_page)
        if _mi:
            globals()['_PUBLISHED_MAIN_IMG'] = _mi
            print(f"[上架主图] 回检(详情页)采集: {_mi[:80]}")
    except Exception as _e:
        print(f"[上架主图] 回检采集异常(忽略,用form页兜底): {_e}")

    for rnd in range(1, max_rounds + 1):
        # 读详情页表
        state = await read_detail_state(detail_page)
        sc = len(state.get("specs", []) or [])
        print(f"[验证-第{rnd}轮] detail_state: specs={sc}  "
              f"stocks={(state.get('stocks') or [])[:3]}  "
              f"groups={(state.get('groups') or [])[:3]}  "
              f"singles={(state.get('singles') or [])[:3]}")

        if sc == 0:
            # detail_state 抓不到 → 回落到旧 edit_state 路径(只兜底一次,避免无限循环)
            print(f"[验证-第{rnd}轮] ⚠ detail_state 抓不到表,回落到 edit_state")
            edit_page = await click_edit_goods(detail_page)
            estate = await read_edit_state(edit_page)
            reasons = _compare(rec_like, estate)
            if not reasons:
                print(f"[验证-第{rnd}轮] ✅ edit_state 显示对齐,发布成功(回落路径)")
                return True
            print(f"[验证-第{rnd}轮] ⚠ edit_state 报 {len(reasons)} 处差异(回落路径不再修复,直接返回 mismatch)")
            return False

        reasons = _compare(rec_like, state)
        if not reasons:
            print(f"[验证-第{rnd}轮] ✅ 详情页表显示对齐,发布成功!(短路,跳过编辑页)")
            return True

        print(f"[验证-第{rnd}轮] ⚠ 详情页表显示 {len(reasons)} 处差异:")
        for r in reasons[:5]:
            print(f"  • {r}")
        if rnd >= max_rounds:
            print(f"[验证] ❌ 达到最大重试 {max_rounds} 轮,验证失败")
            return False

        # 进编辑页精准修复:按规格名 + 字段定位单行单字段(同 inspect_one 的修复路径)
        # 比 append_spec_suffix / set_new_stock 全表盲扫稳:不会撞虚拟列表漏行 / 写错位置 /
        # fill_prices 把对的 18.75 改成单支 11.62。fixes 来自 _compare_with_fixes 的结构化指令。
        print(f"[验证-第{rnd}轮] 进编辑页精准修复(按规格名定位单字段)...")
        edit_page = await click_edit_goods(detail_page)
        # lazy import 避免循环 import(pdd_inspect 顶层 import pdd_publish)
        from pdd_inspect import _compare_with_fixes, _fix_prices_via_cluster
        _r2, fixes = _compare_with_fixes(rec_like, state)
        print(f"[验证-第{rnd}轮] {len(fixes)} 条精准修复指令", flush=True)
        ok_count = 0
        price_failures = 0
        for fx in fixes:
            ok2 = await fix_row_field(edit_page, fx["spec_name"], fx["field"], fx["value"], actual_value=fx.get("actual"))
            if ok2:
                ok_count += 1
            elif fx["field"] in ("group_price", "single_price"):
                price_failures += 1
        print(f"[验证-第{rnd}轮] fix_row_field 成功 {ok_count}/{len(fixes)}", flush=True)

        # 主路径有价格类失败 → y 聚类兜底(对"拍一发X 开头"等 fix_row_field no_input 的 case)
        # 兜底失败(单 SKU / 多维规格 / 列变)会自动 abort 不写任何 input,绝不会乱写
        if price_failures > 0:
            print(f"[验证-第{rnd}轮] {price_failures} 条价格类失败 → 启用 y 聚类兜底", flush=True)
            cluster_res = await _fix_prices_via_cluster(edit_page, rec_like, state.get("unit_specs") or state.get("specs", []))  # 份数取套餐列
            print(f"[验证-第{rnd}轮] 列头法兜底: ok={cluster_res['ok']} "
                  f"fixed={cluster_res['fixed']}/{cluster_res['total']}", flush=True)
            for ln in cluster_res.get("log", []):
                print(f"  [cluster] {ln}", flush=True)
            if cluster_res["ok"] and cluster_res["fixed"] == cluster_res["total"]:
                # 兜底全成功 → 等价于所有价格类 fix 都修对(它一次性写了所有价格表行)
                ok_count += price_failures

        ok = await click_edit_submit(edit_page)
        if not ok:
            print(f"[验证-第{rnd}轮] [!] 重新提交失败")
            return False
        # fix_row_field 全部成功 + 提交 OK → 直接判 ok,跳过第 2 轮 detail_state 校验。
        # 原因:PDD 详情页"款式"列对短规格名(1瓶/2瓶)/组合规格(豆蔻粉+美德拉【各1支】)
        # 显示截断,不带后缀;read_detail_state 抓到的不是后端真值,二次校验会误报 mismatch。
        # 编辑页 input value(=后端真值)才是可靠来源,fix_row_field 已经按真值写入并提交。
        if ok_count == len(fixes) and len(fixes) > 0:
            print(f"[验证-第{rnd}轮] ✅ fix_row_field {ok_count}/{len(fixes)} 全成功 + 提交 OK,"
                  f"跳过第 2 轮 detail 校验(详情页对短/组合规格名显示截断,非后端真值)")
            return True
        # 部分修复(ok_count < len(fixes)) → reload detail_page 进下一轮重检
        try:
            await asyncio.sleep(3)
            await detail_page.reload(wait_until="domcontentloaded", timeout=20000)
            await asyncio.sleep(3)
        except Exception as e:
            print(f"[验证-第{rnd}轮] detail reload 失败(继续): {e}")
    return False


async def click_view_detail(form_page):
    """提交成功页 → 点击「查看商品详情」→ 扫描 context.pages 找 goods_detail 页
    若只找到 goods_return_detail 则关掉重试，直到出现 goods_detail。
    """
    print("\n[查看详情] 等 10 秒让 PDD 处理...")
    await asyncio.sleep(10)

    async def _find_btn():
        return await form_page.evaluate("""() => {
            for (const el of document.querySelectorAll('button, [role="button"], a, span, div')) {
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (direct === '查看商品详情') {
                    const r = el.getBoundingClientRect();
                    if (r.width > 30 && r.height > 10)
                        return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
                }
            }
            return null;
        }""")

    def _scan_pages(ctx):
        """从 context.pages 找匹配的页面，返回 (goods_detail_page, return_detail_page)"""
        good, ret = None, None
        for p in ctx.pages:
            try:
                u = p.url
            except Exception:
                continue
            if "goods_return_detail" in u:
                ret = p
            elif "goods_detail" in u and "goods_add" not in u:
                good = p
        return good, ret

    detail_page = None
    for attempt in range(1, 9):
        # 先扫描，看是否已经有 goods_detail 页
        good, ret = _scan_pages(form_page.context)
        if good:
            print(f"[查看详情] ✅ context.pages 中已存在 goods_detail")
            detail_page = good
            break
        # 没有的话，先关掉 return_detail（如果存在），再点按钮
        if ret and ret != form_page:
            print(f"[查看详情] 清掉残留 return_detail Tab")
            try: await ret.close()
            except Exception: pass
        # 在 form_page 上找按钮
        btn = await _find_btn()
        if not btn:
            print(f"[!] 第{attempt}次未找到「查看商品详情」按钮，url={form_page.url[:80]}")
            await asyncio.sleep(3)
            continue
        print(f"[查看详情] 第 {attempt} 次点击按钮 ({btn['x']},{btn['y']})")
        await form_page.mouse.click(btn['x'], btn['y'])
        await asyncio.sleep(5)
        # 再次扫描
        good, ret = _scan_pages(form_page.context)
        if good:
            print(f"[查看详情] ✅ 已找到 goods_detail")
            detail_page = good
            break
        if ret:
            print(f"[查看详情] 当前是 return_detail（发布中），关闭并等 3 秒后重试...")
            if ret != form_page:
                try: await ret.close()
                except Exception: pass
            await asyncio.sleep(3)
            continue
        # 检查 form_page 自身是否同 Tab 跳转到了 goods_detail
        try:
            u = form_page.url
            if "goods_detail" in u and "goods_add" not in u:
                print(f"[查看详情] form_page 已跳到 goods_detail")
                detail_page = form_page
                break
        except Exception:
            pass
        print(f"[查看详情] 未匹配到任何详情页，等 3 秒后重试...")
        await asyncio.sleep(3)

    if not detail_page:
        print("[!] 8 次尝试均未进入 goods_detail，使用 form_page 兜底")
        detail_page = form_page

    try:
        await detail_page.screenshot(path="D:/files/pdd_goods_detail.png", full_page=True)
    except Exception:
        pass
    print(f"[查看详情] 最终 url={detail_page.url[:120]}")
    return detail_page


def _parse_spec_units(spec_text: str) -> int:
    """从规格名解析份数：
    - '*N瓶/支' → N
    - '【各N瓶】' → 2*N（组合规格）
    - '任选N支/瓶' → N（含中文数字 一/二/两/三/四/五/六/七/八/九/十）
    - 默认 1
    """
    import re
    # 简体 + 繁体 + 大写(会计写法)。"两"/"兩"是"二"的口语/繁体写法,"贰/叁/陆"是大写简化字。
    cn_map = {
        # 简体小写
        '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5,
        '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
        # 繁体
        '兩': 2,
        # 繁体/大写(会计):壹贰叁肆伍陆柒捌玖拾 + 繁体 貳/參/陸
        '壹': 1, '貳': 2, '贰': 2, '參': 3, '叁': 3, '肆': 4,
        '伍': 5, '陸': 6, '陆': 6, '柒': 7, '捌': 8, '玖': 9, '拾': 10,
    }
    units_pat = '[瓶件套支盒包箱]'

    # 0) 「共N瓶/盒…」= 商家明示买家总共得到 N 件(买X送Y共Z / 一共N盒 促销话术),
    #    最权威,优先级最高(否则规则4会先命中"买2盒"的 2,漏掉真实总数 3)。
    #    实测踩过:草本牙粉"买2盒送1盒共3盒"被判 2 份 → 核查永远对不上还毁价(966765928983)。
    m = re.search(rf'共\s*(\d+)\s*{units_pat}', spec_text)
    if m: return int(m.group(1))
    for cn, num in cn_map.items():
        if re.search(rf'共\s*{cn}\s*{units_pat}', spec_text):
            return num

    # 1) 任选 N 支/瓶（最高优先级，避免与「各N」冲突）
    m = re.search(rf'任选\s*(\d+)\s*{units_pat}', spec_text)
    if m: return int(m.group(1))
    for cn, num in cn_map.items():
        if re.search(rf'任选\s*{cn}\s*{units_pat}', spec_text):
            return num

    # 2) 【各N瓶】 → 2*N（组合规格双份）
    m = re.search(rf'各\s*(\d+)\s*{units_pat}', spec_text)
    if m: return 2 * int(m.group(1))
    for cn, num in cn_map.items():
        if re.search(rf'各\s*{cn}\s*{units_pat}', spec_text):
            return 2 * num

    # 3) *N瓶 / xN支
    m = re.search(rf'[*xX×]\s*(\d+)\s*{units_pat}', spec_text)
    if m: return int(m.group(1))

    # 3.5) *N 末尾或后接非单位字符:如 "6.5g*2" / "6.5g*2 +赠品" / "*2】"
    #      表示套装包含 N 份(常见包装规格,如 6.5g*2 = 2 包共 13g)
    m = re.search(r'[*xX×]\s*(\d+)(?:\s*$|\s*[+)\s】])', spec_text)
    if m: return int(m.group(1))

    # 4) 裸数字+单位:N瓶 / N支(单位字只含容器类,不会与 ml/g/kg 等容量冲突)
    #    只排除小数(前面是 '.',如 "2.5瓶" 不当 5 份);**不再排除 '/'**
    #    —— 原 (?<![./]) 会误伤「限量活动/2瓶」「囤货/3瓶」这种斜杠后真份数。
    #    容量(300ml/500g)本身后面不是容器量词,不会被这条匹配,无需额外排除。
    m = re.search(rf'(?<![.])(\d+)\s*{units_pat}', spec_text)
    if m: return int(m.group(1))
    for cn, num in cn_map.items():
        if re.search(rf'{cn}\s*{units_pat}', spec_text):
            return num

    # 4.5) 「拍N发M」 / 「买N送M」 → 实际发货 M 份(1688 常见促销话术,M 不一定跟单位字相连)
    #     例:"【人参精华液】拍一发二/限时特价" → 2 份
    #         "拍1发3" / "买一送一" → 1+1=2
    #         "拍二发三" → 3 份
    cn_keys = '一二两三四五六七八九十壹贰叁肆伍陆柒捌玖拾兩貳參'
    m = re.search(rf'拍\s*[\d{cn_keys}]+\s*发\s*(\d+)', spec_text)
    if m: return int(m.group(1))
    for cn, num in cn_map.items():
        if re.search(rf'拍\s*[\d{cn_keys}]+\s*发\s*{cn}(?![瓶支盒包箱件套])', spec_text):
            return num
        if re.search(rf'拍\s*[\d{cn_keys}]+\s*发\s*{cn}\s*({units_pat}|$|[/，,.+])', spec_text):
            return num
    # 4.5a) 「买N发M」/「拍N发M」→ 实际发货 M 份；这里的“买”不是“买N送M”。
    m = re.search(rf'(?:\u62cd|\u4e70)\s*[\d{cn_keys}]+\s*\u53d1\s*(\d+)', spec_text)
    if m: return int(m.group(1))
    for cn, num in cn_map.items():
        if re.search(rf'(?:\u62cd|\u4e70)\s*[\d{cn_keys}]+\s*\u53d1\s*{cn}(?![\u74f6\u652f\u76d2\u5305\u7bb1\u4ef6\u5957])', spec_text):
            return num
        if re.search(rf'(?:\u62cd|\u4e70)\s*[\d{cn_keys}]+\s*\u53d1\s*{cn}\s*({units_pat}|$|[/，,.+])', spec_text):
            return num

    # 「买N送M」→ N+M
    m = re.search(rf'买\s*(\d+)\s*送\s*(\d+)', spec_text)
    if m: return int(m.group(1)) + int(m.group(2))
    for cn1, n1 in cn_map.items():
        for cn2, n2 in cn_map.items():
            if re.search(rf'买\s*{cn1}\s*送\s*{cn2}', spec_text):
                return n1 + n2

    # 5) 色号组合规格:"01#+02#" / "#01裸米棕+#02粉白棕" / "01号+02号" → 数 # 或 号 个数
    #    两种格式都认:数字在前(01#)和井号在前(#01)
    #    例:"仙女组合【01#+02#】不纠结" → 2;"#01裸米棕+#02粉白棕" → 2
    #    例:"绿色+粉色+蓝色" 不属于此类(无 # 或 号),不计
    hash_count = len(re.findall(r'\d+\s*#|#\s*\d+', spec_text))
    if hash_count >= 2:
        return hash_count
    hao_count = len(re.findall(r'\d+\s*号|号\s*\d+', spec_text))
    if hao_count >= 2:
        return hao_count

    # 6) "X色+Y色" 组合:如 "奶茶色+豆沙色" → 计算 + 号连接的色块数
    #    更保守:必须含"组合/套装/套盒"字眼才算,避免误判 "粉色+面膜"(后者是赠品)
    if re.search(r'(组合|套装|套盒|套餐)', spec_text):
        color_groups = re.findall(r'[一-龥]{1,4}色', spec_text)
        if len(color_groups) >= 2:
            return len(color_groups)

    return 1


def detect_units_ambiguous(spec_names) -> tuple:
    """【独立兜底检测,不参与定价】判断商品份数是否"根本算不出"。

    场景:供货价是 1 盒价,但属性没写 1 盒 = 几贴 —— 当多个 SKU 只靠"贴/片/张/枚"数量
    区分(如 1贴/10贴/50贴)、又没有真容器单位(瓶/支/盒…)时,盒↔贴换算缺失,份数无解。
    这类不该硬发错价,而是 0 库存上架 + 标"需人工核价"。

    返回 (ambiguous: bool, 命中的规格名列表)。
    判定:出现 >=2 个**不同**的"贴/片"数,且全程无"N瓶/支/盒"容器数 → True。
    单个"10片装"这种(只有1个含量数)不算,正常发(份数=1)。
    """
    import re as _re
    CONTENT = _re.compile(r"(\d+)\s*[贴片张枚抽粒颗]")
    REAL    = _re.compile(r"\d+\s*[瓶支盒件套罐桶条袋包]")
    counts = set()
    hit = []
    for name in (spec_names or []):
        nm = str(name)
        if REAL.search(nm):
            # 有真容器单位 → 份数可由现有逻辑算,不属于本兜底场景,直接放弃整体判定
            return False, []
        for m in CONTENT.finditer(nm):
            counts.add(int(m.group(1)))
            hit.append(nm)
    ambiguous = len(counts) >= 2
    return ambiguous, (hit if ambiguous else [])


async def apply_window_mode(context, page, show_browser: bool):
    """主动用 CDP 设窗口位置(不只靠启动参数——复用同 profile 旧窗口时启动参数可能不生效):
    show_browser=True → 拉回屏幕内并最大化;False → 挪到屏幕外静默。每次强制生效。
    供 pdd_publish / pdd_inspect / pdd_takedown / pdd_delete / pdd_sync_status / pdd_restore 共用。"""
    try:
        cdp = await context.new_cdp_session(page)
        wid = (await cdp.send("Browser.getWindowForTarget"))["windowId"]
        if show_browser:
            await cdp.send("Browser.setWindowBounds",
                           {"windowId": wid, "bounds": {"windowState": "normal"}})
            await cdp.send("Browser.setWindowBounds",
                           {"windowId": wid, "bounds": {"left": 0, "top": 0,
                                                        "width": 1920, "height": 1080}})
            await cdp.send("Browser.setWindowBounds",
                           {"windowId": wid, "bounds": {"windowState": "maximized"}})
        else:
            await cdp.send("Browser.setWindowBounds",
                           {"windowId": wid, "bounds": {"windowState": "normal"}})
            await cdp.send("Browser.setWindowBounds",
                           {"windowId": wid, "bounds": {"left": -32000, "top": -32000,
                                                        "width": 1920, "height": 1080}})
    except Exception as e:
        print(f"[窗口] 调整窗口位置失败(不影响任务): {e}")


def _ceil_to_9(x: float) -> float:
    """卖价取价:向上取到最近的「整数.9」,保证不低于原算价(保障利润)。
    例:11.29→11.9, 13.25→13.9, 11.95→12.9, 10.90→10.9, 10.91→11.9, 7.00→7.9。"""
    x = float(x)
    n = int(x - 0.9 - 1e-9)          # floor(x-0.9),x≥0.9 时成立
    while n + 0.9 < x - 1e-9:        # 浮点兜底进位
        n += 1
    if n < 0:
        n = 0
    return round(n + 0.9, 1)


async def fill_prices(edit_page, supplier_cost: float, shipping: float = 4.0,
                     margin: float = 0.9, single_buy_extra: float = 2.0,
                     units_map: dict = None) -> int:
    """根据供货价 + 运费按毛利率算拼单价、单买价,填入价格表。

    重写策略(2026-05-26):**按行 y 坐标聚类**,从「款式」列直接读规格名,
    不再扫顶部"商品规格"input(那个扫法会把 PDD 提示文字误识别为规格 +
    部分规格被重复扫,导致多规格商品价格写到错的行/部分行漏写)。
    """
    print(f"\n[价格计算] 供货价={supplier_cost} 运费={shipping} 毛利率={margin*100:.0f}%")
    # 先滚整页触发虚拟列表渲染,确保所有规格行 input 都被渲染
    # (编辑页规格表是虚拟滚动,初始视口外的行 input 不渲染 → 漏行)
    await edit_page.evaluate("""async () => {
        for (let y = 0; y < document.body.scrollHeight; y += 600) {
            window.scrollTo(0, y); await new Promise(r => setTimeout(r, 200));
        }
    }""")
    await asyncio.sleep(1)
    # 滚完后把「款式」列头滚到视口正中,避免视口停在底部时 PDD 顶部 sticky
    # banner(主搜索栏/"规格与库存"标题等) 跟表格行 y 接近 → 被误识别成规格名
    await edit_page.evaluate("""() => {
        for (const el of document.querySelectorAll('th, span, div, label')) {
            const d = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (d === '款式') { el.scrollIntoView({block: 'center'}); return; }
        }
    }""")
    await asyncio.sleep(1)
    rows = await edit_page.evaluate("""() => {
        // 1) 找列头
        const findHeader = (txt) => {
            for (const el of document.querySelectorAll('th, span, div, label')) {
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (direct === txt) {
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0) return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width)};
                }
            }
            return null;
        };
        const groupHdr = findHeader('拼单价(元)') || findHeader('*拼单价(元)');
        const singleHdr = findHeader('单买价(元)') || findHeader('*单买价(元)');
        const styleHdr  = findHeader('款式');  // 规格名所在列(第1层规格)
        const stockHdr  = findHeader('库存') || findHeader('*库存');  // 规格列区右边界(套餐在款式与库存之间)
        if (!groupHdr || !singleHdr) return {error: 'no_header'};
        // 扫描表格里所有可能的列头(用于把每个 input 严格归属到正确列,避免误归)
        const HDR_NAMES = ['款式','色号','库存','*库存','拼单价(元)','*拼单价(元)','单买价(元)','*单买价(元)',
                           '规格编码','规格预览图','状态','操作'];
        const allHdrs = [];
        for (const el of document.querySelectorAll('th, span, div, label')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3)
                .map(n => n.textContent).join('').trim();
            if (HDR_NAMES.includes(direct)) {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0 && r.y < groupHdr.y + 60 && r.y > groupHdr.y - 60) {
                    allHdrs.push({name: direct, cx: r.x + r.width/2});
                }
            }
        }
        const all = Array.from(document.querySelectorAll('input'));
        const inputs = all.map((inp, i) => {
            const r = inp.getBoundingClientRect();
            return {
                i,
                v:(inp.value||'').trim(),
                x:Math.round(r.x), y:Math.round(r.y), w:Math.round(r.width),
                disabled: !!(inp.disabled || inp.readOnly),
                visible: r.width > 0 && r.height > 0,
            };
        }).filter(it => it.visible && !it.disabled && it.w > 30 && it.y > groupHdr.y + 10);
        // 每个 input 找最近的列头,只收落入 拼单价/单买价 列的
        const isGroup  = (n) => n === '拼单价(元)' || n === '*拼单价(元)';
        const isSingle = (n) => n === '单买价(元)' || n === '*单买价(元)';
        const groupInps = [];
        const singleInps = [];
        for (const it of inputs) {
            const itCx = it.x + (it.w || 100) / 2;
            let bestHdr = null;
            let bestD = 999;
            for (const h of allHdrs) {
                const d = Math.abs(itCx - h.cx);
                if (d < bestD) { bestD = d; bestHdr = h; }
            }
            if (!bestHdr) continue;
            if (isGroup(bestHdr.name)) groupInps.push(it);
            else if (isSingle(bestHdr.name)) singleInps.push(it);
        }
        groupInps.sort((a,b) => a.y - b.y);
        singleInps.sort((a,b) => a.y - b.y);
        // N = 价格表实际行数(取 group/single 的最小值);不再依赖顶部规格 input 个数,
        // 否则多规格商品时顶部 y 限制扫不到全部 spec → 错误截断到 1 行
        const N = Math.min(groupInps.length, singleInps.length);
        groupInps.splice(N);
        singleInps.splice(N);
        // 3) 优先从「款式」列读每行的完整规格名(份数信息靠它)
        //    款式列单元格通常是 div/span(只读文本),不是 input,所以扫 div/span
        //    styleHdr 在「1) 找列头」段已声明(line ~1143),复用即可
        // 规格列区域:从「款式」列 到「库存」列之间(覆盖 款式 + 套餐 等多层规格列)。
        // 2026-06-03 修:多层 SKU(款式×套餐)份数信息常在第2层「套餐」列(如"拍一发二/3瓶装"),
        //   原来只读款式列(styleCx±120)→ 漏读套餐 → 份数全算成 1、价格全按 1 份。
        //   现读整个规格列区域,按列聚合后左→右拼接成完整规格名,份数交给 judge_units 判。
        const specLeft  = styleHdr ? styleHdr.x : (stockHdr ? stockHdr.x - 400 : groupHdr.x - 400);
        const specRight = stockHdr ? stockHdr.x : groupHdr.x;
        // 屏蔽 PDD UI 噪声文字(banner/版本提示/列名等)
        const NOISE = /版本|V\\d+\\.\\d|最新|操作|删除|已启用|已停用|已上架|已下架|未上架|系统自动|商品参考价|总库存|拼单价|单买价|规格与库存|您可输入|随时随地经营|商品列表|商品详情|基本信息|跨境.社区团购|客户端|规则中心|商家后台|^规格$|^库存$|^款式$|^套餐$|^色号$/;
        const findRowSpecName = (yRow) => {
            // 收集规格列区域内、同一行(±30px)的小盒子文本
            const cands = [];
            for (const el of document.querySelectorAll('div, span, p, a')) {
                const r = el.getBoundingClientRect();
                if (r.height < 4 || r.height > 80) continue;        // 单行高度
                if (r.width < 20 || r.width > 400) continue;        // 单元格宽度
                if (Math.abs(r.y + r.height/2 - yRow) > 30) continue;
                const cx = r.x + r.width/2;
                if (cx < specLeft - 40 || cx > specRight - 15) continue;  // 只取 款式..库存 之间的规格列
                let txt = (el.innerText || '').trim();
                if (!txt || txt.length < 2 || txt.length > 120) continue;
                txt = txt.split('\\n').map(s => s.trim()).find(s => s) || '';  // 只取第一行非空
                if (!txt) continue;
                if (NOISE.test(txt)) continue;                       // 噪声文字
                if (/^\\d+(\\.\\d+)?$/.test(txt)) continue;           // 纯数字
                if (!/[\\u4e00-\\u9fa5A-Za-z]/.test(txt)) continue;   // 必须含字母/中文
                let score = txt.length;
                if (/[【\\[].+[】\\]]/.test(txt)) score += 50;        // 含【】优先(完整规格名)
                if (/\\d+\\s*[瓶支盒件套罐桶袋包装]/.test(txt)) score += 30;  // 含份数信息优先
                if (/\\+/.test(txt)) score += 10;                    // 含 + 号(套装)
                cands.push({txt, cx, score});
            }
            if (!cands.length) return '';
            // 按 cx 聚成"列"(间隔>150 视为新列),每列取最高分文本,左→右拼接 = 完整多层规格名
            cands.sort((a, b) => a.cx - b.cx);
            const cols = [];
            for (const c of cands) {
                const last = cols.length ? cols[cols.length - 1] : null;
                if (last && Math.abs(c.cx - last.cx) < 150) {
                    if (c.score > last.score) { last.txt = c.txt; last.cx = c.cx; last.score = c.score; }
                } else {
                    cols.push({txt: c.txt, cx: c.cx, score: c.score});
                }
            }
            return {name: cols.map(c => c.txt).join(' '), parts: cols.map(c => c.txt)};
        };
        // 按 y 配对 group 和 single,而不是按下标(下标可能错位)
        // 每个 group 找 |dy|<=12 的最近 single,且 single 不能被复用
        const tableRows = [];
        const used_s = new Set();
        for (const g of groupInps) {
            let bestS = null;
            let bestDy = 9999;
            for (const s of singleInps) {
                if (used_s.has(s.i)) continue;
                const dy = Math.abs(s.y - g.y);
                if (dy <= 12 && dy < bestDy) { bestDy = dy; bestS = s; }
            }
            if (!bestS) continue;
            used_s.add(bestS.i);
            const sn = findRowSpecName(g.y);   // {name:拼接名, parts:各规格列文本}
            tableRows.push({
                name: sn.name,
                parts: sn.parts,
                group_idx: g.i,
                single_idx: bestS.i,
                y: g.y,
            });
        }
        return {anchor: true, rows: tableRows, headers: {group: groupHdr, single: singleHdr}};
    }""")
    if rows.get('error'):
        print(f"[!] 未找到列表头: {rows}")
        return 0
    print(f"[价格计算] 列表头: 拼单价 x={rows['headers']['group']['x']}  单买价 x={rows['headers']['single']['x']}")
    print(f"[价格计算] 表格行 {len(rows['rows'])} 行")
    # 准备每行 (group_idx, group_price, single_idx, single_price) 一次性传给 JS
    # 用 JS 直接 set value + dispatch event,不走 Playwright click → 避免 PDD「重置规格」对话框
    # (PDD 在用户点击规格与库存 tab 的任意 input 时会弹此对话框,阻塞后续填写)
    # 份数判断:双判(LLM + 正则)。一致用该值;打架取大值(防亏本)+ 记存疑标记。
    # 发布时规格名还没加后缀,suffix 传空。Ollama 没装会自动回落正则,不阻断。
    try:
        from spec_units import judge_units
    except Exception:
        judge_units = None
    globals()['_units_uncertain'] = []   # 本次商品的存疑 SKU 列表(主流程写 history 时读)
    # 暂存本次所有规格名(供独立兜底检测 detect_units_ambiguous 用,不参与定价)
    globals()['_last_spec_names'] = [r.get('name', '') for r in rows['rows']]
    payload = []
    for row in rows['rows']:
        name = row['name']
        # 多层 SKU(款式×套餐):份数**只看最后一层(套餐)变体列**,第一层款式不参与
        #   —— 款式"500ml+冻膜一小包"会被 7B 误判成 2(当成洗发乳+冻膜两样),所以绝不能算款式。
        #   parts 左→右,parts[-1]=最右规格列=套餐(2层)/款式(1层时就它自己)。
        parts = [p for p in (row.get('parts') or []) if p]
        unit_src = parts[-1] if parts else (name or "")
        # 份数:智能SKU维持云端判(云端给了就用);非智能模式走原 judge_units(正则+7B)。
        _um_hit = None
        if units_map:
            for _k in (name, unit_src):
                if _k and _k in units_map:
                    _um_hit = int(units_map[_k]); break
        if _um_hit is not None:            # 智能SKU:维持云端判,云端给了份数直接用
            units = _um_hit
            print(f"  [份数·云端] 规格={(name or unit_src)[:28]} → {units}份")
        elif judge_units:
            jr = judge_units(unit_src, suffix="")
            units = jr["units"]
            if jr["disagree"]:
                globals()['_units_uncertain'].append(
                    {"spec": unit_src, "regex": jr["regex"], "llm": jr["llm"], "used": units})
                print(f"  [份数存疑] 规格={unit_src[:24]}  正则={jr['regex']} LLM={jr['llm']} → 取大={units}")
        else:
            units = _parse_spec_units(unit_src)
        cost = supplier_cost * units + shipping
        group_price = _ceil_to_9(cost / (1 - margin))
        single_price = _ceil_to_9(group_price + single_buy_extra)
        print(f"  规格={(name or unit_src or '')[:30]}  份数={units}  成本={cost:.2f}  拼单价={group_price}  单买价={single_price}")
        payload.append({
            "group_idx":    row['group_idx'],
            "single_idx":   row['single_idx'],
            "group_price":  group_price,
            "single_price": single_price,
        })
    count = await edit_page.evaluate("""(rows) => {
        const setter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value').set;
        const all = document.querySelectorAll('input');
        let n = 0;
        const writeOne = (idx, val) => {
            if (idx < 0 || idx >= all.length) return false;
            const inp = all[idx];
            try {
                setter.call(inp, String(val));
                inp.dispatchEvent(new Event('input', {bubbles:true}));
                inp.dispatchEvent(new Event('change', {bubbles:true}));
                return true;
            } catch(e) { return false; }
        };
        for (const r of rows) {
            const gOk = writeOne(r.group_idx,  r.group_price);
            const sOk = writeOne(r.single_idx, r.single_price);
            if (gOk || sOk) n += 1;
        }
        return n;
    }""", payload)
    await asyncio.sleep(0.5)
    print(f"[价格计算] 已写 {count} 行价格 (JS 直接 set value,无 click → 不触发重置规格弹窗)")

    # 商品参考价不在此处写:它必须用真键盘输入,且要在「库存归零」等会触发价格表重渲染的
    # 步骤之后、提交之前写,否则会被 React 回滚成默认 0(提交报「参考价不能小于等于0」)。
    # 见 set_reference_price(),由发布主流程在 zero_out_stock 之后调用。
    await edit_page.screenshot(path="D:/files/pdd_prices_filled.png", full_page=True)
    print("[价格计算] 截图: pdd_prices_filled.png")
    return count


async def fix_row_field(edit_page, spec_name: str, field: str, value, actual_value=None) -> bool:
    """按规格名精准修单行单字段。
    field: 'spec_suffix'(value=新规格名) / 'stock'(value=int) /
           'group_price'(value=float) / 'single_price'(value=float)
    用 cell text scrollIntoView + 找同行同列 input + native setter。
    避免 fill_prices 全表盲扫在虚拟列表下漏行/写错位置。
    """
    col_label_map = {
        "spec_suffix": None,           # 不按列定位,直接找 value=spec_name 的 input
        "stock": "改后库存",
        "group_price": "拼单价(元)",
        "single_price": "单买价(元)",
    }
    col_label = col_label_map.get(field)
    if field == "spec_suffix":
        # 用真键盘 keyboard.type 写入(模拟用户输入,React 不会把它当 native setter 回滚)。
        # 实测:native setter + dispatchEvent 对组合规格/短规格名/任选规格 input 提交后
        # 不被 PDD 后端保存(屏幕显示是新值但点重开编辑页又变回原值)。
        # 真键盘输入序列被 PDD 正确接受。
        try:
            # 用 JS 找所有 value === spec_name 的可编辑 input,加 data-attr 标记定位
            found = await edit_page.evaluate(f"""() => {{
                const TARGET = {spec_name!r};
                let n = 0;
                for (const inp of document.querySelectorAll('input')) {{
                    if (inp.disabled || inp.readOnly) continue;
                    if (inp.type && inp.type !== 'text') continue;
                    if ((inp.value || '').trim() !== TARGET) continue;
                    const r = inp.getBoundingClientRect();
                    if (r.width < 30 || r.height < 4) continue;
                    inp.setAttribute('data-fix-kb', String(n));
                    n++;
                }}
                return n;
            }}""")
            if not found:
                print(f"  [fix-row] spec_suffix 找不到 value={spec_name!r} 的可编辑 input")
                return False
            ok_n = 0
            for idx in range(found):
                inp_loc = edit_page.locator(f'input[data-fix-kb="{idx}"]').first
                try:
                    # scroll + click 拿 focus
                    await inp_loc.scroll_into_view_if_needed(timeout=3000)
                    await asyncio.sleep(0.2)
                    await inp_loc.click(timeout=3000)
                    await asyncio.sleep(0.2)
                    # 全选 + 删除 + 真键盘 type 新值 + Tab(blur 触发 React commit)
                    await edit_page.keyboard.press("Control+a")
                    await asyncio.sleep(0.1)
                    await edit_page.keyboard.press("Delete")
                    await asyncio.sleep(0.1)
                    await edit_page.keyboard.type(str(value), delay=25)
                    await asyncio.sleep(0.2)
                    await edit_page.keyboard.press("Tab")
                    await asyncio.sleep(0.2)
                    ok_n += 1
                except Exception as ie:
                    print(f"  [fix-row] spec_suffix input #{idx} 键盘输入异常: {ie}")
            # 清理 data-attr
            try:
                await edit_page.evaluate("""() => {
                    document.querySelectorAll('[data-fix-kb]').forEach(el => el.removeAttribute('data-fix-kb'));
                }""")
            except Exception: pass
            print(f"  [fix-row] spec_suffix spec={spec_name[:30]!r} -> 键盘输入 {ok_n}/{found} 个 input")
            return ok_n > 0
        except Exception as e:
            print(f"  [fix-row] spec_suffix 异常: {e}")
            return False

    # stock/group_price/single_price:按规格名找 cell → scrollIntoView → 同行同列 input
    res = await edit_page.evaluate(f"""async () => {{
        const NAME = {spec_name!r};
        const COL_LABEL = {col_label!r};
        const ACTUAL = {actual_value!r};
        const norm = s => (s || '').replace(/\\s+/g, ' ').trim();
        const nameN = norm(NAME);
        const direct = el => Array.from(el.childNodes || [])
            .filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
        const findHdr = () => {{
            for (const el of document.querySelectorAll('th, span, div, label')) {{
                const d = direct(el);
                if (d === COL_LABEL || d === '*' + COL_LABEL) {{
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0) return r;
                }}
            }}
            return null;
        }};
        let hdrR = findHdr();
        if (!hdrR) return {{err: 'no_header', col: COL_LABEL}};

        // PDD 有些 SKU 文本不是独立叶子节点,且底部 SKU 行要滚到附近才渲染。
        // 分段滚动搜索:先找完全等于 NAME 的最小节点;找不到再退到“包含 NAME 且文本最短”的行容器。
        let cell = null, bestScore = 1e9, bestText = '';
        const tryFindCell = () => {{
            for (const el of document.querySelectorAll('div, span, td, p, a')) {{
                const t = norm(el.innerText || '');
                if (!t || !t.includes(nameN)) continue;
                const r = el.getBoundingClientRect();
                if (r.width <= 0 || r.height <= 0) continue;
                if (t.length > 600 && t !== nameN) continue;
                const score = (t === nameN ? 0 : 10000) + t.length;
                if (score < bestScore) {{ cell = el; bestScore = score; bestText = t; }}
            }}
        }};
        const scrollTargets = (() => {{
            const doc = document.scrollingElement || document.documentElement;
            const items = [doc];
            for (const el of document.querySelectorAll('div, main, section, article')) {{
                if (el.scrollHeight > el.clientHeight + 80 && el.clientHeight > 80) items.push(el);
            }}
            const seen = new Set();
            return items.filter(el => {{
                const key = el === doc ? 'document' : `${{el.tagName}}:${{el.className}}:${{el.scrollHeight}}:${{el.clientHeight}}`;
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
            }}).slice(0, 12);
        }})();
        const positionsFor = el => {{
            const doc = document.scrollingElement || document.documentElement;
            const cur = el === doc ? window.scrollY : el.scrollTop;
            const max = Math.max(0, el.scrollHeight - el.clientHeight);
            return [...new Set([cur, 0, Math.round(max * 0.35), Math.round(max * 0.55), Math.round(max * 0.75), max])];
        }};
        const scrollToPos = (el, pos) => {{
            const doc = document.scrollingElement || document.documentElement;
            if (el === doc) window.scrollTo(0, pos);
            else {{
                el.scrollTop = pos;
                el.dispatchEvent(new Event('scroll', {{bubbles: true}}));
            }}
        }};
        for (const target of scrollTargets) {{
            for (const pos of positionsFor(target)) {{
                scrollToPos(target, pos);
                await new Promise(r => setTimeout(r, 450));
                hdrR = findHdr() || hdrR;
                tryFindCell();
                if (cell && bestScore < 10000) break;
            }}
            if (cell && bestScore < 10000) break;
        }}
        let directInp = null;
        if (!cell && ACTUAL !== null && ACTUAL !== undefined) {{
            const sameVal = (a, b) => {{
                const sa = norm(String(a));
                const sb = norm(String(b));
                if (sa === sb) return true;
                const na = Number(sa), nb = Number(sb);
                return Number.isFinite(na) && Number.isFinite(nb) && Math.abs(na - nb) < 0.01;
            }};
            const matches = [];
            for (const target of scrollTargets) {{
                for (const pos of positionsFor(target)) {{
                    scrollToPos(target, pos);
                    await new Promise(r => setTimeout(r, 350));
                    hdrR = findHdr() || hdrR;
                    const hdrCx2 = hdrR.x + hdrR.width / 2;
                    for (const inp of document.querySelectorAll('input')) {{
                        if (inp.disabled || inp.readOnly) continue;
                        const r = inp.getBoundingClientRect();
                        if (r.width < 30 || r.height < 4) continue;
                        const dx = Math.abs((r.x + r.width / 2) - hdrCx2);
                        if (dx > 90) continue;
                        if (sameVal(inp.value, ACTUAL)) matches.push(inp);
                    }}
                }}
            }}
            const uniq = [...new Set(matches)];
            if (uniq.length === 1) directInp = uniq[0];
            else if (uniq.length > 1) return {{err: 'actual_ambiguous', actual: ACTUAL, count: uniq.length}};
        }}
        if (!cell && !directInp) return {{err: 'no_cell', name: NAME}};
        if (cell) cell.scrollIntoView({{block: 'center'}});
        await new Promise(r => setTimeout(r, 800));
        hdrR = findHdr() || hdrR;
        const hdrCx = hdrR.x + hdrR.width / 2;
        let rowCy = null;
        if (cell) {{
            const cellR = cell.getBoundingClientRect();
            rowCy = cellR.y + cellR.height / 2;
        }}

        // 在该行 y±45 范围内找列头列下的 input。放宽到 45px,兼容高行/行容器。
        let bestInp = directInp, bestDx = directInp ? 0 : 9999, bestDy = directInp ? 0 : 9999;
        if (!bestInp && rowCy !== null) for (const inp of document.querySelectorAll('input')) {{
            if (inp.disabled || inp.readOnly) continue;
            const r = inp.getBoundingClientRect();
            if (r.width < 30 || r.height < 4) continue;
            const dy = Math.abs(r.y + r.height/2 - rowCy);
            if (dy > 45) continue;
            const cx = r.x + r.width / 2;
            const dx = Math.abs(cx - hdrCx);
            if (dx < bestDx || (dx === bestDx && dy < bestDy)) {{
                bestDx = dx; bestDy = dy; bestInp = inp;
            }}
        }}
        if (!bestInp) return {{err: 'no_input', matched: bestText.slice(0, 120), y: rowCy === null ? null : Math.round(rowCy)}};
        const before = bestInp.value;
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(bestInp, String({value!r}));
        bestInp.dispatchEvent(new Event('input', {{bubbles: true}}));
        bestInp.dispatchEvent(new Event('change', {{bubbles: true}}));
        await new Promise(r => setTimeout(r, 300));
        return {{ok: true, before, after: bestInp.value, matched: bestText.slice(0, 120)}};
    }}""")
    if res.get("err"):
        print(f"  [fix-row] {field} 失败 spec={spec_name[:30]!r} err={res.get('err')}")
        return False
    print(f"  [fix-row] {field} spec={spec_name[:30]!r} {res.get('before')} -> {res.get('after')}")
    return True


async def set_new_stock(edit_page, stock_value: int) -> int:
    """把编辑页「改后库存」列的每个 input 填成指定值"""
    print(f"\n[改后库存] 填入 {stock_value}")
    # 滚整页触发虚拟列表行渲染(避免 append_spec_suffix 跑完视口在底部导致顶部行被卸载)
    await edit_page.evaluate("""async () => {
        for (let y = 0; y < document.body.scrollHeight; y += 600) {
            window.scrollTo(0, y); await new Promise(r => setTimeout(r, 200));
        }
    }""")
    await asyncio.sleep(1)
    # 滚回「改后库存」列头到视口正中,让所有行 input 都在 viewport 范围
    await edit_page.evaluate("""() => {
        for (const el of document.querySelectorAll('th, span, div, label')) {
            const d = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (d === '改后库存') { el.scrollIntoView({block: 'center'}); return; }
        }
    }""")
    await asyncio.sleep(1)
    info = await edit_page.evaluate("""() => {
        const findHeader = (txt) => {
            for (const el of document.querySelectorAll('th, span, div, label')) {
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (direct === txt) {
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0) return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width)};
                }
            }
            return null;
        };
        const hdr = findHeader('改后库存');
        if (!hdr) return {error:'no_header'};
        // 不再用"顶部规格数 N"限制(滚动后顶部规格可能出视口导致 N 算错 → 漏行)。
        // 直接收「改后库存」列下方所有 input,每行一个,全部写满。
        // 拼单价列 input 总是渲染(值是小数),用它的行数兜底校验"是否漏行"。
        const range = [hdr.x - 80, hdr.x + hdr.w + 80];
        const candidates = [];
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 30) return;
            if (r.x < range[0] || r.x >= range[1]) return;
            if (r.y < hdr.y + 10) return;
            candidates.push({i, y: r.y});
        });
        candidates.sort((a,b) => a.y - b.y);
        const indices = candidates.map(c => c.i);  // 全部,不切 N
        // 拼单价列行数(参考):看漏没漏行
        let groupHdr = findHeader('拼单价(元)') || findHeader('*拼单价(元)');
        let groupRows = 0;
        if (groupHdr) {
            const grange = [groupHdr.x - 60, groupHdr.x + groupHdr.w + 60];
            document.querySelectorAll('input').forEach(inp => {
                if (inp.type && inp.type !== 'text') return;
                const r = inp.getBoundingClientRect();
                if (r.width < 30) return;
                if (r.x < grange[0] || r.x >= grange[1]) return;
                if (r.y < groupHdr.y + 10) return;
                groupRows++;
            });
        }
        return {hdr, indices, groupRows};
    }""")
    if info.get('error'):
        print(f"[!] 未找到「改后库存」列表头")
        return 0
    gr = info.get('groupRows', 0)
    n_stock = len(info['indices'])
    print(f"[改后库存] 列 x={info['hdr']['x']}  找到 {n_stock} 个库存 input"
          f"(拼单价列 {gr} 行参考)")
    if gr and n_stock < gr:
        print(f"[改后库存] ⚠ 库存 input({n_stock}) 少于价格行({gr}),可能虚拟列表漏渲染 → "
              f"verify 阶段 y 聚类兜底会补")
    # JS 直接写值,避免 Playwright click 触发 PDD「重置规格」对话框
    count = await edit_page.evaluate("""(payload) => {
        const setter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value').set;
        const all = document.querySelectorAll('input');
        let n = 0;
        for (const idx of payload.indices) {
            if (idx >= all.length) continue;
            const inp = all[idx];
            try {
                setter.call(inp, String(payload.value));
                inp.dispatchEvent(new Event('input', {bubbles:true}));
                inp.dispatchEvent(new Event('change', {bubbles:true}));
                n += 1;
            } catch(e) {}
        }
        return n;
    }""", {"indices": info['indices'], "value": stock_value})
    await asyncio.sleep(0.5)
    print(f"[改后库存] 已写 {count} 行 = {stock_value} (JS set value)")
    await edit_page.screenshot(path="D:/files/pdd_stock_set.png", full_page=True)
    print("[改后库存] 截图: pdd_stock_set.png")
    return count


async def click_edit_submit(edit_page) -> bool:
    """点击编辑页底部「提交」按钮 + 轮询确认页面出现「提交成功」"""
    print("\n[提交] 点击编辑页「提交」按钮")
    await edit_page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
    await asyncio.sleep(1)
    btn = await edit_page.evaluate("""() => {
        for (const el of document.querySelectorAll('button, [role="button"], span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '提交') {
                const r = el.getBoundingClientRect();
                if (r.width > 30 && r.width < 300 && r.height > 10)
                    return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
            }
        }
        return null;
    }""")
    if not btn:
        print("[!] 未找到「提交」按钮")
        return False
    print(f"[提交] 找到按钮 ({btn['x']},{btn['y']})")
    await edit_page.mouse.click(btn['x'], btn['y'])
    print("[提交] 已点击，轮询确认上架成功（URL 或文字双重判定）...")
    # ★二次编辑提交也会弹「轮播图/48小时发货承诺不符→确认已删除,继续提交」等拦截弹窗。
    #   原来只在首次提交处理(handle_post_submit_popups),这里没处理 → 弹窗没人点确认 → 卡住=发布失败。
    #   现复用同一处理器先点掉弹窗,再轮询成功。价格预警类返回 ok=False → 判失败。
    try:
        _pp = await handle_post_submit_popups(edit_page)
        if not _pp.get("ok"):
            print(f"[提交] ❌ 二次编辑拦截弹窗未通过: {_pp.get('reason')}")
            return False
    except Exception as _e:
        print(f"[提交] 弹窗处理异常(继续轮询): {_e}")
    # 轮询最多 30 秒：URL 含 goods_add/success 或文字含「提交成功」
    success = False
    for i in range(30):
        await asyncio.sleep(1)
        # ★每轮都点掉「确认已删除,继续提交」等拦截弹窗——此弹窗常在点提交后【数秒才弹】,
        #   上面 handle_post_submit_popups 那次窗口(~7.5s)可能已过,所以轮询里持续盯着点。
        try:
            _bp = await edit_page.evaluate("""() => {
                for (const el of document.querySelectorAll('button, div, span')) {
                    const t = (el.innerText || '').trim();
                    if (t === '确认已删除，继续提交' || t === '确认已删除,继续提交'
                        || t === '确认提交' || t === '继续提交') {
                        const r = el.getBoundingClientRect();
                        if (r.width > 0 && r.width < 400 && r.height > 0 && r.y >= 0)
                            return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
                    }
                }
                return null;
            }""")
            if _bp:
                await edit_page.mouse.click(_bp["x"], _bp["y"])
                print(f"[提交] 轮询中点掉拦截弹窗「确认已删除,继续提交」({_bp['x']},{_bp['y']})")
        except Exception:
            pass
        try:
            url = edit_page.url
        except Exception:
            url = ""
        if "goods_add/success" in url:
            success = True
            print(f"[提交] ✅ URL 跳转到 success 页（耗时 {i+1}s, url={url[:80]}）")
            break
        try:
            has_text = await edit_page.evaluate("""() => {
                const t = document.body.innerText || '';
                return t.includes('提交成功');
            }""")
        except Exception:
            has_text = False
        if has_text:
            success = True
            print(f"[提交] ✅ 检测到「提交成功」文字（耗时 {i+1}s）")
            break
    if not success:
        print(f"[提交] [!] 30 秒内未确认上架成功，URL={edit_page.url[:120]}")
    try:
        await edit_page.screenshot(path="D:/files/pdd_edit_after_submit.png", full_page=True)
    except Exception:
        pass
    return success


async def click_edit_goods(detail_page, light=False):
    """商品详情页 → 点击「编辑商品」，返回编辑表单页（不要刷新，刷新后按钮会消失）"""
    print("\n[编辑商品] 不刷新，直接找按钮（刷新会让按钮消失）...")
    await asyncio.sleep(2)
    # 列出所有含「编辑」文字的可见元素调试
    candidates = await detail_page.evaluate("""() => {
        const out = [];
        document.querySelectorAll('button, [role="button"], a, span, div').forEach(el => {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct.includes('编辑') && direct.length < 20) {
                const r = el.getBoundingClientRect();
                if (r.width > 20 && r.height > 10 && r.width < 200)
                    out.push({txt: direct, tag: el.tagName, cls: (el.className||'').slice(0,60), x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height)});
            }
        });
        return out;
    }""")
    print(f"[编辑商品] 含「编辑」的可见元素 {len(candidates)} 个:")
    for c in candidates[:15]:
        print(f"  {c['tag']} '{c['txt']}' ({c['x']},{c['y']}) {c['w']}x{c['h']}")
    # 优先精确匹配「编辑商品」，否则用「编辑」
    found = next((c for c in candidates if c['txt'] == '编辑商品'), None) \
        or next((c for c in candidates if c['txt'] == '编辑'), None)
    if not found:
        print("[!] 未找到「编辑商品」按钮")
        await detail_page.screenshot(path="D:/files/pdd_no_edit_btn.png", full_page=True)
        return detail_page
    btn = {'x': found['x'] + found['w']//2, 'y': found['y'] + found['h']//2}
    # 用 JS 找到该 SPAN 的父级 button/a 并直接 .click()，避免 SPAN 不响应
    await detail_page.evaluate(f"""() => {{
        const els = document.querySelectorAll('button, [role="button"], a, span, div');
        for (const el of els) {{
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === {found['txt']!r}) {{
                let target = el;
                // 沿父链找最近的 button/a
                let p = el;
                for (let i = 0; i < 5 && p; i++) {{
                    if (p.tagName === 'BUTTON' || p.tagName === 'A') {{ target = p; break; }}
                    p = p.parentElement;
                }}
                target.click();
                return;
            }}
        }}
    }}""")
    print(f"[编辑商品] 找到按钮 ({btn['x']},{btn['y']})  等待新 Tab...")
    try:
        async with detail_page.context.expect_event("page", timeout=(2500 if light else 8000)) as page_info:
            await detail_page.mouse.click(btn['x'], btn['y'])
        edit_page = await page_info.value
        await edit_page.wait_for_load_state("domcontentloaded", timeout=15000)
        await asyncio.sleep(3)
        print(f"[编辑商品] 新 Tab url: {edit_page.url[:120]}")
    except Exception as e:
        print(f"[编辑商品] 未捕获新 Tab ({e})，使用原 page")
        await asyncio.sleep(3)
        edit_page = detail_page
        print(f"[编辑商品] 原 page url: {edit_page.url[:120]}")
    # 换主图(light)只动顶部轮播图,不碰规格表 → 跳过 reload/滚整页/截图,直接返回(快)
    if light:
        await asyncio.sleep(1)
        return edit_page
    # 强制 reload 清 react state(否则编辑页 input value 残留上次未提交的脏数据)
    # 实测:不 reload 会拿到上次 fill_prices 写错的 11.62,导致后续提交失败
    try:
        await edit_page.reload(wait_until="domcontentloaded", timeout=20000)
    except Exception as e:
        print(f"[编辑商品] reload 异常(继续): {e}")
    await asyncio.sleep(5)
    # 滚整页触发虚拟列表全行渲染(13 行多规格场景必须)
    try:
        await edit_page.evaluate("""async () => {
            for (let y = 0; y < document.body.scrollHeight; y += 600) {
                window.scrollTo(0, y); await new Promise(r => setTimeout(r, 300));
            }
        }""")
    except Exception:
        pass
    await asyncio.sleep(2)
    await edit_page.screenshot(path="D:/files/pdd_edit_page.png", full_page=True)
    print("[编辑商品] 截图: pdd_edit_page.png (已 reload + 滚整页)")
    return edit_page


def _strip_banned_words(name: str) -> str:
    """去掉 PDD 审核违禁词:规格名含「赠品」会被驳回(要求用官方"下单送赠品"活动)。
    这类词从复制的同款规格名带进来(如「【体验装】1瓶 无赠品」),补后缀时清掉,
    否则第二段编辑提交会被驳回 → 库存/后缀都存不进去(踩过 967298527552)。
    只清「(无/有/含/不/送/加)?赠品」,不动「送」(买N送M 是真份数,且未被驳回)。"""
    import re as _re
    if not name:
        return name
    s = _re.sub(r"[（(]?\s*[无有含不送加]?\s*赠\s*品\s*[）)]?", "", name)
    s = _re.sub(r"[【\[（(]\s*[】\]）)]", "", s)   # 去掉清空后残留的空括号【】()
    s = _re.sub(r"\s{2,}", " ", s).strip(" +＋·、,，")
    return s or name   # 万一清空,退回原名


async def append_spec_suffix(form_page, suffix: str) -> int:
    """给所有规格值（含中文、不含纯数字小数）追加 suffix（先清「赠品」违禁词,防编辑被驳回）。
    用 native setter + dispatchEvent 触发 React/Vue 状态更新。
    """
    print(f"\n[规格-追加] 给所有规格值追加 {suffix!r}")
    # 先滚整页触发虚拟列表渲染,确保所有规格行 input 都被渲染
    # (编辑页规格表是虚拟滚动,初始视口外的行 input 不渲染 → 漏行)
    await form_page.evaluate("""async () => {
        for (let y = 0; y < document.body.scrollHeight; y += 600) {
            window.scrollTo(0, y); await new Promise(r => setTimeout(r, 200));
        }
    }""")
    await asyncio.sleep(1)
    # 每轮重新查找尚未追加 suffix 的 input（避免 React 重渲染后 handle 失效）
    count = 0
    for iteration in range(15):
        target_val = await form_page.evaluate(f"""() => {{
            let anchor = null;
            for (const el of document.querySelectorAll('label, span, div')) {{
                const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
                if (direct === '商品规格') {{ anchor = el; break; }}
            }}
            if (!anchor) return null;
            const ar = anchor.getBoundingClientRect();
            // 屏蔽 PDD 顶部 readonly 标签 input(如「规格类型1」value=「包装规格」/ 「颜色」等)
            const NOISE_VAL = /^(包装规格|颜色|规格|款式|规格类型|规格编码|总库存)$/;
            for (const inp of document.querySelectorAll('input')) {{
                if (inp.type && inp.type !== 'text') continue;
                if (inp.readOnly || inp.disabled) continue;  // 跳过 readonly/disabled
                const v = (inp.value || '').trim();
                if (!v || v.length < 3) continue;
                if (!/[\\u4e00-\\u9fa5]/.test(v)) continue;
                if (v === '全部颜色') continue;
                if (NOISE_VAL.test(v)) continue;             // PDD 顶部标签
                if (v.endsWith({suffix!r})) continue;
                const r = inp.getBoundingClientRect();
                if (r.y < ar.y - 20 || r.y > ar.y + 250) continue;
                if (r.width < 50) continue;
                return v;
            }}
            return null;
        }}""")
        if not target_val:
            break
        new_val = _strip_banned_words(target_val) + suffix
        # 用 value 选择器定位(避免索引失效);加 5s 超时避免误中 readonly input 卡 30s
        try:
            esc = target_val.replace('"', '\\"')
            loc = form_page.locator(f'input[value="{esc}"]').first
            await loc.fill(new_val, timeout=5000)
            await asyncio.sleep(0.5)
            print(f"  [{iteration+1}] {target_val!r} -> {new_val!r}")
            count += 1
        except Exception as e:
            print(f"  [!] fill 失败 ({target_val!r}): {e}")
            # 不 break,继续尝试下一个(避免卡死)
            continue
    print(f"[规格-追加] 成功修改 {count} 个规格值")
    await asyncio.sleep(1)
    await form_page.screenshot(path="D:/files/pdd_specs_appended.png", full_page=True)
    print("[规格-追加] 截图: pdd_specs_appended.png")
    return count




async def capture_product_attrs_for_package_label(form_page, out_path: str) -> bool:
    """Capture the visible 商品属性 section at normal scale for upload."""
    print("[属性截图] 正常比例截取商品属性板块...")
    setup = await form_page.evaluate("""() => {
        function directText(el) {
            return Array.from(el.childNodes).filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
        }
        function rectOf(el) {
            const r = el.getBoundingClientRect();
            if (r.width <= 0 || r.height <= 0) return null;
            return r;
        }
        function findText(text) {
            const matches = [];
            for (const el of document.querySelectorAll('label, span, div, td, th')) {
                if (directText(el) === text) {
                    const r = rectOf(el);
                    if (r) matches.push({el, r});
                }
            }
            if (!matches.length) return null;
            const main = matches.find(x => x.r.left > 240);
            return (main || matches[0]).el;
        }
        function findContains(texts) {
            const matches = [];
            for (const el of document.querySelectorAll('label, span, div, td, th')) {
                const t = directText(el);
                if (texts.some(x => t.includes(x))) {
                    const r = rectOf(el);
                    if (r) matches.push({el, r});
                }
            }
            if (!matches.length) return null;
            const main = matches.find(x => x.r.left > 240);
            return (main || matches[0]).el;
        }
        function nearestScrollParent(el) {
            let cur = el ? el.parentElement : null;
            while (cur && cur !== document.body) {
                const st = getComputedStyle(cur);
                if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && cur.scrollHeight > cur.clientHeight + 80) return cur;
                cur = cur.parentElement;
            }
            return document.scrollingElement || document.documentElement;
        }
        const titleAnchor = findText('商品属性');
        const fillAnchor = findContains(['填写率', '请准确填写属性']);
        const anchor = fillAnchor || titleAnchor;
        if (!anchor) return {ok: false, reason: '未找到商品属性标题/填写率'};
        const scroller = nearestScrollParent(anchor);
        const isDoc = scroller === document.scrollingElement || scroller === document.documentElement;
        const oldScrollTop = isDoc ? window.scrollY : scroller.scrollTop;
        const oldScrollBehavior = document.documentElement.style.scrollBehavior || '';
        document.documentElement.style.scrollBehavior = 'auto';
        anchor.scrollIntoView({block: 'start', inline: 'nearest'});
        const ar = anchor.getBoundingClientRect();
        const sr = scroller.getBoundingClientRect ? scroller.getBoundingClientRect() : {top: 0};
        const desiredTop = fillAnchor ? Math.min(window.innerHeight * 0.36, 260) : Math.max(8, (sr.top || 0) + 10);
        const delta = ar.top - desiredTop;
        if (isDoc) window.scrollTo(0, Math.max(0, window.scrollY + delta));
        else scroller.scrollTop = Math.max(0, scroller.scrollTop + delta);
        return {ok: true, oldScrollTop, oldScrollBehavior, isDocumentScroller: isDoc};
    }""")
    if not setup or not setup.get("ok"):
        print(f"[属性截图][!] {setup.get('reason') if setup else '定位失败'}")
        return False

    try:
        await asyncio.sleep(0.35)
        rect = await form_page.evaluate("""() => {
            function directText(el) {
                return Array.from(el.childNodes).filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
            }
            function rectOf(el) {
                const r = el.getBoundingClientRect();
                if (r.width <= 0 || r.height <= 0) return null;
                return r;
            }
            function findText(text) {
                const matches = [];
                for (const el of document.querySelectorAll('label, span, div, td, th')) {
                    if (directText(el) === text) {
                        const r = rectOf(el);
                        if (r) matches.push({el, r});
                    }
                }
                if (!matches.length) return null;
                const main = matches.find(x => x.r.left > 240);
                return (main || matches[0]).el;
            }
            function findAnyText(texts) {
                for (const el of document.querySelectorAll('label, span, div, td, th')) {
                    const t = directText(el);
                    if (texts.includes(t)) {
                        const r = rectOf(el);
                        if (r) return el;
                    }
                }
                return null;
            }
            function findContains(texts) {
                const matches = [];
                for (const el of document.querySelectorAll('label, span, div, td, th')) {
                    const t = directText(el);
                    if (texts.some(x => t.includes(x))) {
                        const r = rectOf(el);
                        if (r) matches.push({el, r});
                    }
                }
                if (!matches.length) return null;
                const main = matches.find(x => x.r.left > 240);
                return (main || matches[0]).el;
            }
            let titleAnchor = findText('商品属性');
            let anchor = findContains(['填写率', '请准确填写属性']) || titleAnchor;
            let packageLabel = findAnyText(['包装标签图', '*包装标签图']);
            if (!anchor) return {ok: false, reason: '未找到商品属性标题/填写率'};
            if (!packageLabel) return {ok: false, reason: '未找到包装标签图字段'};
            function hasNewSidePanel() {
                for (const el of document.querySelectorAll('label, span, div')) {
                    const t = directText(el);
                    if (t === '商品填写建议' || t === '发布助手') {
                        const r = rectOf(el);
                        if (r && r.left < 260 && r.top > 80) return true;
                    }
                }
                return false;
            }
            function findAttrPanel(anchorEl) {
                let best = null;
                let cur = anchorEl ? anchorEl.parentElement : null;
                while (cur && cur !== document.body) {
                    const r = rectOf(cur);
                    if (r && r.width > 760 && r.height > 260 && r.left >= 0 && r.right <= window.innerWidth + 8) {
                        best = r;
                    }
                    cur = cur.parentElement;
                }
                return best;
            }
            function visibleAttrBottom() {
                let bottom = 0;
                const keys = ['品牌', '功能', '质地', '规格类型', '产地', '生产日期', '保质期', '适用人群', '包装方式', '化妆品批准文号'];
                for (const el of document.querySelectorAll('label, span, div')) {
                    const t = directText(el).replace(/^\\*/, '').trim();
                    if (!keys.some(k => t === k || t.includes(k))) continue;
                    const r = rectOf(el);
                    if (r && r.bottom > 0 && r.top < window.innerHeight) bottom = Math.max(bottom, r.bottom);
                }
                return bottom;
            }
            function nearestScrollParent(el) {
                let cur = el ? el.parentElement : null;
                while (cur && cur !== document.body) {
                    const st = getComputedStyle(cur);
                    if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && cur.scrollHeight > cur.clientHeight + 80) return cur;
                    cur = cur.parentElement;
                }
                return document.scrollingElement || document.documentElement;
            }
            const scroller = nearestScrollParent(anchor);
            const isDoc = scroller === document.scrollingElement || scroller === document.documentElement;
            const bottomLimit = window.innerHeight - 95;
            let ar = anchor.getBoundingClientRect();
            let pr = packageLabel.getBoundingClientRect();
            if (ar && pr && pr.top >= bottomLimit && hasNewSidePanel()) {
                let top = Math.max(0, ar.top - 28);
                for (const el of document.querySelectorAll('label, span, div')) {
                    const t = directText(el);
                    if (t.includes('填写率') || t.includes('请准确填写属性')) {
                        const r = rectOf(el);
                        if (r && r.bottom > 0 && r.top < window.innerHeight) top = Math.max(0, Math.min(top, r.top - 18));
                    }
                }
                const panel = findAttrPanel(anchor);
                const visibleBottom = visibleAttrBottom();
                let bottom = Math.max(visibleBottom + 38, pr.top + 95, ar.bottom + 430);
                const height = Math.round(bottom - top);
                if (height >= 420) {
                    const left = panel && panel.left > 180 ? Math.max(0, Math.round(panel.left - 8)) : Math.max(240, Math.round(ar.left - 120));
                    const right = panel && panel.right > left + 640 ? Math.min(window.innerWidth, Math.round(panel.right + 8)) : window.innerWidth;
                    return {
                        ok: true,
                        layout: 'new-sidebar-before-package-scroll-docclip',
                        docClip: true,
                        x: Math.round(window.scrollX + left),
                        y: Math.round(window.scrollY + top),
                        width: Math.max(640, right - left),
                        height,
                        packageTop: Math.round(pr.top),
                        viewportH: window.innerHeight
                    };
                }
                return {ok: false, reason: '新版商品属性初始可见区域高度异常', height, packageTop: Math.round(pr.top), viewportH: window.innerHeight};
            }
            if (pr.top >= bottomLimit) {
                const delta = pr.top - bottomLimit + 20;
                if (isDoc) window.scrollTo(0, Math.max(0, window.scrollY + delta));
                else scroller.scrollTop = Math.max(0, scroller.scrollTop + delta);
                titleAnchor = findText('商品属性');
                anchor = findContains(['填写率', '请准确填写属性']) || titleAnchor;
                packageLabel = findAnyText(['包装标签图', '*包装标签图']);
                ar = anchor ? anchor.getBoundingClientRect() : null;
                pr = packageLabel ? packageLabel.getBoundingClientRect() : null;
            }
            if (ar && pr && pr.top >= window.innerHeight - 40 && hasNewSidePanel()) {
                let top = Math.max(0, ar.top - 28);
                for (const el of document.querySelectorAll('label, span, div')) {
                    const t = directText(el);
                    if (t.includes('填写率') || t.includes('请准确填写属性')) {
                        const r = rectOf(el);
                        if (r && r.bottom > 0 && r.top < window.innerHeight) top = Math.max(0, Math.min(top, r.top - 18));
                    }
                }
                const panel = findAttrPanel(anchor);
                const visibleBottom = visibleAttrBottom();
                let bottom = Math.min(bottomLimit, Math.max(visibleBottom + 38, ar.bottom + 360));
                if (panel) {
                    top = Math.max(0, Math.min(top, panel.top - 8));
                    bottom = Math.min(bottom, panel.bottom + 8, bottomLimit);
                }
                const height = Math.round(bottom - top);
                if (height >= 360) {
                    const left = panel && panel.left > 180 ? Math.max(0, Math.round(panel.left - 8)) : Math.max(240, Math.round(ar.left - 120));
                    const right = panel && panel.right > left + 640 ? Math.min(window.innerWidth, Math.round(panel.right + 8)) : window.innerWidth;
                    return {
                        ok: true,
                        layout: 'new-sidebar-attr-visible',
                        x: left,
                        y: Math.round(top),
                        width: Math.max(640, right - left),
                        height,
                        packageTop: Math.round(pr.top),
                        viewportH: window.innerHeight
                    };
                }
                return {ok: false, reason: '新版商品属性可见区域高度异常', height, packageTop: Math.round(pr.top), viewportH: window.innerHeight};
            }
            if (!ar || !pr || !(pr.top > ar.top && pr.top < window.innerHeight - 40)) {
                return {ok: false, reason: '包装标签图仍不在当前视口，正常比例一屏截不全', packageTop: pr ? Math.round(pr.top) : null, viewportH: window.innerHeight};
            }
            let top = Math.max(0, ar.top - 18);
            for (const el of document.querySelectorAll('label, span, div')) {
                const t = directText(el);
                if (t.includes('填写率') || t.includes('请准确填写属性')) {
                    const r = rectOf(el);
                    if (r && r.bottom > 0 && r.top < window.innerHeight) top = Math.max(0, Math.min(top, r.top - 18));
                }
            }
            let bottom = Math.min(bottomLimit, pr.top + 95);
            const height = Math.round(bottom - top);
            if (height < 460 && hasNewSidePanel()) {
                let ntop = Math.max(0, ar.top - 28);
                for (const el of document.querySelectorAll('label, span, div')) {
                    const t = directText(el);
                    if (t.includes('填写率') || t.includes('请准确填写属性')) {
                        const r = rectOf(el);
                        if (r && r.bottom > 0 && r.top < window.innerHeight) ntop = Math.max(0, Math.min(ntop, r.top - 18));
                    }
                }
                const panel = findAttrPanel(anchor);
                const visibleBottom = visibleAttrBottom();
                let nbottom = Math.min(bottomLimit, Math.max(visibleBottom + 38, ar.bottom + 360, bottom));
                if (panel) {
                    ntop = Math.max(0, Math.min(ntop, panel.top - 8));
                    nbottom = Math.min(nbottom, panel.bottom + 8, bottomLimit);
                }
                const nheight = Math.round(nbottom - ntop);
                if (nheight >= 360) {
                    const left = panel && panel.left > 180 ? Math.max(0, Math.round(panel.left - 8)) : Math.max(240, Math.round(ar.left - 120));
                    const right = panel && panel.right > left + 640 ? Math.min(window.innerWidth, Math.round(panel.right + 8)) : window.innerWidth;
                    return {
                        ok: true,
                        layout: 'new-sidebar-height-fallback',
                        x: left,
                        y: Math.round(ntop),
                        width: Math.max(640, right - left),
                        height: nheight,
                        oldHeight: height,
                        packageTop: Math.round(pr.top),
                        viewportH: window.innerHeight
                    };
                }
                return {ok: false, reason: '新版商品属性可见区域高度异常', height: nheight, oldHeight: height, packageTop: Math.round(pr.top), viewportH: window.innerHeight};
            }
            if (height < 460) return {ok: false, reason: '商品属性截图高度异常', height};
            return {ok: true, x: 0, y: Math.round(top), width: Math.round(window.innerWidth), height};
        }""")
        if not rect or not rect.get("ok"):
            print(f"[属性截图][!] {rect.get('reason') if rect else '截图区域定位失败'}")
            return False
        clip_kind = "doc-clip" if rect.get("docClip") else "viewport-clip"
        print(f"[属性截图] {clip_kind}={rect} ratio={rect['width']}x{rect['height']}")
        shot_clip = {"x": rect["x"], "y": rect["y"], "width": rect["width"], "height": rect["height"]}
        if rect.get("docClip"):
            await form_page.evaluate("""() => {
                window.__probeHiddenFixed = [];
                for (const el of document.querySelectorAll('body *')) {
                    const st = getComputedStyle(el);
                    if (st.position !== 'fixed' && st.position !== 'sticky') continue;
                    const r = el.getBoundingClientRect();
                    if (r.width > 300 && r.height > 30 && r.height < 180 && r.bottom > window.innerHeight - 160) {
                        window.__probeHiddenFixed.push([el, el.style.visibility]);
                        el.style.visibility = 'hidden';
                    }
                }
            }""")
            try:
                await form_page.screenshot(path=out_path, full_page=True, clip=shot_clip)
            finally:
                await form_page.evaluate("""() => {
                    for (const item of (window.__probeHiddenFixed || [])) {
                        item[0].style.visibility = item[1] || '';
                    }
                    window.__probeHiddenFixed = [];
                }""")
        else:
            await form_page.screenshot(path=out_path, clip=shot_clip)
    finally:
        await form_page.evaluate("""(state) => {
            function directText(el) {
                return Array.from(el.childNodes).filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
            }
            function findText(text) {
                for (const el of document.querySelectorAll('label, span, div, td, th')) {
                    if (directText(el) === text) return el;
                }
                return null;
            }

            function nearestScrollParent(el) {
                let cur = el ? el.parentElement : null;
                while (cur && cur !== document.body) {
                    const st = getComputedStyle(cur);
                    if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && cur.scrollHeight > cur.clientHeight + 80) return cur;
                    cur = cur.parentElement;
                }
                return document.scrollingElement || document.documentElement;
            }
            const anchor = findText('商品属性');
            if (!anchor) return;
            const scroller = nearestScrollParent(anchor);
            if (state.isDocumentScroller) window.scrollTo(0, state.oldScrollTop || 0);
            else if (scroller) scroller.scrollTop = state.oldScrollTop || 0;
            document.documentElement.style.scrollBehavior = state.oldScrollBehavior || '';
        }""", setup)

    size = Path(out_path).stat().st_size
    print(f"[属性截图] 已保存原图: {out_path}  size={size/1024:.0f}KB")
    if size >= 3 * 1024 * 1024:
        print("[属性截图][!] 原图超过 3MB")
        return False
    return True
async def upload_package_label(form_page, image_path: str) -> bool:
    """把当前表单的商品属性截图上传到「*包装标签图」字段。"""
    # 部分类目没有包装标签图字段：该字段不适用时跳过，保留后续既有上传失败重试逻辑。
    field_exists = await form_page.evaluate("""() => {
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes)
                .filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
            if (direct.replace(/^[*]/, '') === '包装标签图') return true;
        }
        return false;
    }""")
    if not field_exists:
        print("[包装标签图] 当前类目未配置该字段，跳过上传")
        return True

    OUT_DIR = APP_DIR / "data" / "pdd" / "publish_logs"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    attr_image_path = OUT_DIR / f"attr_package_label_{time.strftime('%Y%m%d_%H%M%S')}.png"
    print(f"\n[包装标签图] 生成商品属性截图: {attr_image_path}")
    if not await capture_product_attrs_for_package_label(form_page, str(attr_image_path)):
        print("[包装标签图][!] 商品属性截图失败，停止上传包装标签图")
        return False
    image_path = str(attr_image_path)
    print(f"[包装标签图] 上传属性截图: {image_path}")
    # 1) 滚动到「包装标签图」label 位置
    label_pos = await form_page.evaluate("""() => {
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '包装标签图') {
                el.scrollIntoView({block: 'center'});
                const r = el.getBoundingClientRect();
                return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height)};
            }
        }
        return null;
    }""")
    if not label_pos:
        print("[!] 未找到「包装标签图」字段")
        return False
    print(f"[包装标签图] 找到 label 位置: ({label_pos['x']},{label_pos['y']})")
    await asyncio.sleep(1)

    # 2) 在 label 附近找 input[type=file]（label 之下/之右，y > label.y - 10）
    file_inputs = await form_page.query_selector_all('input[type="file"]')
    print(f"[包装标签图] 页面共 {len(file_inputs)} 个 file input")
    # 在 JS 中找位置最接近 label 的 file input 的索引
    best_idx = await form_page.evaluate("""() => {
        let label = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '包装标签图') { label = el; break; }
        }
        if (!label) return -1;
        const lr = label.getBoundingClientRect();
        const inputs = document.querySelectorAll('input[type="file"]');
        let bestIdx = -1, bestDist = Infinity;
        inputs.forEach((inp, i) => {
            // 沿父链找一个可见的容器（offsetWidth > 30）
            let p = inp;
            while (p && p.offsetWidth < 30 && p.parentElement) p = p.parentElement;
            if (!p) return;
            const pr = p.getBoundingClientRect();
            // 容器需在 label 右侧或下方 200px 范围内
            const dx = pr.x - lr.x;
            const dy = pr.y - lr.y;
            if (dy >= -20 && dy < 200 && dx >= -50 && dx < 400) {
                const dist = Math.abs(dx) + Math.abs(dy);
                if (dist < bestDist) { bestDist = dist; bestIdx = i; }
            }
        });
        return bestIdx;
    }""")
    print(f"[包装标签图] 邻近匹配的 file input 索引: {best_idx}")
    if best_idx < 0 or best_idx >= len(file_inputs):
        print("[!] 未找到「包装标签图」对应的 file input")
        return False
    target_input = file_inputs[best_idx]
    if not target_input:
        print("[!] 未找到「包装标签图」对应的 file input")
        return False

    await target_input.set_input_files(image_path)
    print("[包装标签图] 已上传图片，等待处理...")
    await asyncio.sleep(4)
    await form_page.screenshot(path="D:/files/pdd_package_label.png", full_page=True)
    print("[包装标签图] 截图: pdd_package_label.png")
    try:
        attr_image_path.unlink(missing_ok=True)
        print(f"[包装标签图] 已删除临时属性截图: {attr_image_path}")
    except Exception as e:
        print(f"[包装标签图][!] 临时属性截图删除失败(忽略): {e}")
    return True


# 抓 1688 货源页 skuModel(供「核对批准文号」时顺手取规格料,喂自定义SKU路)。
# 沿用 parse_sku_material.py 验证脚本里实测通过的 walk:找 dataJson.skuModel(含 skuProps)。
_SKU_MODEL_JS = r"""() => {
  let skuModel = null;
  const seen = new Set();
  function walk(o, depth){
    if(!o || typeof o!=='object' || depth>7) return;
    if(seen.has(o)) return; seen.add(o);
    if(skuModel) return;
    for(const k of Object.keys(o)){
      if(k==='skuModel' && o[k] && o[k].skuProps){ skuModel = o[k]; return; }
    }
    for(const k of Object.keys(o)){
      let v; try{v=o[k];}catch(e){continue;}
      if(v && typeof v==='object') walk(v, depth+1);
      if(skuModel) return;
    }
  }
  try{ walk(window.context, 0); }catch(e){}
  return skuModel;
}"""


def parse_sku_material(sku_model: dict, offer_url: str = "") -> dict:
    """把 1688 货源页 skuModel 解析成「自定义SKU路」可直接填的料。

    逻辑已在一次性脚本 parse_sku_material.py 对 1层/2层 多条真实货源实测通过:
      - 多维 specAttrs 分隔符靠"维度值集合归属"自动探测(1688 实测是 `&gt;`),不写死;
      - 取价两级:skuInfoMap[*].discountPrice 优先,缺失回退 offer 级 skuPriceScale
        (单值/区间取最低;不加会出现 price=0 → 上架0元)。
    返回 {offer_id, dim_count, dims:[{name,values:[{name,imageUrl}]}], sep,
          sku_count, skus:[{specAttrs,parts,matched,price,price_src,stock,skuId,specId}]}
    sku_model 空/异常 → 返回 {}(调用方按"无料"处理,绝不抛)。
    """
    import re as _re
    if not isinstance(sku_model, dict) or not sku_model.get("skuProps"):
        return {}

    def _n(v):
        try:
            m = _re.search(r"[\d]+(?:\.[\d]+)?", str(v))
            return float(m.group(0)) if m else 0.0
        except Exception:
            return 0.0

    try:
        mid = _re.search(r"/offer/(\d+)", offer_url or "")
        offer_id = mid.group(1) if mid else ""

        dims = []
        for p in (sku_model.get("skuProps") or []):
            vals = [{"name": str(v.get("name") or "").strip(),
                     "imageUrl": str(v.get("imageUrl") or "").strip()}
                    for v in (p.get("value") or [])]
            dims.append({"name": str(p.get("prop") or "").strip(), "values": vals})
        # 每维值名按长度降序,优先匹配最长(防一个值是另一个的子串)
        dim_val_names = [sorted([x["name"] for x in d["values"] if x["name"]],
                                key=len, reverse=True) for d in dims]

        # offer 级兜底价
        scale_price = 0.0
        nums = _re.findall(r"[\d]+(?:\.[\d]+)?", str(sku_model.get("skuPriceScale") or ""))
        if nums:
            scale_price = min(float(n) for n in nums)

        skus = []
        sep_votes = {}
        for spec_attrs, meta in (sku_model.get("skuInfoMap") or {}).items():
            spec_attrs = str(spec_attrs).strip()
            parts, ok = [], True
            for names in dim_val_names:
                hit = next((n for n in names if n and n in spec_attrs), None)
                if hit is None:
                    ok = False
                    parts.append("")
                else:
                    parts.append(hit)
            if ok and len(parts) >= 2:
                resid = spec_attrs
                for hit in parts:
                    resid = resid.replace(hit, "\x00", 1)
                for piece in resid.split("\x00"):
                    piece = piece.strip()
                    if piece:
                        sep_votes[piece] = sep_votes.get(piece, 0) + 1
            dp = _n(meta.get("discountPrice"))
            skus.append({
                "specAttrs": spec_attrs, "parts": parts, "matched": ok,
                "price": dp or scale_price,
                "price_src": "discountPrice" if dp else ("skuPriceScale" if scale_price else "none"),
                "stock": int(_n(meta.get("canBookCount"))),
                "skuId": meta.get("skuId"), "specId": meta.get("specId"),
            })

        sep = max(sep_votes, key=sep_votes.get) if sep_votes else ("" if len(dims) <= 1 else "?")
        return {
            "offer_url": offer_url, "offer_id": offer_id,
            "dim_count": len(dims), "dims": dims,
            "sep": sep, "sku_count": len(skus), "skus": skus,
        }
    except Exception as e:
        print(f"[skuModel] 解析异常(忽略): {e}")
        return {}


_SUPPLIER_OFFER_TITLE_JS = r"""() => {
    const clean = v => (v || '').replace(/\s+/g, ' ').trim()
        .replace(/\s*[-|\uff5c]\s*(?:\u8d77\u6279|1688).*$/i, '').trim();
    const company = /(?:\u6709\u9650\u516c\u53f8|\u516c\u53f8|\u5b9e\u4e1a|\u751f\u7269\u79d1\u6280|\u5546\u8d38|\u5de5\u5382)$/;
    const valid = value => value && value.length >= 4 && value.length <= 180 && !company.test(value);
    const selectors = ['[class*="offer-title"]', '[class*="detail-title"]', '[class*="product-title"]', '[class*="title"] h1', 'h1'];
    for (const sel of selectors) {
        for (const el of document.querySelectorAll(sel)) {
            const value = clean(el.innerText || el.textContent);
            if (valid(value)) return value;
        }
    }
    for (const sel of ['meta[property="og:title"]', 'meta[name="title"]']) {
        const el = document.querySelector(sel);
        const value = clean(el && el.content);
        if (valid(value)) return value;
    }
    const pageTitle = clean(document.title);
    return valid(pageTitle) ? pageTitle : '';
}"""


async def read_supplier_offer_title(context, supplier_url: str) -> str:
    """Read only the 1688 offer title for spec-code name fallback."""
    url = (supplier_url or "").strip()
    if not url:
        return ""
    sup_page = await context.new_page()
    try:
        await sup_page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(2)
        title = (await sup_page.evaluate(_SUPPLIER_OFFER_TITLE_JS) or "").strip()
        if title:
            print(f"[spec-code] supplier title fallback: {title[:80]}")
        return title
    finally:
        await sup_page.close()

async def scrape_supplier_attrs(context, supplier_url: str) -> dict:
    """打开 1688 供应商详情页，抓取「是否特殊化妆品」和「化妆品批准文号」属性
    返回 {'is_special': '是'/'否'/'', 'license_no': '...', 'all_attrs': {...},
          'sku_material': {...}}  (sku_material = 顺手抓的 1688 规格料,供自定义SKU路;无则 {})
    """
    print(f"\n[供应商] 打开页面: {supplier_url[:80]}")
    sup_page = await context.new_page()
    try:
        await sup_page.goto(supplier_url, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(4)
        # 触发懒加载（属性区通常在页面下方）
        await sup_page.evaluate("""async () => {
            const h = document.body.scrollHeight;
            for (let y = 0; y < h; y += 800) {
                window.scrollTo(0, y);
                await new Promise(r => setTimeout(r, 300));
            }
            window.scrollTo(0, 0);
        }""")
        await asyncio.sleep(2)
        # 1688 属性区通常是 dt/dd 或 th/td 表格
        attrs = await sup_page.evaluate("""() => {
            const out = {};
            // 模式 1：dl > dt + dd
            document.querySelectorAll('dl').forEach(box => {
                const dts = box.querySelectorAll('dt');
                const dds = box.querySelectorAll('dd');
                for (let i = 0; i < Math.min(dts.length, dds.length); i++) {
                    const k = (dts[i].innerText || '').trim().replace(/[:：]$/, '');
                    const v = (dds[i].innerText || '').trim();
                    if (k && v && k.length < 30) out[k] = v;
                }
            });
            // 模式 2：表格 — 每行可能是 [k1,v1,k2,v2,...]
            document.querySelectorAll('tr').forEach(tr => {
                const cells = tr.querySelectorAll('th, td');
                for (let i = 0; i + 1 < cells.length; i += 2) {
                    const k = (cells[i].innerText || '').trim().replace(/[:：]$/, '');
                    const v = (cells[i+1].innerText || '').trim();
                    if (k && v && k.length < 30 && v.length < 200) out[k] = v;
                }
            });
            return out;
        }""")
        offer_title = await sup_page.evaluate(r"""() => {
            const clean = v => (v || '').replace(/\s+/g, ' ').trim()
                .replace(/\s*[-|\uff5c]\s*(?:\u8d77\u6279|1688).*$/i, '').trim();
            const company = /(?:\u6709\u9650\u516c\u53f8|\u516c\u53f8|\u5b9e\u4e1a|\u751f\u7269\u79d1\u6280|\u5546\u8d38|\u5de5\u5382)$/;
            const valid = value => value && value.length >= 4 && value.length <= 180 && !company.test(value);
            const selectors = ['[class*="offer-title"]', '[class*="detail-title"]', '[class*="product-title"]', '[class*="title"] h1', 'h1'];
            for (const sel of selectors) {
                for (const el of document.querySelectorAll(sel)) {
                    const value = clean(el.innerText || el.textContent);
                    if (valid(value)) return value;
                }
            }
            for (const sel of ['meta[property="og:title"]', 'meta[name="title"]']) {
                const el = document.querySelector(sel);
                const value = clean(el && el.content);
                if (valid(value)) return value;
            }
            const pageTitle = clean(document.title);
            return valid(pageTitle) ? pageTitle : '';
        }""")
        if offer_title:
            print(f"[spec-code] supplier title: {offer_title[:80]}")
        print(f"[供应商] 抓到 {len(attrs)} 个属性")
        # 关键字段匹配（按 1688 实际字段名）
        is_special = ""
        license_no = ""
        _lic_score = -1
        import re as _re
        _LIC_VAL_RE = _re.compile(r'妆(网备字|特字)')
        for k, v in attrs.items():
            kt = k.strip()
            vt = v.strip()
            # 「特殊用途化妆品」字段直接给出 是/否(精确避免被"...证号"等子串匹配覆盖)
            if (("特殊用途化妆品" in kt and "证号" not in kt and "批准" not in kt and "编号" not in kt)
                    and vt in ("是", "否")):
                is_special = vt
                print(f"  ★ 是否特殊化妆品(精确匹配): {k} = {v}")
            # 「非特化妆品备案证号」「化妆品批准文号」「特殊用途化妆品证号」等
            # 排除「生产许可证号/卫生许可证号」——它们带「证号」但不是批准文号(只是数字),
            # 会把正确的备案号覆盖掉(实测 584152 覆盖 粤G妆网备字...)。
            if "许可" in kt:
                continue
            if "备案证号" in kt or "备案号" in kt or "批准文号" in kt or "证号" in kt:
                # 打分择优:值像备案号(妆网备字/妆特字)+10;key 明确含备案/批准文号 +5;泛「证号」+1。
                # 取分最高,避免后匹配的弱候选(纯数字)覆盖前面的强候选。
                score = 0
                if _LIC_VAL_RE.search(vt): score += 10
                if ("备案证号" in kt or "批准文号" in kt or "备案号" in kt): score += 5
                elif "证号" in kt: score += 1
                if score > _lic_score:
                    _lic_score = score
                    license_no = vt
                    print(f"  ★ 化妆品批准文号候选: {k} = {v} (score={score})")
        # 兜底1:从所有 attr value 里正则匹配批准文号
        if not license_no:
            import re
            for v in attrs.values():
                m = re.search(r'(国|[一-龥]?)妆(网备字|特字)\S+', v)
                if m:
                    license_no = m.group(0)
                    print(f"  ★ 从属性值正则提取批准文号: {license_no}")
                    break
        # 兜底2:attrs 完全没抓到 → 扫描整页 innerText 正则匹配
        # (有些 1688 供应商页属性区不是 dl/table 结构,信息散在 div 里)
        if not license_no:
            try:
                page_text = await sup_page.evaluate("() => document.body.innerText")
                import re
                m = re.search(r'(国|[一-龥]?)妆(网备字|特字)[A-Za-z0-9]+', page_text or '')
                if m:
                    license_no = m.group(0)
                    print(f"  ★ 全页正文扫描提取批准文号: {license_no}")
            except Exception as e:
                print(f"  [!] 全页扫描异常(忽略): {e}")
        # 若 is_special 未直接给出,根据批准文号推断(国妆特字 → 是 / X妆网备字 → 否)
        if not is_special and license_no:
            if "特字" in license_no:
                is_special = "是"
            elif "网备" in license_no or "备字" in license_no:
                is_special = "否"
            print(f"  ★ 根据批准文号推断是否特殊: is_special={is_special!r}")
        # 顺手抓 skuModel → 解析成自定义SKU路的填充料(规格名/价/图/库存)。
        # 整段 try 包住:抓不到/解析失败绝不影响备案号核对主流程。
        sku_material = {}
        try:
            sm = await sup_page.evaluate(_SKU_MODEL_JS)
            sku_material = parse_sku_material(sm, supplier_url)
            if sku_material:
                print(f"[供应商] skuModel: 维度{sku_material['dim_count']} "
                      f"SKU{sku_material['sku_count']} 分隔符={sku_material['sep']!r}")
            else:
                print("[供应商] skuModel: 未抓到(页面无规格/结构变化)")
        except Exception as e:
            print(f"[供应商] skuModel 抓取异常(忽略): {e}")
        await sup_page.screenshot(path="D:/files/supplier_page.png", full_page=True)
        print("[供应商] 截图: supplier_page.png")
        return {"is_special": is_special, "license_no": license_no,
                "all_attrs": attrs, "sku_material": sku_material, "offer_title": offer_title}
    finally:
        await sup_page.close()


async def _carousel_bg_order(form_page) -> list:
    """读当前轮播图区图块的 background-image url(按 DOM/视觉顺序),用于验证重排前后顺序。"""
    try:
        return await form_page.evaluate(r"""() => {
            const cont = document.querySelector('[id="basic.carousel_gallery"]') || document.body;
            return [...cont.querySelectorAll('.MaterialModalButton_v2_imageBox__1NfrZ')]
                .map(d => { let bg=''; try{bg=getComputedStyle(d).backgroundImage||'';}catch(e){}
                           const m=bg.match(/[0-9a-f-]{30,}/i); return m?m[0]:bg.slice(0,40); });
        }""")
    except Exception:
        return []


async def _carousel_first_image_url(form_page) -> str:
    """读轮播图首图(=PDD 上架主图)的完整 background-image / img URL,存进发布历史供"已发布"表展示。
    类名后缀随 PDD 版本变 → 多选择器兜底;读不到返回 ''(不影响发布)。"""
    try:
        return await form_page.evaluate(r"""() => {
            const cont = document.querySelector('[id="basic.carousel_gallery"]');
            const scope = cont || document.body;
            const readTile = (t) => {
                if (!t) return '';
                let bg = '';
                try { bg = getComputedStyle(t).backgroundImage || ''; } catch(e) {}
                const m = bg.match(/url\(["']?(.*?)["']?\)/i);
                if (m && m[1] && m[1] !== 'none') return m[1];
                const img = t.querySelector && t.querySelector('img');
                if (img && img.src) return img.src;
                if (t.tagName === 'IMG' && t.src) return t.src;
                return '';
            };
            // ① 已知类名 + 模糊类名(后缀随版本变,用 [class*=] 兜)
            const tiles = scope.querySelectorAll(
                '.MaterialModalButton_v2_imageBox__1NfrZ, .MaterialModalButton_v2_imgContainer__3qGOI,'
                + ' [class*="imgContainer"], [class*="imageBox"]');
            for (const t of tiles) { const u = readTile(t); if (u) return u; }
            // ② 兜底:仅在轮播容器内取第一张有效 img(不扩到 body,避免抓到无关图)
            if (cont) {
                for (const im of cont.querySelectorAll('img')) {
                    if (im.src && /^https?:/.test(im.src)) return im.src;
                }
            }
            return '';
        }""")
    except Exception:
        return ""


async def _detail_main_image_url(detail_page) -> str:
    """上架成功回检:从商品详情页「商品轮播图」一行抓**第一张(主轮播图)**=上架主图。
    锚定「商品轮播图」label,取其右侧/下方同一带里位置最靠前(上→左)的图(img 或 background-image)。
    label 找不到时回落到诊断模式(打印候选图,留空)。读不到返回 ''。"""
    try:
        await detail_page.evaluate("() => window.scrollTo(0, 0)")
        await asyncio.sleep(0.8)
        url = await detail_page.evaluate(r"""() => {
            // 找直接文本为「商品轮播图」的 label 元素
            let label = null;
            for (const el of document.querySelectorAll('div,span,label,td,th,p')) {
                const direct = Array.from(el.childNodes).filter(n=>n.nodeType===3)
                    .map(n=>n.textContent).join('').trim();
                if (direct === '商品轮播图') { label = el; break; }
            }
            if (!label) return '';
            const lr = label.getBoundingClientRect();
            const inBand = (r) => (r.left > lr.left - 5) && ((r.top - lr.top) > -80) && ((r.top - lr.top) < 220);
            // funimg/promotion/genimg/commimg = 商品预览/促销/手机壳样机图,不是真轮播图。
            // 踩过(966765928983):funimg .slim.png 手机壳样机(在最右、稍微靠上)被当主图。
            // 真商品图在 img.pddpic.com,排除坏域名 + 优先 img.pddpic.com,再取最靠上左=主轮播图。
            const BAD = /funimg\.pddpic\.com|promotion\.pddpic\.com|genimg\.pddpic\.com|commimg\.pddpic\.com/;
            const GOOD = /^https?:\/\/img\.pddpic\.com\//;
            const cands = [];
            for (const im of document.querySelectorAll('img')) {
                const r = im.getBoundingClientRect();
                if (im.src && /^https?:/.test(im.src) && !BAD.test(im.src) && r.width>=50 && r.height>=50 && inBand(r))
                    cands.push({src: im.src, x: r.left, y: r.top, good: GOOD.test(im.src)?1:0});
            }
            if (!cands.length) {   // 轮播块可能是 background-image div
                for (const el of document.querySelectorAll('div,a,span')) {
                    const r = el.getBoundingClientRect();
                    if (r.width<50 || r.height<50 || !inBand(r)) continue;
                    let bg=''; try { bg = getComputedStyle(el).backgroundImage || ''; } catch(e){}
                    const m = bg.match(/url\(["']?(.*?)["']?\)/i);
                    if (m && m[1] && m[1]!=='none' && /^https?:/.test(m[1]) && !BAD.test(m[1]))
                        cands.push({src: m[1], x: r.left, y: r.top, good: GOOD.test(m[1])?1:0});
                }
            }
            if (!cands.length) return '';
            cands.sort((a,b) => (b.good - a.good) || (a.y - b.y) || (a.x - b.x));  // 真商品图优先,再上→左
            return cands[0].src;
        }""")
        if url:
            print(f"[上架主图] 详情页「商品轮播图」首图: {url[:90]}")
            return url
        # 锚点没找到 → 诊断:打印候选,便于按真实 DOM 调
        data = await detail_page.evaluate(r"""() => {
            const out = [];
            for (const im of document.querySelectorAll('img')) {
                if (!im.src || !/^https?:/.test(im.src)) continue;
                const r = im.getBoundingClientRect();
                out.push({src: im.src, w: Math.round(r.width), h: Math.round(r.height), top: Math.round(r.top)});
            }
            return out;
        }""")
        cand = sorted([d for d in (data or []) if d['w']>=80 and d['h']>=80 and -50<=d['top']<=1200],
                      key=lambda d: -(d['w']*d['h']))
        print(f"[上架主图][诊断] 未找到「商品轮播图」锚点,详情页候选图 {len(cand)} 个(前8):")
        for d in cand[:8]:
            print(f"    {d['w']}x{d['h']} top={d['top']}  {d['src'][:90]}")
        return ""
    except Exception as e:
        print(f"[上架主图][诊断] 异常: {e}")
        return ""


async def reorder_carousel(form_page, shift: int):
    """把商品轮播图第 shift 个图块(0-based)拖到首位 → 换主图(防 PDD 判重复铺货)。

    shift<=0 跳过。轮播图块是 background-image 的 div、无 draggable 属性,页面提示
    「拖拽可调整顺序」→ 是 JS 指针排序(sortable),用 page.mouse 多段移动模拟指针拖放。
    shift 超过张数时取模循环。拖完打印前后首图顺序到本进程发布日志,验证是否生效。
    """
    if not shift or shift <= 0:
        print(f"[轮播] shift={shift},跳过重排")
        return
    print(f"\n[轮播] 重排:把第 {shift} 个图块(0-based)拖到首位 ...")
    try:
        await form_page.evaluate("() => window.scrollTo(0, 0)")
        await asyncio.sleep(0.5)
        boxes = await form_page.evaluate(r"""() => {
            const cont = document.querySelector('[id="basic.carousel_gallery"]') || document.body;
            const tiles = [...cont.querySelectorAll('.MaterialModalButton_v2_imgContainer__3qGOI')];
            return tiles.map(t => {
                const r = t.getBoundingClientRect();
                return {cx: r.x + r.width/2, cy: r.y + r.height/2,
                        x: r.x, y: r.y, w: r.width, h: r.height};
            });
        }""")
        n = len(boxes)
        if n < 2:
            print(f"[轮播] 图块数={n},无法重排"); return
        k = shift % n
        if k == 0:
            print(f"[轮播] shift % {n} = 0,无需重排"); return
        order_before = await _carousel_bg_order(form_page)
        src, dst = boxes[k], boxes[0]
        print(f"[轮播] 共 {n} 张,把 #{k}(x={src['x']:.0f}) 拖到 #0(x={dst['x']:.0f})")
        # 指针拖放:按下 → 小幅抖动触发 sortable → 多段插值移动到首张左半区 → 松开
        await form_page.mouse.move(src['cx'], src['cy'])
        await asyncio.sleep(0.15)
        await form_page.mouse.down()
        await asyncio.sleep(0.2)
        await form_page.mouse.move(src['cx'] - 6, src['cy'] + 4, steps=5)
        await asyncio.sleep(0.15)
        target_x = dst['x'] + dst['w'] * 0.25   # 落到首张左 1/4 处 → 插到最前
        target_y = dst['cy']
        cur_x, cur_y = src['cx'] - 6, src['cy'] + 4
        steps = 25
        for i in range(1, steps + 1):
            nx = cur_x + (target_x - cur_x) * i / steps
            ny = cur_y + (target_y - cur_y) * i / steps
            await form_page.mouse.move(nx, ny)
            await asyncio.sleep(0.02)
        await asyncio.sleep(0.3)
        await form_page.mouse.up()
        await asyncio.sleep(0.8)
        order_after = await _carousel_bg_order(form_page)
        moved = bool(order_before) and bool(order_after) and order_before[0] != order_after[0]
        # 顺序信息只打到本进程发布日志(per-id),不写共享文件,避免并发多条互相覆盖
        print(f"[轮播] 拖放完成。首图变化={moved}  k={k}/n={n}")
        print(f"[轮播]   before[0..2]={order_before[:3]}")
        print(f"[轮播]   after [0..2]={order_after[:3]}")
        if not moved:
            print("[轮播][!] 首图未变化,拖拽可能未生效(本条主图与首条相同,仍有重复铺货风险)")
    except Exception as e:
        print(f"[轮播] 重排失败(忽略): {e}")


# ── 主流程 ────────────────────────────────────────────────────────────────────

final_status = "fail"  # 模块级变量
_PRODUCT_TYPE_UNCERTAIN = None  # 产品类型靠"猜"(没匹配上)时记这里,写进 history 留人工复核
_PUBLISHED_MAIN_IMG = ""        # 上架主图URL:form页轮播先抓作兜底,回检(详情页)抓到则覆盖,写进 history
_PUBLISH_GATE = ""              # 同款核对闸门结果:vlm_same/heat_fallback/force_style,写进 history(已发布表标🟢绿旗)


# ── VLM 同款核对闸门(发布选候选) ──────────────────────────────────────────────
# 规则(用户拍板):查前7候选,挑「VLM说同款+热度最高」的发;7个全不同款→不发(标无同款);
# AI连不上→回退按热度发(标🟢绿旗待人工复核)。人工强发(--force-style):无视VLM,按 DINOv2相似度+热度挑。
def _dl_hires(url, w=800, q=85):
    """把 PDD 候选缩略图(默认w200/q50糊,VLM读不到品牌)下成高清本地文件,返回路径;失败 None。
    ★高清图不能把URL丢给ark(它服务器端下载大图会超时),必须本地下→base64发(见实测)。"""
    import urllib.request as _u, tempfile, os as _os
    try:
        hurl = url.split("?")[0] + "?imageView2/2/w/%d/q/%d" % (w, q)
        op = _u.build_opener(_u.ProxyHandler({}))
        data = op.open(_u.Request(hurl, headers={"User-Agent": "Mozilla/5.0"}), timeout=30).read()
        _os.makedirs(r"D:/files/data/pdd/temp", exist_ok=True)
        fd, path = tempfile.mkstemp(suffix=".jpg", dir=r"D:/files/data/pdd/temp")
        _os.close(fd)
        with open(path, "wb") as f:
            f.write(data)
        return path
    except Exception as e:
        print(f"[同款核对] 高清下载失败({e!r})")
        return None


def _judge_retry(ref, target, tries=2):
    """调 vlm_judge.judge_same,单次超时重试(偶发抖动不算 AI 连不上)。"""
    import vlm_judge
    r = vlm_judge.judge_same(ref, target)
    n = 0
    while (not r.get("ok")) and any(k in str(r.get("error") or "")
                                    for k in ("Timeout", "timed out", "TimeoutError")) and n < tries:
        n += 1
        print(f"[同款核对] 超时重试 {n}/{tries} ...")
        r = vlm_judge.judge_same(ref, target)
    return r


MAX_VLM_SAME_CANDIDATES = 3


async def _vlm_select(args, candidates):
    """正常发布 VLM 闸门。candidates 已按热度倒序。返回 (to_try, gate_mode, msg)。
      vlm_same     : to_try=[第一个VLM判同款候选](失败后再懒加载下一个同款)
      no_same_style: to_try=[](都判了且无同款 → 不发)
      heat_fallback: to_try=candidates(AI不可用 → 回退按热度发,标🟢绿旗)"""
    ref = args.image
    judged_ok = vlm_err = 0
    tmps = []
    try:
        for c in candidates:
            url = c.get("img")
            if not url:
                continue
            _t0 = time.perf_counter()
            path = _dl_hires(url)
            _dl_s = time.perf_counter() - _t0
            if path:
                tmps.append(path)
            _judge_t0 = time.perf_counter()
            r = _judge_retry(ref, path or url)   # 下载失败退用URL让ark试
            _judge_s = time.perf_counter() - _judge_t0
            _total_s = time.perf_counter() - _t0
            if not r.get("ok"):
                vlm_err += 1
                print(f"[同款核对] 热度{c['heat']} 判定失败: {r.get('error')}  耗时=下载{_dl_s:.2f}s/VLM{_judge_s:.2f}s/总{_total_s:.2f}s")
                continue
            judged_ok += 1
            if r.get("same"):
                print(f"[同款核对] 热度{c['heat']} ✅同款 → 选为当前候选. {r.get('reason','')}  耗时=下载{_dl_s:.2f}s/VLM{_judge_s:.2f}s/总{_total_s:.2f}s")
                return [c], "vlm_same", f"命中同款候选(热度:{c.get('heat', 0)})"
            print(f"[同款核对] 热度{c['heat']} ❌不同款: {r.get('reason','')}  耗时=下载{_dl_s:.2f}s/VLM{_judge_s:.2f}s/总{_total_s:.2f}s")
        if judged_ok > 0 and vlm_err == 0:
            return [], "no_same_style", f"前{judged_ok}个候选AI全判不同款"
        return candidates, "heat_fallback", f"VLM不可用(失败{vlm_err}次),回退按热度发+标🟢绿旗"
    finally:
        for p in tmps:
            try:
                __import__("os").remove(p)
            except Exception:
                pass


def _same_candidate(a, b):
    return a is b or a == b


def _remaining_candidates_after(candidate_pool, attempted_candidates, max_same=MAX_VLM_SAME_CANDIDATES):
    if len(attempted_candidates) >= max_same:
        return []
    if not attempted_candidates:
        return list(candidate_pool)
    last = attempted_candidates[-1]
    start = 0
    for i, c in enumerate(candidate_pool):
        if _same_candidate(c, last):
            start = i + 1
            break
    return [
        c for c in candidate_pool[start:]
        if not any(_same_candidate(c, tried) for tried in attempted_candidates)
    ]


async def _vlm_select_next(args, candidate_pool, attempted_candidates, max_same=MAX_VLM_SAME_CANDIDATES):
    if len(attempted_candidates) >= max_same:
        return [], "no_same_style", f"已达到最多{max_same}个同款候选"
    remaining = _remaining_candidates_after(candidate_pool, attempted_candidates, max_same=max_same)
    if not remaining:
        return [], "no_same_style", "没有剩余候选可继续核对"
    return await _vlm_select(args, remaining)

def _force_select(args, candidates):
    """人工强发:无视VLM,按 DINOv2相似度(降序)+ 热度(降序)挑1个。返回 ([best], 'force_style')。"""
    try:
        import match_rank
    except Exception as e:
        print(f"[人工强发] DINOv2不可用({e!r}) → 直接按热度最高发")
        return (candidates[:1], "force_style")
    scored, tmps = [], []
    for c in candidates:
        url = c.get("img")
        sim = -1.0
        if url:
            path = _dl_hires(url)
            if path:
                tmps.append(path)
            try:
                jp = match_rank.judge_pair(args.image, path or url)
                if jp.get("sim") is not None:
                    sim = jp["sim"]
            except Exception:
                pass
        scored.append((sim, c.get("heat", 0), c))
    for p in tmps:
        try:
            __import__("os").remove(p)
        except Exception:
            pass
    scored.sort(key=lambda x: (-x[0], -x[1]))
    if scored:
        print(f"[人工强发] 选中 相似度{scored[0][0]:.2f} 热度{scored[0][1]} {scored[0][2]['name'][:30]}")
        return ([scored[0][2]], "force_style")
    return ([], "force_style")


def write_publish_history(record: dict):
    """追加一条成功发布记录到 D:/files/data/pdd/pdd_publish_history.json"""
    history_path = APP_DIR / "data" / "pdd" / "pdd_publish_history.json"
    history = []
    if history_path.exists():
        try:
            with open(history_path, encoding="utf-8") as f:
                history = json.load(f)
        except Exception:
            history = []
    history.insert(0, record)
    history_path.parent.mkdir(parents=True, exist_ok=True)
    with open(history_path, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)
    print(f"[历史] 已记录到 {history_path}（共 {len(history)} 条）")

async def _try_freebie_reject_repair(context, detail_page, args) -> tuple[dict, object | None]:
    """One-shot automatic repair for gift/buy-get rejection after initial submit."""
    try:
        from tools.repair_pdd_freebie_reject_vlm import repair_freebie_reject_in_context
    except Exception as e:
        print(f"[freebie-repair] module unavailable: {e!r}")
        return {"ok": False, "blocked": "repair_module_unavailable", "error": repr(e)}, None

    reject_url = detail_page.url or ""
    print(f"[freebie-repair] rejected page detected, trying auto repair: {reject_url[:120]}")
    try:
        res = await repair_freebie_reject_in_context(
            context,
            reject_url,
            store_name=getattr(args, "store", "") or "",
            apply=True,
            include_page=True,
        )
    except Exception as e:
        print(f"[freebie-repair] exception: {e!r}")
        return {"ok": False, "blocked": "repair_exception", "error": repr(e)}, None

    repair_page = res.pop("_page", None) if isinstance(res, dict) else None
    if res.get("ok"):
        safe = {
            "ok": True,
            "deleted_indices": res.get("deleted_indices", []),
            "before_count": res.get("before_count"),
            "after_count": res.get("after_count"),
            "title_cleanup": res.get("title_cleanup", {}),
            "vlm_screenshot": res.get("vlm_screenshot", ""),
            "screenshot_before": res.get("screenshot_before", ""),
            "screenshot_after": res.get("screenshot_after", ""),
            "screenshot_final": res.get("screenshot_final", ""),
            "url": res.get("url", ""),
        }
        globals()["_FREEBIE_REPAIR"] = safe
        print(f"[freebie-repair] repaired and resubmitted: deleted={safe['deleted_indices']} title={safe['title_cleanup'].get('cleaned_title','')[:40]}")
    else:
        print(f"[freebie-repair] not repaired: {res.get('blocked')} {res.get('error','')}")
    return res, repair_page


async def _close_current_goods_tabs(context, goods_id: str, *pages):
    """Close publish/detail/edit tabs for the current goods_id, leaving search/result pages alive."""
    seen = set()
    targets = []
    gid = str(goods_id or "").strip()
    for p in pages:
        if p and id(p) not in seen:
            seen.add(id(p)); targets.append(p)
    if gid:
        for p in list(getattr(context, "pages", []) or []):
            if id(p) in seen:
                continue
            try:
                u = p.url or ""
            except Exception:
                continue
            if gid in u and ("goods_add" in u or "goods_detail" in u or "goods_return_detail" in u):
                seen.add(id(p)); targets.append(p)
    for p in targets:
        try:
            await p.close()
        except Exception:
            pass


# ASCII-only overrides for spec-code automation. Unicode is represented with escapes
# so the Windows shell cannot corrupt DOM labels or SKU parsing rules.
_SPEC_CODE_PACK_RE = re.compile(
    r"(?:\d+(?:\.\d+)?\s*(?:g|kg|mg|ml|mL|ML|L|l|\u514b|\u6beb\u5347)(?:\s*[*xX\u00d7]\s*\d+\s*[\u74f6\u652f\u76d2\u888b\u7f50\u5957\u4ef6\u7247\u6761])?|\d+\s*[\u74f6\u652f\u76d2\u888b\u7f50\u5957\u4ef6\u7247\u6761])", re.I)

_SPEC_CODE_COUNT_UNIT_RE = re.compile(r"(?:\d+|[\u4e00\u4e8c\u4e24\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341]+)\s*([\u74f6\u652f\u76d2\u888b\u7f50\u5957\u4ef6\u7247\u6761])")


def _spec_code_confirmed_unit_pack(style: str, suffix: str, units_map: dict | None) -> str:
    original = (style or "").strip()
    raw = original
    if suffix and raw.endswith(suffix):
        raw = raw[:-len(suffix)]
    core = _spec_code_core(raw, "")
    candidates = [original, raw, core, raw.split("/")[-1].strip(), core.split("/")[-1].strip()]
    units = None
    for candidate in candidates:
        if candidate and candidate in (units_map or {}):
            try:
                units = int(units_map[candidate])
            except (TypeError, ValueError):
                units = None
            break
    if not units or units < 1:
        return ""
    match = _SPEC_CODE_COUNT_UNIT_RE.search(_spec_code_main_part(style, suffix))
    if match:
        pack = f"{units}{match.group(1)}"
        return pack if _valid_spec_code_pack(pack) else ""
    return f"*{units}"



def _spec_code_main_part(style: str, suffix: str) -> str:
    return re.split(r"[+\uff0b]", _spec_code_core(style, suffix), maxsplit=1)[0].strip()


async def read_pdd_product_name(form_page, attempts: int = 4) -> str:
    for attempt in range(max(1, attempts)):
        value = await form_page.evaluate(r"""() => {
          const direct=e=>Array.from(e.childNodes||[]).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
          const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0};
          const want=['\u4ea7\u54c1\u540d\u79f0','\u5546\u54c1\u540d\u79f0','\u54c1\u540d']; const candidates=[];
          for(const label of document.querySelectorAll('label,span,div,td,th')){
            if(!visible(label)||!want.includes(direct(label).replace(/^\*/, '').trim()))continue;
            const lr=label.getBoundingClientRect(); let root=label.parentElement;
            for(let depth=0;root&&depth<5;depth++,root=root.parentElement)for(const input of root.querySelectorAll('input,textarea')){
              if(!visible(input))continue;const r=input.getBoundingClientRect();const dy=Math.abs(r.y+r.height/2-lr.y-lr.height/2),dx=r.x-lr.right;
              if(dy<42&&dx>-20&&dx<900)candidates.push({input,dy,dx});
            }
          }
          candidates.sort((a,b)=>a.dy-b.dy||a.dx-b.dx); return candidates.length?(candidates[0].input.value||'').trim():'';
        }""")
        if value and value not in ('\u8bf7\u8f93\u5165', '\u2014'):
            print(f"[spec-code] PDD product name: {value}")
            return value
        if attempt + 1 < attempts:
            await asyncio.sleep(0.8)
    return ""


def _spec_code_core(style: str, suffix: str) -> str:
    value = (style or "").strip()
    if suffix and value.endswith(suffix):
        value = value[:-len(suffix)]
    value = re.sub(r"\u3010[^\u3011]*\u3011|\[[^\]]*\]|[\uff08(][^\uff09)]*[\uff09)]", "", value)
    return re.sub(r"\s+", "", value).strip("+\uff0b-_/\uff0c,\u3002")


def _spec_code_pack_spec(style: str, suffix: str) -> str:
    raw = (style or "").strip()
    if suffix and raw.endswith(suffix):
        raw = raw[:-len(suffix)]
    match = _SPEC_CODE_PACK_RE.search(raw)
    if not match:
        match = _SPEC_CODE_PACK_RE.search(_spec_code_core(style, suffix))
    return re.sub(r"\s+", "", match.group(0)) if match else ""


def _valid_spec_code_pack(value: str) -> bool:
    return bool((value or "") and _SPEC_CODE_PACK_RE.fullmatch(re.sub(r"\s+", "", value or "")))


def _spec_code_residue_is_product_base(residue: str, product_name: str) -> bool:
    token = re.sub(r"[\s+\uff0b\-_/\uff0c,\u3002]", "", residue or "")
    base = re.sub(r"\s+", "", product_name or "")
    return len(token) >= 2 and token in base


def _build_spec_code(product_name: str, variant: str, package_spec: str, suffix: str, style_core: str) -> str:
    if not _valid_spec_code_pack(package_spec):
        return ""
    if not variant:
        return product_name + package_spec + (suffix or "")
    if variant not in style_core:
        return ""
    parts = [part.strip() for part in variant.split("+") if part.strip()]
    count_match = re.fullmatch(r"(\d+)([\u74f6\u652f\u76d2\u888b\u7f50\u5957\u4ef6\u7247\u6761])", package_spec)
    if len(parts) >= 2 and count_match and int(count_match.group(1)) == len(parts):
        unit = count_match.group(2)
        return product_name + "".join("\u3010" + part + "\u3011" for part in parts) + f"\u54041{unit}" + (suffix or "")
    return product_name + "\u3010" + variant + "\u3011" + package_spec + (suffix or "")


def _valid_pdd_base_decision(title: str, decision: dict) -> str:
    raw = (title or "").strip(); base = (decision.get("base_name") or "").strip(); removed = (decision.get("removed_variant") or "").strip()
    try: confidence = float(decision.get("confidence") or 0)
    except Exception: confidence = 0
    if confidence < 0.75 or not base or not raw.startswith(base): return ""
    if not removed: return raw if base == raw else ""
    suffix = raw[len(base):]
    allowed = {removed, "-" + removed, "\uff0d" + removed, "/" + removed,
               "\uff08" + removed + "\uff09", "(" + removed + ")", "(" + removed + "\uff09", "\uff08" + removed + ")", "\u3010" + removed + "\u3011", "[" + removed + "]"}
    return base if suffix in allowed else ""


_SUPPLIER_MARKETING_CLAIM_RE = re.compile(r"\u900f\u4eae\u808c\u80a4")
_SUPPLIER_MARKETING_TAIL_RE = re.compile(r"(?:\s*[-—|｜,，、:：]?\s*)(?:\u900f\u4eae\u808c\u80a4)$")


def _trim_supplier_marketing_tail(value: str) -> str:
    """Remove only a known full trailing benefit claim from an LLM base-name result."""
    return _SUPPLIER_MARKETING_TAIL_RE.sub("", (value or "").strip()).strip()


def _valid_supplier_base_name(value: str, source_title: str) -> bool:
    value = (value or "").strip()
    if len(value) < 2 or len(value) > 48 or value not in (source_title or ""): return False
    if _SUPPLIER_MARKETING_CLAIM_RE.search(value): return False
    return not bool(re.search(r"(?:\u6279\u53d1|\u4ee3\u53d1|\u5305\u90ae|\u4e00\u4ef6\u4ee3\u53d1|\u5382\u5bb6\u76f4\u9500|\u8d77\u6279|\u4ef7\u683c|\u00a5|\d+\s*(?:\u74f6|\u652f|\u76d2|\u888b|\u7f50|\u7247|\u6761|g|ml))", value, re.I))


def _resolve_spec_code_product_name(pdd_name: str, supplier_title: str, styles: list[str]) -> dict:
    pdd_name = (pdd_name or "").strip(); supplier_title = (supplier_title or "").strip()
    if pdd_name:
        has_tail = bool(re.search(r"(?:[-\uff0d/]\s*\S+|[\uff08(\u3010\[][^\uff09)\u3011\]]+[\uff09)\u3011\]])$", pdd_name))
        if not has_tail: return {"name": pdd_name, "source": "pdd_approved", "reason": ""}
        try:
            import smart_sku
            decision = smart_sku.classify_pdd_base_name(pdd_name, styles)
            base = _valid_pdd_base_decision(pdd_name, decision)
            return {"name": base, "source": "pdd_approved_cleaned" if base else "", "reason": "pdd-title-variant-uncertain" if not base else "", "title_decision": decision}
        except Exception as exc:
            return {"name": "", "source": "", "reason": f"pdd-title-model-error:{exc}"}
    if supplier_title:
        try:
            import smart_sku
            decision = smart_sku.extract_supplier_base_name(supplier_title, styles)
            name = _trim_supplier_marketing_tail(decision.get("base_name") or ""); confidence = float(decision.get("confidence") or 0)
            if confidence >= 0.75 and _valid_supplier_base_name(name, supplier_title): return {"name": name, "source": "1688_llm", "reason": ""}
            return {"name": "", "source": "", "reason": "supplier-title-uncertain"}
        except Exception as exc:
            return {"name": "", "source": "", "reason": f"supplier-title-model-error:{exc}"}
    return {"name": "", "source": "", "reason": "no-pdd-name-or-supplier-title"}


_SPEC_CODE_ROWS_JS = r"""(mark) => {
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0}; const text=e=>(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();
 const box=[...document.querySelectorAll('table,[class*="sku-list"]')].filter(visible).map(e=>({e,a:e.getBoundingClientRect().width*e.getBoundingClientRect().height})).sort((a,b)=>b.a-a.a)[0]?.e;if(!box)return{ok:false,reason:'no-sku-table'};
 const trs=[...box.querySelectorAll('tr')],head=trs.map(tr=>({tr,n:tr.querySelectorAll('th,td').length})).sort((a,b)=>b.n-a.n)[0];if(!head)return{ok:false,reason:'no-sku-header'};
 const hs=[...head.tr.querySelectorAll('th,td')].map(c=>{const r=c.getBoundingClientRect();return{name:text(c),x:r.x+r.width/2}}),code=hs.find(h=>h.name==='\u89c4\u683c\u7f16\u7801'),stock=hs.find(h=>['\u5f53\u524d\u5e93\u5b58','\u5e93\u5b58','*\u5e93\u5b58','\u6539\u540e\u5e93\u5b58'].includes(h.name));
 const skip=new Set(['\u89c4\u683c\u7f16\u7801','\u89c4\u683c\u9884\u89c8\u56fe','\u9884\u89c8\u56fe','\u72b6\u6001','\u64cd\u4f5c','\u5f53\u524d\u5e93\u5b58','\u5e93\u5b58','*\u5e93\u5b58','\u5e93\u5b58\u589e\u51cf','\u6539\u540e\u5e93\u5b58','\u62fc\u5355\u4ef7(\u5143)','*\u62fc\u5355\u4ef7(\u5143)','\u5355\u4e70\u4ef7(\u5143)','*\u5355\u4e70\u4ef7(\u5143)','\u5546\u54c1\u7f16\u7801']);
 const specs=hs.filter(h=>h.name&&!skip.has(h.name)&&(!stock||h.x<stock.x));if(!code||!specs.length)return{ok:false,reason:'missing-spec-or-code-header'};
 const prior={},rows=[];for(const [rowNo,tr] of trs.entries()){if(tr===head.tr)continue;const ins=[...tr.querySelectorAll('input,textarea')].filter(visible);if(!ins.length)continue;const cells=[...tr.querySelectorAll('td')],at=h=>cells.map(c=>{const r=c.getBoundingClientRect();return{c,d:Math.abs(r.x+r.width/2-h.x)}}).sort((a,b)=>a.d-b.d)[0],parts=[];
  for(const h of specs){const hit=at(h);let v=hit&&hit.d<160?text(hit.c):'';if(!v)v=prior[h.name]||'';if(v)prior[h.name]=v;if(v)parts.push(v)}const cc=at(code);let input=cc&&cc.d<160?[...cc.c.querySelectorAll('input,textarea')].find(visible):null;if(!input)input=ins.map(e=>{const r=e.getBoundingClientRect();return{e,d:Math.abs(r.x+r.width/2-code.x)}}).sort((a,b)=>a.d-b.d)[0]?.e;const style=parts.join(' / ');if(!style||!input)continue;if(mark)input.setAttribute('data-spec-code-row',String(rowNo));rows.push({rowNo,style,value:(input.value||'').trim(),disabled:!!input.disabled,readonly:!!input.readOnly,maxLength:Number(input.maxLength||0)})}
 return{ok:true,rows};
}"""


async def _read_spec_code_rows(edit_page, mark: bool = False) -> dict:
    try:
        await edit_page.evaluate("""async () => { for(let y=0;y<document.body.scrollHeight;y+=600){window.scrollTo(0,y);await new Promise(r=>setTimeout(r,150));} }""")
        await asyncio.sleep(0.5)
        return await edit_page.evaluate(_SPEC_CODE_ROWS_JS, mark)
    except Exception as exc:
        return {"ok": False, "reason": f"spec-code-row-read-error:{exc}"}

_SPEC_CODE_INPUT_BY_STYLE_JS = r"""target => {
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0};
 const direct=e=>Array.from(e.childNodes||[]).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
 const norm=s=>(s||'').replace(/\s+/g,' ').trim();
 const findHeader=()=>[...document.querySelectorAll('th,span,div,label')].find(e=>visible(e)&&(direct(e)==='规格编码'||direct(e)==='*规格编码'));
 const header=findHeader(); if(!header)return{ok:false,reason:'spec-code-header-not-found'};
 const wanted=norm(target.style), matches=[];
 for(const el of document.querySelectorAll('div,span,td,p,a')){
   const t=norm(el.innerText||''); if(!t||!t.includes(wanted)||t.length>600)continue;
   const r=el.getBoundingClientRect(); if(!visible(el))continue;
   matches.push({el,t,r,score:(t===wanted?0:10000)+t.length});
 }
 if(!matches.length)return{ok:false,reason:'spec-style-not-found'};
 const best=Math.min(...matches.map(x=>x.score));
 const ordered=matches.filter(x=>x.score===best).sort((a,b)=>a.r.y-b.r.y||a.r.x-b.r.x);
 const rows=[]; for(const item of ordered){if(!rows.some(x=>Math.abs(x.r.y-item.r.y)<8&&Math.abs(x.r.x-item.r.x)<8))rows.push(item)}
 const cell=rows[Number(target.ordinal)||0]||rows[0]; cell.el.scrollIntoView({block:'center'});
 const cellR=cell.el.getBoundingClientRect(), rowCy=cellR.y+cellR.height/2, headerNow=findHeader()||header, headerR=headerNow.getBoundingClientRect(), headerCx=headerR.x+headerR.width/2;
 let input=null,bestDx=1e9,bestDy=1e9;
 for(const el of document.querySelectorAll('input,textarea')){
   if(el.disabled||el.readOnly)continue; const r=el.getBoundingClientRect(); if(r.width<30||r.height<4)continue;
   const dy=Math.abs(r.y+r.height/2-rowCy); if(dy>55)continue; const dx=Math.abs(r.x+r.width/2-headerCx);
   if(dx<bestDx||(dx===bestDx&&dy<bestDy)){input=el;bestDx=dx;bestDy=dy}
 }
 if(!input||bestDx>140)return{ok:false,reason:'spec-code-input-not-found',matched:cell.t,dx:Math.round(bestDx),dy:Math.round(bestDy)};
 input.setAttribute('data-spec-code-key',target.token); return{ok:true,value:(input.value||'').trim(),matched:cell.t,dx:Math.round(bestDx),dy:Math.round(bestDy),maxLength:Number(input.maxLength||0),disabled:!!input.disabled,readonly:!!input.readOnly};
}"""


_SPEC_CODE_INPUT_BY_TABLE_STYLE_JS = r"""target => {
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0};
 const text=e=>(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();
 const tables=[...document.querySelectorAll('table')].filter(visible);
 for(const table of tables){
  const trs=[...table.querySelectorAll('tr')];
  const header=trs.map(tr=>({tr,cells:[...tr.querySelectorAll('th,td')]})).filter(x=>x.cells.length).sort((a,b)=>b.cells.length-a.cells.length)[0];
  if(!header)continue;
  const codeIndex=header.cells.findIndex(cell=>text(cell)==='\u89c4\u683c\u7f16\u7801'); if(codeIndex<0)continue;
  const matches=[];
  for(const tr of trs){if(tr===header.tr)continue;const cells=[...tr.querySelectorAll('td')];if(cells.length<=codeIndex)continue;
   const values=cells.map(text);const exact=values.some(v=>v===target.style);const contains=values.some(v=>v.includes(target.style));
   if(exact||contains)matches.push({cells,score:exact?0:1});
  }
  if(!matches.length)continue;
  const best=Math.min(...matches.map(x=>x.score));const rows=matches.filter(x=>x.score===best);
  const row=rows[Number(target.ordinal)||0]||rows[0];
  const input=[...row.cells[codeIndex].querySelectorAll('input,textarea')].find(visible);if(!input)continue;
  input.setAttribute('data-spec-code-table-key',target.token);
  return{ok:true,value:(input.value||'').trim(),maxLength:Number(input.maxLength||0),disabled:!!input.disabled,readonly:!!input.readOnly};
 }
 return{ok:false,reason:'table-spec-code-input-not-found'};
}"""


async def _locate_spec_code_input_by_table(edit_page, row: dict):
    token = "table-spec-code-" + hashlib.sha1((row.get("rowKey") or "").encode("utf-8")).hexdigest()
    try:
        state = await edit_page.evaluate(_SPEC_CODE_INPUT_BY_TABLE_STYLE_JS, {"style": row.get("style", ""), "ordinal": row.get("rowOrdinal", 0), "token": token})
        if not state.get("ok"):
            return None, state
        loc = edit_page.locator(f'input[data-spec-code-table-key="{token}"],textarea[data-spec-code-table-key="{token}"]').first
        if not await loc.count():
            return None, {"ok": False, "reason": "table-spec-code-marker-not-found"}
        return loc, state
    except Exception as exc:
        return None, {"ok": False, "reason": f"table-spec-code-locate-error:{exc}"}


async def _locate_spec_code_input(edit_page, row: dict):
    token = "spec-code-" + hashlib.sha1((row.get("rowKey") or "").encode("utf-8")).hexdigest()
    try:
        state = await edit_page.evaluate(_SPEC_CODE_INPUT_BY_STYLE_JS, {"style": row.get("style", ""), "ordinal": row.get("rowOrdinal", 0), "token": token})
        if not state.get("ok"):
            return None, state
        loc = edit_page.locator(f'input[data-spec-code-key="{token}"],textarea[data-spec-code-key="{token}"]').first
        if not await loc.count():
            return None, {"ok": False, "reason": "spec-code-marker-not-found"}
        return loc, state
    except Exception as exc:
        return None, {"ok": False, "reason": f"spec-code-direct-locate-error:{exc}"}


async def _locate_spec_code_input_for_row(edit_page, row: dict):
    if row.get("use_table_spec_code_locator"):
        return await _locate_spec_code_input_by_table(edit_page, row)
    return await _locate_spec_code_input(edit_page, row)


async def _read_spec_code_values_direct(edit_page, rows: list[dict]) -> tuple[dict, list[dict]]:
    values, errors = {}, []
    for row in rows:
        loc, state = await _locate_spec_code_input_for_row(edit_page, row)
        key = row.get("rowKey", "")
        if not loc:
            errors.append({"style": row.get("style", ""), "reason": state.get("reason", "direct-locate-failed")})
            continue
        try:
            values[key] = (await loc.input_value()).strip()
        except Exception as exc:
            errors.append({"style": row.get("style", ""), "reason": f"direct-read-failed:{exc}"})
    return values, errors

def _can_replace_spec_code_over_max_length(current: str, planned: str, max_length: int) -> bool:
    """Allow a correction that shortens an already persisted over-limit legacy code."""
    return bool(current and max_length > 0 and len(planned) > max_length and len(planned) < len(current))


async def fill_spec_codes(edit_page, pdd_name: str, supplier_title: str, suffix: str, correct_existing: bool = False, confirmed_units_map: dict | None = None, known_styles: list[str] | None = None) -> dict:
    result = {"status":"skipped","product_name":"","source":"","failed_rows":[],"written":0,"existing":0,"corrected":0,"changed_rows":[],"expected_codes":[],"write_verified":False}
    if known_styles:
        rows = [{"rowNo": index, "style": style.strip(), "value": "", "disabled": False, "readonly": False, "maxLength": 0}
                for index, style in enumerate(known_styles) if style and style.strip()]
        state = {"ok": bool(rows)}
    else:
        state = await _read_spec_code_rows(edit_page); rows = state.get("rows") or []
    if not state.get("ok") or not rows:
        result["reason"] = state.get("reason", "no-spec-code-rows"); return result
    seen_styles = {}
    for row in rows:
        style = (row.get("style") or "").strip()
        ordinal = seen_styles.get(style, 0)
        seen_styles[style] = ordinal + 1
        row["rowOrdinal"] = ordinal
        row["rowKey"] = f"{style}\x1f{ordinal}"
    if known_styles:
        for row in rows:
            loc, locate_state = await _locate_spec_code_input(edit_page, row)
            if not loc:
                result["reason"] = locate_state.get("reason", "direct-spec-code-row-read-failed")
                return result
            value = (await loc.input_value()).strip()
            if correct_existing:
                table_loc, table_state = await _locate_spec_code_input_by_table(edit_page, row)
                if table_loc:
                    table_value = (await table_loc.input_value()).strip()
                    if table_value and table_value != value:
                        loc, locate_state, value = table_loc, table_state, table_value
                        row["use_table_spec_code_locator"] = True
            row["value"] = value
            row["disabled"] = bool(locate_state.get("disabled"))
            row["readonly"] = bool(locate_state.get("readonly"))
            row["maxLength"] = int(locate_state.get("maxLength") or 0)
    product = _resolve_spec_code_product_name(pdd_name, supplier_title, [r["style"] for r in rows]); result.update({"product_name":product.get("name", ""),"source":product.get("source", "")})
    if "title_decision" in product:
        result["title_decision"] = product["title_decision"]
    confirmed_packs = {}
    if confirmed_units_map:
        candidate_packs = {row["rowNo"]: _spec_code_confirmed_unit_pack(row["style"], suffix, confirmed_units_map) for row in rows}
        if len(candidate_packs) == len(rows) and all(candidate_packs.values()):
            confirmed_packs = candidate_packs
            print(f"[spec-code] reusing confirmed smart-SKU units for {len(rows)} count-only rows")
    if not product.get("name"):
        result["reason"] = product.get("reason", "no-product-base"); return result
    planned, model_rows = {}, []
    for row in rows:
        core = _spec_code_core(row["style"], suffix); pack = _spec_code_pack_spec(row["style"], suffix); residue = _SPEC_CODE_PACK_RE.sub("", core).strip("*xX\u00d7-/ ")
        if confirmed_packs:
            planned[row["rowNo"]] = product["name"] + confirmed_packs[row["rowNo"]] + (suffix or "")
            continue
        if pack and _spec_code_residue_is_product_base(residue, product["name"]):
            planned[row["rowNo"]] = product["name"] + pack + (suffix or "")
        elif re.search(r"[\u4e00-\u9fffA-Za-z]", residue): model_rows.append(row)
        elif pack: planned[row["rowNo"]] = product["name"] + pack + (suffix or "")
        else: result["failed_rows"].append({"style":row["style"],"reason":"package-spec-not-found"})
    decisions = {}
    if model_rows:
        try:
            import smart_sku
            decisions = {str(x.get("style") or "").strip():x for x in smart_sku.classify_spec_code_rows(product["name"], [r["style"] for r in model_rows]) if isinstance(x,dict)}
        except Exception as exc:
            result["failed_rows"].extend({"style":r["style"],"reason":f"variant-model-error:{exc}"} for r in model_rows)
        for row in model_rows:
            item=decisions.get(row["style"]) or {}; variant=(item.get("variant") or "").strip(); model_pack=re.sub(r"\s+","",item.get("package_spec") or ""); pack=model_pack if _valid_spec_code_pack(model_pack) else _spec_code_pack_spec(row["style"],suffix)
            try: confidence=float(item.get("confidence") or 0)
            except Exception: confidence=0
            code = _build_spec_code(product["name"], variant, pack, suffix, _spec_code_core(row["style"], suffix))
            if confidence<0.75 or not code: result["failed_rows"].append({"style":row["style"],"reason":"variant-or-package-uncertain"}); continue
            planned[row["rowNo"]] = code
    duplicate={code for code in planned.values() if list(planned.values()).count(code)>1}
    expected_by_no = {}
    for row in rows:
        code=planned.get(row["rowNo"])
        if code and code == row["value"]:
            result["existing"] += 1; planned.pop(row["rowNo"], None); continue
        if row["value"] and not correct_existing:
            result["existing"] += 1; planned.pop(row["rowNo"], None); continue
        allow_shorter_correction = correct_existing and _can_replace_spec_code_over_max_length(
            row["value"], code or "", row["maxLength"])
        if code and (code in duplicate or ((row["maxLength"]>0 and len(code)>row["maxLength"]) and not allow_shorter_correction) or row["disabled"] or row["readonly"]):
            result["failed_rows"].append({"style":row["style"],"reason":"duplicate-too-long-or-readonly"}); planned.pop(row["rowNo"],None); continue
        if code:
            expected_by_no[row["rowNo"]] = code
    rows_by_no = {row["rowNo"]: row for row in rows}
    rows_by_key = {row["rowKey"]: row for row in rows}
    result["expected_codes"] = [expected_by_no.get(row["rowNo"], "") for row in rows]
    verified_keys = {row["rowKey"] for row in rows if expected_by_no.get(row["rowNo"]) == row.get("value")}
    for row_no, code in list(planned.items()):
        row = rows_by_no[row_no]
        loc, locate_state = await _locate_spec_code_input_for_row(edit_page, row)
        if not loc:
            result["failed_rows"].append({"style": row["style"], "reason": locate_state.get("reason", "direct-locate-failed")})
            continue
        try:
            await loc.fill(code, timeout=5000)
            await loc.evaluate("""el => {
                el.dispatchEvent(new Event('input', {bubbles: true}));
                el.dispatchEvent(new Event('change', {bubbles: true}));
                el.blur();
            }""")
            await loc.press("Tab")
            await asyncio.sleep(0.4)
            values, errors = await _read_spec_code_values_direct(edit_page, rows)
            mismatches = [key for key in verified_keys | {row["rowKey"]} if values.get(key) != expected_by_no[rows_by_key[key]["rowNo"]]]
            if errors or mismatches:
                result["failed_rows"].extend(errors)
                result["failed_rows"].extend({"style": rows_by_key[key]["style"], "reason": "direct-readback-mismatch"} for key in mismatches)
                continue
            verified_keys.add(row["rowKey"])
            result["written"] += 1
            previous = row.get("value", "")
            if previous:
                result["corrected"] += 1
                result["changed_rows"].append({"style": row["style"], "old": previous, "new": code})
        except Exception as exc:
            result["failed_rows"].append({"style": row["style"], "reason": f"write-failed:{exc}"})
    if expected_by_no:
        values, errors = await _read_spec_code_values_direct(edit_page, rows)
        expected_by_key = {rows_by_no[row_no]["rowKey"]: code for row_no, code in expected_by_no.items()}
        rows_by_key = {row["rowKey"]: row for row in rows}
        mismatches = [key for key, code in expected_by_key.items() if values.get(key) != code]
        if errors or mismatches:
            result["failed_rows"].extend(errors)
            result["readback_warning"] = [{"style": rows_by_key[key]["style"], "row_key": key, "expected": expected_by_key[key], "actual": values.get(key, "")} for key in mismatches]
        result["write_verified"] = not errors and not mismatches

    done=result["written"]+result["existing"]; result["status"]="ok" if done==len(rows) and not result["failed_rows"] else ("partial" if done else "skipped")
    if result["failed_rows"] and not result.get("reason"): result["reason"]="some-spec-codes-not-filled"
    print(f"[spec-code] status={result['status']} written={result['written']} existing={result['existing']} failed={len(result['failed_rows'])} reason={result.get('reason', '')}")
    return result

async def process_single_candidate(context, result_page, cand, args) -> str:
    """处理单个候选商品的完整发布流程。
    返回:
      "ok"        发布成功(verified + history 已写)
      "mismatch"  已上架但对齐差异(history 已写)
      "retry"     可重试,继续下一候选(关闭页面)
      "fail"      不可重试的失败(history 已写但有问题)
    """
    globals()["_FREEBIE_REPAIR"] = None
    _spec_code_result = {"status": "skipped", "reason": "not-attempted", "failed_rows": []}
    tmp_page = await click_publish(result_page, cand)
    if not tmp_page:
        return "retry"
    await asyncio.sleep(2)
    is_category_picker = await tmp_page.evaluate("""() => {
        const t = document.body.innerText || '';
        return t.includes('选择分类') && t.includes('确认发布该类商品');
    }""")
    if is_category_picker:
        print(f"[跳过] 该商品需要手动选分类,关闭并试下一个...")
        await _capture_failure(tmp_page, "category_picker", "需要手动选分类", cand, args)
        try: await tmp_page.close()
        except Exception: pass
        return "retry"
    print(f"[OK] 进入正常发布表单,使用此商品")
    form_page = tmp_page

    # 填特殊化妆品:优先用预核对值(商品库已核对的,免开 1688 页重抓,省时);
    # 没传(老数据未核对)才回落原样打开 1688 抓取。
    _pre_special = (args.is_special or "").strip()
    _pre_license = (args.license_no or "").strip()
    if _pre_special or _pre_license:
        print(f"[填表] 用预核对值(免抓1688): 特殊={_pre_special!r} 批准文号={_pre_license!r}")
        sup = {"is_special": _pre_special, "license_no": _pre_license}
    elif args.supplier_url:
        sup = await scrape_supplier_attrs(context, args.supplier_url)
    else:
        sup = {}
    if sup:
        _special_ok = await fill_special_cosmetic(form_page,
                                                  sup.get('is_special',''),
                                                  sup.get('license_no',''))
        if not _special_ok and sup.get('is_special') in ('是', '否'):
            print(f"[!!] 是否特殊用途化妆品 填写失败 → 换下一候选")
            await _capture_failure(form_page, "special_cosmetic", "是否特殊用途化妆品填写失败", cand, args)
            try: await form_page.close()
            except Exception: pass
            return "retry"

    _spec_code_pdd_name = await read_pdd_product_name(form_page)
    _spec_code_supplier_title = (sup.get("offer_title", "") or "").strip()
    if not _spec_code_pdd_name and not _spec_code_supplier_title and args.supplier_url:
        # Read the supplier title only when neither source has supplied a usable title.
        try:
            _title_sup = await scrape_supplier_attrs(context, args.supplier_url)
            _spec_code_supplier_title = (_title_sup.get("offer_title", "") or "").strip()
        except Exception as _title_exc:
            print(f"[spec-code] supplier title fallback failed (non-blocking): {_title_exc}")

    # 产品类型(部分类目必填,按商品标题智能选;无该字段自动跳过)。先重置存疑标记(防上一候选残留)
    globals()['_PRODUCT_TYPE_UNCERTAIN'] = None
    try:
        await fill_product_type(form_page, (cand.get('name', '') if cand else ''))
    except Exception as _e:
        print(f"[产品类型][!] 处理异常(继续发布): {_e}")
    # 字号类型(牙膏/日化等必填:有「其他」选其他、否则按品判定;无该字段自动跳过)
    try:
        await fill_font_type(form_page, (cand.get('name', '') if cand else ''))
    except Exception as _e:
        print(f"[字号类型][!] 处理异常(继续发布): {_e}")

    # 上传属性截图到包装标签图、扫规格、填价、归零库存、提交
    image_path = str(Path(args.image).resolve())
    if not await upload_package_label(form_page, image_path):
        print("[包装标签图][!!] 属性截图或上传失败 → 换下一候选")
        await _capture_failure(form_page, "package_label", "商品属性截图上传包装标签图失败", cand, args)
        try: await form_page.close()
        except Exception: pass
        return "retry"
    await dismiss_benign_popups(form_page)  # 良性弹窗兜底
    _scraped_spec_values = await scrape_spec_values(form_page)
    await reorder_carousel(form_page, args.carousel_shift)  # 同商品多条:按 shift 换主图防重复铺货
    # 记录上架主图:重排后轮播首图即 PDD 主图,读其完整 URL 存进发布历史(已发布表三图对比用)
    published_main_image = await _carousel_first_image_url(form_page)
    if published_main_image:
        print(f"[上架主图] form页采集(兜底): {published_main_image[:80]}")
    globals()['_PUBLISHED_MAIN_IMG'] = published_main_image or ""   # 兜底;回检若抓到会覆盖

    # 智能SKU(--smart-sku):云端DeepSeek判每行份数能不能确定。
    #   都能确定 → 保留同款SKU(下面 fill_prices 照常填)。
    #   有判不准 → 清掉照1688真料(商品库 sku_material)重建「款式」维SKU,再交给同一个 fill_prices。
    #   云端异常/无料 → 保守保留,绝不阻断发布。默认关,不影响日常发布。
    # 智能SKU:先【保留原SKU + 云端份数填价】正常发;若提交报错(规格规范不符等),
    # 才在下面 submit 失败处删SKU、读颜色、云端营销名重建、重提交(必须报错才重建)。
    _title = (cand.get('name', '') if cand else '')
    _smart_units_map = None
    _smart_rebuilt = False        # 防同一商品重复重建(主动重建过就不再在报错处重建)
    _smart_orig_specs = None      # 原SKU名(写日记对比用)
    _smart_spec_code_units = None  # populated whenever the smart judge confirms quantity-only SKU differences
    _smart_count_only = False
    if getattr(args, 'smart_sku', False):
        try:
            import smart_sku
            _judge = await smart_sku.cloud_judge(form_page, _title)
            if getattr(args, 'force_sku_rebuild', False):
                print("[智能SKU] --force-sku-rebuild:强制走重建路径(诊断用,捕捉重置规格弹窗)")
                _judge["keepable"] = False
                _judge["banned"] = False
            print(f"[智能SKU] keepable={_judge['keepable']}  规格{len(_judge.get('names',[]))}行  reason={_judge.get('reason','')}")
            _smart_units_map = _judge.get("units_map")
            _smart_count_only = _judge.get("count_only") is True
            if _smart_count_only:
                _smart_spec_code_units = _smart_units_map
            _smart_orig_specs = _judge.get("names")
            if not _judge.get("keepable"):
                # 违禁词(赠/送)触发的重建:用云端已判好的"名+份数"建干净名(extract_variants 会把含送的整名丢光)。
                # 真·判不出的重建:走 extract_variants(读同行颜色/款式)。
                _jr = _judge.get("rows") if _judge.get("banned") else None
                _rb = await smart_sku.rebuild_from_form(form_page, _title, image_path, args.stock, judged_rows=_jr, suffix=args.suffix)
                print(f"[智能SKU] {'违禁词' if _jr else '云端判不出'}→重建 ok={_rb.get('ok')} 值={_rb.get('built')}")
                if _rb.get("ok"):
                    _smart_units_map = _rb.get("units_map"); _smart_rebuilt = True
                    if _smart_count_only:
                        _smart_spec_code_units = _smart_units_map
                # 日记:原SKU + 改后SKU 同一条,可对比
                try:
                    smart_sku.journal_append({"kind": "云端判不准→重建", "title": _title,
                                              "原SKU": _smart_orig_specs, "改后SKU": _rb.get("names"),
                                              "reason": _judge.get("reason"),
                                              "result": "建成" if _rb.get("ok") else "重建失败"})
                except Exception:
                    pass
                if not _rb.get("ok"):
                    _reason = _rb.get("reason") or "smart-sku-rebuild-failed"
                    print(f"[智能SKU][!!] 必须重建但失败({_reason}) → 停止当前候选,不提交原始两层SKU")
                    await _capture_failure(form_page, "smart_sku_rebuild_failed", _reason, cand, args)
                    try: await form_page.close()
                    except Exception: pass
                    return "retry"
            else:
                print(f"[智能SKU] 先保留原SKU,用云端份数填价: {_smart_units_map}")
        except Exception as _e:
            print(f"[智能SKU][!] 判定异常,原样发布: {_e}")

    _price_rows_written = 0
    if args.supplier_cost > 0:
        _price_rows_written = await fill_prices(form_page, args.supplier_cost,
                                                shipping=args.shipping,
                                                margin=args.margin,
                                                single_buy_extra=args.single_extra,
                                                units_map=_smart_units_map)
        _risk, _expected_rows, _actual_rows = _sku_row_count_risk(_scraped_spec_values, _price_rows_written)
        if _risk:
            print(f"[SKU行数提示] 有效规格 {_expected_rows} 行,价格表当前写入 {_actual_rows} 行 → "
                  f"继续提交后由发布后核查/自动整改补齐")
    await dismiss_benign_popups(form_page)
    if _smart_rebuilt:
        # 重建SKU过程中网页会把库存清空(建款式/填价会重渲染)→ 这里补填真库存,
        # 第一次发布就带库存,不用等二次编辑补(用户要求)。form页是「库存」列,用 STOCK_FILL_JS。
        try:
            import smart_sku as _ss
            _sr = await _ss.fill_stock(form_page, int(args.stock))
            print(f"[智能SKU] 第一次发布即填真库存 {args.stock}: {_sr}")
        except Exception as _se:
            print(f"[智能SKU] 第一次填库存异常(二次编辑仍会补): {_se}")
        await dismiss_benign_popups(form_page)
    else:
        await zero_out_stock(form_page)
        await dismiss_benign_popups(form_page)
    # 参考价必须在库存操作之后写(否则被重渲染冲回 0),且用真键盘输入
    if args.supplier_cost > 0:
        await set_reference_price(form_page)
    # 净含量"100g"在原表上修=死路(实测:改净含量会把款式SKU维冲掉)→ 这类品改走"重建清空净含量"。
    # 故停用 fix_net_content 调用(函数留着备用);普通品本就不进它,无影响。
    # await fix_net_content(form_page)
    await click_submit_publish(form_page)
    popup_res = await handle_post_submit_popups(form_page)
    if not popup_res["ok"]:
        print(f"[!!] 提交拦截弹窗未通过: {popup_res['reason']} → 换下一候选")
        await _capture_failure(form_page, "submit_popup", str(popup_res.get('reason', '')), cand, args)
        try: await form_page.close()
        except Exception: pass
        return "retry"
    # 净含量等错误是"一闪而过的顶部 toast"(如「属性[净含量]校验错误…需是数值类型」)→ 提交后【立刻】抓,
    # 否则等 sleep(1)+detect 时 toast 已消失=err_n 漏成 0、不触发重建(候选1 净含量品就栽在这)。
    _early_toast = []
    try:
        for _i in range(4):
            _early_toast = await capture_form_errors(form_page)
            if _early_toast:
                break
            await asyncio.sleep(0.3)
    except Exception:
        pass
    if _early_toast:
        print(f"[提交后·早] 立即捕获 toast: {_early_toast}")
    # 校验类 toast(净含量格式/需是数值/规格规范等)= 也算"提交失败需重建"(err_n 常因 toast 已消失=0)
    _toast_need_rebuild = any(
        ('校验错误' in t or '格式错误' in t or '需是数值' in t or '需为数值' in t
         or '净含量' in t or '规范不符' in t or '格式不正确' in t)
        for t in (_early_toast or []))
    # 检测表单红色错误提示「X个错误项未处理」(submit 被 PDD 表单校验拒绝)
    await asyncio.sleep(1)
    err_n = await detect_form_errors(form_page)
    # ★ 提交后立刻抓 PDD 红字错误原文(在重建/换候选清掉页面之前!),日志明示到底嫌哪个字段。
    #   原来只在 _capture_failure 里抓,但那时重建已把页面搞乱→抓到空。这里提早抓,纯诊断不改流程。
    try:
        _post_submit_errs = []
        for _t in range(4):              # 错误条有时延迟渲染(尤其轮播弹窗后重提交)→ 重试几次再抓
            _post_submit_errs = await capture_form_errors(form_page)
            if _post_submit_errs:
                break
            await asyncio.sleep(0.8)
        if err_n > 0 or _post_submit_errs:
            print(f"[提交后检查] 错误项={err_n}  PDD红字原文={_post_submit_errs}")
            # 重建/换候选会清掉页面 → 这里先存一张带时间戳整页图,定格"重建前"的真实错误现场
            try:
                _es = f"D:/files/data/pdd/publish_logs/preerr_{time.strftime('%Y%m%d_%H%M%S')}.png"
                await asyncio.wait_for(form_page.screenshot(path=_es, full_page=True), timeout=15)
                print(f"[提交后检查] 错误现场整页图: {_es}")
            except Exception:
                pass
    except Exception:
        pass
    # 智能SKU:提交报错(规格规范不符/规格类型2空 等)→ 删SKU、读颜色、云端营销名重建、重提交(一次)
    # (若上面已主动重建过则不再重复)
    if (err_n > 0 or _toast_need_rebuild) and getattr(args, 'smart_sku', False) and not _smart_rebuilt:
        print(f"[智能SKU] 提交失败(错误项={err_n} toast触发={_toast_need_rebuild})→ 删SKU重建后重试")
        try:
            import smart_sku
            _rb = await smart_sku.rebuild_from_form(form_page, _title, image_path, args.stock, suffix=args.suffix)
            if _rb.get("ok"):
                _smart_units_map = _rb.get("units_map")
                if _smart_count_only:
                    _smart_spec_code_units = _smart_units_map
                if args.supplier_cost > 0:
                    await fill_prices(form_page, args.supplier_cost, shipping=args.shipping,
                                      margin=args.margin, single_buy_extra=args.single_extra,
                                      units_map=_smart_units_map)
                await dismiss_benign_popups(form_page)
                if args.supplier_cost > 0:
                    await set_reference_price(form_page)
                await click_submit_publish(form_page)
                await handle_post_submit_popups(form_page)
                await asyncio.sleep(1)
                err_n = await detect_form_errors(form_page)
                print(f"[智能SKU] 重建重提交后 错误项={err_n}")
                try:
                    smart_sku.journal_append({"kind": "报错→重建", "title": _title,
                                              "原SKU": _smart_orig_specs, "改后SKU": _rb.get("names"),
                                              "result": "ok" if err_n == 0 else "仍失败", "err_n": err_n})
                except Exception:
                    pass
            else:
                print(f"[智能SKU] 重建未成功({_rb.get('reason','')}),不重试")
                try:
                    smart_sku.journal_append({"kind": "报错→重建失败", "title": _title,
                                              "原SKU": _smart_orig_specs, "改后SKU": _rb.get("names"),
                                              "reason": _rb.get("reason", "build-fail")})
                except Exception:
                    pass
        except Exception as _e:
            print(f"[智能SKU][!] 重建重试异常: {_e}")
    if err_n > 0:
        print(f"[!!] 表单校验失败:「{err_n} 个错误项未处理」(可能缺特殊化妆品/批准文号等必填) → 换下一候选")
        await _capture_failure(form_page, "submit_validation", f"{err_n}个错误项未处理", cand, args)
        try: await form_page.close()
        except Exception: pass
        return "retry"

    # 进入详情页
    detail_page = await click_view_detail(form_page)

    # 详情页状态检测(在点击编辑商品之前!):
    #   - URL 还在 goods_add/index → 提交根本没成功(PDD 字段校验或其他错误拒绝),立刻 retry
    #   - "发布已驳回" → PDD 已驳回 → 换下一候选
    #   - "新商品发布中" → 等 5s reload 再查,最多等 6 次(30s)
    async def _detect_detail_status():
        try:
            url = detail_page.url or ""
        except Exception:
            url = ""
        # 关键:URL 是真值判定。click_view_detail 兜底用 form_page 时 url 还在 goods_add/index,
        # 此时页面 innerText 不含驳回/审核中关键字 → 老逻辑误判 ok 后整条链失败。
        if "goods_add/index" in url:
            return 'submit_failed'
        try:
            return await detail_page.evaluate("""() => {
                const t = document.body.innerText || '';
                if (t.includes('发布已驳回')) return 'rejected';
                if (t.includes('新商品发布中')) return 'pending';
                return 'ok';
            }""")
        except Exception:
            return 'ok'

    status = await _detect_detail_status()
    print(f"[详情] 状态={status}  url={(detail_page.url or '')[:80]}")
    if status == 'submit_failed':
        print(f"[!!] URL 还在 goods_add/index → 首次提交未被 PDD 接受(可能 PDD 字段校验错误等)→ retry")
        await _capture_failure(form_page or detail_page, "submit_failed", "提交后URL仍在goods_add", cand, args)
        for p in (form_page, detail_page):
            if p:
                try: await p.close()
                except Exception: pass
        return "retry"
    if status == 'pending':
        # 等待 PDD 审核进度,reload 重查
        ok_after_wait = False
        for wait_i in range(6):
            print(f"[详情] 「新商品发布中」,等 5s 后 reload 重检 ({wait_i+1}/6)")
            await asyncio.sleep(5)
            try: await detail_page.reload(wait_until="domcontentloaded", timeout=15000)
            except Exception: pass
            await asyncio.sleep(2)
            status = await _detect_detail_status()
            print(f"[详情] reload 后状态={status}")
            if status == 'ok':
                ok_after_wait = True
                break
            if status == 'rejected':
                break  # rejected will be handled below
        if not ok_after_wait and status == 'pending':
            print(f"[!!] pending after 30s, retry next candidate")
            for p in (form_page, detail_page):
                if p:
                    try: await p.close()
                    except Exception: pass
            return "retry"
    if status == 'rejected':
        repair_res, repair_page = await _try_freebie_reject_repair(context, detail_page, args)
        if repair_res.get("ok") and repair_page:
            print("[freebie-repair] repaired, opening detail page for normal post-publish checks")
            detail_page = await click_view_detail(repair_page)
            status = await _detect_detail_status()
            print(f"[freebie-repair] detail status after repair={status} url={(detail_page.url or '')[:80]}")
            if status != 'ok':
                print("[freebie-repair] repaired but detail page is still not OK, retry next candidate")
                for p in (form_page, detail_page, repair_page):
                    if p:
                        try: await p.close()
                        except Exception: pass
                return "retry"
        else:
            print("[freebie-repair] rejected and auto repair failed, retry next candidate")
            for p in (form_page, detail_page):
                if p:
                    try: await p.close()
                    except Exception: pass
            return "retry"

    # Status OK: continue existing edit/check flow

    edit_page = await click_edit_goods(detail_page)

    # 兜底:click_edit_goods 之后再扫一次「存在已驳回审核详情」弹窗(详情页没暴露但点击编辑触发的极少情况)
    try:
        rejected = await edit_page.evaluate("""() => {
            const t = document.body.innerText || '';
            return t.includes('存在已驳回审核详情');
        }""")
    except Exception:
        rejected = False
    if rejected:
        print(f"[!!] 兜底检测到「存在已驳回审核详情」弹窗 → 换下一候选")
        try:
            await edit_page.evaluate("""() => {
                for (const el of document.querySelectorAll('button, span, div')) {
                    if ((el.innerText || '').trim() === '取消') {
                        let p = el;
                        for (let i = 0; i < 5 && p; i++) {
                            if (p.tagName === 'BUTTON' || p.tagName === 'A') { p.click(); return; }
                            p = p.parentElement;
                        }
                        el.click(); return;
                    }
                }
            }""")
        except Exception: pass
        await asyncio.sleep(1)
        for p in (form_page, detail_page, edit_page):
            if p:
                try: await p.close()
                except Exception: pass
        return "retry"

    # 追加规格后缀 + 改库存 + 第二次提交
    await append_spec_suffix(edit_page, args.suffix)
    _spec_code_result = await fill_spec_codes(
        edit_page, _spec_code_pdd_name, _spec_code_supplier_title, args.suffix,
        confirmed_units_map=_smart_spec_code_units)
    # 【独立兜底】贴/片多档份数不可算(供货是整盒价、缺每盒贴数):各规格被迫同价(占位),
    # 若按正常库存(如8888)上架,会被人按错价真实下单 → 巨亏。所以**库存强制设 0**,
    # 上架但买不了,等人工核价+补库存。标"需人工核价",跳过核查,不算未对齐。
    _amb, _amb_specs = detect_units_ambiguous(globals().get('_last_spec_names', []))
    _stock_to_set = 0 if _amb else args.stock
    if _amb:
        print(f"[份数兜底] 检测到「贴/片」多档份数不可算({len(set(_amb_specs))}规格)→ "
              f"库存强制设 0(防按错价被下单),标记「需人工核价」")
    await set_new_stock(edit_page, _stock_to_set)
    ok = await click_edit_submit(edit_page)
    if not ok:
        print("[FINAL] ⚠ 编辑提交未检测到「提交成功」")
        _gid = ""
        try:
            _m = re.search(r'goods_id=(\d+)', edit_page.url)
            _gid = _m.group(1) if _m else ""
        except Exception:
            pass
        await _close_current_goods_tabs(context, _gid, form_page, detail_page, edit_page)
        return "fail"

    if _amb:
        verified = False
        print(f"[份数兜底] 已上架(库存0)→ 标记「需人工核价」,跳过核查")
    else:
        verified = await verify_published(
            edit_page,
            supplier_cost=args.supplier_cost,
            suffix=args.suffix,
            stock_value=args.stock,
            shipping=args.shipping,
            margin=args.margin,
            single_extra=args.single_extra,
            units_map=_smart_units_map)   # 智能SKU:核查用云端份数,别拿本地份数改错价
    # 写 history(无论 verify 通过还是有差异,都记录 — PDD 已上架了)
    import re as _re
    from datetime import datetime as _dt
    m = _re.search(r'goods_id=(\d+)', edit_page.url)
    goods_id = m.group(1) if m else ""
    record = {
        "time": _dt.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": "need_price" if _amb else ("ok" if verified else "mismatch"),
        "store": args.store,
        "target_name": cand.get('name', '') if cand else '',
        "goods_id": goods_id,
        "source_prod_id": str(getattr(args, "source_prod_id", "") or ""),
        "source_insight_url": str(getattr(args, "source_insight_url", "") or ""),
        "supplier_url": args.supplier_url,
        "supplier_cost": args.supplier_cost,
        "mode": args.rule_name,
        "margin": args.margin,
        "shipping": args.shipping,
        "single_buy_extra": args.single_extra,
        "stock": args.stock,
        "suffix": args.suffix,
        "image": args.image,
        "xuanpin_image": getattr(args, "xuanpin_image_url", "") or "",  # 选品图(平移自待发布,已发布表直接读)
        "source_image":  getattr(args, "source_image_url", "") or "",   # 货源图(平移自待发布,已发布表直接读)
        "published_main_image": globals().get('_PUBLISHED_MAIN_IMG', '') or '',  # 上架主图:回检(详情页)优先,form页兜底
        "detail_url": f"https://mms.pinduoduo.com/goods/goods_detail?goods_id={goods_id}" if goods_id else "",
        "publish_gate": globals().get('_PUBLISH_GATE', '') or '',  # 同款核对闸门:vlm_same/heat_fallback/force_style(后两个=AI没核同款,已发布表标🟢)
        "spec_code": _spec_code_result,
        "units_map": _smart_units_map or {},  # Preserve the same smart-SKU quantities used for pricing and verification.
    }
    # 份数存疑标记:fill_prices 里 LLM 和正则打架的 SKU(取了大值,待人工复核)
    _uncertain = globals().get('_units_uncertain', []) or []
    if _uncertain:
        record["units_uncertain"] = _uncertain
        print(f"[份数存疑] 本商品 {len(_uncertain)} 个 SKU 份数 LLM/正则不一致,已标记待人工复核")
    # 产品类型存疑:标题没匹配上选项、7B也没定,选了第一项(待人工复核)
    _pt = globals().get('_PRODUCT_TYPE_UNCERTAIN', None)
    if _pt:
        record["product_type_uncertain"] = _pt
        print(f"[产品类型存疑] 选了「{_pt.get('picked','')}」(选项{_pt.get('options')}),已标记待人工复核")
    # 贴/片份数不可算兜底:加原因,当成功处理(已0库存上架),不换候选、不进未对齐
    _fr = globals().get("_FREEBIE_REPAIR", None)
    if _fr:
        record["freebie_repair"] = _fr
    if _amb:
        record["price_note"] = "份数按贴/片估算(整盒贴数未知),已0库存上架,需人工核价"
        record["units_ambiguous_specs"] = sorted(set(_amb_specs))
    write_publish_history(record)
    if _amb:
        print("[FINAL] 💰 已0库存上架,份数按贴/片不可算 → 标记「需人工核价」")
        await _close_current_goods_tabs(context, goods_id, form_page, detail_page, edit_page)
        return "ok"
    if verified:
        print("[FINAL] ✅ 商品发布完成 + 核对一致")
        await _close_current_goods_tabs(context, goods_id, form_page, detail_page, edit_page)
        return "ok"
    print("[FINAL] ⚠ 商品已上架但核对存在差异(需人工核查/下架)")
    await _close_current_goods_tabs(context, goods_id, form_page, detail_page, edit_page)
    return "mismatch"


async def _prepare_single_start_page(context):
    """Persistent Chrome profiles may restore old tabs on some customer machines; keep one clean tab."""
    pages = list(getattr(context, "pages", []) or [])
    if not pages:
        return await context.new_page()
    keep = pages[0]
    closed = 0
    for p in pages[1:]:
        try:
            await p.close()
            closed += 1
        except Exception:
            pass
    if len(pages) > 1:
        print(f"[tabs] 启动时恢复了 {len(pages)} 个标签页,已关闭多余 {closed} 个")
    return keep

async def run(args):
    globals()['final_status'] = "fail"  # 默认失败，验证通过才置 ok
    if args.list:
        list_stores(); return

    chrome_exe = find_chrome()
    print(f"[Chrome] {chrome_exe}")

    # 选 profile
    stores = _load_stores()
    if args.new or (not args.store and not stores):
        # 新店铺：先用临时占位名，登录后更新
        tmp_name = f"new_{int(time.time())}"
        profile_dir = _profile_dir_for(tmp_name)
        pending_rename = True
    elif args.store:
        # 先在已有里模糊匹配
        matched = next((k for k in stores if args.store in k or k in args.store), None)
        if matched:
            profile_dir = PROFILE_DIR / stores[matched]
            print(f"[profile] 匹配到: {matched}")
        else:
            profile_dir = _profile_dir_for(args.store)
        pending_rename = False
    else:
        # 用最近的
        latest = max(stores.items(), key=lambda kv: (PROFILE_DIR / kv[1]).stat().st_mtime
                     if (PROFILE_DIR / kv[1]).exists() else 0)
        profile_dir = PROFILE_DIR / latest[1]
        print(f"[profile] 最近使用: {latest[0]}")
        pending_rename = False

    print(f"[profile] 目录: {profile_dir}")

    # 浏览器显隐:默认静默(窗口挪屏幕外+固定大尺寸,不挡桌面、按钮不出界);
    # --show-browser 时最大化显示,方便盯着看。
    # ⚠ 扫码登录(--new)必须显示在屏幕内,否则二维码被挪到屏幕外根本扫不到 → 强制显示。
    _show_win = bool(getattr(args, "show_browser", False) or args.new)
    if _show_win:
        _win_args = ["--start-maximized"]
    else:
        _win_args = ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            executable_path=chrome_exe,
            headless=False,
            args=_win_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        page = await _prepare_single_start_page(context)

        await apply_window_mode(context, page, _show_win)   # --new 扫码登录强制屏幕内

        ok = await open_page(context, page, wait_for_login=bool(args.new))
        if not ok:
            await context.close(); return

        # 检测店铺名
        store = await detect_store_name(page)
        print(f"[店铺] {store!r}")
        if store and pending_rename:
            # 更新 stores.json：把临时名替换为真实名
            stores = _load_stores()
            old_key = next((k for k, v in stores.items()
                            if str(PROFILE_DIR / v) == str(profile_dir)), None)
            if old_key and old_key != store:
                stores[store] = stores.pop(old_key)
                _save_stores(stores)
                print(f"[profile] 已注册为: {store}")

        # 截图
        await page.screenshot(path="D:/files/pdd_chance_page.png", full_page=True)
        print("[OK] 截图: pdd_chance_page.png")

        # --new 扫码登录专属收尾:此时已登录 + 店铺名已写入 stores.json。
        # 直接关浏览器并退出,不进下面的图搜/探查流程(那是发布用的)。
        # 检测到店铺名 = 登录成功(exit 0);没检测到 = 已登录但名字没拿到(exit 2),客户端据此弹窗。
        if args.new:
            _login_ok = bool(store)
            print(f"[OK] 登录{'成功' if _login_ok else '完成但未检测到店铺名'},store={store!r},关闭浏览器退出")
            try:
                await asyncio.wait_for(context.close(), timeout=3)
            except Exception as e:
                print(f"[!] context.close 异常(继续退出): {e}")
            sys.stdout.flush()
            import os as _os
            _os._exit(0 if _login_ok else 2)

        if args.image:
            fi = await find_and_click_camera(page)
            if fi:
                image_path = str(Path(args.image).resolve())
                print(f"[上传] {image_path}")
                await fi.set_input_files(image_path)
                result_page = await click_query_button(page)
                if result_page:
                    print("[OK] 已点击查询，等待结果加载...")
                    await asyncio.sleep(6)
                    await result_page.screenshot(path="D:/files/pdd_results.png", full_page=True)
                    print("[OK] 结果截图: pdd_results.png")
                    verified = await verify_image_search_results(result_page)
                    if verified:
                        print("[OK] 查询结果已确认与上传图片对应")
                        items = await parse_results(result_page)
                        # 只保留真实商品（btnPos 非空，过滤掉价格文本误匹配）
                        real_items = [x for x in items if x.get('btnPos')]
                        # 按热度倒序：100 优先，失败则用次高（95、94...）
                        # 取热度前 7 个候选(PDD图搜第一排=7个),给 VLM 同款核对逐个判
                        MAX_CANDIDATES = 7
                        candidates_all = sorted(real_items, key=lambda x: -x['heat'])
                        candidates = candidates_all[:MAX_CANDIDATES]
                        print(f"\n[目标筛选] 真实商品共 {len(candidates_all)} 个，"
                              f"按热度倒序取前 {len(candidates)} 个(上限={MAX_CANDIDATES})"
                              f"  最高热度={candidates[0]['heat'] if candidates else 0}")
                        if not candidates:
                            print(f"\n[!] 未找到真实商品(共{len(real_items)}个真实结果)")
                        # ── VLM 同款核对闸门(--vlm-gate)/ 人工强发(--force-style) ──
                        gate_mode = ""
                        vlm_candidate_pool = list(candidates)
                        if getattr(args, "force_style", False) and candidates:
                            candidates, gate_mode = _force_select(args, candidates)
                            print(f"[人工强发] 无视VLM,按相似度+热度选定 {len(candidates)} 个候选")
                        elif getattr(args, "vlm_gate", False) and candidates:
                            candidates, gate_mode, _gmsg = await _vlm_select(args, vlm_candidate_pool)
                            print(f"[同款核对] 结论={gate_mode}  {_gmsg}")
                            if gate_mode == "no_same_style":
                                globals()['final_status'] = "no_same_style"
                                print("[同款核对] 前候选均非同款 → 不发布,留【待发布】标『无同款·品牌不一致』")
                        globals()['_PUBLISH_GATE'] = gate_mode
                        # 候选 loop:每个候选完整跑一遍 process_single_candidate;
                        # ★retry 失败一次就换下一个同款候选。VLM 模式会懒加载下一个同款,
                        #   最多试 MAX_VLM_SAME_CANDIDATES 个同款,避免同一个坏版面/坏候选反复卡住。
                        # 成功(ok/mismatch)或硬失败(fail)就 break 出循环。
                        RETRY_PER_CAND = 1
                        for ci, cand in enumerate(candidates, 1):
                            result = "retry"
                            for attempt in range(1, RETRY_PER_CAND + 1):
                                print(f"\n[尝试 候选{ci}/{len(candidates)} 第{attempt}/{RETRY_PER_CAND}次] ¥{cand['price']:.2f}  热度{cand['heat']}  {cand['name'][:40]}")
                                result = await process_single_candidate(context, result_page, cand, args)
                                print(f"[候选 {ci}/{len(candidates)} 第{attempt}次] 处理结果 = {result}")
                                if result != "retry":
                                    break
                                # 关闭可能残留的非 result_page tab,避免下次 click_publish 干扰,再重试同一候选
                                try:
                                    extras = [p for p in context.pages
                                              if p not in (page, result_page)
                                              and "chance_list" not in (p.url or "")]
                                    for p in extras:
                                        try: await p.close()
                                        except Exception: pass
                                except Exception: pass
                            if result == "ok":
                                globals()['final_status'] = "ok"
                                break
                            elif result == "mismatch":
                                globals()['final_status'] = "fail"  # mismatch 算 fail 但 history 已写
                                break
                            elif result == "fail":
                                globals()['final_status'] = "fail"
                                break
                            # result == "retry"→ VLM模式下再从剩余候选懒加载下一个同款,最多3个。
                            if (result == "retry" and gate_mode == "vlm_same"
                                    and getattr(args, "vlm_gate", False)
                                    and len(candidates) < MAX_VLM_SAME_CANDIDATES):
                                more, more_mode, more_msg = await _vlm_select_next(args, vlm_candidate_pool, candidates)
                                print(f"[同款核对] 当前同款候选失败,继续识别下一个: {more_mode}  {more_msg}")
                                if more_mode == "vlm_same" and more:
                                    candidates.extend(more)
                                    continue
                            # result == "retry"→ 换下一候选(若有)
                        else:
                            # for loop 完整跑完没 break = 所有候选都 retry 失败
                            # (no_same_style 已在闸门设状态、candidates 为空,别覆盖)
                            if globals().get('final_status') != "no_same_style" and candidates:
                                print(f"\n[!] 所有 {len(candidates)} 个候选都重试失败")
                                globals()['final_status'] = "fail_all_candidates_retry"
                    else:
                        print("[!] 查询结果验证失败，请人工确认")
            else:
                print("[!] 未找到相机按钮")
        else:
            print("\n[探查模式] 分析相机按钮位置...")
            await find_and_click_camera(page)

        if args.auto_close:
            # 失败时保存所有打开页面的截图,放日志同目录方便人工排查
            if final_status != "ok":
                try:
                    import time as _t
                    ts = _t.strftime("%Y%m%d_%H%M%S")
                    prefix = args.log_prefix or str(APP_DIR / "data" / "pdd" / "publish_logs" / f"fail_{ts}")
                    pages = list(context.pages)
                    print(f"[失败截图] 共 {len(pages)} 个开启的页面,保存中...")
                    for i, p in enumerate(pages):
                        try:
                            png_path = f"{prefix}_fail_page{i+1}.png"
                            await asyncio.wait_for(
                                p.screenshot(path=png_path, full_page=True),
                                timeout=5)
                            url = p.url[:80]
                            print(f"[失败截图] page{i+1}: {png_path}  url={url}")
                        except Exception as e:
                            print(f"[失败截图] page{i+1} 异常: {e}")
                except Exception as e:
                    print(f"[失败截图] 整体异常: {e}")
            print(f"[OK] 任务完成 (status={final_status})，准备关闭浏览器并退出...")
            await asyncio.sleep(2)
            try:
                await asyncio.wait_for(context.close(), timeout=3)
            except Exception as e:
                print(f"[!] context.close 异常或超时（继续退出）: {e}")
            exit_code = 0 if final_status == "ok" else 2
            print(f"[OK] === 子进程即将退出 exit_code={exit_code} ===")
            sys.stdout.flush()
            import os as _os
            _os._exit(exit_code)
        else:
            print("[OK] 浏览器保持开启，等待确认后手动关闭...")
            try:
                await page.wait_for_event("close", timeout=0)
            except Exception:
                pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--store",  default="", help="店铺名")
    ap.add_argument("--image",  default="", help="图片路径")
    ap.add_argument("--xuanpin-image-url", default="", help="选品图(我方图)URL,原样存进 history 供已发布表展示(平移自待发布)")
    ap.add_argument("--source-image-url",  default="", help="货源图(1688)URL,原样存进 history 供已发布表展示(平移自待发布)")
    ap.add_argument("--supplier-url", default="", help="1688 供应商详情页 URL")
    ap.add_argument("--source-prod-id", default="", help="选品 ID，原样存入 history 供视频补传直接使用")
    ap.add_argument("--source-insight-url", default="", help="单品洞察链接，原样存入 history 供视频补传直接使用")
    ap.add_argument("--supplier-cost", type=float, default=0, help="供应商单件供货价（元），用于计算拼单价/单买价")
    ap.add_argument("--is-special", default="", help="是否特殊用途化妆品(是/否),商品库预核对值;传了就不再开1688页抓")
    ap.add_argument("--license-no", default="", help="化妆品批准文号/备案号,商品库预核对值;传了就不再开1688页抓")
    ap.add_argument("--carousel-shift", type=int, default=0,
                    help="同商品发多条时,把轮播图第 N 张(0-based)拖到首位换主图,防 PDD 判重复铺货;0=不动(默认)")
    # 定价规则参数（向后兼容；默认值 = 老硬编码"强付费高定价"模式）
    ap.add_argument("--shipping", type=float, default=4.0, help="运费（元/单），计入成本")
    ap.add_argument("--margin", type=float, default=0.9, help="毛利率（0~1），group_price = cost / (1 - margin)")
    ap.add_argument("--single-extra", type=float, default=2.0, help="单买价相对拼单价的加价（元）")
    ap.add_argument("--suffix", default="+面膜1片", help="规格名追加的防比价搭配后缀")
    ap.add_argument("--stock", type=int, default=8888, help="改后库存值")
    ap.add_argument("--rule-name", default="强付费高定价", help="定价规则名称（仅用于历史记录 mode 字段）")
    ap.add_argument("--log-prefix", default="", help="失败截图前缀(client.py 传入,无扩展名)")
    ap.add_argument("--auto-close", action="store_true", help="任务完成后自动关闭浏览器并退出（供 client.py 子进程调用）")
    ap.add_argument("--show-browser", action="store_true", help="显示浏览器（调试用）；默认屏幕外静默不打扰")
    ap.add_argument("--list",   action="store_true", help="列出店铺")
    ap.add_argument("--new",    action="store_true", help="新店铺登录")
    ap.add_argument("--smart-sku", action="store_true",
                    help="智能SKU:云端判份数,判不准则清掉照1688真料重建SKU(默认关,不影响日常发布)")
    ap.add_argument("--force-sku-rebuild", action="store_true",
                    help="诊断用:强制走智能SKU重建路径(无视云端keepable判定),配合 reset_specs 诊断日志捕捉重置规格弹窗")
    ap.add_argument("--vlm-gate", action="store_true",
                    help="VLM同款核对闸门:查前7候选,挑「同款+热度最高」发;全不同款→不发(no_same_style);AI连不上→回退热度发+标🟢绿旗")
    ap.add_argument("--force-style", action="store_true",
                    help="人工强发:无视VLM否决,按 DINOv2相似度+热度 挑1个发(待发布页对「无同款」商品人工授权用)")
    args = ap.parse_args()
    _crash = False
    try:
        asyncio.run(run(args))
    except Exception:
        # run() 抛了未捕获异常(多为瞬时/候选相关):打印 traceback 进日志。
        # 否则下面的 os._exit 会抢在解释器打印 traceback 之前终止进程,
        # 把崩溃伪装成 exit 0 且 traceback 永不出现(2026-06-16 实测踩过)。
        import traceback
        traceback.print_exc()
        _crash = True
    finally:
        try:
            sys.stdout.flush()
        except Exception:
            pass
        if args.auto_close:
            # 兜底强制退出,确保 QProcess.finished 触发。
            # 崩溃→非0(3),让父进程正确判失败而非误判成功;
            # 正常路径 run() 内部已自行 _os._exit,走不到这里。
            import os
            os._exit(3 if _crash else 0)
