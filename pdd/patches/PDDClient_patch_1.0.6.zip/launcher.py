from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from auto_updater import check_and_apply_update
from license_gate import ensure_license_or_prompt


BASE_DIR = Path(__file__).resolve().parent


def main() -> int:
    check_and_apply_update(show_ui=True)

    if not ensure_license_or_prompt():
        return 1

    subprocess.Popen(
        [sys.executable, str(BASE_DIR / "client.py")],
        cwd=str(BASE_DIR),
        close_fds=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
