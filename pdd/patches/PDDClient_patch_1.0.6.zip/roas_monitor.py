"""推广监控 / 数据回传引擎 —— 抓 PDD 推广列表的 live 数据,回传给「自动推广」页 + 自动调车用。

只读:打开推广中心列表(yingxiao…/promotion/list)→ 逐条在推广的计划读:
  {goods_id, 状态, 净目标投产比, 预算日限额, 退款豁免率,
   花费, 曝光, 点击, 结算交易额, 结算投产比, 结算成交笔数, 每笔成交花费, … 成交笔数}
写 data/pdd/roas_monitor.json = {goods_id: {...}}。**不改任何计划**(关车/调车是另一个引擎)。

列表是 beast-core-table,td 直读常为空 → 按【行 innerText】正则 + 尾部指标序列解析。
表头顺序(2026-06-21 实测): 推广 / 推广状态 / 预算及出价 / 操作 /
  总花费 / 曝光量 / 点击量 / 结算交易额 / 结算投产比 / 结算成交笔数 /
  每笔结算成交花费 / 交易额结算率 / 订单结算率 / 每笔结算成交金额 / 点击率 / 点击转化率 / 成交笔数
即"操作"后共 13 个指标列,按位映射。
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from playwright.async_api import async_playwright

import roas_calc
from pdd_publish import find_chrome, _load_stores, _profile_dir_for, PROFILE_DIR, apply_window_mode

PROMO_URL = "https://yingxiao.pinduoduo.com/goods/promotion/list?msfrom=mms_sidenav"
MONITOR_PATH = Path(r"D:/files/data/pdd/roas_monitor.json")

# "操作"列之后的 13 个指标列(按表头顺序)
# ★列顺序(2026-06-25 会话⑥ 复位):点击率/点击转化率 在【最后】,不在点击量后面。
#   ⑤ 曾把它俩挪到点击量后(第4/5位)→ 现网整列错位(结算交易额被当点击率、投产比被当转化率、
#   结算成交笔数被当结算交易额…图1客户端 969237255850 即此症)。对 roas_monitor.json 36 行有花费的
#   做算术交叉验证坐实本序全对(36/36 吻合):
#   点击率=点击/曝光、点击转化率=成交笔数/点击、投产比=交易额/花费、每笔成交花费=花费/结算笔数、
#   订单结算率=结算笔数/成交笔数、每笔成交金额=交易额/结算笔数。
#   ★按位贴本就脆(PDD 列序会变);改后旧 roas_monitor.json 是错的,需重新「📊抓数据」刷新。
METRIC_KEYS = ["花费", "曝光", "点击", "结算交易额", "结算投产比", "结算成交笔数", "每笔成交花费",
               "交易额结算率", "订单结算率", "每笔成交金额", "点击率", "点击转化率", "成交笔数"]

# ── 列序自检/自动纠偏:PDD 改版会调列顺序(本工程已栽两次),纯按位贴必错位。
#    每次抓数据用【有花费+点击+成交笔数的富行】跑算术不变式投票选对的列序;
#    候选都不吻合→警告并回退默认请人工核对(绝不silently错位)。──
_ORDER_V5 = ["花费", "曝光", "点击", "点击率", "点击转化率", "结算交易额", "结算投产比",
             "结算成交笔数", "交易额结算率", "订单结算率", "每笔成交金额", "每笔成交花费", "成交笔数"]
_CANDIDATE_ORDERS = [METRIC_KEYS, _ORDER_V5]   # 平局/默认 → 规范序(列表靠前)先中

# PDD 会按店铺/功能灰度调整指标列，优先按页面表头动态映射；拿不到表头时才走旧的列序自检。
_METRIC_HEADER_ALIASES = {
    "总花费": "花费", "总花费(元)": "花费", "总花费（元）": "花费",
    "曝光量": "曝光", "点击量": "点击",
    "结算交易额": "结算交易额", "结算交易额(元)": "结算交易额", "结算交易额（元）": "结算交易额",
    "结算投产比": "结算投产比", "结算成交笔数": "结算成交笔数",
    "每笔结算成交花费": "每笔成交花费", "每笔结算成交花费(元)": "每笔成交花费", "每笔结算成交花费（元）": "每笔成交花费",
    "交易额结算率": "交易额结算率", "订单结算率": "订单结算率",
    "每笔结算成交金额": "每笔成交金额", "每笔结算成交金额(元)": "每笔成交金额", "每笔结算成交金额（元）": "每笔成交金额",
    "点击率": "点击率", "点击转化率": "点击转化率", "成交笔数": "成交笔数",
}


def _order_from_headers(headers):
    order = []
    seen = set()
    for h in headers or []:
        key = _METRIC_HEADER_ALIASES.get(str(h).strip())
        if key and key not in seen:
            seen.add(key)
            order.append(key)
    return order


def _to_num(v):
    if v in (None, ""):
        return None
    try:
        return float(str(v).replace("%", "").replace(",", ""))
    except Exception:
        return None


def _order_score(nums, order):
    """一行 nums 按 order 映射后,满足几个算术不变式(点击率=点击/曝光 等)。容 3% 或 0.05。"""
    m = {k: (nums[i] if i < len(nums) else "") for i, k in enumerate(order)}
    g = lambda k: _to_num(m.get(k))
    花费, 曝光, 点击 = g("花费"), g("曝光"), g("点击")
    交易额, 投产比, 结算笔数, 每笔花费 = g("结算交易额"), g("结算投产比"), g("结算成交笔数"), g("每笔成交花费")
    成交笔数, 点击率, 点击转化率, 订单结算率, 每笔成交金额 = (
        g("成交笔数"), g("点击率"), g("点击转化率"), g("订单结算率"), g("每笔成交金额"))

    def ok(a, b):
        return a is not None and b is not None and abs(a - b) <= max(0.05, abs(b) * 0.03)
    s = 0
    if 曝光 and ok(点击率, (点击 or 0) / 曝光 * 100): s += 1
    if 点击 and ok(点击转化率, (成交笔数 or 0) / 点击 * 100): s += 1
    if 花费 and ok(投产比, (交易额 or 0) / 花费): s += 1
    if 结算笔数 and ok(每笔花费, 花费 / 结算笔数): s += 1
    if 结算笔数 and ok(每笔成交金额, (交易额 or 0) / 结算笔数): s += 1
    if 成交笔数 and ok(订单结算率, (结算笔数 or 0) / 成交笔数 * 100): s += 1
    return s


def _is_rich(nums):
    """有花费+点击+成交笔数 的行才有区分力(0花费/0成交行算术两边都碰巧成立,排除)。
    成交笔数在所有候选序里都是末位 → 直接取 nums[12],不依赖列序。"""
    if len(nums) < 13:
        return False
    f, c, last = _to_num(nums[0]), _to_num(nums[2]), _to_num(nums[12])
    return bool(f and f > 0 and c and c > 0 and last and last > 0)


def _pick_order(rows):
    """富行投票选列序。返回 (order, switched, note)。
    高度吻合某候选→用它;都不吻合→默认+警告;无富行→默认不动(信息不足不乱切)。"""
    rich = [r.get("nums") for r in rows if _is_rich(r.get("nums") or [])]
    rich.sort(key=lambda n: _to_num(n[0]) or 0, reverse=True)
    rich = rich[:5]
    if not rich:
        return METRIC_KEYS, False, "no-rich(信息不足,保持默认)"
    possible = 6 * len(rich)
    scored = [(sum(_order_score(n, o) for n in rich), o) for o in _CANDIDATE_ORDERS]
    bestscore = max(s for s, _ in scored)
    best = next(o for s, o in scored if s == bestscore)
    defscore = next(s for s, o in scored if o is METRIC_KEYS)
    if bestscore < possible * 0.8:
        return METRIC_KEYS, False, f"no-match(best={bestscore}/{possible}) PDD可能换新列序!用默认,请人工核对"
    if best is not METRIC_KEYS and bestscore > defscore:
        return best, True, f"switched(best={bestscore} def={defscore}) PDD列序变了→自动纠偏"
    return METRIC_KEYS, False, f"default-ok({defscore}/{possible})"


async def _collect_page_rows(pg, scrape_js: str) -> list[dict]:
    """当前页:虚拟滚动表只渲染视口内的行(滚出去会被卸载)→ 鼠标滚轮逐段下滚,边滚边抓,
    按 gid 去重累积,连续多次不再新增=到底。返回这一页全部行。"""
    by_gid = {}
    try:
        await pg.mouse.move(900, 500)        # 鼠标移到表格区,滚轮才作用在表上
        # ★先滚到顶:翻页后页面常停在底部(翻页按钮在底部),不回顶会漏掉本页顶部的行
        for _ in range(18):
            await pg.mouse.wheel(0, -1500)
            await asyncio.sleep(0.12)
        await asyncio.sleep(0.5)
    except Exception:
        pass
    stagnant = 0
    for _ in range(80):
        for r in await pg.evaluate(scrape_js):
            by_gid[r["gid"]] = r
        before = len(by_gid)
        try:
            await pg.mouse.wheel(0, 700)
        except Exception:
            try:
                await pg.evaluate("()=>window.scrollBy(0, 700)")
            except Exception:
                pass
        await asyncio.sleep(0.7)
        for r in await pg.evaluate(scrape_js):
            by_gid[r["gid"]] = r
        if len(by_gid) == before:
            stagnant += 1
            if stagnant >= 5:                # 连续5次没新增 = 滚到底了
                break
        else:
            stagnant = 0
    return list(by_gid.values())


async def scan_promotions(context, store=None) -> list[dict]:
    """打开推广列表,逐条计划解析。返回 [{goods_id, status, target_roas, budget, exempt, metrics{...}, raw}]。"""
    pg = await context.new_page()
    rows = []
    metrics_by_range = {}        # {gid: {日期档: {指标..}}} 各产品历史档数据(昨日/近7日/近30日 每天抓1次)
    scan_labels = ['今日']
    try:
        await pg.goto(PROMO_URL, wait_until="domcontentloaded", timeout=40000)
        await asyncio.sleep(7)
        # 顺手抓顶部「推广数据」汇总面板(4个日期档:今日/昨日/近7日/近30日)→ 存 roas_summary.json
        if store:
            try:
                from roas_summary import scrape_ranges, save_summary_merged, ranges_to_scrape
                scan_labels = ranges_to_scrape(store)   # 今日每轮抓;昨日/近7日/近30日每天只抓1次
                _rg = await scrape_ranges(pg, scan_labels)
                save_summary_merged(store, _rg)     # 按档合并,只抓今日时保留历史档
                _t = _rg.get('今日', {})
                print(f"[监控] 汇总面板已抓({'/'.join(scan_labels)}): 今日花费={_t.get('总花费')} 结算投产={_t.get('结算投产比')}", file=sys.stderr)
            except Exception as _e:
                print(f"[监控] 汇总抓取跳过(不影响监控): {_e}", file=sys.stderr)
        _SCRAPE_JS = r"""() => {
            const tbls=[...document.querySelectorAll('table')];
            let body=null,maxb=0;
            for(const t of tbls){const n=t.querySelectorAll('tbody tr').length; if(n>maxb){maxb=n;body=t;}}
            if(!body) return [];
            const clean=s=>(s||'').replace(/ /g,' ').replace(/\r/g,'').trim();
            const fullText=clean(document.body.innerText||'');
            const tableText=clean(body.innerText||'');
            function metricHeaders(){
                let source=tableText, start=tableText.indexOf('推广状态'), end=tableText.indexOf('合计数据');
                if(!(start>=0 && end>start)){
                    source=fullText; start=fullText.indexOf('推广状态'); end=fullText.indexOf('合计数据');
                    if(start<0) start=fullText.indexOf('总花费');
                }
                if(!(start>=0 && end>start)) return [];
                return source.slice(start,end).split('\n').map(clean).filter(Boolean);
            }
            const headers=metricHeaders();
            const out=[];
            for(const tr of body.querySelectorAll('tbody tr')){
                const txt=(tr.innerText||'').replace(/ /g,' ').replace(/\r/g,'');
                const gm=txt.match(/商品\s*ID[：:]\s*(\d{6,})/);
                if(!gm) continue;
                const roi=(txt.match(/净目标投产比[\s：:]*([0-9.]+)/)||[])[1]||'';
                const bud=((txt.match(/预算日限额[\s：:]*([0-9,.]+|不限)/)||[])[1]||'').replace(/,/g,'');
                const exempt=(txt.match(/退款豁免率[^0-9]*([0-9.]+)\s*%/)||[])[1]||'';
                const tp=(txt.match(/拼单价[：:]\s*([0-9.]+)/)||[])[1]||'';
                const stage=(txt.match(/(一阶段|二阶段)/)||[])[1]||'';
                const swEl=tr.querySelector('[data-testid^="adStatusSwitch"]');
                const adId=swEl?(swEl.getAttribute('data-testid').replace('adStatusSwitch-','')):'';
                // ★状态以【状态开关 aria-checked】为准(true=推广中 / false=暂停),最可靠。
                //   别用文本:"手动暂停"既可能是状态也可能是动作,"推广中"也可能出现在别处 → 误判。
                let swAria = swEl ? swEl.getAttribute('aria-checked') : null;
                if(swAria===null && swEl){const a=swEl.querySelector('[aria-checked]'); if(a) swAria=a.getAttribute('aria-checked');}
                // 异常/受限状态(开关常还ON但实际投不出去):无可用创意/限制推广/推广受限/审核中等 → 报具体异常
                const ABN=['无可用创意','限制推广','推广受限','商品售罄','售罄','创意审核中','审核中','商品已下架','计划已结束','已结束'];
                let abn=''; for(const k of ABN){ if(txt.includes(k)){ abn=k; break; } }
                let status='未知';
                if(swAria==='false') status='已暂停';          // 手动暂停优先
                else if(abn) status=abn;                        // 开关ON但受限/无创意/审核 → 报具体异常
                else if(swAria==='true') status='推广中';
                else if(/手动暂停|已暂停|暂停中|计划已暂停/.test(txt)) status='已暂停';
                else if(txt.includes('推广中')) status='推广中';
                // 尾部指标:"操作"区(详情/数据/更多)之后的数字序列
                let tail=txt;
                const k=tail.lastIndexOf('更多'); if(k>=0) tail=tail.slice(k+2);
                // ★先去千分位逗号:PDD 大数字如曝光「5,029」会被正则拆成 5 和 029 → 后面指标整体错位一格。
                const nums=(tail.replace(/,/g,'').match(/-?[0-9]+\.?[0-9]*%?/g)||[]);
                // 行内商品主图:取面积最大的那张 http(s) 图(商品缩略图最大,图标/箭头都小)
                let img='', best=0;
                for(const im of tr.querySelectorAll('img')){
                    const rc=im.getBoundingClientRect(); const a=rc.width*rc.height;
                    const s=im.src||im.getAttribute('data-src')||'';
                    if(a>best && /^https?:/.test(s)){ best=a; img=s; }
                }
                out.push({gid:gm[1], adId, roi, bud, exempt, status, tp, stage, nums, img, headers});
            }
            return out;
        }"""
        _ACTIVE_PAGE_JS = ("()=>{const a=document.querySelector('.anq-pagination-item-active');"
                           "return a?(a.innerText||'').trim():'';}")
        # 翻回第1页:切日期档后分页不会自动回第1页,不回的话会从上一档停留的页开始抓→漏前面的页。
        async def _goto_first_page():
            for _ in range(35):
                prev = pg.locator('.anq-pagination-prev').first
                if not await prev.count():
                    break
                cls = (await prev.get_attribute("class")) or ""
                if "disabled" in cls or (await prev.get_attribute("aria-disabled")) == "true":
                    break
                try:
                    await prev.click(timeout=3000)
                except Exception:
                    try:
                        await prev.click(force=True, timeout=3000)
                    except Exception:
                        break
                await asyncio.sleep(1.2)

        # ★逐页抓:推广列表默认每页50条,产品多了会分页 → 先回第1页,再翻到底(不止抓第一页)。各日期档复用。
        async def _scrape_all_pages():
            await _goto_first_page()
            out = []
            page_no = 0
            while True:
                page_no += 1
                out.extend(await _collect_page_rows(pg, _SCRAPE_JS))   # 边滚边抓,拿全本页(治虚拟滚动漏行)
                nxt = pg.locator('.anq-pagination-next').first
                if not await nxt.count():
                    break                                    # 没分页控件 = 单页
                cls = (await nxt.get_attribute("class")) or ""
                if "disabled" in cls or (await nxt.get_attribute("aria-disabled")) == "true":
                    break                                    # 下一页禁用 = 末页
                if page_no >= 30:
                    print("[监控] 已翻到30页上限,停", file=sys.stderr)
                    break
                cur = await pg.evaluate(_ACTIVE_PAGE_JS)
                try:
                    await nxt.click(timeout=4000)
                except Exception:
                    try:
                        await nxt.click(force=True, timeout=4000)
                    except Exception:
                        break
                await asyncio.sleep(3)                        # 等下一页渲染
                new = await pg.evaluate(_ACTIVE_PAGE_JS)
                if cur and new and cur == new:
                    break                                    # 页码没变 = 没翻动,停
            return out

        rows = await _scrape_all_pages()   # 今日(summary 抓完已回到今日档)
        print(f"[监控] 今日列表抓了 {len(rows)} 行", file=sys.stderr)
        # ★列序:优先按当前页面表头动态映射；拿不到表头时才用富行算术不变式兜底。
        header_order = _order_from_headers((rows[0].get("headers") if rows else []) or [])
        if header_order:
            active_order, _order_switched, _order_note = header_order, False, "header:" + "/".join(header_order)
        else:
            active_order, _order_switched, _order_note = _pick_order(rows)
        print(f"[监控][列序] {_order_note}", file=sys.stderr)
        # ── 临时诊断日志(查单品历史档为何没抓到;定位后删)──
        def _dbg(msg):
            try:
                with open(r"D:/files/data/pdd/range_debug.log", "a", encoding="utf-8") as _f:
                    _f.write(f"{__import__('time').strftime('%H:%M:%S')} [{store}] {msg}\n")
            except Exception:
                pass
        # ★各产品历史档(昨日/近7日/近30日):仅"全档抓取日"抓——逐档点切→翻页抓→按gid存指标。
        #   不影响今日(失败只是少了历史档);单品状态/预算/投产只认今日那份(它们不随日期档变)。
        _extra = [l for l in scan_labels if l != '今日']
        _dbg(f"今日{len(rows)}行 | scan_labels={scan_labels} | _extra={_extra}")
        if store and _extra:
            try:
                from roas_summary import _click_range
                for _lab in _extra:
                    _ok = await _click_range(pg, _lab); await asyncio.sleep(3)
                    _rr = await _scrape_all_pages()
                    for _row in _rr:
                        _nums = _row.get("nums") or []
                        _range_order = _order_from_headers(_row.get("headers") or []) or active_order
                        _m = {k: (_nums[i] if i < len(_nums) else "") for i, k in enumerate(_range_order)}
                        metrics_by_range.setdefault(_row["gid"], {})[_lab] = _m
                    _dbg(f"{_lab}: 点档={_ok} 抓到{len(_rr)}行 首行gid={_rr[0]['gid'] if _rr else '无'}")
                    print(f"[监控] {_lab} 单品数据抓了 {len(_rr)} 行", file=sys.stderr)
            except Exception as _e:
                import traceback
                _dbg(f"历史档异常: {repr(_e)} | {traceback.format_exc()[-300:]}")
                print(f"[监控] 单品历史档抓取跳过(不影响今日): {_e}", file=sys.stderr)
        else:
            _dbg(f"跳过历史档抓取: store={bool(store)} _extra={_extra}")
    finally:
        try: await pg.close()
        except Exception: pass

    parsed = []
    for r in rows:
        nums = r.get("nums") or []
        metrics = {}
        for i, key in enumerate(active_order):
            metrics[key] = nums[i] if i < len(nums) else ""
        gid = r["gid"]
        mbr = {"今日": metrics}
        mbr.update(metrics_by_range.get(gid, {}))   # 本轮抓到的历史档(昨日/近7日/近30日)
        parsed.append({
            "goods_id":   gid,
            "ad_id":      r.get("adId", ""),    # 计划ID,直达数据页:list?adId=<ad_id>&drawerTab=unit
            "status":     r.get("status", "未知"),
            "target_roas": r.get("roi", ""),     # 当前净目标投产比
            "stage":       r.get("stage", ""),   # 一阶段/二阶段(7天跑满20单进二阶段)
            "group_price": r.get("tp", ""),      # 拼单价(实际售价)
            "img":        r.get("img", ""),      # 行内商品主图 URL(抓数据时一并抓,补"图"列)
            "budget":     r.get("bud", ""),      # 预算日限额(数字或"不限")
            "exempt":     r.get("exempt", ""),   # 退款豁免率%
            "metrics":    metrics,               # 今日(兼容旧字段)
            "metrics_by_range": mbr,             # {日期档: 指标},供表格按档切换
        })
    return parsed


def save_monitor_merged(by_gid: dict, store: str) -> dict:
    """把【本店铺】这次抓到的计划并入 roas_monitor.json:保留其它店铺数据,只替换本店铺这一片
    (本店铺旧条目先清掉=丢弃已删/已结束的,再并入这次抓的)→ 多店铺互不覆盖。返回合并后的全量。"""
    live_keys = {
        "goods_id", "ad_id", "status", "target_roas", "stage", "group_price",
        "img", "budget", "exempt", "metrics", "metrics_by_range", "store",
    }
    existing = {}
    if MONITOR_PATH.exists():
        try:
            existing = json.loads(MONITOR_PATH.read_text(encoding="utf-8"))
            if not isinstance(existing, dict):
                existing = {}
        except Exception:
            existing = {}
    # ★保留各 gid 已有的历史档单品数据:本轮只抓今日时,昨日/近7日/近30日 沿用旧值(否则会被覆盖丢失)
    for g, d in by_gid.items():
        old = existing.get(g) or {}
        old_mbr = old.get("metrics_by_range") or {}
        new_mbr = d.get("metrics_by_range") or {}
        for _rng, _m in old_mbr.items():
            if _rng not in new_mbr and _m:
                new_mbr[_rng] = _m
        d["metrics_by_range"] = new_mbr
        # 保留旧记录里的本地业务字段(如开车日期/人工标记/归属标记);
        # 本轮页面实时抓取字段仍覆盖更新,避免监控刷新抹掉本地状态。
        kept = {k: v for k, v in old.items() if k not in live_keys}
        if kept:
            kept.update(d)
            by_gid[g] = kept
    merged = {g: d for g, d in existing.items() if (d.get("store") or "") != store}
    merged.update(by_gid)
    MONITOR_PATH.parent.mkdir(parents=True, exist_ok=True)
    MONITOR_PATH.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
    return merged


async def run(args):
    stores = _load_stores()
    matched = next((k for k in stores if args.store in k or k in args.store), None)
    profile_dir = (PROFILE_DIR / stores[matched]) if matched else _profile_dir_for(args.store)
    print(f"[监控] store={args.store!r} profile={profile_dir}", file=sys.stderr)
    _win = (["--start-maximized"] if args.show_browser
            else ["--window-position=-32000,-32000", "--window-size=1700,1000"])
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir), executable_path=find_chrome(),
            headless=False, args=_win + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"], viewport=None)
        ip = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await apply_window_mode(ctx, ip, args.show_browser)
        try:
            data = await scan_promotions(ctx, args.store)
        finally:
            try: await asyncio.wait_for(ctx.close(), timeout=5)
            except Exception: pass

    # 按 goods_id 汇成 dict(同 id 取第一条),并入店铺
    by_gid = {}
    for d in data:
        d["store"] = args.store
        by_gid.setdefault(d["goods_id"], d)
    save_monitor_merged(by_gid, args.store)   # ★合并写:不覆盖其它店铺

    running = sum(1 for d in by_gid.values() if d["status"] == "推广中")
    print(f"[监控] 抓到 {len(by_gid)} 条在推广计划(推广中 {running}) → {MONITOR_PATH}", file=sys.stderr)
    for d in list(by_gid.values())[:8]:
        mt = d["metrics"]
        print(f"  {d['goods_id']} [{d['status']}] 目标={d['target_roas']} 预算={d['budget']} "
              f"花费={mt.get('花费')} 结算投产={mt.get('结算投产比')} 成交={mt.get('结算成交笔数')}",
              file=sys.stderr)
    print(json.dumps({"total": len(by_gid), "running": running, "output": str(MONITOR_PATH)}, ensure_ascii=False))


def main():
    ap = argparse.ArgumentParser(description="推广监控/数据回传(只读,不改计划)")
    ap.add_argument("--store", required=True, help="店铺名(模糊匹配)")
    ap.add_argument("--show-browser", action="store_true")
    ap.add_argument("--auto-close", action="store_true")
    args = ap.parse_args()
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        sys.exit(130)
    finally:
        if args.auto_close:
            os._exit(0)


if __name__ == "__main__":
    main()
