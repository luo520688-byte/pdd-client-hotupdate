﻿"""PDD 差评申诉：查询评价，或在用户最终确认后提交已编辑的申诉草稿。"""
import argparse
import asyncio
import json
import sys
import time
from datetime import datetime, timedelta

from playwright.async_api import async_playwright

from pdd_takedown import _profile_dir_for, find_chrome


REVIEW_PAGE_URL = "https://mms.pinduoduo.com/goods/evaluation/index?msfrom=mms_sidenav"
REVIEW_LIST_URL = "https://mms.pinduoduo.com/saturn/reviews/list"
REVIEW_SUBMIT_URL = "https://mms.pinduoduo.com/saturn/reportedReview/edit/createReportedReview"


def _browser_window_args(show_browser: bool) -> list[str]:
    """显示时强制新窗口居中，避免复用店铺 profile 里保存的屏幕外位置。"""
    if not show_browser:
        return ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    width, height = 1280, 860
    try:
        import ctypes
        screen_width = ctypes.windll.user32.GetSystemMetrics(0)
        screen_height = ctypes.windll.user32.GetSystemMetrics(1)
        width = min(width, max(1000, screen_width - 120))
        height = min(height, max(720, screen_height - 140))
        x = max(20, (screen_width - width) // 2)
        y = max(20, (screen_height - height) // 2)
    except Exception:
        x, y = 80, 60
    return ["--new-window", f"--window-position={x},{y}", f"--window-size={width},{height}"]

def _emit(payload: dict) -> None:
    print("REVIEW_APPEAL_RESULT=" + json.dumps(payload, ensure_ascii=False))


def _normalize(record: dict) -> dict:
    """只保留页面显示所需的评价字段，避免将会话或无关响应带回客户端。"""
    goods = record.get("goodsInfo") or record.get("goods") or {}
    return {
        "review_id": str(record.get("reviewId") or record.get("id") or ""),
        "order_sn": str(record.get("orderSn") or ""),
        "created_at": _format_time(record.get("reviewTime") or record.get("commentTime") or record.get("commentCreateTime") or record.get("evaluationTime") or record.get("createTime") or record.get("createdAt") or record.get("createdTime") or record.get("time")),
        "score": record.get("descScore") or record.get("score") or "",
        "content": str(record.get("comment") or record.get("reviewContent") or record.get("content") or ""),
        "goods_name": str(goods.get("goodsName") or record.get("goodsName") or ""),
        "goods_id": str(goods.get("goodsId") or record.get("goodsId") or ""),
        "report_status": (record.get("reportResult") or {}).get("status"),
        "report_desc": str((record.get("reportResult") or {}).get("desc") or ""),
    }



def _date_timestamp(value: str, *, end_of_day: bool = False) -> int:
    date = datetime.strptime(value, "%Y-%m-%d")
    if end_of_day:
        date += timedelta(days=1, seconds=-1)
    return int(date.timestamp())


def _format_time(value) -> str:
    """将接口的秒/毫秒时间戳转成用户可读的本地时间。"""
    if value in (None, ""):
        return ""
    try:
        timestamp = float(value)
        if timestamp > 10_000_000_000:
            timestamp /= 1000
        return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError, OSError, OverflowError):
        return str(value)

async def _request_page(page, payload: dict) -> dict:
    """在 PDD 已登录页面同源发只读请求，不读取或输出 cookie。"""
    raw = await page.evaluate(
        """async (request) => {
            const response = await fetch(request.url, {
                method: 'POST', credentials: 'include',
                headers: {'content-type': 'application/json;charset=UTF-8'},
                body: JSON.stringify(request.data),
            });
            return {status: response.status, text: await response.text()};
        }""",
        {"url": REVIEW_LIST_URL, "data": payload},
    )
    if raw.get("status") != 200:
        raise RuntimeError(f"评价接口返回 HTTP {raw.get('status')}")
    try:
        data = json.loads(raw.get("text") or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("评价接口返回了非 JSON 内容，请确认店铺登录状态") from exc
    if not data.get("success"):
        raise RuntimeError(str(data.get("errorMsg") or data.get("message") or "评价接口请求失败"))
    return data.get("result") or {}


async def _submit_review(page, review_id: str, report_type: str, describes: str) -> dict:
    """提交一条评价，供单次提交和同店铺批量会话复用。"""
    if not review_id.strip() or not report_type.strip():
        raise RuntimeError("提交参数不完整：缺少评价或申诉类型")
    report_type = report_type.strip()
    review_id = review_id.strip()
    describes = describes.strip()
    payload = {"reportType": report_type, "reviewId": review_id}
    if report_type in {"7", "8"} and not describes:
        raise RuntimeError("提交参数不完整：该申诉类型缺少申诉说明")
    if describes:
        payload["describes"] = describes
        payload["pictureUrls"] = []
    raw = await page.evaluate(
        """async (request) => {
            const response = await fetch(request.url, {
                method: 'POST', credentials: 'include',
                headers: {'content-type': 'application/json;charset=UTF-8'},
                body: JSON.stringify(request.data),
            });
            return {status: response.status, text: await response.text()};
        }""",
        {"url": REVIEW_SUBMIT_URL, "data": payload},
    )
    if raw.get("status") != 200:
        raise RuntimeError(f"提交接口返回 HTTP {raw.get('status')}")
    try:
        data = json.loads(raw.get("text") or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("提交接口返回了非 JSON 内容，请确认店铺登录状态") from exc
    if not data.get("success"):
        raise RuntimeError(str(data.get("errorMsg") or data.get("message") or "提交审核失败"))
    return {"ok": True, "mode": "submit", "review_id": review_id, "report_type": report_type}


async def _submit_worker(page) -> int:
    """同一店铺批量提交共用一个已登录浏览器会话。"""
    _emit({"ok": True, "mode": "worker_ready"})
    while True:
        raw = await asyncio.to_thread(sys.stdin.readline)
        if not raw:
            return 0
        try:
            command = json.loads(raw)
        except json.JSONDecodeError:
            _emit({"ok": False, "mode": "submit", "error": "提交指令格式错误"})
            continue
        if command.get("action") == "stop":
            _emit({"ok": True, "mode": "worker_stopped"})
            return 0
        if command.get("action") != "submit":
            _emit({"ok": False, "mode": "submit", "error": "未知提交指令"})
            continue
        request_id = str(command.get("request_id") or "")
        try:
            result = await _submit_review(
                page,
                str(command.get("review_id") or ""),
                str(command.get("report_type") or ""),
                str(command.get("describes") or ""),
            )
        except Exception as exc:
            result = {"ok": False, "mode": "submit", "error": str(exc)[:300]}
        result["request_id"] = request_id
        _emit(result)

async def run(args: argparse.Namespace) -> int:
    profile_dir = _profile_dir_for(args.store)
    if not profile_dir.exists():
        _emit({"ok": False, "error": "未找到该店铺的登录档案"})
        return 2

    window_args = _browser_window_args(args.show_browser)
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir), executable_path=find_chrome(), headless=False,
            args=window_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"], viewport=None,
        )
        try:
            page = context.pages[0] if context.pages else await context.new_page()
            await page.goto(REVIEW_PAGE_URL, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            if "login" in page.url.lower():
                raise RuntimeError("店铺未登录，请先在店铺管理中完成登录")

            if args.worker:
                return await _submit_worker(page)
            if args.submit:
                _emit(await _submit_review(page, args.review_id, args.report_type, args.describes))
                return 0

            now = int(time.time())
            scores = [int(value) for value in args.scores.split(",") if value.strip() in {"1", "2", "3", "4", "5"}]
            if not scores:
                raise RuntimeError("请至少选择一个用户评分")
            payload = {
                "startTime": _date_timestamp(args.start_date) if args.start_date else now - args.days * 86400,
                "endTime": _date_timestamp(args.end_date, end_of_day=True) if args.end_date else now,
                "pageSize": min(args.page_size, 40),
                "descScore": scores,
            }
            if args.report_status == "success":
                payload["reportStatus"] = "1"
            if args.order_sn.strip():
                payload["orderSn"] = args.order_sn.strip()
            if args.goods_id.strip():
                payload["goodsId"] = args.goods_id.strip()
            records: list[dict] = []
            total = 0
            for page_no in range(1, args.max_pages + 1):
                result = await _request_page(page, {**payload, "pageNo": page_no})
                items = result.get("data") or []
                total = int(result.get("reviewNum") or total or 0)
                records.extend(_normalize(item) for item in items if isinstance(item, dict))
                if not items or len(records) >= args.limit:
                    break
            if args.report_status == "pending":
                records = [item for item in records if str(item.get("report_status")) == "99"]
            elif args.report_status == "success":
                records = [item for item in records if "举报成功" in str(item.get("report_desc") or "")]
            _emit({"ok": True, "store": args.store, "total": total, "records": records[:args.limit]})
            return 0
        finally:
            await context.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="PDD 差评申诉只读评价查询")
    parser.add_argument("--store", required=True)
    parser.add_argument("--days", type=int, default=180)
    parser.add_argument("--start-date", default="")
    parser.add_argument("--end-date", default="")
    parser.add_argument("--scores", default="1,2,3")
    parser.add_argument("--report-status", choices=["pending", "success", "all"], default="pending")
    parser.add_argument("--order-sn", default="")
    parser.add_argument("--goods-id", default="")
    parser.add_argument("--page-size", type=int, default=40)
    parser.add_argument("--max-pages", type=int, default=3)
    parser.add_argument("--limit", type=int, default=120)
    parser.add_argument("--show-browser", action="store_true")
    parser.add_argument("--submit", action="store_true")
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--review-id", default="")
    parser.add_argument("--report-type", default="")
    parser.add_argument("--describes", default="")
    args = parser.parse_args()
    try:
        return asyncio.run(run(args))
    except Exception as exc:
        _emit({"ok": False, "error": str(exc)[:300]})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
