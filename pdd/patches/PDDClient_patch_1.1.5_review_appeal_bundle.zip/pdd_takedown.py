"""
PDD 自动下架核查工具：
- 读取 D:/files/data/pdd/pdd_publish_history.json 找 status=mismatch 的记录
- 打开 PDD 商品列表 https://mms.pinduoduo.com/goods/goods_list?msfrom=mms_sidenav
- 按 goods_id 搜索：找到 → 下架；找不到 → 标记 not_listed
- 写回 history JSON

用法：
  python pdd_takedown.py --store 元气少女美妆馆 [--auto-close]
"""
import argparse
import asyncio
import hashlib
import json
import re
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding='utf-8')
except (AttributeError, Exception):
    pass  # client.py 无控制台启动时 sys.stdout 是 None,跳过

from playwright.async_api import async_playwright

BASE_DIR = Path(__file__).resolve().parent
PROFILE_DIR = BASE_DIR / "pdd_profiles"
STORES_JSON = PROFILE_DIR / "stores.json"
HISTORY_PATH = BASE_DIR / "data" / "pdd" / "pdd_publish_history.json"
GOODS_LIST_URL = "https://mms.pinduoduo.com/goods/goods_list?msfrom=mms_sidenav"


async def _click_all_tab(page):
    """点商品列表「全部」tab(一次显示在售/已下架/已售罄/驳回… 所有状态),区别于商品分类的「全部」。
    下架/删除前都先点它再搜索,否则品在别的状态 tab 里搜不到。"""
    try:
        await page.evaluate(r"""() => {
            for (const el of document.querySelectorAll('a,span,div,li')) {
                if ((el.innerText || '').trim() !== '全部') continue;
                const r = el.getBoundingClientRect();
                const p = el.parentElement;
                if (p && (p.innerText || '').includes('在售中') && r.width > 10 && r.width < 140 && r.height > 8) {
                    el.click(); return;
                }
            }
        }""")
        await asyncio.sleep(2)
    except Exception:
        pass

CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    str(Path.home() / "AppData/Local/Google/Chrome/Application/chrome.exe"),
]


def _load_stores() -> dict:
    if STORES_JSON.exists():
        with open(STORES_JSON, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _profile_dir_for(display_name: str) -> Path:
    stores = _load_stores()
    if display_name in stores:
        return PROFILE_DIR / stores[display_name]
    dir_name = "pdd_" + hashlib.md5(display_name.encode()).hexdigest()[:8]
    return PROFILE_DIR / dir_name


def find_chrome() -> str:
    for p in CHROME_PATHS:
        if Path(p).exists():
            return p
    raise FileNotFoundError("未找到本地 Chrome")


def load_history() -> list:
    if HISTORY_PATH.exists():
        try:
            with open(HISTORY_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_history(history: list):
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)


async def close_message_overlay_after_search(page) -> bool:
    """Close only the PDD right-side message overlay if it blocks the pager."""
    state = await page.evaluate("""() => {
        const isVisible = el => {
            const r = el.getBoundingClientRect();
            const s = getComputedStyle(el);
            return r.width > 180 && r.height > 120 && s.display !== 'none'
                && s.visibility !== 'hidden' && s.opacity !== '0';
        };
        const newMessage = String.fromCharCode(0x65B0, 0x6D88, 0x606F);
        const viewAll = String.fromCharCode(0x67E5, 0x770B, 0x5168, 0x90E8);
        const root = [...document.querySelectorAll('div[class*="ImportantList_msgbox"]')]
            .find(el => isVisible(el) && (el.innerText || '').includes(newMessage)
                && (el.innerText || '').includes(viewAll));
        if (!root) return {found: false};
        const rr = root.getBoundingClientRect();
        const close = [...root.querySelectorAll('i, button, [role="button"], span')]
            .map(el => {
                const r = el.getBoundingClientRect();
                return {tag: el.tagName, x: Math.round(r.x + r.width / 2),
                    y: Math.round(r.y + r.height / 2), w: Math.round(r.width),
                    h: Math.round(r.height), topRight: r.right >= rr.right - 85 && r.top <= rr.top + 65};
            })
            .find(item => item.tag === 'I' && item.topRight && item.w >= 8
                && item.w <= 55 && item.h >= 8 && item.h <= 55);
        return {found: true, close: close || null};
    }""")
    if not state.get("found"):
        print("  [overlay] no right-side message overlay")
        return True
    if not state.get("close"):
        print("  [!] message overlay found but no safe close control")
        return False
    close = state["close"]
    print(f"  [overlay] close right-side message overlay ({close['x']},{close['y']})")
    await page.mouse.click(close["x"], close["y"])
    for _ in range(10):
        still_visible = await page.evaluate("""() => {
            const newMessage = String.fromCharCode(0x65B0, 0x6D88, 0x606F);
            const viewAll = String.fromCharCode(0x67E5, 0x770B, 0x5168, 0x90E8);
            return [...document.querySelectorAll('div[class*="ImportantList_msgbox"]')]
                .some(el => {
                    const r = el.getBoundingClientRect();
                    const s = getComputedStyle(el);
                    return r.width > 180 && r.height > 120 && s.display !== 'none'
                        && s.visibility !== 'hidden' && s.opacity !== '0'
                        && (el.innerText || '').includes(newMessage)
                        && (el.innerText || '').includes(viewAll);
                });
        }""")
        if not still_visible:
            print("  [overlay] message overlay closed")
            return True
        await asyncio.sleep(0.1)
    print("  [!] message overlay remained visible after close click")
    return False


async def batch_fill_ids(page, ids: list) -> bool:
    """一次性把多个 goods_id 用空格分隔填进「商品ID」输入框,点查询。"""
    info = await page.evaluate("""() => {
        let lbl = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3)
                .map(n => n.textContent).join('').trim();
            if (direct === '商品ID') { lbl = el; break; }
        }
        if (!lbl) return {err: 'no_label'};
        const lr = lbl.getBoundingClientRect();
        const labelCenterY = lr.y + lr.height / 2;
        const labelRight = lr.x + lr.width;
        let best = null, bestDx = 9999;
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 80) return;
            const cy = r.y + r.height / 2;
            if (Math.abs(cy - labelCenterY) > 25) return;
            const dx = r.x - labelRight;
            if (dx < -10 || dx > 400) return;
            if (dx < bestDx) { bestDx = dx; best = {i, x: r.x, y: r.y}; }
        });
        return best || {err: 'no_input'};
    }""")
    if info.get("err"):
        print(f"  [!] 找商品ID输入框失败: {info}")
        return False
    joined = " ".join(ids)
    await page.locator('input').nth(info['i']).fill(joined)
    await asyncio.sleep(0.5)
    print(f"  [批量] 已填入 {len(ids)} 个 ID 到输入框")
    clicked = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('button')) {
            const t = (el.innerText || '').trim();
            if (t === '查询') {
                const r = el.getBoundingClientRect();
                if (r.width >= 30 && r.height >= 20) { el.click(); return true; }
            }
        }
        return false;
    }""")
    if not clicked:
        print("  [!] 未找到「查询」按钮")
        return False
    await asyncio.sleep(0.5)
    if not await close_message_overlay_after_search(page):
        print("  [!] message overlay could not be closed safely")
        return False
    await asyncio.sleep(4.5)
    return True


async def get_result_count(page) -> int:
    """从「共有 N 条」提取总数。无则 -1。"""
    txt = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('span, div')) {
            const t = (el.innerText || '').trim();
            const m = t.match(/共有\\s*(\\d+)\\s*条/);
            if (m) return m[1];
        }
        return null;
    }""")
    return int(txt) if txt else -1


async def set_page_size_100(page) -> bool:
    """切到每页 100(用于结果数 > 10 时)。"""
    await page.evaluate("""() => {
        const li = document.querySelector('li[class*="PGT_pagerItem"]');
        if (li) li.scrollIntoView({block: 'center'});
    }""")
    await asyncio.sleep(1)
    info = await page.evaluate("""() => {
        const lis = document.querySelectorAll('li[class*="PGT_pagerItem"]');
        if (!lis.length) return null;
        const lr = lis[0].getBoundingClientRect();
        const pagerY = lr.y + lr.height/2;
        for (const el of document.querySelectorAll('div[class*="ST_selectValueSingle"]')) {
            const r = el.getBoundingClientRect();
            if (Math.abs(r.y + r.height/2 - pagerY) > 30) continue;
            return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
        }
        return null;
    }""")
    if not info:
        print("  [!] 找不到「每页N」下拉触发器")
        return False
    tx, ty = info['x'], info['y']
    print(f"  [分页] 点开下拉 ({tx},{ty})")
    await page.mouse.click(tx, ty)
    await asyncio.sleep(1.5)
    # ★精确点 beast-core 下拉面板里的选项 li(ul[role=listbox].ST_dropdownPanel > li[role=option] > span「100」)
    #   不用泛 li/div/span+文本匹配(页面底部「机会商品」卡片的热度值也是100,会误点)
    clicked = await page.evaluate(r"""() => {
        const lis = document.querySelectorAll(
            '[class*=ST_dropdownPanel] li[role="option"], [data-testid="beast-core-portal"] li[role="option"]');
        for (const el of lis) {
            if ((el.innerText || '').trim() === '100') {
                const r = el.getBoundingClientRect();
                if (r.width > 4 && r.height > 4) { el.click(); return true; }
            }
        }
        return false;
    }""")
    if not clicked:
        print("  [!] 下拉面板里找不到「100」选项(li[role=option])")
        return False
    print(f"  [分页] 已切每页 100")
    await asyncio.sleep(3)
    return True


async def click_header_checkbox(page) -> bool:
    """点表头全选 checkbox。"""
    await page.evaluate("window.scrollTo(0, 0)")
    await asyncio.sleep(1)
    info = await page.evaluate("""() => {
        const labels = Array.from(document.querySelectorAll('label[class*="CBX_outerWrapper"]'));
        const arr = labels.map(el => {
            const r = el.getBoundingClientRect();
            return {x: r.x + r.width/2, y: r.y + r.height/2};
        }).filter(it => it.y > 0);
        if (arr.length < 2) return null;
        arr.sort((a,b) => a.y - b.y);
        return {x: Math.round(arr[0].x), y: Math.round(arr[0].y), total: arr.length};
    }""")
    if not info:
        print("  [!] 找不到表头复选框")
        return False
    print(f"  [全选] 点表头 ({info['x']},{info['y']}),共 {info['total']} 个 checkbox")
    await page.mouse.click(info['x'], info['y'])
    await asyncio.sleep(1)
    return True


async def click_batch_takedown_button(page) -> bool:
    """点「批量下架」按钮 → 弹窗「确定」。"""
    info = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('button')) {
            const t = (el.innerText || '').trim();
            if (t === '批量下架') {
                const r = el.getBoundingClientRect();
                if (r.width > 30 && r.height > 15) {
                    return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
                }
            }
        }
        return null;
    }""")
    if not info:
        print("  [!] 找不到「批量下架」按钮")
        return False
    print(f"  [下架] 点「批量下架」({info['x']},{info['y']})")
    await page.mouse.click(info['x'], info['y'])
    await asyncio.sleep(2.5)
    confirm = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('button')) {
            const t = (el.innerText || '').trim();
            if (t === '确定' || t === '确认' || t === '确认下架') {
                const r = el.getBoundingClientRect();
                if (r.width > 30 && r.height > 15) {
                    return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
                }
            }
        }
        return null;
    }""")
    if confirm:
        print(f"  [下架] 弹窗确认 ({confirm['x']},{confirm['y']})")
        await page.mouse.click(confirm['x'], confirm['y'])
        await asyncio.sleep(4)
    return True


async def search_goods_by_id(page, goods_id: str) -> bool:
    """在商品列表页用 goods_id 搜索：
    1. 用 label 文字「商品ID」精确定位输入框（不是 规格编码/商品编码）
    2. 用 Playwright fill 填值（更可靠）
    3. 点击「查询」按钮（PDD 用「查询」不是「搜索」）
    4. 等结果，检测结果区是否含 goods_id
    """
    await asyncio.sleep(2)
    # 1) 精确定位「商品ID」label 右侧的 input
    info = await page.evaluate("""() => {
        // 找文字恰好 "商品ID" 的元素
        let labelEl = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品ID') { labelEl = el; break; }
        }
        if (!labelEl) return {err: 'no_label'};
        const lr = labelEl.getBoundingClientRect();
        // 在 label 右侧 400px、同 y(±25) 找最近的 input
        const labelCenterY = lr.y + lr.height / 2;
        const labelRight = lr.x + lr.width;
        let best = null, bestDist = Infinity;
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 80) return;
            const cy = r.y + r.height / 2;
            if (Math.abs(cy - labelCenterY) > 25) return;
            const dx = r.x - labelRight;
            if (dx < -10 || dx > 400) return;
            if (dx < bestDist) { bestDist = dx; best = {i, x: r.x, y: r.y, w: r.width}; }
        });
        if (!best) return {err: 'no_input'};
        return best;
    }""")
    if info.get("err"):
        print(f"  [!] 未找到「商品ID」输入框: {info}")
        return False
    print(f"  [搜索] 「商品ID」输入框 idx={info['i']} pos=({info['x']:.0f},{info['y']:.0f})")
    # 用 locator 填值（更可靠，触发 React 状态）
    inputs_loc = page.locator('input')
    await inputs_loc.nth(info["i"]).fill(goods_id)
    await asyncio.sleep(0.5)
    print(f"  [搜索] 已填入 goods_id={goods_id}")
    # 2) 列出所有含「查询」文字的元素，挑最合适的点击
    candidates = await page.evaluate("""() => {
        const list = [];
        // innerText 等于（兼容嵌套 span/icon）
        for (const el of document.querySelectorAll('button, a, [role="button"], span, div')) {
            const txt = (el.innerText || '').trim();
            if (txt === '查询' || txt === '搜索') {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0) {
                    list.push({
                        tag: el.tagName, txt,
                        cls: (el.className || '').toString().slice(0, 80),
                        x: Math.round(r.x), y: Math.round(r.y),
                        w: Math.round(r.width), h: Math.round(r.height),
                    });
                }
            }
        }
        return list;
    }""")
    print(f"  [搜索] 所有「查询/搜索」元素 {len(candidates)} 个:")
    for c in candidates:
        print(f"    {c['tag']} ({c['x']},{c['y']}) {c['w']}x{c['h']} '{c['txt']}' class={c['cls']!r}")
    # 选最像 button 的（尺寸 50-150 宽，25-60 高，BUTTON > 其它）
    best = None
    for c in candidates:
        if 30 <= c['w'] <= 200 and 20 <= c['h'] <= 70:
            score = 0 if c['tag'] == 'BUTTON' else 1
            if best is None or score < best['_score'] or (score == best['_score'] and c['w'] < best['w']):
                c['_score'] = score
                best = c
    if not best:
        print(f"  [!] 未找到合适的查询按钮（候选 {len(candidates)} 个，但尺寸不匹配）")
        return False
    print(f"  [搜索] 点击 {best['tag']} ({best['x']+best['w']//2},{best['y']+best['h']//2})")
    await page.mouse.click(best['x'] + best['w']//2, best['y'] + best['h']//2)
    await asyncio.sleep(5)  # 等结果加载
    # 3) 检测结果区是否含 goods_id
    found = await page.evaluate(f"""() => {{
        const t = document.body.innerText || '';
        return t.includes({goods_id!r});
    }}""")
    return bool(found)


async def click_takedown(page, goods_id: str) -> bool:
    """点击表格行的「下架」按钮 → 等待「确定下架商品？」弹窗 → 点击「确定」→ 验证消失。
    全部成功才返回 True。
    """
    # 1) 找操作列的「下架」按钮（限定行内按钮：宽度 20-100，行内单个）
    btn = await page.evaluate("""() => {
        // 操作列「下架」通常是 a 标签或 span，紧挨着「编辑」
        for (const el of document.querySelectorAll('a, button, [role="button"], span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '下架') {
                const r = el.getBoundingClientRect();
                // 行内的「下架」链接通常较小，宽度 < 100
                if (r.width > 15 && r.width < 100 && r.height > 10 && r.height < 50) {
                    return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2), tag: el.tagName};
                }
            }
        }
        return null;
    }""")
    if not btn:
        print(f"  [!] 未找到行内「下架」按钮")
        return False
    print(f"  [下架] 点击行内按钮 {btn['tag']} ({btn['x']},{btn['y']})")
    await page.mouse.click(btn['x'], btn['y'])
    await asyncio.sleep(2)

    # 2) 等待「确定下架商品？」弹窗出现（最多 6 秒）
    dialog_appeared = False
    for _ in range(12):
        has_dlg = await page.evaluate("""() => {
            const t = document.body.innerText || '';
            return t.includes('确定下架商品') || t.includes('确认下架');
        }""")
        if has_dlg:
            dialog_appeared = True; break
        await asyncio.sleep(0.5)
    if not dialog_appeared:
        print(f"  [!] 未出现「确定下架商品？」弹窗")
        return False
    print(f"  [下架] 已检测到下架确认弹窗")

    # 3) 找「确定」按钮 — 用 innerText 兼容 BUTTON > SPAN 嵌套结构
    await asyncio.sleep(0.8)
    candidates = await page.evaluate("""() => {
        const list = [];
        for (const el of document.querySelectorAll('button, a, [role="button"]')) {
            const txt = (el.innerText || '').trim();
            if (txt === '确定' || txt === '确认' || txt === '确认下架') {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0) {
                    list.push({
                        tag: el.tagName, txt,
                        cls: (el.className || '').toString().slice(0, 80),
                        x: Math.round(r.x), y: Math.round(r.y),
                        w: Math.round(r.width), h: Math.round(r.height),
                    });
                }
            }
        }
        return list;
    }""")
    print(f"  [下架] 所有「确定/确认」按钮 {len(candidates)} 个:")
    for c in candidates:
        print(f"    {c['tag']} ({c['x']},{c['y']}) {c['w']}x{c['h']} '{c['txt']}' class={c['cls']!r}")
    # 选最像弹窗确定按钮的（BUTTON > 其它，宽 40-200，高 20-60）
    best = None
    for c in candidates:
        if 30 <= c['w'] <= 250 and 20 <= c['h'] <= 70:
            score = 0 if c['tag'] == 'BUTTON' else 1
            if best is None or score < best['_score']:
                c['_score'] = score
                best = c
    if not best:
        print(f"  [!] 未找到合适的确定按钮")
        return False
    print(f"  [下架] 点击 {best['tag']} ({best['x']+best['w']//2},{best['y']+best['h']//2})")
    await page.mouse.click(best['x'] + best['w']//2, best['y'] + best['h']//2)
    await asyncio.sleep(3)

    # 4) 验证：弹窗消失 + 商品消失/状态变化（页面不再含原 goods_id 的"下架"按钮）
    still_has = await page.evaluate(f"""() => {{
        const t = document.body.innerText || '';
        return t.includes('确定下架商品');
    }}""")
    if still_has:
        print(f"  [!] 下架弹窗仍存在，可能未确认成功")
        return False
    print(f"  [下架] ✅ 确认下架成功")
    return True


async def run(args):
    chrome_exe = find_chrome()
    profile_dir = _profile_dir_for(args.store)
    if not profile_dir.exists():
        print(f"[!] profile 不存在: {profile_dir}")
        return

    history = load_history()
    # 模式 1：指定 --goods-ids（GUI 勾选下架）
    if args.goods_ids:
        wanted = {gid.strip() for gid in args.goods_ids.split(",") if gid.strip()}
        mismatches = [r for r in history
                      if r.get("store") == args.store
                      and r.get("goods_id") in wanted]
        # 即使 history 里没记录也要支持下架（直接造一条临时记录）
        existing_ids = {r.get("goods_id") for r in mismatches}
        for gid in wanted - existing_ids:
            mismatches.append({"goods_id": gid, "store": args.store,
                               "target_name": "(无历史记录)", "status": "manual"})
        print(f"[下架] 模式: 指定 ID  共 {len(mismatches)} 条")
    else:
        # 模式 2：自动核查所有未对齐
        mismatches = [r for r in history if r.get("status") == "mismatch"
                      and r.get("store") == args.store and r.get("goods_id")]
        print(f"[下架] 模式: 未对齐自动核查  共 {len(mismatches)} 条")
    if not mismatches:
        print("[OK] 无需下架")
        return

    _win_args = ["--start-maximized"] if getattr(args, "show_browser", False) \
        else ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            executable_path=chrome_exe,
            headless=False,
            args=_win_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        page = context.pages[0] if context.pages else await context.new_page()
        from pdd_publish import apply_window_mode
        await apply_window_mode(context, page, getattr(args, "show_browser", False))
        await page.goto(GOODS_LIST_URL, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(4)
        try: await page.keyboard.press("Escape")
        except Exception: pass
        await asyncio.sleep(1)
        await _click_all_tab(page)    # 先点「全部」tab 再搜(否则品在别的状态 tab 搜不到)

        all_ids = [r["goods_id"] for r in mismatches if r.get("goods_id")]
        processed = 0
        # ─── 50 个硬上限(单次操作) ──────────────────────────────────────
        MAX_BATCH = 50
        if len(all_ids) > MAX_BATCH:
            print(f"[!] 单次最多 {MAX_BATCH} 个 ID,你送入了 {len(all_ids)} 个 → 中止")
            print(f"    请分批勾选(每批 ≤ {MAX_BATCH} 个)再点批量下架")
            return
        # ─── 批量下架流程 ─────────────────────────────────────────────────
        if 2 <= len(all_ids) <= MAX_BATCH:
            print(f"\n[批量下架] 启用批量流程({len(all_ids)} 个 ID)")
            ok_fill = await batch_fill_ids(page, all_ids)
            if ok_fill:
                cnt = await get_result_count(page)
                print(f"  [批量] 查询返回 共有 {cnt} 条(送入 {len(all_ids)} 个 ID)")
                # 用户规则:勾选 <= 10 个跳过切每页 100,> 10 才切
                if len(all_ids) > 10 and cnt > 10:
                    ok_sz = await set_page_size_100(page)
                    if not ok_sz:
                        print("  [批量] 切每页 100 失败 → 中止批量,回落逐条")
                        ok_fill = False
            if ok_fill:
                ok_sel = await click_header_checkbox(page)
                if ok_sel:
                    ok_td = await click_batch_takedown_button(page)
                    if ok_td:
                        # PDD 不直接返回哪些 ID 成功下架,以列表中"在售中"剩多少为准。
                        # 简单策略:把所有送入的 ID 标 taken_down(实际下架数 = cnt)。
                        ts = time.strftime("%Y-%m-%d %H:%M:%S")
                        for rec in mismatches:
                            rec["status"] = "taken_down"
                            rec["takedown_at"] = ts
                        processed = cnt if cnt > 0 else len(all_ids)
                        # 未在结果中的 ID 标 not_listed(送入 N 个但只搜出 M 个 → N-M 个不在售)
                        if 0 < cnt < len(all_ids):
                            print(f"  [批量] {len(all_ids) - cnt} 个 ID 不在「在售中」(可能已下架/驳回)")
                        save_history(history)
                        print(f"\n[OK] 批量处理完成：标 taken_down {processed} 件")
                        if args.auto_close:
                            print("[OK] 自动关闭浏览器")
                            await asyncio.sleep(2)
                            try: await asyncio.wait_for(context.close(), timeout=5)
                            except Exception: pass
                            return
                else:
                    print("  [批量] 全选失败 → 回落逐条")

        # ─── 单 ID 或批量失败:逐条流程(老逻辑兜底)─────────────────────
        if processed == 0:
            print(f"\n[逐条下架] 共 {len(mismatches)} 条")
            for rec in mismatches:
                gid = rec["goods_id"]
                print(f"\n[核查] goods_id={gid}  {rec.get('target_name','')[:30]}")
                await page.goto(GOODS_LIST_URL, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(3)
                await _click_all_tab(page)    # 先点「全部」tab 再搜
                found = await search_goods_by_id(page, gid)
                if not found:
                    print(f"  [回填] 未在商品列表中找到 → status=not_listed")
                    rec["status"] = "not_listed"
                    rec["takedown_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                    continue
                ok = await click_takedown(page, gid)
                if ok:
                    print(f"  [✓] 已下架")
                    rec["status"] = "taken_down"
                    rec["takedown_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                    processed += 1
                else:
                    print(f"  [!] 下架按钮未点击成功，保留状态")

        save_history(history)
        print(f"\n[OK] 处理完成：实际下架 {processed} 件")

        if args.auto_close:
            print("[OK] 自动关闭浏览器")
            await asyncio.sleep(2)
            try:
                await asyncio.wait_for(context.close(), timeout=5)
            except Exception:
                pass
        else:
            print("[OK] 浏览器保持开启")
            try:
                await page.wait_for_event("close", timeout=0)
            except Exception:
                pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", required=True, help="店铺名")
    ap.add_argument("--goods-ids", default="",
                    help="逗号分隔的 goods_id 列表；指定后只下架这些，不再扫描 mismatch")
    ap.add_argument("--auto-close", action="store_true")
    ap.add_argument("--show-browser", action="store_true", help="显示浏览器（调试用）；默认屏幕外静默")
    args = ap.parse_args()
    try:
        asyncio.run(run(args))
    finally:
        if args.auto_close:
            import os
            os._exit(0)
