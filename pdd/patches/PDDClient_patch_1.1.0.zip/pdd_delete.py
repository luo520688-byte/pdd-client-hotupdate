"""PDD 已下架商品 → 店铺内永久删除
打开 https://mms.pinduoduo.com/goods/goods_list?activeKeyNew=key_4 (已下架 tab)
搜索 goods_id → 点行内「删除」→ 弹窗「确定」

用法：
  python pdd_delete.py --store 元气少女美妆馆 --goods-ids id1,id2 [--auto-close]
"""
import argparse
import asyncio
import json
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, r"D:/files")

from playwright.async_api import async_playwright
from pdd_takedown import (
    _profile_dir_for, find_chrome, load_history, save_history,
    batch_fill_ids, get_result_count, set_page_size_100, click_header_checkbox,
)

YIXIAJIA_URL = "https://mms.pinduoduo.com/goods/goods_list?msfrom=mms_sidenav&activeKeyNew=key_4"


def remove_recycled_promo_images(goods_ids) -> tuple[int, int]:
    """删除进入本地回收站商品的推广图及其换图登记。"""
    ids = {str(goods_id or "") for goods_id in goods_ids if str(goods_id or "").isdigit()}
    if not ids:
        return 0, 0
    removed = freed = 0
    promo_dir = Path(r"D:/files/data/promo")
    for goods_id in ids:
        image = promo_dir / f"{goods_id}.jpg"
        try:
            if image.is_file():
                freed += image.stat().st_size
                image.unlink()
                removed += 1
        except OSError as exc:
            print(f"[推广图清理] {goods_id} 删除失败: {exc}")
    done_path = Path(r"D:/files/data/pdd/promo_done.json")
    try:
        done = json.loads(done_path.read_text(encoding="utf-8")) if done_path.exists() else {}
    except (OSError, json.JSONDecodeError):
        done = {}
    changed = any(goods_id in done for goods_id in ids)
    if changed:
        for goods_id in ids:
            done.pop(goods_id, None)
        try:
            done_path.write_text(json.dumps(done, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError as exc:
            print(f"[推广图清理] 换图登记更新失败: {exc}")
    if removed or changed:
        print(f"[推广图清理] 回收站商品 {len(ids)} 条，删除图片 {removed} 张，释放 {freed / 1048576:.0f} MB")
    return removed, freed


async def search_in_yixiajia(page, goods_id: str) -> bool:
    """在已下架 tab 搜索 goods_id，返回是否找到"""
    await asyncio.sleep(2)
    info = await page.evaluate("""() => {
        let labelEl = null;
        for (const el of document.querySelectorAll('label, span, div')) {
            const direct = Array.from(el.childNodes).filter(n => n.nodeType===3).map(n=>n.textContent).join('').trim();
            if (direct === '商品ID') { labelEl = el; break; }
        }
        if (!labelEl) return {err: 'no_label'};
        const lr = labelEl.getBoundingClientRect();
        const labelCenterY = lr.y + lr.height / 2;
        const labelRight = lr.x + lr.width;
        let best = null, bestDist = Infinity;
        document.querySelectorAll('input').forEach((inp, i) => {
            if (inp.type && inp.type !== 'text') return;
            const r = inp.getBoundingClientRect();
            if (r.width < 80) return;
            const cy = r.y + r.height / 2;
            if (Math.abs(cy - labelCenterY) > 25) return;
            const dx = r.x - labelRight;
            if (dx < -10 || dx > 400) return;
            if (dx < bestDist) { bestDist = dx; best = {i, x: r.x, y: r.y, w: r.width}; }
        });
        return best || {err: 'no_input'};
    }""")
    if info.get("err"):
        print(f"  [!] 未找到「商品ID」输入框: {info}")
        return False
    await page.locator('input').nth(info["i"]).fill(goods_id)
    await asyncio.sleep(0.5)
    print(f"  [搜索] 已填入 goods_id={goods_id}")
    # 点击查询按钮
    candidates = await page.evaluate("""() => {
        const list = [];
        for (const el of document.querySelectorAll('button, a, [role="button"]')) {
            const t = (el.innerText || '').trim();
            if (t === '查询' || t === '搜索') {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0)
                    list.push({tag: el.tagName, w: Math.round(r.width), h: Math.round(r.height), x: Math.round(r.x), y: Math.round(r.y)});
            }
        }
        return list;
    }""")
    best = None
    for c in candidates:
        if 30 <= c['w'] <= 200 and 20 <= c['h'] <= 70:
            score = 0 if c['tag'] == 'BUTTON' else 1
            if best is None or score < best.get('_score', 99):
                c['_score'] = score; best = c
    if not best:
        print(f"  [!] 未找到查询按钮"); return False
    await page.mouse.click(best['x'] + best['w']//2, best['y'] + best['h']//2)
    await asyncio.sleep(5)
    body = await page.evaluate("() => document.body.innerText || ''")
    return goods_id in body


async def click_delete(page, goods_id: str) -> bool:
    """点击行内「删除」→ 弹窗「确定」→ 验证"""
    # 1) 找行内删除按钮（<a> 标签，data-tracking-viewid='delete'，宽 20-100）
    btn = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('a, button, [role="button"], span, div')) {
            const t = (el.innerText || '').trim();
            if (t === '删除' || t === '彻底删除') {
                const r = el.getBoundingClientRect();
                if (r.width >= 15 && r.width <= 100 && r.height >= 10 && r.height <= 50) {
                    return {tag: el.tagName, x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
                }
            }
        }
        return null;
    }""")
    if not btn:
        print(f"  [!] 未找到行内删除按钮")
        return False
    print(f"  [删除] 点击行内按钮 {btn['tag']} ({btn['x']},{btn['y']})")
    await page.mouse.click(btn['x'], btn['y'])
    await asyncio.sleep(2)

    # 2) 等待删除确认弹窗
    appeared = False
    for _ in range(12):
        has = await page.evaluate("""() => {
            const t = document.body.innerText || '';
            return t.includes('确定删除') || t.includes('确认删除') || t.includes('永久删除');
        }""")
        if has: appeared = True; break
        await asyncio.sleep(0.5)
    if not appeared:
        print(f"  [!] 未出现删除确认弹窗")
        return False
    print(f"  [删除] 已检测到删除确认弹窗")
    await asyncio.sleep(0.8)

    # 3) 找确定按钮
    candidates = await page.evaluate("""() => {
        const list = [];
        for (const el of document.querySelectorAll('button, a, [role="button"]')) {
            const t = (el.innerText || '').trim();
            if (t === '确定' || t === '确认' || t === '确认删除') {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.height > 0)
                    list.push({tag: el.tagName, w: Math.round(r.width), h: Math.round(r.height),
                               x: Math.round(r.x), y: Math.round(r.y), txt: t});
            }
        }
        return list;
    }""")
    best = None
    for c in candidates:
        if 30 <= c['w'] <= 250 and 20 <= c['h'] <= 70:
            score = 0 if c['tag'] == 'BUTTON' else 1
            if best is None or score < best.get('_score', 99):
                c['_score'] = score; best = c
    if not best:
        print(f"  [!] 未找到确定按钮（候选 {len(candidates)} 个，尺寸不匹配）")
        return False
    print(f"  [删除] 点击 {best['tag']} ({best['x']+best['w']//2},{best['y']+best['h']//2}) '{best['txt']}'")
    await page.mouse.click(best['x'] + best['w']//2, best['y'] + best['h']//2)
    await asyncio.sleep(3)
    # 4) 验证：弹窗消失
    still = await page.evaluate("""() => {
        const t = document.body.innerText || '';
        return t.includes('确定删除') || t.includes('确认删除');
    }""")
    if still:
        print(f"  [!] 删除弹窗仍存在")
        return False
    print(f"  [删除] ✅ 已永久删除")
    return True


async def click_batch_delete_button(page) -> bool:
    """点「批量删除」按钮 → 弹窗「确定/永久删除/确认删除」。"""
    info = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('button')) {
            const t = (el.innerText || '').trim();
            if (t === '批量删除') {
                const r = el.getBoundingClientRect();
                if (r.width > 30 && r.height > 15) {
                    return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)};
                }
            }
        }
        return null;
    }""")
    if not info:
        print("  [!] 找不到「批量删除」按钮")
        return False
    print(f"  [删除] 点「批量删除」({info['x']},{info['y']})")
    await page.mouse.click(info['x'], info['y'])
    await asyncio.sleep(2.5)
    # 弹窗确认按钮:文字可能是 确定/确认/确认删除/永久删除
    confirm = await page.evaluate("""() => {
        const TXTS = ['确定', '确认', '确认删除', '永久删除', '确定删除'];
        for (const el of document.querySelectorAll('button')) {
            const t = (el.innerText || '').trim();
            if (!TXTS.includes(t)) continue;
            const r = el.getBoundingClientRect();
            if (r.width > 30 && r.height > 15) {
                return {x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2), t};
            }
        }
        return null;
    }""")
    if confirm:
        print(f"  [删除] 弹窗确认按钮「{confirm['t']}」({confirm['x']},{confirm['y']})")
        await page.mouse.click(confirm['x'], confirm['y'])
        await asyncio.sleep(4)
    else:
        print(f"  [!] 没找到确认按钮(可能 PDD 改了弹窗文案,需要人工)")
        return False
    return True


async def run(args):
    chrome_exe = find_chrome()
    profile_dir = _profile_dir_for(args.store)
    if not profile_dir.exists():
        print(f"[!] profile 不存在"); return

    wanted = [g.strip() for g in args.goods_ids.split(",") if g.strip()]
    if not wanted:
        print("[!] 未指定 goods_ids"); return
    print(f"[删除] 共 {len(wanted)} 个 ID 待删除")

    history = load_history()
    _win_args = ["--start-maximized"] if getattr(args, "show_browser", False) \
        else ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            executable_path=chrome_exe,
            headless=False,
            args=_win_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        page = context.pages[0] if context.pages else await context.new_page()
        from pdd_publish import apply_window_mode
        await apply_window_mode(context, page, getattr(args, "show_browser", False))
        await page.goto(YIXIAJIA_URL, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(4)
        try: await page.keyboard.press("Escape")
        except Exception: pass
        await asyncio.sleep(1)

        deleted = 0
        # ─── 50 个硬上限(单次操作) ──────────────────────────────────────
        MAX_BATCH = 50
        if len(wanted) > MAX_BATCH:
            print(f"[!] 单次最多 {MAX_BATCH} 个 ID,你送入了 {len(wanted)} 个 → 中止")
            print(f"    请分批勾选(每批 ≤ {MAX_BATCH} 个)再点批量删除")
            return
        # ─── 批量删除流程(同 pdd_takedown 的批量下架) ───────────────────
        if 2 <= len(wanted) <= MAX_BATCH:
            print(f"\n[批量删除] 启用批量流程({len(wanted)} 个 ID)")
            ok_fill = await batch_fill_ids(page, wanted)
            if ok_fill:
                cnt = await get_result_count(page)
                print(f"  [批量] 查询返回 共有 {cnt} 条(送入 {len(wanted)} 个 ID)")
                # 用户规则:勾选 <= 10 个跳过切每页 100,> 10 才切
                if len(wanted) > 10 and cnt > 10:
                    ok_sz = await set_page_size_100(page)
                    if not ok_sz:
                        print("  [批量] 切每页 100 失败 → 中止批量,回落逐条")
                        ok_fill = False
            if ok_fill:
                ok_sel = await click_header_checkbox(page)
                if ok_sel:
                    ok_del = await click_batch_delete_button(page)
                    if ok_del:
                        ts = time.strftime("%Y-%m-%d %H:%M:%S")
                        for gid in wanted:
                            for rec in history:
                                if rec.get("goods_id") == gid and rec.get("store") == args.store:
                                    rec["status"] = "deleted"
                                    rec["deleted_at"] = ts
                        deleted = cnt if cnt > 0 else len(wanted)
                        remove_recycled_promo_images(wanted)
                        if 0 < cnt < len(wanted):
                            print(f"  [批量] {len(wanted) - cnt} 个 ID 不在「已下架」(可能仍在售/已删除)")
                        save_history(history)
                        print(f"\n[OK] 批量处理完成：标 deleted {deleted} 件")
                        if args.auto_close:
                            try: await asyncio.wait_for(context.close(), timeout=5)
                            except Exception: pass
                            return
                else:
                    print("  [批量] 全选失败 → 回落逐条")

        # ─── 单 ID / 批量失败:逐条流程(老逻辑兜底) ─────────────────────
        if deleted == 0:
            print(f"\n[逐条删除] 共 {len(wanted)} 条")
            recycled_ids = []
            for gid in wanted:
                print(f"\n[处理] goods_id={gid}")
                await page.goto(YIXIAJIA_URL, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(3)
                found = await search_in_yixiajia(page, gid)
                if not found:
                    print(f"  [跳过] 未在已下架 tab 找到该商品（可能在售或已删除）")
                    continue
                if await click_delete(page, gid):
                    deleted += 1
                    recycled_ids.append(gid)
                    for rec in history:
                        if rec.get("goods_id") == gid and rec.get("store") == args.store:
                            rec["status"] = "deleted"
                            rec["deleted_at"] = time.strftime("%Y-%m-%d %H:%M:%S")

            remove_recycled_promo_images(recycled_ids)
        save_history(history)
        print(f"\n[OK] 处理完成：实际删除 {deleted}/{len(wanted)} 件")

        if args.auto_close:
            try: await asyncio.wait_for(context.close(), timeout=5)
            except Exception: pass
        else:
            try: await page.wait_for_event("close", timeout=0)
            except Exception: pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", required=True)
    ap.add_argument("--goods-ids", required=True)
    ap.add_argument("--auto-close", action="store_true")
    ap.add_argument("--show-browser", action="store_true", help="显示浏览器（调试用）；默认屏幕外静默")
    args = ap.parse_args()
    try:
        asyncio.run(run(args))
    finally:
        if args.auto_close:
            import os
            os._exit(0)
