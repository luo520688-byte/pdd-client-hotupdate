"""自动开车 —— PDD 稳定成本推广建计划(浏览器自动化)。

对一条已发布在架商品,自动在推广中心建一条【稳定成本推广】计划:
  搜品 → 设净目标投产比(来自 roas_calc 算的目标) → 设日预算 → 关「全局优选起量」 → 开启推广

★ 安全第一:**默认 dry-run**,把每一步都填好、停在"开启推广"按钮前截图,绝不真开车;
   只有显式传 --confirm 才点"开启推广"。第一次务必先 dry-run 看截图确认。

硬规则(用户确认):① 只用稳定成本推广;② 每次系统默认勾「全局优选起量」,必须关闭;
   ③ 净目标投产比用 ÷(1−退款率) 的实际保本档(信自己口袋,不信豁免)。

已坐实的 DOM(2026-06-20 探针):
  - 入口按钮:button.anq-btn-primary 含「添加推广商品」(只有 Playwright locator.click 点得动)
  - 搜索框:input[placeholder*=商品]
  - 投产比编辑触发:[data-testid=editBid_<goods_id>_create_create] → 弹 popover 改值
  - 全局优选起量:底部勾选框,label 含「全局优选起量」
  - 确定:button 含「开启推广」

复用 pdd_publish 的 find_chrome/_load_stores/_profile_dir_for/apply_window_mode。
roas 目标值由调用方传入(可由 roas_scan/roas_calc 先算好);本文件只负责"填进去 + 开"。
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

from playwright.async_api import async_playwright

from pdd_publish import (
    find_chrome, _load_stores, _profile_dir_for, PROFILE_DIR, apply_window_mode,
)

PROMO_URL = "https://yingxiao.pinduoduo.com/goods/promotion/list?msfrom=mms_sidenav"
SHOT_DIR = Path(__file__).resolve().parent / "data" / "pdd" / "promote_shots"


def _log(msg: str):
    print(f"[开车] {msg}", file=sys.stderr, flush=True)


def _e1(e) -> str:
    """异常只取第一行(干掉 Playwright 那一大坨 Call log,界面才干净)。"""
    s = str(e).strip()
    return s.splitlines()[0][:120] if s else type(e).__name__


async def _shot(page, name: str):
    SHOT_DIR.mkdir(parents=True, exist_ok=True)
    path = SHOT_DIR / name
    try:
        await asyncio.wait_for(page.screenshot(path=str(path), full_page=True), timeout=8)
        _log(f"截图 {path}")
    except Exception as e:
        _log(f"截图失败 {name}: {e}")
    return str(path)


# ── 开车成功核验:回推广列表按 gid 读 live 状态(2026-06-23 roas_verify_probe 实测坐实)──
# 状态以 adStatusSwitch 的 aria-checked 为准(true=推广中/false=暂停),与 roas_monitor 同口径。
_FIND_JS = r"""(gid)=>{
    const tbls=[...document.querySelectorAll('table')];
    let body=null,maxb=0;
    for(const t of tbls){const n=t.querySelectorAll('tbody tr').length; if(n>maxb){maxb=n;body=t;}}
    if(!body) return {found:false, rows:0};
    let nrows=0, hit=null;
    for(const tr of body.querySelectorAll('tbody tr')){
        const txt=(tr.innerText||'').replace(/ /g,' ').replace(/\r/g,'');
        const gm=txt.match(/商品\s*ID[：:]\s*(\d{6,})/);
        if(!gm) continue;
        nrows++;
        if(gm[1]!==String(gid)) continue;
        const swEl=tr.querySelector('[data-testid^="adStatusSwitch"]');
        const adId=swEl?(swEl.getAttribute('data-testid').replace('adStatusSwitch-','')):'';
        let swAria = swEl ? swEl.getAttribute('aria-checked') : null;
        if(swAria===null && swEl){const a=swEl.querySelector('[aria-checked]'); if(a) swAria=a.getAttribute('aria-checked');}
        const ABN=['无可用创意','限制推广','推广受限','商品售罄','售罄','创意审核中','审核中','商品已下架','计划已结束','已结束'];
        let abn=''; for(const k of ABN){ if(txt.includes(k)){ abn=k; break; } }
        let status='未知';
        if(swAria==='false') status='已暂停';
        else if(abn) status=abn;
        else if(swAria==='true') status='推广中';
        else if(/手动暂停|已暂停|暂停中|计划已暂停/.test(txt)) status='已暂停';
        else if(txt.includes('推广中')) status='推广中';
        const roi=(txt.match(/净目标投产比[\s：:]*([0-9.]+)/)||[])[1]||'';
        const bud=(txt.match(/预算日限额[\s：:]*([0-9.]+|不限)/)||[])[1]||'';
        hit={found:true, status, adId, swAria, roi, bud};
    }
    if(hit){ hit.rows=nrows; return hit; }
    return {found:false, rows:nrows};
}"""


def _result(found: bool, *, status="", ad_id="", roi="", bud="",
            rows=0, tries_used=0, note="") -> dict:
    """核验出参统一形状 —— 任何分支都返回完整 dict,绝不缺键。
    live = found 且状态=推广中(=真建成且真在投)。"""
    return {
        "found":       bool(found),
        "live":        bool(found) and status == "推广中",
        "status":      status,
        "ad_id":       ad_id,
        "target_roas": roi,
        "budget":      bud,
        "rows":        rows,
        "tries_used":  tries_used,
        "note":        note,
    }


async def find_plan(pg, gid: str, *, tries: int = 3) -> dict:
    """在推广列表按 gid 搜,读这一条的 live 状态。只读。

    空态(整店无计划)→ found=False, status='无计划'(=核验失败,非崩溃);
    搜索框慢加载 → 重试 tries 次兜底,避免把真计划误判没建成。
    """
    gid = str(gid).strip()
    sb_sel = ('[data-testid="trTableSearch"], '
              'input[placeholder*="商品 ID"], input[placeholder*="商品名称"]')
    last = {"found": False, "rows": 0}
    attempt = 0
    for attempt in range(1, tries + 1):
        sb = pg.locator(sb_sel).first
        if not await sb.count():
            empty = await pg.evaluate(
                "()=>{const t=document.body.innerText||''; return t.includes('什么是稳定成本推广');}")
            if empty:
                return _result(False, status="无计划", tries_used=attempt, note="店内空态,无任何计划")
            if attempt < tries:
                await asyncio.sleep(3)
            continue
        try:
            await sb.click()
            try:
                await sb.fill("")
            except Exception:
                pass
            await pg.keyboard.type(gid, delay=8)
            await pg.keyboard.press("Enter")
        except Exception as e:
            _log(f"核验搜索异常(第{attempt}次): {_e1(e)}")
        await asyncio.sleep(4.5)
        last = await pg.evaluate(_FIND_JS, gid)
        if last.get("found"):
            break
        if attempt < tries:
            await asyncio.sleep(3)
    return _result(
        bool(last.get("found")), status=last.get("status", ""),
        ad_id=last.get("adId", ""), roi=last.get("roi", ""), bud=last.get("bud", ""),
        rows=last.get("rows", 0), tries_used=attempt)


async def create_one(context, goods_id: str, roas: float, budget: float,
                     *, confirm: bool = False) -> dict:
    """建一条稳定成本推广计划。confirm=False 时 dry-run(停在开启推广前)。

    返回 {"ok":bool, "stage":str, "note":str}
    """
    gid = str(goods_id).strip()
    pg = await context.new_page()
    try:
        await pg.goto(PROMO_URL, wait_until="domcontentloaded", timeout=40000)
        await asyncio.sleep(6)
        _log(f"推广中心已打开: {pg.url[:60]}")

        # 1) 打开「添加推广商品」抽屉
        await pg.locator('button.anq-btn-primary', has_text='添加推广商品').first.click(timeout=10000)
        await asyncio.sleep(6)
        _log("已打开添加推广抽屉")

        # 2) 模式默认就是稳定成本推广;只点真正的按钮/tab(别匹配到说明文字的 div),失败无所谓
        try:
            tab = pg.locator('button:has-text("稳定成本推广"), [role="tab"]:has-text("稳定成本推广")').first
            if await tab.count():
                await tab.click(timeout=2500)
                await asyncio.sleep(1)
                _log("已选『稳定成本推广』")
        except Exception as e:
            _log(f"模式默认稳定成本推广(切换跳过: {_e1(e)})")

        # 3) 搜目标 goods —— 用抽屉专属搜索框(placeholder「请输入商品名/ID」),
        #    别用页面上那个「请输入推广名称/商品名称…」(会搜错地方)
        sb = pg.locator('input[placeholder*="请输入商品名"]').first
        await sb.fill(gid)
        await sb.press("Enter")
        await asyncio.sleep(2)
        try:
            await pg.locator('button:has-text("查询")').first.click(timeout=2000)
        except Exception:
            pass
        await asyncio.sleep(3)
        has = await pg.evaluate("(g)=>(document.body.innerText||'').includes(g)", gid)
        if not has:
            await _shot(pg, f"{gid}_notfound.png")
            return {"ok": False, "stage": "search", "note": f"待推广列表里没有 {gid}(可能已在推广/不可选)"}
        _log(f"搜到商品 {gid}")

        # 4) 选中该行(勾选框)——确保它进入"开启推广 (N/30)"计数
        try:
            row = pg.locator(f'[data-testid="editBid_{gid}_create_create"]').first
            # 行内勾选框:从编辑触发器往上找最近的行,点其 checkbox
            await pg.evaluate(r'''(gid)=>{
                const trig=document.querySelector(`[data-testid="editBid_${gid}_create_create"]`);
                if(!trig) return false;
                let row=trig; for(let i=0;i<8;i++){row=row.parentElement; if(!row)break;
                    const cb=row.querySelector('input[type=checkbox]');
                    if(cb){ if(!cb.checked) cb.click(); return true; }}
                return false;
            }''', gid)
            await asyncio.sleep(1)
            _log("已勾选目标行")
        except Exception as e:
            _log(f"勾选行跳过: {_e1(e)}")

        # 5) 设净目标投产比:点 editBid 弹 popover
        # 先等列表加载转圈(anq-spin-spinning)消失,否则它会拦截点击
        try:
            await pg.locator('.anq-spin-spinning').first.wait_for(state="hidden", timeout=8000)
        except Exception:
            pass
        await asyncio.sleep(1)
        try:
            await pg.locator(f'[data-testid="editBid_{gid}_create_create"]').first.click(timeout=10000)
        except Exception:
            await _shot(pg, f"{gid}_skip.png")
            return {"ok": False, "stage": "maybe_promoted",
                    "note": f"{gid} 打不开投产比设置(多半已在推广/不可加),跳过"}
        await asyncio.sleep(1.5)
        # 5a) 关「极速起量·高级版」开关 —— 它开着 PDD 把投产比锁得很死(上限低),关了才能预设高。
        adv_off = "n/a"
        try:
            adv = pg.locator('.anq-switch[class*="Advanc"]').first
            if await adv.count():
                if (await adv.get_attribute("aria-checked")) == "true":
                    await adv.click(timeout=3000)
                    await asyncio.sleep(1)
                    # 关高级版会弹"确定关闭"二次确认 → 必须点它,否则开关弹回(还是高级版)
                    try:
                        await pg.get_by_role("button", name="确定关闭", exact=True).first.click(timeout=3000)
                    except Exception:
                        try:
                            await pg.locator('button:has-text("确定关闭")').first.click(timeout=2000)
                        except Exception:
                            pass
                    await asyncio.sleep(1.2)
                    state2 = await adv.get_attribute("aria-checked")
                    adv_off = "turned_off" if state2 == "false" else f"STILL_ON(aria={state2})"
                else:
                    adv_off = "already_off"
            else:
                adv_off = "switch_absent"
        except Exception as e:
            adv_off = f"err:{_e1(e)}"
        _log(f"高级版开关: {adv_off}")
        # 高级版没真关掉 = 投产被锁 + 计划带高级版 → 中止,绝不建错计划
        if str(adv_off).startswith("STILL_ON"):
            await _shot(pg, f"{gid}_adv_on.png")
            return {"ok": False, "stage": "adv_not_off",
                    "note": f"高级版开关没能关闭({adv_off}),已中止(避免建出高级版计划)"}
        await asyncio.sleep(0.5)
        # 5b) 填净目标投产比 —— ★新版弹层是受控 input(data-testid=CustomInputNumber):
        #     必须 keyboard.type(JS setter/fill 会被 React 回滚成推荐档,如填1.73被回滚成1.65;2026-06-23 dump 坐实)。
        roi_set = False
        cin = pg.locator('[data-testid="CustomInputNumber"]').first
        if await cin.count():
            try:
                await cin.click(timeout=4000)
                await cin.press("Control+a")
                await cin.press("Delete")
                await pg.keyboard.type(str(roas), delay=25)
                await asyncio.sleep(0.5)
                _v = (await cin.input_value() or "").strip()
                try:
                    roi_set = abs(float(_v) - float(roas)) < 0.011
                except Exception:
                    roi_set = (_v == str(roas))
            except Exception as e:
                _log(f"投产比 keyboard.type 异常: {_e1(e)}")
        if not roi_set:
            # 回退:老版弹层(自由输入,JS setter 也认)
            roi_set = await pg.evaluate(r'''(val)=>{
                const ins=[...document.querySelectorAll('input')].filter(e=>{
                    const r=e.getBoundingClientRect();
                    return r.width>0 && r.height>0 && (e.type==='text'||e.type==='number')
                           && !(e.placeholder||'').includes('商品');});
                if(!ins.length) return false;
                const inp=ins[ins.length-1];
                const setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
                setter.call(inp, String(val));
                inp.dispatchEvent(new Event('input',{bubbles:true}));
                inp.dispatchEvent(new Event('change',{bubbles:true}));
                return true;
            }''', roas)
        await asyncio.sleep(0.5)
        # 5c) 应用并【关掉弹层】—— ★先点弹层专属确定 confirm_<gid>(关掉它才不会挡住后面的「更多设置」/全局优选,
        #     2026-06-23 dump 坐实弹层会盖住更多设置),再回退通用「确定」。
        _closed = False
        try:
            cbtn = pg.locator(f'[data-testid="confirm_{gid}"]').first
            if await cbtn.count():
                await cbtn.click(timeout=3000); _closed = True
        except Exception:
            pass
        if not _closed:
            try:
                await pg.get_by_role("button", name="确定", exact=True).last.click(timeout=2500)
            except Exception:
                pass
        await asyncio.sleep(1.2)
        # 5d) 关了高级版后若仍报"低至 X 及以下"=残留上限 → 跳过(建议换新链接)
        cap = await pg.evaluate(r'''()=>{
            const m=(document.body.innerText||'').match(/低至\s*([0-9]+\.?[0-9]*)\s*及以下/);
            return m?parseFloat(m[1]):null;
        }''')
        if cap is not None and roas > cap + 1e-9:
            await _shot(pg, f"{gid}_capped.png")
            return {"ok": False, "stage": "roas_capped",
                    "note": f"关高级版后仍锁:实际保本{roas} > 上限{cap},跳过(老链接被锁投产,换新链接开)"}
        _log(f"净目标投产比已填 {roas}  (高级版={adv_off}, 残留上限={cap}, set={roi_set})")

        # 6) 设日预算:更多设置 → 点「预算日限额」(★cursor=pointer 的下拉项)→ 弹窗填→确定。
        #    ★慢店铺(如皙颜)首点常超时 → 失败重试3次 + 每次先滚动到元素再点;budget_ok 标记是否真设上。
        budget_set = "n/a"; budget_ok = False
        for _b_try in range(1, 4):
            try:
                more = pg.locator('text=更多设置').first
                try: await more.scroll_into_view_if_needed(timeout=4000)
                except Exception: pass
                await asyncio.sleep(0.6)
                await more.click(timeout=8000)
                await asyncio.sleep(1.6)
                pos = await pg.evaluate(r'''()=>{
                    const els=[...document.querySelectorAll('*')].filter(e=>{const t=(e.innerText||'').trim();const r=e.getBoundingClientRect();
                        return t==='预算日限额'&&r.width>0&&r.height>0&&getComputedStyle(e).cursor==='pointer';});
                    if(!els.length) return null; const r=els[els.length-1].getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2};
                }''')
                if pos:
                    await pg.mouse.click(pos['x'], pos['y'])
                    await asyncio.sleep(1.8)
                modal = pg.locator('[role="dialog"]', has_text='确定').filter(has_text='预算日限额').first
                if await modal.count():
                    inp = modal.locator('input').first
                    await inp.click()
                    await inp.fill(str(int(budget)), timeout=4000)
                    _val = (await inp.input_value() or "").strip()
                    await modal.get_by_role("button", name="确定", exact=True).click(timeout=4000)
                    await asyncio.sleep(1)
                    budget_set = _val
                    budget_ok = (_val == str(int(budget)))
                    if budget_ok:
                        break
                else:
                    budget_set = "no_modal(预算日限额没点开弹窗)"
            except Exception as e:
                budget_set = f"err:{_e1(e)}"
            if _b_try < 3:
                _log(f"设预算第{_b_try}次未成({budget_set}),滚动重试…")
                await asyncio.sleep(1.2)
        _log(f"日预算: 目标{budget} set={budget_set} ok={budget_ok}")

        # 7) 关「全局优选起量」勾选框(默认勾上,必须取消)。★慢店铺『确定关闭』点击常超时 →
        #    失败重试3次:取消勾选 → 点确定关闭 → 读回确认真 OFF;global_off 标记最终是否关掉。
        global_off = False; unchecked = "n/a"
        for _g_try in range(1, 4):
            state = await pg.evaluate(r'''()=>{
                const cbs=[...document.querySelectorAll('input[type=checkbox]')];
                for(const cb of cbs){let lab='';let p=cb;for(let i=0;i<6;i++){p=p.parentElement;if(!p)break;
                    const t=(p.innerText||'');if(t.includes('全局优选起量')){lab=t;break;}}
                    if(lab){ if(cb.checked){cb.click(); return 'clicked';} return 'already_off'; }}
                return 'not_found';
            }''')
            unchecked = state
            if state == 'already_off':
                global_off = True; break
            if state == 'not_found':
                global_off = True; _log("全局优选: 未找到勾选框(该模式可能没有),跳过"); break
            # clicked → 弹"确定关闭"二次确认,点它才真关
            await asyncio.sleep(0.8)
            try:
                await pg.locator('button:has-text("确定关闭")').first.click(timeout=4000)
                await asyncio.sleep(1)
            except Exception as e:
                _log(f"全局优选『确定关闭』第{_g_try}次未点到: {_e1(e)}")
            # 读回确认是否真 OFF
            still_on = await pg.evaluate(r'''()=>{
                const cbs=[...document.querySelectorAll('input[type=checkbox]')];
                for(const cb of cbs){let l='';let p=cb;for(let i=0;i<6;i++){p=p.parentElement;if(!p)break;
                    const t=(p.innerText||'');if(t.includes('全局优选起量')){l=t;break;}}
                    if(l) return cb.checked;}
                return false;
            }''')
            if not still_on:
                global_off = True; break
            if _g_try < 3:
                _log(f"全局优选第{_g_try}次没关掉,重试…")
                await asyncio.sleep(1.2)
        _log(f"全局优选起量: OFF={global_off} (last={unchecked})")

        # 8) 读回复核(花钱前坐实:已选数量/行投产比/全局优选状态/预算真实值)
        verify = await pg.evaluate(r'''(gid)=>{
            const out={};
            const ob=[...document.querySelectorAll('button')].find(e=>(e.innerText||'').includes('开启推广'));
            out.openBtn = ob ? ob.innerText.trim() : '';
            const trig=document.querySelector(`[data-testid="editBid_${gid}_create_create"]`);
            if(trig){ let cell=trig; for(let i=0;i<4;i++){cell=cell.parentElement; if(!cell)break;
                const m=(cell.innerText||'').match(/[0-9]+\.[0-9]+/); if(m){out.rowRoi=m[0]; break;}} }
            const cbs=[...document.querySelectorAll('input[type=checkbox]')];
            for(const cb of cbs){let p=cb,l=''; for(let i=0;i<6;i++){p=p.parentElement; if(!p)break;
                const t=(p.innerText||''); if(t.includes('全局优选起量')){l=t;break;}}
                if(l){out.globalOpt = cb.checked ? 'ON' : 'OFF'; break;}}
            // 预算从该行显示文本读(填完弹窗关了,行上是文本不是输入框)
            const brow=[...document.querySelectorAll('*')].find(e=>{const t=(e.innerText||'');
                return t.includes(gid)&&t.includes('预算日限额')&&t.length<400;});
            const mm=brow?(brow.innerText||'').match(/预算日限额[\s：:]*([0-9.]+|不限)/):null;
            out.budget = mm?mm[1]:'';
            return out;
        }''', gid)
        _log(f"复核: 开启按钮=[{verify.get('openBtn')}] 行投产比={verify.get('rowRoi')} "
             f"全局优选={verify.get('globalOpt')} 预算={verify.get('budget')}")

        # 9) 预览截图(dry-run 一定看这张)
        await _shot(pg, f"{gid}_preview.png")

        # ★花钱前硬自检:关键参数任一没设对 → 列成 problems(供闸门拦截/dry-run 报告)
        problems = []
        if not budget_ok:
            problems.append(f"预算没设上(set={budget_set})")
        if not global_off or verify.get("globalOpt") == "ON":
            problems.append("全局优选起量没关掉")
        if not roi_set:
            problems.append("净目标投产比没填上")
        if adv_off not in ("turned_off", "already_off"):
            problems.append(f"高级版没确认关掉(adv={adv_off})")
        _log(f"花钱前自检: {'通过' if not problems else '未通过 → ' + ';'.join(problems)}")

        if not confirm:
            return {"ok": True, "stage": "dry_run",
                    "note": f"dry-run 完成:投产比={roas}(set={roi_set}) 预算={budget}(ok={budget_ok}) "
                            f"全局优选OFF={global_off} 高级版={adv_off}。"
                            f"自检{'通过' if not problems else '未通过:' + ';'.join(problems)}。"
                            f"未点开启推广,截图 promote_shots/{gid}_preview.png。"}

        # ★硬闸门:自检没过就【中止不开】——宁可不开,也不开一条 不限预算/全局优选ON/高级版没关 的废计划
        if problems:
            await _shot(pg, f"{gid}_setup_fail.png")
            return {"ok": False, "stage": "setup_incomplete",
                    "note": "开车前自检未通过,已中止不开(避免建废计划):" + ";".join(problems)
                            + "。多因该店铺推广页慢/布局异常,重试仍不行需人工开或换链接。"}

        await pg.locator('button:has-text("开启推广")').first.click(timeout=6000)
        await asyncio.sleep(4)
        await _shot(pg, f"{gid}_after_confirm.png")
        # 成功提示文字仅留作日志,★不再作为判定依据(handoff:提示=False 也可能其实建成,反之亦然)
        ok_text = await pg.evaluate(r'''()=>{
            const t=document.body.innerText||'';
            return t.includes('开启成功')||t.includes('推广成功')||t.includes('提交成功');
        }''')
        _log(f"点完开启推广(成功提示={ok_text}),先关成功弹窗再回列表核验…")
        # ★点完会弹「开启成功」弹窗(继续推广/查看推广/×)——不关它会卡住,且弹窗+抽屉盖着列表会让核验失准。
        #   先关弹窗(优先「查看推广」=去列表,回退 ×/继续推广/Esc)。
        await asyncio.sleep(2)
        _dismissed = False
        for _nm in ("查看推广", "继续推广"):
            try:
                _b = pg.get_by_role("button", name=_nm, exact=True)
                if await _b.count():
                    await _b.first.click(timeout=3000); _dismissed = True
                    _log(f"已关成功弹窗(点「{_nm}」)"); break
            except Exception:
                pass
        if not _dismissed:
            try: await pg.keyboard.press("Escape")
            except Exception: pass
        # ★成功判定 = 回【干净的推广列表】按 gid 核验真有 live 计划(之前停在抽屉/弹窗上下文→核验失准)
        await asyncio.sleep(2)
        try:
            await pg.goto(PROMO_URL, wait_until="domcontentloaded", timeout=40000)
            await asyncio.sleep(6)
        except Exception as e:
            _log(f"回列表 goto 异常(继续核验): {_e1(e)}")
        try:
            chk = await find_plan(pg, gid)
        except Exception as e:
            chk = _result(False, note=f"核验异常:{_e1(e)}")
        await _shot(pg, f"{gid}_verify.png")
        _log(f"核验: found={chk['found']} live={chk['live']} 状态={chk.get('status')} "
             f"adId={chk.get('ad_id')} 投产={chk.get('target_roas')} 预算={chk.get('budget')}")
        if chk["live"]:
            return {"ok": True, "stage": "confirmed_verified", "ad_id": chk.get("ad_id", ""),
                    "note": f"已开启并核验:列表里有这条 live 计划(状态={chk.get('status')} "
                            f"adId={chk.get('ad_id')} 投产={chk.get('target_roas')} "
                            f"预算={chk.get('budget')} 成功提示={ok_text})。"}
        if chk["found"]:
            return {"ok": False, "stage": "verify_not_live", "ad_id": chk.get("ad_id", ""),
                    "status": chk.get("status", ""),
                    "note": f"已点开启推广,但核验非推广中(状态={chk.get('status')},成功提示={ok_text})"
                            f"——计划存在却未在投(审核中/被暂停/受限?),需人工核对。"}
        return {"ok": False, "stage": "verify_not_found",
                "note": f"已点开启推广,但列表核验搜不到这条计划(成功提示={ok_text})"
                        f"——多半没真建成(投产被锁/提交失败),需换新链接或人工核对。"}
    except Exception as e:
        await _shot(pg, f"{gid}_error.png")
        return {"ok": False, "stage": "exception", "note": f"{type(e).__name__}: {_e1(e)}"}
    finally:
        try:
            await pg.close()
        except Exception:
            pass


async def run(args):
    stores = _load_stores()
    matched = next((k for k in stores if args.store in k or k in args.store), None)
    profile_dir = (PROFILE_DIR / stores[matched]) if matched else _profile_dir_for(args.store)
    _log(f"profile={profile_dir}")
    _win = ["--start-maximized"] if args.show_browser \
        else ["--window-position=-32000,-32000", "--window-size=1600,1000"]
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir), executable_path=find_chrome(),
            headless=False, args=_win + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"], viewport=None)
        ip = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await apply_window_mode(ctx, ip, args.show_browser)
        res = await create_one(ctx, args.goods_id, args.roas, args.budget, confirm=args.confirm)
        try:
            await asyncio.wait_for(ctx.close(), timeout=6)
        except Exception:
            pass
    print(res)
    return res


def main():
    ap = argparse.ArgumentParser(description="自动建稳定成本推广计划(默认dry-run)")
    ap.add_argument("--store", required=True)
    ap.add_argument("--goods-id", required=True)
    ap.add_argument("--roas", type=float, required=True, help="净目标投产比(实际保本档,如1.58)")
    ap.add_argument("--budget", type=float, default=200.0, help="日预算(元),PDD最低200,默认200")
    ap.add_argument("--confirm", action="store_true", help="真点开启推广(花钱!不加=dry-run)")
    ap.add_argument("--show-browser", action="store_true")
    ap.add_argument("--auto-close", action="store_true")
    args = ap.parse_args()
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        sys.exit(130)
    finally:
        if args.auto_close:
            os._exit(0)


if __name__ == "__main__":
    main()
