"""商品库数据层 —— PDD 自动上架模块的"待提交商品池"。

商品库是选品/已比价数据与待发布之间的稳定缓冲:
  - 入库后即与上游(compared_products.json)解耦,上游删除不影响商品库
  - 删除/合并/状态变更只能通过商品库自身 API
  - 支持多来源入库: auto(自动同步已比价)/ manual(手动选条入库)/ excel(表格导入)
  - Excel 导入的条目未必有 supplier_link/cost,商品库内可单独跑 1688 比价补全

数据文件: data/pdd/product_library.json
图片:     data/pdd/library_images/<prod_id>.jpg  (仅 Excel 嵌入图保存为本地;URL 图保留原 URL)

模块自包含,不依赖项目其它代码,便于未来 PDD 模块独立打包销售。
路径基于 __file__,不硬编码 D:/files,可整体迁移到任意安装目录。
"""
from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import Optional, Iterable

# ── 路径配置(可整体迁移) ────────────────────────────────────────────────────
_BASE_DIR = Path(__file__).resolve().parent
LIB_PATH = _BASE_DIR / "data" / "pdd" / "product_library.json"
LIBRARY_IMAGE_DIR = _BASE_DIR / "data" / "pdd" / "library_images"


# ── 字段 schema(向前兼容用) ────────────────────────────────────────────────
# 加新字段时给默认值即可;不破老数据。
_SCHEMA = {
    "id":                 (str,   ""),     # 库内唯一 id(uuid)
    "prod_id":            (str,   ""),     # PDD 商品 ID(用于去重)
    "name":               (str,   ""),
    "image":              (str,   ""),     # 封面图 URL(优先);若为本地文件路径以 file:/ 区分
    "image_local":        (str,   ""),     # 本地保存的图路径(Excel 嵌入图)
    "price_range":        (str,   ""),     # 售价区间字符串
    "category":           (str,   ""),     # 来源类目 "L1>L2>L3"
    "shop_name":          (str,   ""),     # 货主店铺名
    "shop_id":            (str,   ""),
    "pdd_link":           (str,   ""),     # PDD 商品详情链接
    "first_listed":       (str,   ""),     # 首次上架时间
    # 1688 比价字段(导入时可空,后续跑比价补全)
    "supplier_link":      (str,   ""),
    "supplier_cost":      (float, 0.0),    # 供货单价数字
    "cost_ref":           (str,   ""),     # "¥xx (¥xx+运xx)"
    "cost_supplier":      (str,   ""),     # 1688 店铺名
    "cost_top3_str":      (str,   ""),
    "candidates":         (list,  None),   # 1688 候选列表(含 image,供手动比价)
    "auto_note":          (str,   ""),     # "自动比价" / "✋ 手动比价" / "未比价"
    # 批准文号预核对(发布前在商品库核对,发布时直接用,免得开 1688 页重抓)
    "is_special":         (str,   ""),     # 是否特殊用途化妆品: "是"/"否"/""(未核对)
    "license_no":         (str,   ""),     # 化妆品批准文号/备案号
    "license_checked":    (bool,  False),  # 是否已核对过(区分"核对过=无" 与 "没核对过")
    # 视觉同款核对(qwen2.5vl 比对 我方商品图 vs 1688供货图,揪比价选错链接)
    "same_style":         (str,   ""),     # "同款"/"不同款"/"不确定"/""(未核对)
    "same_style_reason":  (str,   ""),     # 模型给的理由
    "same_style_time":    (str,   ""),     # 核对时间
    # 状态字段
    "source":             (str,   "manual"),  # 入库来源: auto/manual/excel
    "added_time":         (str,   ""),
    "last_compared_time": (str,   ""),
    "submitted":          (bool,  False),  # 是否已提交到待发布
    "submit_time":        (str,   ""),
    "warehoused":         (bool,  False), # 是否已标记入仓
    "warehouse_time":     (str,   ""),    # 入仓标记时间
    # 原始 Excel 行(可选,防止后续要补字段时重新解析)
    "raw_excel_row":      (dict,  None),
}


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def _normalize(rec: dict) -> dict:
    """补齐 schema 字段、转换类型;非破坏性,未知字段保留。"""
    out = dict(rec)
    for k, (typ, default) in _SCHEMA.items():
        if k not in out or out[k] is None:
            out[k] = default if default is not None else (
                [] if typ is list else ({} if typ is dict else default)
            )
            continue
        try:
            if typ is bool:
                out[k] = bool(out[k])
            elif typ is int:
                out[k] = int(float(out[k]))
            elif typ is float:
                out[k] = float(out[k])
            elif typ is str:
                out[k] = str(out[k])
            elif typ is list and not isinstance(out[k], list):
                out[k] = []
            elif typ is dict and not isinstance(out[k], dict):
                out[k] = {}
        except (TypeError, ValueError):
            out[k] = default if default is not None else (
                [] if typ is list else ({} if typ is dict else default)
            )
    if not out["id"]:
        out["id"] = _new_id()
    if not out["added_time"]:
        out["added_time"] = _now()
    return out


# ── 持久化 ────────────────────────────────────────────────────────────────

def load_library() -> list[dict]:
    """读商品库列表。文件不存在返回空列表(不主动建文件,避免首次启动产生 noise)。"""
    if not LIB_PATH.exists():
        return []
    try:
        with open(LIB_PATH, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("product_library.json 顶层应为 list")
        return [_normalize(r) for r in data if isinstance(r, dict)]
    except (OSError, json.JSONDecodeError, ValueError) as e:
        # 损坏时备份原文件,返回空(不静默吞;给用户看到)
        bak = LIB_PATH.with_suffix(f".bak.{int(time.time())}.json")
        try:
            LIB_PATH.rename(bak)
            print(f"[product_library] 文件损坏已备份至 {bak.name}: {e}")
        except OSError:
            pass
        return []


def save_library(records: list[dict]) -> None:
    """原子写入。先 .tmp 再 os.replace,中途崩溃也不损坏 json。"""
    records = [_normalize(r) for r in records]
    LIB_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = LIB_PATH.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)
    os.replace(tmp, LIB_PATH)


# ── 查询 / 工具 ───────────────────────────────────────────────────────────

def get_by_id(records: list[dict], rid: str) -> Optional[dict]:
    for r in records:
        if r.get("id") == rid:
            return r
    return None


def find_by_prod_id(records: list[dict], prod_id: str) -> Optional[dict]:
    """按 PDD 商品 ID 找(用于去重)。空 prod_id 返回 None。"""
    if not prod_id:
        return None
    for r in records:
        if r.get("prod_id") == prod_id:
            return r
    return None


# ── 入库 / 更新 ───────────────────────────────────────────────────────────

def add_or_update(records: list[dict], rec: dict, merge: bool = True) -> tuple[list[dict], str, bool]:
    """入库 / 合并。返回 (新列表, id, is_new)。

    去重策略: 按 prod_id 找;命中 + merge=True → 合并非空字段(新值覆盖空旧值,保留旧字段非空值);
                                   merge=False → 跳过,返回旧 id, is_new=False
    无 prod_id 或未命中 → 当作新条插入。
    """
    rec = _normalize(rec)
    out = list(records)
    existing = find_by_prod_id(out, rec.get("prod_id", ""))
    if existing is None:
        out.append(rec)
        return out, rec["id"], True
    if not merge:
        return out, existing["id"], False
    # 合并: 新值非空才覆盖,保留旧的非空值;raw_excel_row 用新的(若新有)
    for k, v in rec.items():
        if k in ("id", "added_time"):
            continue  # 保留旧 id/入库时间
        if v in (None, "", 0, 0.0, [], {}):
            continue
        existing[k] = v
    return out, existing["id"], False


def bulk_add(records: list[dict], new_recs: Iterable[dict], merge: bool = True) -> tuple[list[dict], int, int]:
    """批量入库。返回 (新列表, 新增数, 合并数)。"""
    out = list(records)
    added = 0
    merged = 0
    for r in new_recs:
        out, _id, is_new = add_or_update(out, r, merge=merge)
        if is_new:
            added += 1
        else:
            merged += 1
    return out, added, merged


def delete_by_ids(records: list[dict], ids: Iterable[str]) -> tuple[list[dict], int]:
    """按 id 批量删除。返回 (新列表, 删除数)。"""
    id_set = set(ids)
    out = [r for r in records if r.get("id") not in id_set]
    return out, len(records) - len(out)


def update_fields(records: list[dict], rid: str, patch: dict) -> list[dict]:
    """单条字段更新(用于比价补全/标记已提交等)。"""
    out = list(records)
    for r in out:
        if r.get("id") == rid:
            r.update(patch)
            return [_normalize(x) for x in out]
    return out


def mark_submitted(records: list[dict], ids: Iterable[str], submitted: bool = True) -> list[dict]:
    """标记提交状态。批量。"""
    id_set = set(ids)
    out = list(records)
    now = _now()
    for r in out:
        if r.get("id") in id_set:
            r["submitted"] = submitted
            r["submit_time"] = now if submitted else ""
    return out


def mark_compared(records: list[dict], rid: str, compare_result: dict) -> list[dict]:
    """跑完 1688 比价后回写字段。compare_result 字段名对齐 price_compare.py 返回。"""
    patch = {
        "supplier_link":   compare_result.get("supplier_link", ""),
        "cost_ref":        compare_result.get("cost_ref", ""),
        "cost_supplier":   compare_result.get("cost_supplier", ""),
        "cost_top3_str":   compare_result.get("cost_top3_str", ""),
        "candidates":      compare_result.get("candidates", []),
        "auto_note":       compare_result.get("auto_note", "") or "自动比价",
        "last_compared_time": _now(),
        # 比价换了链接 → 旧批准文号核对作废(A方案),需重新核对
        "is_special": "", "license_no": "", "license_checked": False,
        # 比价时视觉同款结论(price_compare 已对选中链接判过)→ 直接落库,免再人工核对
        "same_style":        compare_result.get("same_style", ""),
        "same_style_reason": compare_result.get("same_style_reason", ""),
        "same_style_time":   _now() if compare_result.get("same_style") else "",
    }
    # supplier_cost 从 cost_ref 提一下数字(可选)
    import re
    m = re.search(r"(\d+\.?\d*)", patch["cost_ref"])
    if m:
        try:
            patch["supplier_cost"] = float(m.group(1))
        except ValueError:
            pass
    return update_fields(records, rid, patch)


# ── 过滤 / 筛选(供"按规则提交"使用) ─────────────────────────────────────

def filter_records(records: list[dict], *,
                   only_unsubmitted: bool = True,
                   only_compared: bool = False,
                   category_contains: str = "",
                   price_min: float = 0.0,
                   price_max: float = 0.0,
                   added_after: str = "",
                   added_before: str = "",
                   max_count: int = 0) -> list[dict]:
    """通用筛选。供 UI/计划提交按规则取候选。

    - only_unsubmitted:仅未提交过的
    - only_compared:   仅已跑过比价的(有 supplier_link)
    - category_contains: 类目子串
    - price_min/max:   解析 price_range 首数字 vs 区间
    - added_after/before: ISO 字符串 "YYYY-MM-DD HH:MM:SS"
    - max_count: 截断条数(0 = 不截断)
    """
    import re
    out = []
    for r in records:
        if only_unsubmitted and r.get("submitted"):
            continue
        if only_compared and not r.get("supplier_link"):
            continue
        if category_contains and category_contains not in (r.get("category") or ""):
            continue
        if price_min > 0 or price_max > 0:
            m = re.search(r"(\d+\.?\d*)", r.get("price_range", ""))
            p = float(m.group(1)) if m else 0
            if price_min > 0 and p < price_min:
                continue
            if price_max > 0 and p > price_max:
                continue
        if added_after and r.get("added_time", "") < added_after:
            continue
        if added_before and r.get("added_time", "") > added_before:
            continue
        out.append(r)
    if max_count > 0:
        out = out[:max_count]
    return out


if __name__ == "__main__":
    # 自检
    recs = load_library()
    print(f"商品库当前 {len(recs)} 条")
    for r in recs[:5]:
        flag = "✓提交" if r["submitted"] else "○未提交"
        comp = "💰" if r["supplier_link"] else "·"
        print(f"  [{r['id']}] {flag} {comp} {r['name'][:40]}  来源={r['source']}  类目={r['category']}")
