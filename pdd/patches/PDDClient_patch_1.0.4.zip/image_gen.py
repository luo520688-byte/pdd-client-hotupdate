# -*- coding: utf-8 -*-
"""生图换图(API 版):调 gpt-image-2(经 grsai 国内/全球节点)给商品货品图生成直通车推广主图。
替代原来开浏览器跑 Google Flow 的方式 —— API 调用,不限流、不娇贵、更快。机制已实测(见 handoff §17)。

- 图生图(/v1/api/generate):传真实货品图 → 保留产品原样 + 换背景 + 加中文大字报文案。
- 文案从商品标题抠卖点(复用智能SKU那套云端 DeepSeek)。
- 配置 data/pdd/image_api.json(base_url/key/model,隐私不进打包);DeepSeek key 在 llm_api.json。

接口:
- generate_promo(src_image, 主标题, 副标题, 卖点标签, out_path) -> dict   # 核心:图生图出一张
- generate_for_product(src_image, title, out_path) -> dict               # 便捷:标题→抠文案→出图
- extract_copy(title) -> {主标题,副标题,卖点标签}
CLI:  python image_gen.py <货品图> --auto <商品标题> [输出路径]
      python image_gen.py <货品图> <主标题> <副标题> <卖点标签> [输出路径]
"""
import base64, json, os, sys, urllib.request
from pathlib import Path

CFG = r"D:/files/data/pdd/image_api.json"          # 图像API(gpt-image-2中转)
LLM_CFG = r"D:/files/data/pdd/llm_api.json"        # DeepSeek(抠文案)
DEFAULT_OUTDIR = r"D:/files/data/promo"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")   # 绕中转站 Cloudflare(error 1010)

# 图生图提示词模板。用户可在 data/pdd/image_prompt.txt 覆盖；无占位符时按原文直接生成。
EDIT_PROMPT = (
    "请根据我上传的产品图，生成一组适合拼多多直通车 / 视频封面风格的高点击主图，尺寸为 800×800。\n"
    "产品必须完整展示，比例自然，不能裁切变形，可根据画面需要改变摆法、角度、大小关系。\n"
    "整体画面风格要采用：\n"
    "高点击视频封面风 + 拼多多爆款主图逻辑 + 小红书种草感 + 大字报排版。\n"
    "高级感/高点击/醒目大字报，产品在左侧，可以加入人物展示效果，采用免费商用字体，文案不得重复，不可出现承诺性词语及夸大宣传词语。\n"
    "不可以带价格标签及价格信息")
PROMPT_FILE = r"D:/files/data/pdd/image_prompt.txt"   # 用户可改的提示词(记事本改完,下次生成生效)


def _load_prompt() -> str:
    """优先读外部提示词文件(用户随时可改);没有/为空才回落内置默认。
    有 {主}{副}{标签} 占位就替换抠的文案;没占位就原样用(让模型自己发挥文案)。"""
    try:
        t = Path(PROMPT_FILE).read_text(encoding="utf-8").strip()
        if t:
            return t
    except Exception:
        pass
    return EDIT_PROMPT

# ── 卖点提取(复用智能SKU那套云端 DeepSeek;失败回落截标题,不阻断出图) ──
COPY_SYS = (
    "你给电商直通车推广主图设计文案。给你一个商品标题,提炼出海报上要渲染的三段中文文字。\n"
    "**铁律:紧扣商品本身真实的品类和核心功效(从标题提取),不准编造无关卖点、不准夸大违规词(如最/第一/纯天然/根治)。**\n"
    "- 主标题:最醒目的大字,商品核心卖点或品类词,4-10字,有冲击力。\n"
    "- 副标题:利益点/使用效果,6-16字。\n"
    "- 卖点标签:2-3个简短卖点,每个2-6字,用 ' / ' 分隔。\n"
    "只输出JSON:{\"主标题\":\"..\",\"副标题\":\"..\",\"卖点标签\":\".. / ..\"}。不要别的字。")


# DeepSeek 直连 opener:不走系统/翻墙代理(VPN/clash 开着时系统代理会拦 api.deepseek.com,
# ProxyHandler({}) = 禁用所有代理。
_NOPROXY_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _llm_json(system, user, temperature=0):
    cfg = json.loads(Path(LLM_CFG).read_text(encoding="utf-8"))
    body = json.dumps({"model": cfg.get("model", "deepseek-chat"), "temperature": temperature,
                       "messages": [{"role": "system", "content": system},
                                    {"role": "user", "content": user}]}).encode()
    req = urllib.request.Request(
        cfg.get("base_url", "https://api.deepseek.com").rstrip("/") + "/chat/completions",
        data=body, headers={"Authorization": "Bearer " + cfg["key"], "Content-Type": "application/json"})
    txt = json.loads(_NOPROXY_OPENER.open(req, timeout=60).read())["choices"][0]["message"]["content"].strip()
    if txt.startswith("```"):
        txt = txt.strip("`")
        txt = txt[txt.find("{"):txt.rfind("}") + 1]
    return json.loads(txt)


def extract_copy(title: str) -> dict:
    """商品标题 → {主标题,副标题,卖点标签}。云端失败回落截标题(不阻断出图)。"""
    title = (title or "").strip()
    try:
        r = _llm_json(COPY_SYS, "商品标题:%s" % title)
        if (r.get("主标题") or "").strip():
            return {"主标题": r["主标题"].strip(), "副标题": (r.get("副标题") or "").strip(),
                    "卖点标签": (r.get("卖点标签") or "").strip()}
    except Exception as e:
        print(f"[生图] 卖点提取失败,回落截标题: {e!r}")
    return {"主标题": title[:10] or "推广主图", "副标题": "", "卖点标签": ""}


def generate_promo(src_image, 主标题, 副标题="", 卖点标签="", out_path=None, product_title="") -> dict:
    """图生图:传货品图 → 保留产品 + 换背景 + 加中文文案。返回 {ok, out_path?, reason?}。
    ★主线路 = grsai 国内节点流式;失败时回退 image_api.json.fallback 配置的 grsai 全球节点。"""
    res = {"ok": False, "src": src_image}
    if not os.path.exists(src_image):
        res["reason"] = "src-not-found"; return res
    try:
        import requests  # noqa: F401
    except Exception as e:
        res["reason"] = f"no-requests:{e!r}"; return res
    cfg = json.loads(Path(CFG).read_text(encoding="utf-8"))
    prompt = _load_prompt().replace("{主}", 主标题 or "").replace("{副}", 副标题 or "").replace("{标签}", 卖点标签 or "")
    product_title = (product_title or "").strip()
    if product_title:
        prompt = prompt.rstrip() + "\n\n产品标题是：" + product_title
    out_path = out_path or os.path.join(DEFAULT_OUTDIR, Path(src_image).stem + "_promo.jpg")
    # 主线路:grsai 流式
    r = _gen_grsai(cfg, src_image, prompt, out_path)
    if r.get("ok"):
        return r
    # 回退备选:grsai 全球节点。仅当配置了 fallback 才回退。
    fb = cfg.get("fallback") or {}
    if fb.get("key") and fb.get("base_url"):
        print(f"[生图] 主线路失败({r.get('reason')}) → 回退 grsai 全球节点 {fb.get('base_url')}")
        r2 = _gen_grsai(fb, src_image, prompt, out_path)
        if r2.get("ok"):
            r2["used_fallback"] = True
            return r2
        r2["primary_reason"] = r.get("reason")   # 两条都失败,带上主线路原因便于排查
        return r2
    return r


def _gen_grsai(cfg, src_image, prompt, out_path) -> dict:
    """grsai /v1/api/generate 流式SSE出图。replyType=stream:连接一直有 progress 数据,不被 Cloudflare ~100s 掐断。"""
    import requests, time as _t
    res = {"ok": False, "src": src_image}
    base = (cfg.get("base_url") or "https://grsai.dakka.com.cn").rstrip("/")
    url = base + "/v1/api/generate"
    try:
        with open(src_image, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        body = {
            "model": cfg.get("model", "gpt-image-2"),
            "prompt": prompt,
            "images": ["data:image/jpeg;base64," + b64],   # 参考图:支持 base64/url,这里传货品图
            "aspectRatio": cfg.get("aspect_ratio", "1024x1024"),
            "replyType": "stream",
        }
        headers = {"Content-Type": "application/json", "Authorization": "Bearer " + cfg["key"]}
        _sess = requests.Session(); _sess.trust_env = False   # 直连,不走系统/翻墙代理
        last = None
        for _att in range(2):   # 仅对【连接级异常】轻重试1次;流式不受100s限制,不会因超时白白重发扣费
            try:
                with _sess.post(url, json=body, headers=headers, stream=True, timeout=600) as r:
                    if r.status_code != 200:
                        res["reason"] = f"http-{r.status_code}"; res["body"] = r.text[:600]; return res
                    for raw in r.iter_lines(decode_unicode=True):
                        if not raw:
                            continue
                        line = raw[5:].strip() if raw.startswith("data:") else raw.strip()
                        if not line or line == "[DONE]":
                            continue
                        try:
                            j = json.loads(line)
                        except Exception:
                            continue
                        last = j
                        if j.get("status") in ("succeeded", "failed", "violation"):
                            break
                break
            except Exception as _pe:
                print(f"[生图·grsai] 流式请求异常(第{_att+1}/2次): {_pe!r}")
                res["reason"] = f"req-exc:{_pe!r}"
                if _att < 1:
                    _t.sleep(3); last = None; continue
                return res
        if not last:
            res["reason"] = "no-stream-data"; return res
        if last.get("status") != "succeeded":
            res["reason"] = f"gen-{last.get('status')}"; res["raw"] = str(last.get("error") or last)[:500]; return res
        _r = last.get("results") or []
        iurl = _r[0].get("url") if (_r and isinstance(_r[0], dict)) else None
        if not iurl:
            res["reason"] = "no-image-url"; res["raw"] = json.dumps(last, ensure_ascii=False)[:500]; return res
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        _img = None
        for _a in range(3):
            try:
                _img = _sess.get(iurl, timeout=120, headers={"User-Agent": UA}).content
                if _img:
                    break
            except Exception:
                _t.sleep(2)
        if not _img:
            res["reason"] = "img-url-dl-failed"; res["raw"] = iurl[:300]; return res
        Path(out_path).write_bytes(_img)
        res["ok"] = True; res["out_path"] = out_path
    except Exception as e:
        res["reason"] = f"exc:{e!r}"
    return res


def generate_for_product(src_image, title, out_path=None) -> dict:
    """便捷入口:货品图 + 商品标题 → 图生图出推广图。返回同 generate_promo + copy。
    ★ 只有提示词里真含 {主}/{副}/{标签} 占位符时才去调 DeepSeek 抠文案;
       自由提示词(无占位符,如用户在 image_prompt.txt 自己写好的)直接生成,不白调 DeepSeek、不白等。"""
    prompt = _load_prompt()
    if any(k in prompt for k in ("{主}", "{副}", "{标签}")):
        copy = extract_copy(title)
        print(f"[生图] 文案: 主='{copy['主标题']}' 副='{copy['副标题']}' 标签='{copy['卖点标签']}'")
    else:
        copy = {"主标题": "", "副标题": "", "卖点标签": ""}
        print("[生图] 提示词无 {主}/{副}/{标签} 占位符 → 跳过 DeepSeek 文案,按提示词原文直接生成")
    res = generate_promo(src_image, copy["主标题"], copy["副标题"], copy["卖点标签"], out_path, product_title=title)
    res["copy"] = copy
    return res


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python image_gen.py <货品图> --auto <商品标题> [输出]")
        print("  或: python image_gen.py <货品图> <主标题> <副标题> <卖点标签> [输出]")
        sys.exit(1)
    src = sys.argv[1]
    if len(sys.argv) > 2 and sys.argv[2] == "--auto":
        title = sys.argv[3] if len(sys.argv) > 3 else ""
        out = sys.argv[4] if len(sys.argv) > 4 else None
        r = generate_for_product(src, title, out)
    else:
        t1 = sys.argv[2] if len(sys.argv) > 2 else "推广主图"
        t2 = sys.argv[3] if len(sys.argv) > 3 else ""
        tags = sys.argv[4] if len(sys.argv) > 4 else ""
        out = sys.argv[5] if len(sys.argv) > 5 else None
        r = generate_promo(src, t1, t2, tags, out)
    if r.get("ok"):
        print(f"\n✓ 出图 → {r['out_path']}")
    else:
        print(f"\n✗ 失败: {r.get('reason')}  {r.get('body') or r.get('raw') or ''}")
