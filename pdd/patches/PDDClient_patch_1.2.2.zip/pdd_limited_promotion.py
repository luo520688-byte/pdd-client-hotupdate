# -*- coding: utf-8 -*-
"""Create PDD limited-quantity promotions for selected published goods.

The script is isolated from activity-price comparison. It uses the selected
store profile, selects every SKU, calculates prices from live group prices,
verifies all filled values, and clicks Create only with ``--submit``.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except (AttributeError, Exception):
    pass

from playwright.async_api import Locator, Page, async_playwright

from pdd_publish import (
    PROFILE_DIR,
    _load_stores,
    _prepare_single_start_page,
    apply_window_mode,
    find_chrome,
)


CREATE_URL = (
    "https://mms.pinduoduo.com/tool/promotion/create"
    "?tool_full_channel=10921_77271"
)
ONE = Decimal("1")
PRICE_ENDING = Decimal("0.9")
DEFAULT_DISCOUNT_RATE = Decimal("0.90")


def normalize_discount_rate(value) -> Decimal:
    text = str(value).strip()
    is_fold_value = "折" in text
    try:
        rate = Decimal(text.replace("折", "").strip())
    except (InvalidOperation, AttributeError) as exc:
        raise ValueError(f"无效折扣：{value!r}") from exc
    if is_fold_value or rate > ONE:
        rate /= Decimal("10")
    if rate <= 0 or rate > ONE:
        raise ValueError(f"折扣必须大于0且不超过10折：{value!r}")
    return rate


def calculate_activity_price(
    group_price, discount_rate=DEFAULT_DISCOUNT_RATE
) -> Decimal:
    """Return the largest price ending in .9 within the discount ceiling."""
    try:
        original = Decimal(
            str(group_price).replace("¥", "").replace("￥", "").strip()
        )
    except (InvalidOperation, AttributeError) as exc:
        raise ValueError(f"无效拼单价：{group_price!r}") from exc
    if original <= 0:
        raise ValueError(f"拼单价必须大于0：{group_price!r}")
    rate = normalize_discount_rate(discount_rate)
    ceiling = original * rate
    if ceiling < PRICE_ENDING:
        raise ValueError(f"拼单价 {original} 折扣后不足0.9元")
    steps = (ceiling - PRICE_ENDING) // ONE
    result = (steps + PRICE_ENDING).quantize(Decimal("0.1"))
    if result > ceiling:
        raise ValueError(f"活动价计算越界：{original} -> {result}")
    return result


def normalize_goods_ids(value: str) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for token in re.split(r"[\s,，、]+", str(value or "")):
        goods_id = token.strip()
        if goods_id.isdigit() and goods_id not in seen:
            seen.add(goods_id)
            result.append(goods_id)
    return result


def is_create_success_url(value: str) -> bool:
    return "/kit/goods-price-management" in str(value or "")


def is_create_success_popup_text(value: str) -> bool:
    text = " ".join(str(value or "").split())
    return "您已创建店铺营销优惠" in text


def _profile_for_store(store: str) -> Path:
    stores = _load_stores()
    matched = store if store in stores else next(
        (name for name in stores if store in name or name in store), None
    )
    if not matched:
        raise ValueError(f"店铺「{store}」没有登录 profile")
    profile = PROFILE_DIR / stores[matched]
    if not profile.exists():
        raise ValueError(f"店铺「{matched}」的登录 profile 不存在")
    return profile


class RunLog:
    def __init__(self, path: str = ""):
        self.path = Path(path) if path else None

    def write(self, message: str) -> None:
        line = str(message)
        print(line, flush=True)
        if not self.path:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        except Exception:
            pass


async def _visible(locator: Locator) -> list[Locator]:
    result: list[Locator] = []
    try:
        count = await locator.count()
    except Exception:
        return result
    for index in range(count):
        item = locator.nth(index)
        try:
            if await item.is_visible():
                result.append(item)
        except Exception:
            continue
    return result


async def _click_text(
    page: Page,
    text: str,
    *,
    exact: bool = True,
    root: Locator | None = None,
    timeout_ms: int = 10000,
    no_wait_after: bool = False,
) -> bool:
    scope = root if root is not None else page
    deadline = asyncio.get_running_loop().time() + timeout_ms / 1000
    while asyncio.get_running_loop().time() < deadline:
        candidates = []
        for selector in ("button", "[role=button]", "label", "a", "span", "div"):
            try:
                candidates.extend(
                    await _visible(scope.locator(selector).filter(has_text=text))
                )
            except Exception:
                continue
        ranked: list[tuple[int, int, Locator]] = []
        for candidate in candidates:
            try:
                current = " ".join((await candidate.inner_text()).split())
                if exact and current != text:
                    continue
                if not exact and text not in current:
                    continue
                tag = await candidate.evaluate("(el) => el.tagName.toLowerCase()")
                priority = {
                    "button": 0,
                    "label": 1,
                    "a": 2,
                    "span": 3,
                    "div": 4,
                }.get(tag, 5)
                ranked.append((priority, len(current), candidate))
            except Exception:
                continue
        for _priority, _length, candidate in sorted(
            ranked, key=lambda item: (item[0], item[1])
        ):
            try:
                await candidate.click(
                    timeout=1500, no_wait_after=no_wait_after)
                return True
            except Exception:
                continue
        await asyncio.sleep(0.25)
    return False


async def _latest_dialog(page: Page, required_text: str) -> Locator | None:
    matches: list[Locator] = []
    for selector in (
        '[role="dialog"]',
        ".ant-modal",
        ".beast-core-modal",
        ".PP_popover",
    ):
        try:
            matches.extend(
                await _visible(page.locator(selector).filter(has_text=required_text))
            )
        except Exception:
            continue
    if matches:
        return matches[-1]
    # Newer MMS pages may render a fixed-position modal without role=dialog
    # or a stable modal class. Use the smallest visible container that has the
    # requested title and actionable buttons.
    ranked: list[tuple[int, Locator]] = []
    try:
        candidates = await _visible(
            page.locator("div").filter(has_text=required_text)
        )
    except Exception:
        candidates = []
    for candidate in candidates:
        try:
            body = " ".join((await candidate.inner_text()).split())
            buttons = await candidate.locator(
                'button,[role="button"]'
            ).count()
            controls = await candidate.locator(
                'input,[role="checkbox"],[class*="checkbox"]'
            ).count()
            if required_text in body and buttons >= 2 and controls:
                ranked.append((len(body), candidate))
        except Exception:
            continue

    return sorted(ranked, key=lambda item: item[0])[0][1] if ranked else None

async def _click_checkbox(container: Locator) -> bool:
    for selector in (
        'input[type="checkbox"]',
        '[role="checkbox"]',
        ".ant-checkbox",
        '[class*="checkbox"]',
    ):
        for checkbox in await _visible(container.locator(selector)):
            try:
                if await checkbox.get_attribute("aria-checked") == "true":
                    return True
                try:
                    if await checkbox.is_checked():
                        return True
                except Exception:
                    pass
                await checkbox.click(timeout=2000, force=True)
                return True
            except Exception:
                continue
    return False


async def _select_auto_create(page: Page) -> None:
    if not await _click_text(
        page, "活动结束后自动创建", exact=False, timeout_ms=12000
    ):
        raise RuntimeError("未找到“活动结束后自动创建”选项")
    await asyncio.sleep(0.5)


async def _open_goods_dialog(page: Page) -> Locator:
    if not await _click_text(page, "选择商品", exact=True, timeout_ms=12000):
        raise RuntimeError("未找到“选择商品”按钮")
    for _ in range(40):
        dialog = await _latest_dialog(page, "选择商品")
        if dialog is not None:
            return dialog
        await asyncio.sleep(0.25)
    raise RuntimeError("选择商品弹窗未出现")


async def _find_search_input(page: Page, dialog: Locator) -> Locator | None:
    for selector in (
        'input[placeholder*="输入商品名称或ID"]',
        'input[placeholder*="商品名称或ID"]',
        'input[placeholder*="多个ID"]',
        'input[placeholder*="商品ID"]',
        'input[placeholder*="商品名称"]',
    ):
        visible = await _visible(page.locator(selector))
        if visible:
            return visible[0]
    # Last resort: only accept a visible text/search input inside the detected
    # modal. Never fall back to checkbox/radio controls.
    visible = await _visible(dialog.locator("input"))
    ranked = []
    for item in visible:
        try:
            input_type = str(await item.get_attribute("type") or "text").lower()
            if input_type not in ("text", "search"):
                continue
            placeholder = str(await item.get_attribute("placeholder") or "")
            score = (
                0 if "ID" in placeholder and "商品" in placeholder
                else 1 if "ID" in placeholder
                else 2
            )
            ranked.append((score, len(placeholder), item))
        except Exception:
            continue
    if ranked:
        return sorted(ranked, key=lambda value: (value[0], value[1]))[0][2]
    return None


async def _row_for_text(root: Locator, text: str) -> Locator | None:
    for selector in ("tr", '[role="row"]'):
        matches = await _visible(root.locator(selector).filter(has_text=text))
        if matches:
            ranked = []
            for match in matches:
                try:
                    ranked.append((len(await match.inner_text()), match))
                except Exception:
                    continue
            if ranked:
                return sorted(ranked, key=lambda item: item[0])[0][1]
    candidates = await _visible(root.locator("div").filter(has_text=text))
    ranked = []
    for candidate in candidates:
        try:
            body = " ".join((await candidate.inner_text()).split())
            has_checkbox = await candidate.locator(
                'input[type="checkbox"],[role="checkbox"],[class*="checkbox"]'
            ).count()
            if text in body and has_checkbox:
                ranked.append((len(body), candidate))
        except Exception:
            continue
    return sorted(ranked, key=lambda item: item[0])[0][1] if ranked else None


async def _select_goods(page: Page, goods_ids: list[str], log: RunLog) -> None:
    dialog = await _open_goods_dialog(page)
    search = await _find_search_input(page, dialog)
    if search is None:
        raise RuntimeError("选择商品弹窗内未找到ID搜索框")
    query_text = ",".join(goods_ids)
    await search.click()
    await search.fill(query_text)
    await asyncio.sleep(0.4)
    readback = (await search.input_value()).strip()
    if readback != query_text:
        await search.click()
        await search.press("Control+A")
        await search.press_sequentially(query_text, delay=35)
        await asyncio.sleep(0.4)
        readback = (await search.input_value()).strip()
    if readback != query_text:
        raise RuntimeError(
            f"商品ID输入回读失败：期望{query_text}，实际{readback!r}"
        )
    log.write(f"已输入商品ID：{query_text}")
    try:
        await search.press("Enter")
    except Exception as exc:
        raise RuntimeError("商品ID已输入，但回车查询失败") from exc
    log.write("已在商品ID搜索框按下回车查询")
    await asyncio.sleep(0.8)

    for goods_id in goods_ids:
        row = None
        for _ in range(40):
            row = await _row_for_text(page, goods_id)
            if row is not None:
                break
            await asyncio.sleep(0.25)
        if row is None:
            raise RuntimeError(f"查询结果未找到商品 {goods_id}")
        row_text = " ".join((await row.inner_text()).split())
        if goods_id not in row_text:
            raise RuntimeError(f"商品 {goods_id} 查询结果无法精确核对")
        if not await _click_checkbox(row):
            raise RuntimeError(f"商品 {goods_id} 查询结果无法勾选")
        log.write(f"已选择商品 {goods_id}")

    if not await _click_text(
        page, "确认选择", exact=True, timeout_ms=7000
    ):
        raise RuntimeError("选择商品弹窗未找到“确认选择”")
    await asyncio.sleep(1.5)


async def _product_row(page: Page, goods_id: str) -> Locator | None:
    for selector in ("tr", '[role="row"]'):
        matches = await _visible(page.locator(selector).filter(has_text=goods_id))
        if matches:
            ranked = []
            for match in matches:
                try:
                    ranked.append((len(await match.inner_text()), match))
                except Exception:
                    continue
            if ranked:
                return sorted(ranked, key=lambda item: item[0])[0][1]
    candidates = await _visible(page.locator("div").filter(has_text=goods_id))
    ranked = []
    for candidate in candidates:
        try:
            body = " ".join((await candidate.inner_text()).split())
            if goods_id in body and ("商品级" in body or "规格级" in body):
                ranked.append((len(body), candidate))
        except Exception:
            continue
    return sorted(ranked, key=lambda item: item[0])[0][1] if ranked else None


async def _choose_all_specs(page: Page, goods_id: str, log: RunLog) -> None:
    row = None
    for _ in range(40):
        row = await _product_row(page, goods_id)
        if row is not None:
            break
        await asyncio.sleep(0.25)
    if row is None:
        raise RuntimeError(f"报名页未找到已选商品 {goods_id}")

    try:
        await row.scroll_into_view_if_needed(timeout=5000)
        await row.evaluate(
            "(element) => element.scrollIntoView("
            "{block: 'center', inline: 'nearest'})")
    except Exception:
        await page.mouse.wheel(0, 600)
    await asyncio.sleep(0.5)
    product_level_point = None
    clicked_product_level = await _click_text(
        page, "商品级", exact=True, root=row, timeout_ms=5000
    )
    if not clicked_product_level:
        product_level_point = await page.evaluate(
            """({goodsId, label}) => {
                const visible = el => {
                    const r = el.getBoundingClientRect();
                    const s = getComputedStyle(el);
                    return r.width > 8 && r.height > 8
                        && s.display !== 'none' && s.visibility !== 'hidden';
                };
                const textOf = el => {
                    if (el instanceof HTMLInputElement) return (el.value || '').trim();
                    return (el.innerText || el.textContent || '').trim();
                };
                const anchors = Array.from(document.querySelectorAll('body *'))
                    .filter(el => visible(el) && textOf(el).includes(goodsId))
                    .sort((a,b) => textOf(a).length-textOf(b).length);
                if (!anchors.length) return null;
                const ar = anchors[0].getBoundingClientRect();
                const candidates = Array.from(document.querySelectorAll(
                    'input,[role="combobox"],button,[role="button"],span,div'
                )).filter(el => visible(el) && textOf(el) === label);
                if (!candidates.length) return null;
                candidates.sort((a,b) => {
                    const x = a.getBoundingClientRect();
                    const y = b.getBoundingClientRect();
                    const ax = Math.abs((x.top+x.bottom)/2-(ar.top+ar.bottom)/2)
                        + (x.left < ar.left ? 1000 : 0);
                    const by = Math.abs((y.top+y.bottom)/2-(ar.top+ar.bottom)/2)
                        + (y.left < ar.left ? 1000 : 0);
                    return ax-by;
                });
                const r = candidates[0].getBoundingClientRect();
                return {x:(r.left+r.right)/2, y:(r.top+r.bottom)/2};
            }""",
            {"goodsId": goods_id, "label": "商品级"},
        )
        if product_level_point:
            await page.mouse.click(
                product_level_point["x"], product_level_point["y"])
            clicked_product_level = True
    if not clicked_product_level:
        if "规格级" in " ".join((await row.inner_text()).split()):
            log.write(f"商品 {goods_id} 已是规格级")
            return
        raise RuntimeError(f"商品 {goods_id} 未找到“商品级”下拉框")
    await asyncio.sleep(0.4)
    selected_spec_level = await _click_text(
        page, "规格级", exact=True, timeout_ms=3000
    )
    if not selected_spec_level:
        option_point = await page.evaluate(
            """label => {
                const visible = el => {
                    const r = el.getBoundingClientRect();
                    const s = getComputedStyle(el);
                    return r.width > 8 && r.height > 8
                        && s.display !== 'none' && s.visibility !== 'hidden';
                };
                const textOf = el => el instanceof HTMLInputElement
                    ? (el.value || '').trim()
                    : (el.innerText || el.textContent || '').trim();
                const hits = Array.from(document.querySelectorAll(
                    'input,[role="option"],li,span,div'
                )).filter(el => visible(el) && textOf(el) === label);
                if (!hits.length) return null;
                const r = hits[hits.length-1].getBoundingClientRect();
                return {x:(r.left+r.right)/2, y:(r.top+r.bottom)/2};
            }""",
            "规格级",
        )
        if option_point:
            await page.mouse.click(option_point["x"], option_point["y"])
            selected_spec_level = True
    if not selected_spec_level:
        try:
            await page.keyboard.press("ArrowDown")
            await asyncio.sleep(0.2)
            await page.keyboard.press("Enter")
            await asyncio.sleep(0.5)
            selected_spec_level = True
            log.write(f"商品 {goods_id} 已通过键盘切换规格级")
        except Exception:
            pass
    if not selected_spec_level:
        raise RuntimeError(f"商品 {goods_id} 无法选择“规格级”")

    dialog = None
    for _ in range(30):
        dialog = await _latest_dialog(page, "选择规格")
        if dialog is not None:
            break
        await asyncio.sleep(0.25)
    if dialog is None:
        async def _reopen_level_control() -> bool:
            retry_row = await _product_row(page, goods_id)
            if retry_row is not None:
                for current_label in ("商品级", "规格级"):
                    if await _click_text(
                        page, current_label, exact=True, root=retry_row,
                        timeout_ms=1200,
                    ):
                        return True
            if product_level_point:
                await page.mouse.click(
                    product_level_point["x"], product_level_point["y"])
                return True
            return False

        if await _reopen_level_control():
            await asyncio.sleep(0.2)
            await page.keyboard.press("Home")
            await page.keyboard.press("Enter")
            await asyncio.sleep(0.3)
            if await _reopen_level_control():
                await asyncio.sleep(0.2)
                await page.keyboard.press("End")
                await page.keyboard.press("Enter")
                log.write(f"商品 {goods_id} 重试切换规格级")
                for _ in range(30):
                    dialog = await _latest_dialog(page, "选择规格")
                    if dialog is not None:
                        break
                    await asyncio.sleep(0.25)
    if dialog is None:
        raise RuntimeError(f"商品 {goods_id} 的选择规格弹窗未出现")

    labels = await _visible(dialog.get_by_text(re.compile(r"全选全部规格")))
    selected_all = False
    if labels:
        control = labels[-1]
        ancestor = control
        for _ in range(4):
            native = ancestor.locator('input[type="checkbox"]')
            if await native.count():
                checkbox = native.first
                try:
                    if not await checkbox.is_checked():
                        await checkbox.check(force=True)
                    selected_all = True
                    break
                except Exception:
                    pass
            ancestor = ancestor.locator("xpath=..")
        if not selected_all:
            try:
                await control.click(timeout=2000)
                selected_all = True
            except Exception:
                pass
    if not selected_all and not await _click_checkbox(dialog):
        raise RuntimeError(f"商品 {goods_id} 未找到全选规格")

    if not await _click_text(
        page, "确认选择", exact=True, timeout_ms=5000
    ):
        raise RuntimeError(f"商品 {goods_id} 规格弹窗无法确认")
    await asyncio.sleep(0.8)
    log.write(f"商品 {goods_id} 已切换规格级并全选规格")


async def _switch_to_activity_price(page: Page) -> None:
    for current in ("折扣(折)", "立减(元)"):
        if await _click_text(page, current, exact=True, timeout_ms=2500):
            break
    else:
        body = " ".join((await page.locator("body").inner_text()).split())
        if "活动价(元)" in body:
            return
        raise RuntimeError("未找到价格类型下拉框")
    if not await _click_text(page, "活动价(元)", exact=True, timeout_ms=5000):
        raise RuntimeError("价格类型下拉框未找到“活动价(元)”")
    await asyncio.sleep(0.8)


async def _discover_sku_price_inputs(page: Page, goods_ids: list[str]) -> list[dict]:
    return await page.evaluate(
        """goodsIds => {
            const visible = el => {
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 8 && r.height > 8 && s.visibility !== 'hidden'
                    && s.display !== 'none';
            };
            const priceRe = /拼单价\\s*[:：]?\\s*[￥¥]?\\s*(\\d+(?:\\.\\d+)?)/;
            const nodes = Array.from(document.querySelectorAll('body *')).filter(el => {
                if (!visible(el)) return false;
                const text = (el.innerText || '').trim();
                if (!priceRe.test(text)) return false;
                return !Array.from(el.children).some(child =>
                    visible(child) && priceRe.test((child.innerText || '').trim()));
            });
            const inputs = Array.from(document.querySelectorAll('input')).filter(el => {
                const type = (el.type || 'text').toLowerCase();
                return visible(el) && !el.disabled
                    && !['checkbox','radio','hidden','file'].includes(type);
            });
            const used = new Set();
            const rows = [];
            for (const node of nodes.sort((a,b) =>
                    a.getBoundingClientRect().top - b.getBoundingClientRect().top)) {
                const text = (node.innerText || '').trim();
                const match = text.match(priceRe);
                if (!match) continue;
                let owner = node;
                let goodsId = '';
                while (owner && owner !== document.body) {
                    const ownerText = owner.innerText || '';
                    goodsId = goodsIds.find(id => ownerText.includes(id)) || '';
                    if (goodsId) break;
                    owner = owner.parentElement;
                }
                const nr = node.getBoundingClientRect();
                const candidates = inputs.map(input => {
                    const r = input.getBoundingClientRect();
                    const vertical = Math.abs(
                        (r.top+r.bottom)/2 - (nr.top+nr.bottom)/2);
                    const horizontal = r.left - nr.right;
                    return {input, vertical, horizontal};
                }).filter(x => !used.has(x.input) && x.horizontal > -15
                    && x.horizontal < 700 && x.vertical < Math.max(42, nr.height));
                candidates.sort((a,b) =>
                    a.vertical - b.vertical || a.horizontal - b.horizontal);
                if (!candidates.length) continue;
                const input = candidates[0].input;
                used.add(input);
                const key = `limited-price-${rows.length}`;
                input.setAttribute('data-codex-limited-price-key', key);
                rows.push({
                    key,
                    goods_id: goodsId,
                    group_price: match[1],
                    sku_text: text.replace(/\\s+/g, ' ').slice(0, 240)
                });
            }
            return rows;
        }""",
        goods_ids,
    )


async def _fill_activity_prices(page: Page, goods_ids: list[str], discount_rate, log: RunLog) -> list[dict]:
    rows = await _discover_sku_price_inputs(page, goods_ids)
    if not rows:
        raise RuntimeError("未识别到任何SKU拼单价及活动价输入框")
    results = []
    for row in rows:
        group_price = Decimal(str(row["group_price"]))
        activity_price = calculate_activity_price(group_price, discount_rate)
        value = f"{activity_price:.1f}"
        locator = page.locator(
            f'input[data-codex-limited-price-key="{row["key"]}"]'
        )
        if await locator.count() != 1:
            raise RuntimeError(f"SKU活动价输入框定位不唯一：{row['sku_text']}")
        await locator.fill(value)
        await locator.press("Tab")
        readback = (await locator.input_value()).strip()
        try:
            actual = Decimal(readback)
        except InvalidOperation as exc:
            raise RuntimeError(
                f"SKU活动价回读失败：期望{value}，实际{readback!r}"
            ) from exc
        if actual != activity_price:
            raise RuntimeError(
                f"SKU活动价回读不一致：期望{value}，实际{readback}"
            )
        if activity_price > group_price * normalize_discount_rate(discount_rate):
            raise RuntimeError(
                f"SKU活动价超过折扣上限：{group_price} -> {activity_price}"
            )
        result = {
            "goods_id": row.get("goods_id") or "",
            "sku_text": row["sku_text"],
            "group_price": f"{group_price:.2f}",
            "activity_price": value,
        }
        results.append(result)
        log.write(
            f"SKU价格：拼单价 {result['group_price']} -> 活动价 {value}"
        )
    return results


def missing_activity_prices(text: str, expected_prices) -> list[str]:
    """Return expected prices that are not present in the page text."""
    counts: dict[Decimal, int] = {}
    for token in re.findall(r"(?<!\d)(\d+(?:\.\d{1,2})?)(?!\d)", text or ""):
        try:
            value = Decimal(token).quantize(Decimal("0.01"))
        except InvalidOperation:
            continue
        counts[value] = counts.get(value, 0) + 1
    missing = []
    for expected in expected_prices:
        value = Decimal(str(expected)).quantize(Decimal("0.01"))
        if counts.get(value, 0):
            counts[value] -= 1
        else:
            missing.append(f"{value:.2f}")
    return missing


async def _verify_price_management(
    page: Page,
    goods_ids: list[str],
    prices: list[dict],
    log: RunLog,
) -> tuple[bool, str, list[dict]]:
    verified = []
    for goods_id in goods_ids:
        expected = [
            item["activity_price"] for item in prices
            if item.get("goods_id") == goods_id
        ]
        if not expected:
            return False, f"商品 {goods_id} 没有可核对的活动价记录", verified
        search = await _find_search_input(page, page)
        if search is None:
            return False, "商品价格管理页未找到商品ID查询框", verified
        await search.click()
        await search.fill(goods_id)
        await search.press("Enter")
        row = None
        for _ in range(40):
            row = await _row_for_text(page, goods_id)
            if row is not None:
                break
            await asyncio.sleep(0.25)
        if row is None:
            return False, f"商品价格管理页未查询到商品 {goods_id}", verified
        for _ in range(3):
            expanded = await _click_text(
                page, "展开更多规格", exact=False, timeout_ms=1200)
            if not expanded:
                break
            await asyncio.sleep(0.5)
        await asyncio.sleep(0.4)
        result_text = " ".join(
            (await page.locator("body").inner_text()).split())
        missing = missing_activity_prices(result_text, expected)
        expected_text = [f"{Decimal(str(value)):.2f}" for value in expected]
        if missing:
            return (
                False,
                f"商品 {goods_id} 活动价核对不一致："
                f"预期 {','.join(expected_text)}；页面缺少 {','.join(missing)}",
                verified,
            )
        item = {
            "goods_id": goods_id,
            "expected_activity_prices": expected_text,
            "verified": True,
        }
        verified.append(item)
        log.write(
            f"商品价格管理页核对通过：{goods_id} / "
            f"活动价 {','.join(expected_text)}")
    return True, "", verified



async def _click_create_and_verify(
    page: Page,
    goods_ids: list[str],
    prices: list[dict],
    log: RunLog,
) -> tuple[bool, str, list[dict]]:
    before_url = page.url
    if not await _click_text(
        page, "创建", exact=True, timeout_ms=7000, no_wait_after=True
    ):
        return False, "未找到“创建”按钮", []
    log.write("已点击创建，等待PDD创建成功弹窗")

    failure_markers = (
        "创建失败",
        "报名失败",
        "请检查",
        "不符合",
        "不可报名",
        "活动冲突",
    )
    saw_navigation = False
    for _ in range(120):
        await asyncio.sleep(0.25)
        open_pages = [
            candidate for candidate in page.context.pages
            if not candidate.is_closed()
        ]
        for candidate in open_pages:
            try:
                popup_matches = candidate.get_by_text(
                    "您已创建店铺营销优惠", exact=False)
                for popup_text in await _visible(popup_matches):
                    text = await popup_text.inner_text()
                    if not is_create_success_popup_text(text):
                        continue
                    log.write("已识别PDD创建成功弹窗，按限时限量报名成功处理")
                    try:
                        await candidate.keyboard.press("Escape")
                    except Exception:
                        pass
                    return True, "", []
            except Exception:
                pass

            try:
                url = candidate.url or ""
            except Exception:
                continue
            if is_create_success_url(url):
                log.write(
                    "创建后已跳转商品价格管理，"
                    "按限时限量报名成功处理")
                return True, "", []

            try:
                success_matches = candidate.get_by_text(
                    re.compile(r"\d+\s*个限时限量活动创建成功"))
                if await _visible(success_matches):
                    log.write("页面确认限时限量活动创建成功")
                    return True, "", []
            except Exception:
                pass

            alerts = []
            for selector in (
                '[role="alert"]',
                '[class*="toast"]',
                '[class*="message"]',
                '[class*="notice"]',
            ):
                for item in await _visible(candidate.locator(selector)):
                    try:
                        alerts.append(
                            " ".join((await item.inner_text()).split()))
                    except Exception:
                        continue
            alert_text = "；".join(item for item in alerts if item)
            if alert_text and any(
                marker in alert_text for marker in failure_markers
            ):
                return False, alert_text[-500:], []
            if candidate is page and before_url != url:
                saw_navigation = True

    reason = (
        "页面已跳转，但未识别到PDD创建成功弹窗"
        if saw_navigation
        else "点击创建后未识别到PDD创建成功弹窗"
    )
    return False, reason, []


async def create_limited_promotion(args) -> dict:
    goods_ids = normalize_goods_ids(args.goods_ids)
    result = {
        "ok": False,
        "stage": "precheck",
        "reason": "",
        "store": args.store,
        "goods_ids": goods_ids,
        "sku_prices": [],
    }
    log = RunLog(args.log_path)
    if not goods_ids:
        result["reason"] = "没有有效 goods_id"
        return result
    if len(goods_ids) > 30:
        result["reason"] = "单批最多30个商品ID"
        return result

    discount_rate = normalize_discount_rate(args.discount)
    profile = _profile_for_store(args.store)
    show_browser = bool(args.show_browser)
    window_args = (
        ["--start-maximized"]
        if show_browser
        else ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    )

    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            executable_path=find_chrome(),
            headless=False,
            args=window_args + ["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport=None,
        )
        try:
            page = await _prepare_single_start_page(context)
            await apply_window_mode(context, page, show_browser)
            result["stage"] = "open"
            log.write(
                f"打开限时限量报名页：{args.store} / {len(goods_ids)}个商品"
            )
            await page.goto(
                CREATE_URL, wait_until="domcontentloaded", timeout=30000
            )
            await asyncio.sleep(3)
            if any(
                item in (page.url or "").lower()
                for item in ("login", "passport", "sso")
            ):
                result["reason"] = "店铺登录已失效"
                return result

            result["stage"] = "settings"
            await _select_auto_create(page)
            result["stage"] = "goods"
            await _select_goods(page, goods_ids, log)

            result["stage"] = "specs"
            for goods_id in goods_ids:
                await _choose_all_specs(page, goods_id, log)

            result["stage"] = "prices"
            await _switch_to_activity_price(page)
            prices = await _fill_activity_prices(
                page, goods_ids, discount_rate, log)
            result["sku_prices"] = prices

            if not args.submit:
                result.update(
                    ok=True,
                    stage="ready_no_submit",
                    reason="全部价格回读通过，未传--submit所以未创建",
                )
                return result

            result["stage"] = "create"
            ok, reason, _verified = await _click_create_and_verify(
                page, goods_ids, prices, log)
            if not ok:
                result["reason"] = reason
                return result
            result.update(ok=True, stage="complete", reason="")
            log.write(
                f"限时限量创建成功：{args.store} / {len(goods_ids)}个商品 / "
                f"{len(prices)}个SKU"
            )
            return result
        finally:
            if args.auto_close:
                for opened_page in list(context.pages):
                    try:
                        await asyncio.wait_for(
                            opened_page.close(run_before_unload=False), timeout=3
                        )
                    except Exception:
                        pass
                try:
                    await asyncio.wait_for(context.close(), timeout=8)
                    log.write("限时限量浏览器已自动关闭")
                except Exception as exc:
                    log.write(
                        f"浏览器上下文关闭超时，尝试强制关闭：{exc!r}")
                    browser = context.browser
                    if browser is not None:
                        try:
                            if browser.is_connected():
                                await asyncio.wait_for(
                                    browser.close(), timeout=5)
                            log.write("限时限量浏览器已强制关闭")
                        except Exception as browser_exc:
                            log.write(
                                "限时限量浏览器强制关闭失败："
                                f"{browser_exc!r}")


def _write_output(path: str, result: dict) -> None:
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if path:
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
    print("[LIMITED_PROMOTION_RESULT] " + json.dumps(result, ensure_ascii=False))


def main() -> int:
    parser = argparse.ArgumentParser(description="PDD 已发布商品报名限时限量购")
    parser.add_argument("--store", required=True)
    parser.add_argument("--goods-ids", required=True)
    parser.add_argument("--output-json", default="")
    parser.add_argument("--log-path", default="")
    parser.add_argument("--discount", default="9")
    parser.add_argument("--submit", action="store_true")
    parser.add_argument("--show-browser", action="store_true")
    parser.add_argument("--auto-close", action="store_true")
    args = parser.parse_args()
    try:
        result = asyncio.run(create_limited_promotion(args))
    except Exception as exc:
        result = {
            "ok": False,
            "stage": "exception",
            "reason": repr(exc),
            "store": args.store,
            "goods_ids": normalize_goods_ids(args.goods_ids),
            "sku_prices": [],
        }
    _write_output(args.output_json, result)
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
