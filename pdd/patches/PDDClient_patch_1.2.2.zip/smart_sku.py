# -*- coding: utf-8 -*-
"""智能SKU:发布同款进表单后,云端DeepSeek判每行份数能不能确定。
- 都能确定(keepable) → 保留同款SKU,走现有 fill_prices 填价。
- 有判不准 → 清空规格重置 → 照1688真料(rec['sku_material'])重建「款式」维SKU
            (多色=各色;单规格=1瓶/2瓶/3瓶)→ 同一个 fill_prices 按名字读份数填价。
机制全部来自已验证脚本(build_sku.py 云端判定 + build2layer_custom.py 清空重建)。
被 pdd_publish.process_single_candidate 在 --smart-sku 时调用。
"""
import asyncio, json, math, os, re, urllib.request
from pathlib import Path

LLM_CFG_PATH = r"D:/files/data/pdd/llm_api.json"
LIB = r"D:/files/data/pdd/product_library.json"
JOURNAL_PATH = r"D:/files/data/pdd/sku_journal.json"


def journal_append(entry: dict) -> int:
    """把"云端判不准"的SKU案例写进日记,积累经验(不管上架成没成)。返回当前总条数。
    供人/后续会话回看:积累几条后读取,拿不准的问用户。"""
    import time as _t
    e = dict(entry); e.setdefault("time", _t.strftime("%Y-%m-%d %H:%M:%S"))
    try:
        data = json.load(open(JOURNAL_PATH, encoding="utf-8")) if os.path.exists(JOURNAL_PATH) else []
    except Exception:
        data = []
    data.append(e)
    try:
        json.dump(data, open(JOURNAL_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception as ex:
        print(f"[SKU日记] 写失败: {ex}")
    print(f"[SKU日记] 已记一条(共{len(data)}条): {e.get('title','')[:20]} | {e.get('reason','')[:30]}")
    return len(data)

# ── 云端判定关(DeepSeek,来自 build_sku.py,已验证:眼影留/睫毛弃/防蚊6-3-2) ──
GATE_SYS = (
    "你是电商SKU份数判定助手。给你一个商品的所有SKU规格名(可能多层,已拼好)。\n"
    "判断每个SKU到底是“几份同样的东西”(units):\n"
    "1) 同类不同颜色/口味/色号的组合,按里面同类物品的个数算份数。\n"
    "2) 赠品搭礼(如+冻膜一小包、送小样)忽略,不算份数。\n"
    "3) 只有当 SKU 搭配了“不同种类的东西”(如+配套工具、不同排数/型号/容量的别的货、说不清是什么)时,该行 sure=false。\n"
    "4) combo:该SKU是不是【主产品 + 卖家防比价搭配/赠品】的组合(主产品后面又 + 了精华液/漱口水/护手霜/冻膜/小样/工具/手持镜/清洁棒/粉扑等【别的种类的东西】)。"
    "是→combo=true(这种要剔掉搭配、只留主产品);若只是同一主产品的数量/颜色/口味/容量不同(没搭别的种类)→combo=false。\n"
    "逐行给 units(份数,整数)、sure(能不能确定份数)、combo(是否带防比价搭配)。"
    "只输出 JSON：{\"rows\":[{\"name\":..,\"units\":int,\"sure\":bool,\"combo\":bool}],\"reason\":\"一句话\"}。不要别的字。"
    "5) Always include count_only=true only when every SKU is the same main product with quantity-only differences (no color, scent, model, or style variant); otherwise false.\n"
)


def _load_cfg():
    return json.load(open(LLM_CFG_PATH, encoding="utf-8"))


# ── DeepSeek 直连 opener:不走系统/翻墙代理(VPN/clash 开着时系统代理会拦 api.deepseek.com,
#    同 image_gen 调 mzlone 用 trust_env=False 的道理)。ProxyHandler({}) = 禁用所有代理。──
_NOPROXY_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _ds_content(messages, temperature=0, timeout=60):
    """调云端 DeepSeek /chat/completions(直连不走代理),返回 message content 原文(strip 后,未做 ``` 处理)。
    异常抛给调用方兜底(各 caller 已有 try/except 或回落)。"""
    cfg = _load_cfg()
    body = json.dumps({"model": cfg.get("model", "deepseek-chat"),
                       "temperature": temperature, "messages": messages}).encode()
    req = urllib.request.Request(
        cfg.get("base_url", "https://api.deepseek.com").rstrip("/") + "/chat/completions",
        data=body, headers={"Authorization": "Bearer " + cfg["key"], "Content-Type": "application/json"})
    return json.loads(_NOPROXY_OPENER.open(req, timeout=timeout).read())["choices"][0]["message"]["content"].strip()


def llm_gate(fullnames, title=""):
    """调云端DeepSeek判份数。返回 {rows:[{name,units,sure}], reason}。异常抛给调用方兜底。"""
    txt = _ds_content([
        {"role": "system", "content": GATE_SYS},
        {"role": "user", "content": "商品标题：%s\nSKU：\n%s" % (title, "\n".join("- " + n for n in fullnames))}], temperature=0)
    if txt.startswith("```"):
        txt = txt.strip("`"); txt = txt[txt.find("{"):txt.rfind("}") + 1]
    return json.loads(txt)


# ── 云端SKU文案设计:给每个要建的SKU起营销名 + 给份数(份数给定价用,不靠从名字猜) ──
DESIGN_SYS = (
    "你给拼多多SKU加文案。**铁律:产品本身的颜色/色号/口味/款式/品名原样保留,一个字都不准改、不准编造**,你只能在它基础上【加数量】和【加营销卖点】。\n"
    "两种情况:\n"
    "**所有SKU名都必须含真实数量+量词,让买家一眼知道买到几件;名里的数量必须和units字段一致**。\n"
    "1) 给了多个颜色/款式 → 每个一个SKU,units=1。name = 原颜色款式名(一字不改) + 数量量词(通常1支/1瓶/1盒,按产品选合适量词) + 【营销卖点】。\n"
    "   例:'01番茄红'→'01番茄红1支【持久不沾杯】';'裸米棕'→'裸米棕1支【自然卧蚕】';'花间酒'→'花间酒1瓶【高级显白】'。\n"
    "2) 只有单一规格(没给变体或只1个) → 设计 1份/2份/3份,units=1/2/3。name = 数量+量词(1瓶/2瓶/3瓶 等) + 【营销卖点】。\n"
    "   例:'1瓶【祛痘舒缓淡化痘印】'、'2瓶【清爽不油更划算】'、'3瓶【囤货装随用随取】'。\n"
    "**卖点必须紧扣这个商品本身的核心功效/特点(从商品标题和规格名里提取):美白沐浴露就突出美白亮肤淡斑、驱蚊液就突出驱蚊止痒、修护精油就突出修护柔顺,严禁写跟产品功能无关的空泛词**。\n"
    "卖点必须用【】括起来。name 6-18字,各不重复;除了【】别用 #＃+*等怪符号。\n"
    "只输出JSON:{\"skus\":[{\"name\":\"..\",\"units\":整数}]}。不要别的字。"
)


def design_custom_skus(variant_names: list, title: str = "") -> list:
    """云端给每个SKU起营销名+份数。variant_names=颜色/款式名列表(来自1688料或表单现有SKU)。
    返回 [{name,units}]。异常抛给调用方回落。"""
    vals = [v for v in (variant_names or []) if v]
    user = "商品标题：%s\n货源规格值(%d个)：\n%s" % (
        title, len(vals), ("\n".join("- " + v for v in vals) if len(vals) > 1 else "(单一规格,无变体→请设计1/2/3份装)"))
    txt = _ds_content([
        {"role": "system", "content": DESIGN_SYS}, {"role": "user", "content": user}], temperature=0.3)
    if txt.startswith("```"):
        txt = txt.strip("`"); txt = txt[txt.find("{"):txt.rfind("}") + 1]
    return json.loads(txt).get("skus") or []


# Activity SKU rewrite: names are rewritten while warehouse codes remain source-controlled.
ACTIVITY_SKU_REWRITE_SYS = (
    "Rewrite PDD SKU display names after the program removes known gift suffixes. "
    "HARD FORBIDDEN WORDS: \u7597\u7a0b, \u6cbb\u7597, \u7597\u6548, \u836f\u7528, \u533b\u7528, \u6cbb\u6108, \u6839\u6cbb, \u836f\u6548, \u6025\u6551, "
    "\u4f53\u9a8c\u88c5, \u8bd5\u7528\u88c5, \u5c0f\u6837, \u52a0\u91cf\u88c5, \u589e\u91cf\u88c5, \u5927\u5bb9\u91cf, \u8d85\u5927\u5bb9\u91cf, \u5468\u671f\u88c5. "
    "Before returning JSON, scan every main_name character by character; if any hard-forbidden word appears, rewrite that row before output. "
    "For each row, preserve every real capacity, quantity, color, shade number, scent, flavor, model, and style; "
    "never merge rows or invent a variant. Remove gifts, add-ons, freebie wording, and stale marketing copy. "
    "Use known_main_name as the primary display-name source. product_title may provide product-category context only; do not copy a long title or brand into main_name unless it already appears in known_main_name. "
    "Count every Chinese character, Latin letter, digit, space, and symbol as one character, and ensure len(main_name) is no greater than main_name_max. "
    "When retry feedback supplies previous_main_name_length and minimum_characters_to_remove, actually shorten the previous name by at least that many characters. "
    "main_name must contain one truthful 4-8 Chinese-character benefit, efficacy, or marketing point wrapped in "
    "\u3010\u3011, based only on product_title and the real SKU. Avoid superlatives, guaranteed outcomes, cures, or fabricated claims. "
    "Make the name conversion-oriented and give a concrete purchase reason, not a bland standalone four-character claim such as "
    "\u7d27\u81f4\u6297\u76b1, \u6ecb\u6da6\u4fee\u62a4, \u8865\u6c34\u4fdd\u6e7f, \u65b9\u4fbf\u5b9e\u7528, or \u54c1\u8d28\u4e4b\u9009. "
    "Combine at least two truthful dimensions when the source supports them: target need or usage scene plus product benefit. "
    "Preserve the exact quantity meaning. Natural equivalent wording is allowed: 1\u74f6 may become \u5355\u74f6, and 2\u74f6 or *2 may become \u53cc\u74f6; never change the count. "
    "Keep each SKU immediately understandable to a shopper, but vary truthful wording and word order naturally across rows instead of using one copied template. "
    "Never relabel a quantity as \u4f53\u9a8c\u88c5, \u8bd5\u7528\u88c5, "
    "\u5c0f\u6837, \u52a0\u91cf\u88c5, \u589e\u91cf\u88c5, \u5927\u5bb9\u91cf, or \u8d85\u5927\u5bb9\u91cf. These labels may falsely imply a sample or a different capacity. "
    "Never use medical or drug-like wording such as \u7597\u7a0b, \u6cbb\u7597, \u7597\u6548, \u836f\u7528, \u533b\u7528, \u6cbb\u6108, \u6839\u6cbb, \u836f\u6548, or \u6025\u6551. "
    "Do not include selected_gift_name in main_name and obey main_name_max. Every main_name in the same request must be unique. "
    "When two rows have the same real specification after gift removal, keep that specification truthful but use different truthful "
    "benefit, efficacy, or marketing points so the final names remain distinct; do not fabricate a specification just to distinguish them. "
    "When previous_main_name or previous_validation_error is present, the prior output failed validation, so correct that conflict and "
    "do not return the same invalid name again. When previous_forbidden_terms is present, none of those exact terms may appear again. "
    "Return every row_id exactly once as JSON only: "
    "{\"rows\":[{\"row_id\":\"0\",\"main_name\":\"real spec\\u3010marketing point\\u3011\"}]}."
)


def rewrite_activity_sku_rows(rows: list[dict], title: str = "", gift_library: list[dict] | None = None) -> list[dict]:
    """Rewrite display names without receiving warehouse-code content."""
    allowed_keys = {
        "row_id", "current_name", "known_main_name", "known_removed_name_gifts",
        "selected_gift_name", "main_name_max", "name_hard_max", "previous_main_name",
        "previous_main_name_length", "required_main_name_max", "minimum_characters_to_remove",
        "previous_validation_error", "previous_forbidden_terms",
    }
    payload = {
        "product_title": str(title or ""),
        "rows": [{key: value for key, value in (item or {}).items() if key in allowed_keys} for item in rows or []],
    }
    txt = _ds_content([
        {"role": "system", "content": ACTIVITY_SKU_REWRITE_SYS},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ], temperature=0.2)
    if txt.startswith("```"):
        txt = txt.strip("`"); txt = txt[txt.find("{"):txt.rfind("}") + 1]
    value = json.loads(txt)
    return value.get("rows") or [] if isinstance(value, dict) else []


ACTIVITY_SKU_NAME_TAIL_SYS = (
    "Classify only the supplied plus-delimited trailing PDD SKU display-name segments. "
    "For each row, decide how many consecutive segments from the RIGHT are gifts, add-ons, or comparison-avoidance bundles that must be removed. "
    "Examples such as cleanser, hand cream, facial mask, frozen mask, serum, mouthwash, samples, tools, and multiple consecutive gift segments are usually gifts. "
    "A real color, shade, scent, flavor, model, capacity, or main-product quantity combination is not a gift and must be preserved. "
    "Use product_title, current_sku_name, already removed gifts, and gift_aliases as evidence. Return 0 when uncertain. "
    "Never return more than len(tail_segments), and never classify a non-trailing gap. Return every row_id exactly once as JSON only: "
    "{\"rows\":[{\"row_id\":\"0\",\"unknown_name_gift_tail_count\":0}]} ."
)


def classify_activity_sku_name_tails(rows: list[dict], title: str = "", gift_library: list[dict] | None = None) -> list[dict]:
    """Classify ambiguous trailing display-name segments without receiving warehouse-code content."""
    allowed_keys = {
        "row_id", "tail_segments", "current_sku_name", "known_removed_name_gifts",
    }
    payload = {
        "product_title": str(title or ""),
        "gift_aliases": [
            {"name": str((item or {}).get("name") or ""), "spec_code": str((item or {}).get("spec_code") or "")}
            for item in gift_library or []
        ],
        "rows": [{key: value for key, value in (item or {}).items() if key in allowed_keys} for item in rows or []],
    }
    txt = _ds_content([
        {"role": "system", "content": ACTIVITY_SKU_NAME_TAIL_SYS},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ], temperature=0)
    if txt.startswith("```"):
        txt = txt.strip("`"); txt = txt[txt.find("{"):txt.rfind("}") + 1]
    value = json.loads(txt)
    return value.get("rows") or [] if isinstance(value, dict) else []


ACTIVITY_SKU_CODE_TAIL_SYS = (
    "Classify only the supplied plus-delimited trailing warehouse-code segments. The main warehouse-code prefix is intentionally hidden. "
    "For each row, decide how many consecutive segments from the RIGHT are gift/add-on codes. A real color, shade, scent, flavor, model, "
    "style, capacity, or quantity combination is not a gift. Use current_sku_name, known_main_name, removed name gifts, and gift aliases as evidence. "
    "Return 0 when uncertain. Never return more than len(tail_segments), never generate or rewrite code text, and never classify a non-trailing gap. "
    "Return every row_id exactly once as JSON only: "
    "{\"rows\":[{\"row_id\":\"0\",\"unknown_code_gift_tail_count\":0}]}."
)


def classify_activity_sku_code_tails(rows: list[dict], title: str = "", gift_library: list[dict] | None = None) -> list[dict]:
    """Classify ambiguous trailing code segments without exposing the main warehouse-code prefix."""
    allowed_keys = {
        "row_id", "tail_segments", "current_sku_name", "known_main_name",
        "known_removed_name_gifts", "known_removed_code_gifts",
    }
    payload = {
        "product_title": str(title or ""),
        "gift_aliases": [
            {"name": str((item or {}).get("name") or ""), "spec_code": str((item or {}).get("spec_code") or "")}
            for item in gift_library or []
        ],
        "rows": [{key: value for key, value in (item or {}).items() if key in allowed_keys} for item in rows or []],
    }
    txt = _ds_content([
        {"role": "system", "content": ACTIVITY_SKU_CODE_TAIL_SYS},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ], temperature=0)
    if txt.startswith("```"):
        txt = txt.strip("`"); txt = txt[txt.find("{"):txt.rfind("}") + 1]
    value = json.loads(txt)
    return value.get("rows") or [] if isinstance(value, dict) else []


# Cloud SKU rebuild used by the publish flow.
REBUILD_SYS = (
    "你是电商SKU整理+文案助手。请结合商品标题和每条原始SKU名,聪明判断真实售卖规格,再生成适合拼多多上架的SKU名称。\n"
    "原始SKU常包含【主产品 + 卖家防比价搭配/赠品】,搭配/赠品多在 + 之后,如 +精华液、+漱口水、+护手霜、+睡眠冻膜、+面膜N片、+冻膜、+小样、+工具、+手持镜、+清洁棒、+粉扑。\n"
    "处理步骤:\n"
    "1. 先为每条原始SKU归一化一个【真实SKU键】= 主产品 + 真实差异维度。真实差异维度包括编号/色号/色名/香味/口味/型号/容量/数量。\n"
    "2. 只删除防比价搭配/赠品/违禁词(赠/送/买一送一/送小样等)。如 +芦荟乳液、+爽肤水、+面霜、+洗面奶、+防晒霜、+芦荟胶、+粉扑、+小样、+工具 通常是搭配赠品,不进入真实SKU键。\n"
    "3. 如果 + 后面其实是真实香味/口味/色号/容量/数量,必须保留到真实SKU键,不能删除。\n"
    "4. 按真实SKU键合并:真实SKU键相同的多条原始SKU只输出1条;真实SKU键不同的必须各输出1条。\n"
    "5. ★两层SKU要合并理解:如果原始SKU里有单独的容量/净含量/规格维度(如 300g/瓶、100ml、大容量)和另一组款式/数量维度,容量是共同上下文,不要把它单独输出成SKU;要把容量与款式层的真实数量/差异组合成最终真实SKU键。\n"
    "   例:输入含 300g/瓶 + 多条 牛油果发膜*1瓶/2瓶+起泡网,应输出 300g*1瓶、300g*2瓶,不能输出单独的 300g。\n"
    "6. 无意义/异常占位(如 0膏0乳霜、仅起泡网1个、仅赠品工具)不是主产品SKU,除非它含有真实容量/数量/色号,否则不要单独输出。\n"
    "7. ★真实差异词必须原样保留在新name里:如 01#花间酒、02#浮光锦、乌木玫瑰、蔚蓝山海、100ml、300g、2瓶/2支。不能把花间酒改成番茄红,不能把乌木玫瑰改成奶茶棕。\n"
    "8. units=买家实得的主产品数量(整数)。1支/1瓶=1,2支/2瓶=2,买一送一按实得总数算;300g/瓶 只是容量时 units=1。\n"
    "9. 结合商品标题写一个贴合商品的【】卖点:撕拉面膜/鼻膜写去黑头、清洁粉刺、深层清洁、收缩毛孔、保湿清爽;发膜/护发素写修护干枯毛躁、柔顺护发、改善烫染受损、持久留香;美甲猫眼胶写玻璃猫眼、磁吸流光、显手白、清透氛围;香水写留香、清新、木质、淡香。不要写无关功效。\n"
    "10. 同一组SKU的【】卖点要尽量差异化,不要每条都用同一句。尤其色号/香味/诗意款名,真实词必须保留在前面,但卖点可以结合该词的意境做自然联想:花间酒→微醺花香/氛围感,浮光锦→流光锦缎/闪耀,乌木玫瑰→冷调玫瑰/高级,屋檐雨→清冷雨雾/通透,南法松露→复古棕调/显手白。\n"
    "11. 差异化只写在【】卖点里,不能改真实识别词本身;不要为了差异化编造新的色号/香味/容量/数量。\n"
    "12. 命名格式:真实差异词在前 + 【卖点】。例:'1支【深层清洁去黑头】','300g*2瓶【囤货更划算】','01#花间酒【微醺玫瑰猫眼】','02#浮光锦【流光锦缎显白】','100ml【深层清洁去黑头】'。\n"
    "13. name 8-24字左右;卖点用【】括起来;除容量*数量里的 * 和原始编号里的 # 外,不要新增 #＃+~ 等怪符号。\n"
    "只输出JSON:{\"skus\":[{\"name\":\"..\",\"units\":int}]}。不要别的字。"
)


def cloud_rebuild_skus(names: list, title: str = "") -> list:
    """云端从原始SKU名剔搭配/赠品、留主产品、给份数。返回 [{name,units}]。异常抛给调用方回落正则。"""
    vals = [v for v in (names or []) if v]
    if not vals:
        return []
    user = "商品标题：%s\n原始SKU(%d个)：\n%s" % (title, len(vals), "\n".join("- " + v for v in vals))
    txt = _ds_content([{"role": "system", "content": REBUILD_SYS}, {"role": "user", "content": user}], temperature=0)
    if txt.startswith("```"):
        txt = txt.strip("`"); txt = txt[txt.find("{"):txt.rfind("}") + 1]
    return json.loads(txt).get("skus") or []


# ── 云端单选(给若干候选选项,挑最符合商品的一个;产品类型等下拉用) ──
PICK_SYS = (
    "你是电商上架助手。给你一个商品标题和若干「{what}」候选选项,"
    "选出最符合该商品的一个选项。只输出选中的选项原文(必须和某个候选一字不差),"
    "不要解释、不要标点、不要引号。")


def cloud_pick(title: str, options: list, what: str = "产品类型"):
    """云端DeepSeek从 options 里挑最符合 title 的一项。返回选项原文或 None。
    网络/key 异常会抛出,调用方需 try/except 兜底。"""
    opts = [o.strip() for o in (options or []) if o and o.strip()]
    if not opts:
        return None
    txt = _ds_content([
        {"role": "system", "content": PICK_SYS.format(what=what)},
        {"role": "user", "content": "商品标题：%s\n选项：%s\n最符合的选项=" % (title, " / ".join(opts))}], temperature=0)
    if txt.startswith("```"):
        txt = txt.strip("`")
    txt = txt.strip().strip('"').strip("'").strip()
    for o in opts:            # 先精确等于
        if o == txt:
            return o
    for o in opts:            # 再互相包含
        if o and (o in txt or txt in o):
            return o
    return None




def _parse_llm_json(text: str) -> dict:
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text[text.find("{"):text.rfind("}") + 1]
    value = json.loads(text)
    return value if isinstance(value, dict) else {}



# ASCII-only override: the Windows shell can otherwise corrupt new Chinese prompt text.
PDD_BASE_NAME_SYS = (
    "Decide whether a PDD product title has a trailing color, scent, or variant. "
    "Only remove a complete trailing segment separated by dash, slash, parentheses, or brackets. "
    "Never rewrite the product body. Return JSON only: "
    "{\"base_name\":\"..\",\"removed_variant\":\"..\",\"kind\":\"color|scent|style|none\",\"confidence\":0.0}."
)
SUPPLIER_BASE_NAME_SYS = (
    "Extract a product base name from a 1688 supplier title. Keep brand and core category; remove pricing, wholesale, "
    "quantity, color, scent, and promotional words. Benefit claims, including \u900f\u4eae\u808c\u80a4, are promotional words, not product names. "
    "base_name must be one contiguous substring of the original title. Return JSON only: {\"base_name\":\"..\",\"confidence\":0.0}."
)
SPEC_CODE_ROW_SYS = (
    "Parse every raw PDD SKU style using the complete product base name. Return JSON only: "
    "{\"rows\":[{\"style\":\"exact original style\",\"variant\":\"..\",\"package_spec\":\"..\",\"confidence\":0.0}]}. "
    "variant is only a real color, scent, model, or style distinction; it must be a contiguous substring of the raw style. "
    "Hard rule: if the normalized candidate is already contained in Product base, variant MUST be empty. "
    "package_spec must be only a normalized explicit quantity or capacity such as 1bottle, 2boxes, 3pieces, 30mL, or 100g*2; "
    "never return brackets, prose, a suitability statement, a recommendation, a discount, or a gift as package_spec. "
    "Words meaning suitable-for, recommended, bargain, gift, free, send, mask, sample, or marketing are never variants or package specs. "
    "A plus-suffix is a gift or anti-price-comparison add-on, not a variant or package spec. "
    "If there is no explicit valid package quantity, return package_spec empty; do not invent one, except for a clearly single-item color cosmetic. "
    "A numbered color code such as 01grayblack is a variant; a combination such as 01grayblack+02deepbrown is a combined variant. "
    "Hard rule: when Product base contains \u53e3\u7ea2, \u5507\u91c9, \u7709\u7b14, \u773c\u7ebf\u7b14, or \u816e\u7ea2, every standalone shade MUST return package_spec 1\u652f; "
    "a two-color combination or text meaning two-pieces may use 2\u652f. "
    "Examples: raw 01grayblack[suitable-for-dark-hair]+mask -> variant 01grayblack, package_spec 1\u652f. "
    "raw 01grayblack+02deepbrown[recommended-combination]+mask -> variant 01grayblack+02deepbrown, package_spec 2\u652f. "
    "raw 01grayblack[two-pieces-bargain]+mask -> variant 01grayblack, package_spec 2\u652f. "
    "raw \u51b0\u6c99\u7ea2\u8c46[\u6e05\u900f\u6c34\u5149\u663e\u767d]+gift -> variant \u51b0\u6c99\u7ea2\u8c46, package_spec 1\u652f. "
    "raw \u51b0\u6c99\u7ea2\u8c46+\u5143\u6c14\u8349\u8393[\u53cc\u8272\u642d\u914d]+gift -> variant \u51b0\u6c99\u7ea2\u8c46+\u5143\u6c14\u8349\u8393, package_spec 2\u652f. "
    "Before returning, check that variant is not in Product base and package_spec is either empty or a real number with a standard Chinese unit."
)


def classify_pdd_base_name(title: str, sku_context: list[str]) -> dict:
    raw = (title or "").strip()
    if not raw:
        return {}
    content = "PDD title: %s\nSKU styles:\n%s" % (raw, "\n".join("- " + x for x in sku_context if x))
    return _parse_llm_json(_ds_content([
        {"role": "system", "content": PDD_BASE_NAME_SYS},
        {"role": "user", "content": content},
    ], temperature=0))


def extract_supplier_base_name(title: str, sku_context: list[str]) -> dict:
    raw = (title or "").strip()
    if not raw:
        return {}
    content = "1688 supplier title: %s\nSKU styles:\n%s" % (raw, "\n".join("- " + x for x in sku_context if x))
    return _parse_llm_json(_ds_content([
        {"role": "system", "content": SUPPLIER_BASE_NAME_SYS},
        {"role": "user", "content": content},
    ], temperature=0))


def classify_spec_code_rows(product_name: str, styles: list[str]) -> list[dict]:
    rows = [s.strip() for s in (styles or []) if s and s.strip()]
    if not rows:
        return []
    content = "Product base: %s\nSKU styles:\n%s" % (product_name or "", "\n".join("- " + s for s in rows))
    value = _parse_llm_json(_ds_content([
        {"role": "system", "content": SPEC_CODE_ROW_SYS},
        {"role": "user", "content": content},
    ], temperature=0))
    result = value.get("rows") or []
    return result if isinstance(result, list) else []

def _infer_units(name: str) -> int:
    m = re.search(r"(\d+)\s*[瓶份支盒件套罐袋]", name or "")
    return int(m.group(1)) if m else 1


# PDD 审核违禁词:规格名含「赠」「送」会被驳回(2026-06-17 实测 967298527552:
# 「无赠品」「买2盒送1盒共3盒」都发不了)。"送"删不掉(删了没意义)→ 这类 SKU 必须重建成干净名。
_BANNED_RE = re.compile(r"[赠送]")


def _has_banned(name: str) -> bool:
    return bool(_BANNED_RE.search(name or ""))


def _clean_rebuilt_name(orig: str, units: int) -> str:
    """重建名兜底:云端没躲开「赠/送」时,按买家实得总数改写成干净的「N量词装」。
    优先取「共N量词」(买N送M共K=K),否则取末尾「N量词」,再否则用 units。"""
    s = re.sub(r"[（(]?[无有含不加]?\s*赠\s*品?[）)]?", "", orig or "")
    if not _has_banned(s):
        return re.sub(r"\s{2,}", " ", s).strip(" +＋·、,，") or f"{units}件装"
    m = re.search(r"共\s*(\d+)\s*([瓶盒支袋件套罐])", orig or "") or \
        re.search(r"(\d+)\s*([瓶盒支袋件套罐])\s*$", orig or "") or \
        re.search(r"(\d+)\s*([瓶盒支袋件套罐])", orig or "")
    if m:
        return f"{m.group(1)}{m.group(2)}装"
    return f"{units}件装"


def _dedupe_count_word(s: str) -> str:
    """折叠重复的"数字+量词":重建命名把原名已有的"2支"又加一遍 → "2支2支" → "2支"。
    只折叠紧挨着、完全相同的"数字+量词",不动正常名字。"""
    s = s or ""
    for _ in range(3):
        ns = re.sub(r"(\d+\s*[支瓶盒件套罐袋张片])\s*\1", r"\1", s)
        if ns == s:
            break
        s = ns
    return s


def _format_capacity_count_name(s: str) -> str:
    """把「容量 + 数量」写成每件容量乘以件数,避免 300g 2瓶 被误解成总量300g。"""
    s = s or ""
    unit = r"(?:g|G|克|kg|KG|ml|mL|ML|l|L)"
    item = r"[瓶盒支袋件套罐]"
    return re.sub(
        rf"(\d+(?:\.\d+)?\s*{unit})\s+(\d+\s*{item})",
        lambda m: re.sub(r"\s+", "", m.group(1)) + "*" + re.sub(r"\s+", "", m.group(2)),
        s,
    )


def _dedupe_rebuilt_skus(skus: list):
    """把 cloud_rebuild_skus 的 [{name,units}] 去重为 (names, units_map)。
    - 同名同份 = 真重复 → 丢一个;
    - ★同名不同份 = 不同款(如剔搭配后只剩"撕拉面膜",但 1支/2支 是真数量款,大模型偶尔给同名)→
      给该名下每款追加数量量词区分,**绝不 silently 丢掉一个款**(治 970201123244:9个SKU被压成1个的根因)。
    名字含「赠/送」违禁词的兜底改写成干净「N量词装」。"""
    cleaned = []
    for it in (skus or []):
        u = int(it.get("units") or 1)
        nm = clean_spec_value(it.get("name", ""))
        if nm and _has_banned(nm):
            nm = clean_spec_value(_clean_rebuilt_name(it.get("name", ""), u))
        nm = _format_capacity_count_name(_dedupe_count_word(nm))
        if nm:
            cleaned.append((nm, u))
    units_of = {}
    for nm, u in cleaned:
        units_of.setdefault(nm, set()).add(u)
    names, units_map, seen = [], {}, set()
    for nm, u in cleaned:
        out = nm
        # 同一基名出现多个不同份数、但名字里没体现数量 → 追加量词区分(否则第二款会被去重丢掉)
        if len(units_of[nm]) > 1 and not re.search(r"\d+\s*[支瓶盒件套罐袋张片份]", nm):
            out = f"{nm}{u}份"
        key = (out, u)
        if key in seen:
            continue
        seen.add(key); names.append(out); units_map[out] = u
    return names, units_map


def load_sku_material(supplier_url: str) -> dict:
    """按 supplier_url 从商品库回查 sku_material(核对批准文号时存的1688真料)。"""
    try:
        recs = json.load(open(LIB, encoding="utf-8"))
    except Exception:
        return {}
    mid = re.search(r"/offer/(\d+)", supplier_url or "")
    oid = mid.group(1) if mid else ""
    for r in recs:
        m = r.get("sku_material") or {}
        if not m:
            continue
        if (oid and m.get("offer_id") == oid) or (supplier_url and supplier_url in (r.get("supplier_link") or "")):
            return m
    return {}


def clean_spec_value(s: str) -> str:
    """规格值清洗:只去掉 PDD 会拒收的怪符号(#＃+~`^等),**保留中文/字母/数字/空格和容量*数量里的星号**。
    不再删前导数字(数量是有意的)、不动颜色名(产品原样)。"""
    s = (s or "").strip()
    s = re.sub(r"[#＃+＋~`^=、，。!！?？]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


# ── 读当前SKU规格名(喂云端判定) ──
READ_SPECS_JS = r"""() => {
  const txt=el=>(el.innerText||'').trim();
  const boxes=[...document.querySelectorAll('[class*="sku-list"]')];let box=null,bh=0;for(const b of boxes){const r=b.getBoundingClientRect();if(r.height>bh){bh=r.height;box=b;}}
  if(!box)return [];
  const cells=[...box.querySelector('tr').querySelectorAll('th,td')].map(td=>{const r=td.getBoundingClientRect();return{t:txt(td),x:Math.round(r.x+r.width/2)};});
  const NON=new Set(['当前库存','库存增减','改后库存','*拼单价(元)','拼单价(元)','*单买价(元)','单买价(元)','*预览图','预览图','规格编码','状态','*库存','库存','商品编码','操作']);
  const curX=(cells.find(c=>['当前库存','*库存','库存'].includes(c.t))||{}).x||99999;
  const specCols=cells.filter(c=>c.t&&c.x<curX&&!NON.has(c.t)).sort((a,b)=>a.x-b.x);
  const colText=(tr,x)=>{let b='',bd=1e9;for(const td of tr.querySelectorAll('td')){const t=txt(td);if(!t||t.length>90||/^\d+(\.\d+)?$/.test(t))continue;const r=td.getBoundingClientRect();if(r.width<=0)continue;const d=Math.abs(r.x+r.width/2-x);if(d<bd&&d<150){bd=d;b=t;}}return b;};
  const trs=[...box.querySelectorAll('tr.TB_tr_5-188-0')].filter(tr=>tr.querySelectorAll('input').length>0);
  const prev={};
  return trs.map(tr=>{
    const parts=specCols.map(c=>{let v=colText(tr,c.x);if(!v)v=prev[c.t]||'';if(v)prev[c.t]=v;return v;}).filter(Boolean);
    return parts.join(' / ');
  });
}"""


async def read_current_specs(form):
    try:
        return await form.evaluate(READ_SPECS_JS)
    except Exception:
        return []


# 赠品/工具类词:重建时从SKU里剔掉(只留真正的颜色/款式)
_GIFT_RE = re.compile(r"面膜|冻膜|小样|赠|送|试用|体验装|工具|夹|镜|刷子|教程|小包|替换")


async def extract_variants_from_form(form):
    """读表单现有SKU → 抽出单个颜色/款式(组合按+/＋拆开、赠品工具丢掉、去重)。
    返回 {variants:[...], messy:bool, single:bool}。messy=有组合或丢了赠品(=该重建)。"""
    names = await read_current_specs(form)
    variants, seen, messy = [], set(), False
    for full in names:
        toks = []
        for part in re.split(r"\s*/\s*", full or ""):
            for t in re.split(r"[+＋]", part):
                t = t.strip()
                if not t:
                    continue
                if _GIFT_RE.search(t):
                    messy = True            # 赠品/工具 → 丢掉,标记需重建
                    continue
                if re.fullmatch(r"\d+(?:\.\d+)?\s*(?:g|mg|kg|ml|mL|ML|l|L|片|G|KG)", t):
                    messy = True            # 净含量值(100g/50mL)不是款式 → 丢掉,别当款式名
                    continue
                toks.append(t)
        if len(toks) > 1:
            messy = True                    # 本行是组合 → 需重建
        for t in toks:
            if t not in seen:
                seen.add(t); variants.append(t)
    return {"variants": variants, "messy": messy, "single": len(variants) <= 1}


async def cloud_judge(form, title=""):
    """读当前SKU名 → 云端判。返回 {keepable, rows, names, reason}。判定失败→keepable=True(保守保留)。"""
    names = await read_current_specs(form)
    if not names:
        return {"keepable": True, "rows": [], "names": [], "reason": "no-specs"}
    try:
        gate = llm_gate(names, title)
        rows = gate.get("rows") or []
        # 规格名含「赠/送」= PDD 审核违禁词(发布必拒)→ 不管份数判没判得出,都强制重建成干净名。
        _banned = any(_has_banned(n) for n in names)
        # ★ keepable 判据:只要云端【每行都给出了份数】(units≥1)且不含违禁词 → 保留原SKU、按份数填价。
        #   不再因 sure=false 就抢着重建——"搭了赠品(如+面膜)所以 sure=false"≠"算不出份数",
        #   云端这种情况照样给得出份数(按主货支数),重建反而把好名字搞乱(1支1支)、还读不回。
        #   真填不出份数(行缺失/行数对不上)或含违禁词才重建;就算保留路填价失败,后面"提交报错→重建"仍兜底。
        _have_units = (bool(rows) and len(rows) == len(names)
                       and all(r.get("units") for r in rows))   # units≥1 恒为真值,None/0 才落空
        # ★大模型判定:任一行是【主产品+防比价搭配/赠品】组合 → 强制重建清理(剔掉卖家搭配,只留主产品+我们的后缀)
        #   不再 keep(keep 会把卖家"+精华液/+漱口水"原样留下并叠加我们的后缀 → 冗长 + 背了卖家不发的赠品承诺)。
        _has_combo = any(r.get("combo") for r in rows)
        keepable = _have_units and not _banned and not _has_combo
        if _has_combo and _have_units and not _banned:
            print("[智能SKU] 大模型判:含防比价搭配组合 → 强制重建(剔搭配、留主产品)")
        # ★ 净含量×款式 这种多维(某段是纯"数字+单位"如100g/50mL=净含量维)→ keep 必栽净含量格式
        #   (原表上改净含量会冲掉款式维,死路)→ 直接强制重建(重建会取消净含量、只留干净款式维)。
        _NET = re.compile(r'^\s*\d+(?:\.\d+)?\s*(?:g|mg|kg|ml|mL|ML|l|L|片)\s*$')
        if any(_NET.match(p or "") for nm in names for p in str(nm).split("/")):
            if keepable:
                print("[智能SKU] 检出净含量维(数字+单位)→ 强制重建(keep 会栽净含量格式,在原表没法修)")
            keepable = False
        # 云端每行份数 → units_map(保留路也用它填价,不用本地蠢判)。
        # 按"喂给云端的名"和"末层名"都建键,提高 fill_prices 命中率。
        umap = {}
        for r in rows:
            nm = (r.get("name") or "").strip()
            u = int(r.get("units") or 1)
            if nm:
                umap[nm] = u
                umap[nm.split("/")[-1].strip()] = u   # 末层(2层时 fill_prices 取最右列)
        return {"keepable": keepable, "rows": rows, "names": names,
                "units_map": umap, "banned": _banned, "count_only": bool(gate.get("count_only")), "reason": gate.get("reason", "")}
    except Exception as e:
        print(f"[智能SKU] 云端判定异常→保守保留: {e}")
        return {"keepable": True, "rows": [], "names": names, "reason": f"gate-error:{e}"}


# ── 清空重建机制(来自 build2layer_custom.py,已验证端到端上架) ──
DIMS_JS = r"""() => {
  const dt=el=>Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
  let sY=null,pY=null;
  for(const el of document.querySelectorAll('*')){const t=dt(el);if(t==='商品规格'&&sY===null)sY=el.getBoundingClientRect().top;if(t==='价格及库存'&&pY===null)pY=el.getBoundingClientRect().top;}
  const inR=el=>{const y=el.getBoundingClientRect().top;return (sY==null||y>sY-40)&&(pY==null||y<pY+10);};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top+r.height/2;};
  const typeIns=[...document.querySelectorAll('input')].filter(i=>/规格类型/.test(i.placeholder||'')&&inR(i)).map(i=>({name:i.value,y:cy(i)})).sort((a,b)=>a.y-b.y);
  const vins=[...document.querySelectorAll('input')].filter(i=>/请输入规格名称|选择或输入主色|自定义/.test(i.placeholder||'')&&inR(i)).map(i=>{const r=i.getBoundingClientRect();return{v:i.value,x:Math.round(r.x+r.width/2),y:r.top+r.height/2,empty:!i.value.trim()};});
  const dims=typeIns.map((t,i)=>{const y0=t.y,y1=(i+1<typeIns.length)?typeIns[i+1].y:1e9;
    const vs=vins.filter(v=>v.y>y0&&v.y<y1);
    const valued=vs.filter(v=>!v.empty).map(v=>({v:v.v,x:v.x,y:Math.round(v.y)}));
    const empt=vs.filter(v=>v.empty);
    return {name:t.name, values:valued, addBox:empt.length?{x:empt[0].x,y:Math.round(empt[0].y)}:null};
  });
  const boxes=[...document.querySelectorAll('[class*="sku-list"]')];let box=null,bh=0;for(const b of boxes){const r=b.getBoundingClientRect();if(r.height>bh){bh=r.height;box=b;}}
  const rows=box?[...box.querySelectorAll('tr.TB_tr_5-188-0')].filter(tr=>tr.querySelectorAll('input').length>0).length:0;
  return {dims, priceRows:rows};
}"""

# 新版规格页兜底读取：不替换旧 DIMS_JS，只给兜底分支使用。
FALLBACK_DIMS_JS = r"""() => {
  const visible = el => {
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.display !== 'none' && cs.visibility !== 'hidden';
  };
  const cy = el => { const r = el.getBoundingClientRect(); return r.top + r.height / 2; };
  const rectOf = el => { const r = el.getBoundingClientRect(); return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height)}; };
  const typeIns = [...document.querySelectorAll('input')]
    .filter(i => visible(i) && /规格类型/.test((i.placeholder || '') + ' ' + (i.value || '')))
    .map(i => ({name: i.value || '', y: cy(i), rect: rectOf(i)}))
    .sort((a, b) => a.y - b.y);
  const vins = [...document.querySelectorAll('input')]
    .filter(i => visible(i) && /请输入规格名称|选择或输入主色|自定义/.test(i.placeholder || ''))
    .map(i => {
      const r = i.getBoundingClientRect();
      return {v: i.value || '', x: Math.round(r.x + r.width / 2), y: cy(i), empty: !(i.value || '').trim(), ph: i.placeholder || ''};
    })
    .sort((a, b) => a.y - b.y || a.x - b.x);
  const dims = typeIns.map((t, idx) => {
    const y0 = t.y;
    const y1 = idx + 1 < typeIns.length ? typeIns[idx + 1].y : y0 + 220;
    const vs = vins.filter(v => v.y > y0 && v.y < y1);
    const empty = vs.find(v => v.empty);
    return {name: t.name, typeRect: t.rect, values: vs.filter(v => !v.empty).map(v => ({v: v.v, x: v.x, y: Math.round(v.y)})), addBox: empty ? {x: empty.x, y: Math.round(empty.y)} : null};
  });
  const boxes = [...document.querySelectorAll('[class*="sku-list"]')];
  let box = null, bh = 0;
  for (const b of boxes) {
    const r = b.getBoundingClientRect();
    if (r.height > bh) { bh = r.height; box = b; }
  }
  const rows = box ? [...box.querySelectorAll('tr.TB_tr_5-188-0')].filter(tr => tr.querySelectorAll('input').length > 0).length : 0;
  return {dims, priceRows: rows};
}"""
STOCK_FILL_JS = r"""(stock) => {
  const txt=el=>(el.innerText||'').trim();
  const boxes=[...document.querySelectorAll('[class*="sku-list"]')];let box=null,bh=0;for(const b of boxes){const r=b.getBoundingClientRect();if(r.height>bh){bh=r.height;box=b;}}
  if(!box)return {rows:0,err:'no box'};
  const cells=[...box.querySelector('tr').querySelectorAll('th,td')].map(td=>{const r=td.getBoundingClientRect();return{t:txt(td),x:Math.round(r.x+r.width/2)};});
  const findX=ns=>{for(const nm of ns){const c=cells.find(c=>c.t===nm);if(c)return c.x;}return null;};
  const nsX=findX(['改后库存','*库存','库存','当前库存']);
  if(nsX==null)return {rows:0,err:'no stock col'};
  const setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
  const setV=(inp,v)=>{setter.call(inp,String(v));inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));};
  const inAt=(tr,x)=>{let b=null,bd=1e9;for(const inp of tr.querySelectorAll('input')){const r=inp.getBoundingClientRect();if(r.width<20)continue;const d=Math.abs(r.x+r.width/2-x);if(d<bd&&d<60){bd=d;b=inp;}}return b;};
  const trs=[...box.querySelectorAll('tr.TB_tr_5-188-0')].filter(tr=>tr.querySelectorAll('input').length>0);
  let n=0;for(const tr of trs){const inp=inAt(tr,nsX);if(inp){setV(inp,stock);n++;}}
  return {nsX,rows:n};
}"""


async def _click_text(form, text, exact=True):
    pos = await form.evaluate(r"""(args)=>{
      const {text,exact}=args;
      const dt=el=>Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
      let sY=null,pY=null;
      for(const el of document.querySelectorAll('*')){const t=dt(el);if(t==='商品规格'&&sY===null)sY=el.getBoundingClientRect().top;if(t==='价格及库存'&&pY===null)pY=el.getBoundingClientRect().top;}
      const inR=el=>{const r=el.getBoundingClientRect();const y=r.top;return r.width>0&&(sY==null||y>sY-50)&&(pY==null||y<pY+20);};
      for(const el of document.querySelectorAll('span,div,a,button,i')){
        const t=dt(el); if(!inR(el))continue;
        if(exact? t===text : (t&&t.includes(text))){const r=el.getBoundingClientRect();return{x:Math.round(r.x+r.width/2),y:Math.round(r.top+r.height/2)};}
      }
      return null;
    }""", {"text": text, "exact": exact})
    if pos:
        await form.mouse.click(pos["x"], pos["y"]); return True
    return False


async def _click_text_global(form, text, exact=True):
    pos = await form.evaluate(r"""(args)=>{
      const {text,exact}=args;
      const dt=el=>Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
      for(const el of document.querySelectorAll('span,div,a,button,i')){
        const t=dt(el); const r=el.getBoundingClientRect(); if(r.width<=0)continue;
        if(exact? t===text : (t&&t.includes(text)))return{x:Math.round(r.x+r.width/2),y:Math.round(r.top+r.height/2)};
      }
      return null;
    }""", {"text": text, "exact": exact})
    if pos:
        await form.mouse.click(pos["x"], pos["y"]); return True
    return False


async def _dbg_reset_popup(form):
    """诊断:重置规格弹窗在不在(只读,不改行为)。"""
    try:
        return await form.evaluate(r"""()=>{for(const el of document.querySelectorAll('*')){if(el.children.length>0)continue;const t=(el.innerText||'').trim();if(/重置规格|规格设置已切换到新版|暂不重置/.test(t)){const r=el.getBoundingClientRect();if(r.width>0)return true;}}return false;}""")
    except Exception:
        return None


async def _click_existing_type_input(form) -> bool:
    """点一个【已有值】的规格类型输入框,触发 PDD「重置规格(已切换新版)」弹窗。返回有没有点到。"""
    return await form.evaluate(r"""()=>{
        const ti=[...document.querySelectorAll('input')].find(i=>/规格类型/.test(i.placeholder||'')&&(i.value||'').trim());
        if(ti){ti.scrollIntoView({block:'center'}); ti.click(); ti.focus(); return true;}
        return false;
    }""")


async def _confirm_delete_spec_type_dialog(form) -> bool:
    """确认「删除规格类型」弹窗。
    弹窗主按钮文字是「删除」,不能全局点普通规格值旁边的删除;必须限定在包含
    「删除该规格类型」提示文案的弹窗容器内。
    """
    pos = await form.evaluate(r"""()=>{
        const directText = el => Array.from(el.childNodes)
            .filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
        const visible = el => {
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
        };
        const dialogs = [...document.querySelectorAll('div')]
            .filter(el => visible(el) && /删除该规格类型/.test(el.innerText || '') && /取消/.test(el.innerText || ''))
            .sort((a, b) => {
                const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
                return (ra.width * ra.height) - (rb.width * rb.height);
            });
        for (const dlg of dialogs) {
            const btns = [...dlg.querySelectorAll('button,a,span,div')]
                .filter(el => visible(el) && directText(el) === '删除');
            if (!btns.length) continue;
            const btn = btns[btns.length - 1];
            const r = btn.getBoundingClientRect();
            return {x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2)};
        }
        return null;
    }""")
    if not pos:
        return False
    await form.mouse.click(pos["x"], pos["y"])
    await asyncio.sleep(1.2)
    print("[reset_specs] 确认删除规格类型弹窗: 点击删除")
    return True


async def _delete_custom_spec_type(form) -> bool:
    """删除一个规格类型。
    优先删程序重建出的 `.custom-standard`;若是同款页原生两层规格,则在「商品规格」范围内
    精确找完整文字「删除规格类型」,不要误点普通规格值旁边的「删除」。
    """
    hit = await form.evaluate(r"""()=>{
        const directText = el => Array.from(el.childNodes)
            .filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
        const visible = el => {
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
        };
        const point = (el, kind) => {
            el.scrollIntoView({block:'center'});
            const r = el.getBoundingClientRect();
            return {x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2), kind};
        };
        const custom = [...document.querySelectorAll('.property-container-v2.custom-standard a.goods-spec-del')]
            .filter(visible);
        if (custom.length) return point(custom[custom.length - 1], 'custom-standard');

        let sY = null, pY = null;
        for (const el of document.querySelectorAll('*')) {
            const t = directText(el);
            if (sY == null && t === '商品规格') sY = el.getBoundingClientRect().top;
            if (pY == null && t === '价格及库存') pY = el.getBoundingClientRect().top;
        }
        const inSpecArea = el => {
            const r = el.getBoundingClientRect();
            return visible(el) && (sY == null || r.top > sY - 60) && (pY == null || r.top < pY + 10);
        };
        const links = [...document.querySelectorAll('a,span,button,div')]
            .filter(el => inSpecArea(el) && directText(el) === '删除规格类型')
            .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
        if (!links.length) return null;
        return point(links[links.length - 1], 'text-delete-spec-type');
    }""")
    if not hit:
        return False
    await form.mouse.click(hit["x"], hit["y"])
    await asyncio.sleep(0.8)
    confirmed = await _confirm_delete_spec_type_dialog(form)
    if not confirmed:
        confirmed = await (_click_text_global(form, "确认") or _click_text_global(form, "确定"))
    await asyncio.sleep(1.0)
    print(f"[reset_specs] 点击删除规格类型 kind={hit.get('kind')} confirmed={confirmed}")
    return bool(confirmed)


async def _has_empty_spec_type_shell(form) -> bool:
    """删除所有旧规格后,PDD 会留下一个空的「规格类型1」选择框。
    这是可直接选「款式」的干净态,不能继续删,否则会卡在空壳上。
    """
    try:
        return bool(await form.evaluate(r"""()=>{
            const directText = el => Array.from(el.childNodes)
                .filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
            let sY = null, pY = null;
            for (const el of document.querySelectorAll('*')) {
                const t = directText(el);
                if (sY == null && t === '商品规格') sY = el.getBoundingClientRect().top;
                if (pY == null && t === '价格及库存') pY = el.getBoundingClientRect().top;
            }
            const visible = el => {
                const r = el.getBoundingClientRect();
                return r.width > 0 && r.height > 0;
            };
            const inSpec = el => {
                const r = el.getBoundingClientRect();
                return visible(el) && (sY == null || r.top > sY - 60) && (pY == null || r.top < pY + 10);
            };
            const typeShell = [...document.querySelectorAll('input')]
                .some(i => inSpec(i) && /规格类型\d*/.test((i.placeholder || '') + ' ' + (i.value || '')));
            if (!typeShell) return false;
            const valueInputs = [...document.querySelectorAll('input')]
                .filter(i => inSpec(i) && /请输入规格名称|选择或输入主色|自定义/.test(i.placeholder || ''));
            return valueInputs.every(i => !(i.value || '').trim());
        }"""))
    except Exception:
        return False


async def reset_specs(form):
    """清空旧规格。新版规格被锁:发布同款抄来的规格,要编辑/清空必须先触发「重置规格」弹窗、点「清空规格重置」。
    老逻辑只"弹窗已在才点清空",但自己不触发弹窗(它点的添加/删除规格类型不触发)→ 永远点不到 → 旧规格没清成。
    新逻辑:① 弹窗已在 → 点清空规格重置;② 没弹窗但有已存规格类型 → 点它触发弹窗(下一轮再点清空);
            ③ 整页空(无规格类型)→ 点添加规格类型造一个。"""
    for _ in range(6):
        _pp = await _dbg_reset_popup(form)
        print(f"[reset_specs] 第{_+1}轮 重置规格弹窗present={_pp}")
        # ① 弹窗在 → 点「清空规格重置」清空(实测:点后规格类型清空、弹窗关闭)
        if await _click_text_global(form, "清空规格重置"):
            print("[reset_specs] 点了「清空规格重置」")
            await asyncio.sleep(1.8)
            print(f"[reset_specs] 清空后 present={await _dbg_reset_popup(form)}")
            return True
        if await _has_empty_spec_type_shell(form):
            print("[reset_specs] 检出空规格类型壳 → 视为已清空")
            return True
        # 草稿/编辑页可能不会弹「清空规格重置」,但程序自建层有稳定删除入口。
        if await _delete_custom_spec_type(form):
            print("[reset_specs] 删除了一个自定义规格类型")
            await asyncio.sleep(0.8)
            continue
        # ② 没弹窗但有已存规格类型 → 点它触发弹窗(新版锁)
        if await _click_existing_type_input(form):
            print("[reset_specs] 点已有规格类型输入框 → 触发重置规格弹窗")
            await asyncio.sleep(1.0)
            continue
        # ③ 整页没有规格类型 → 已是干净态/点添加规格类型造一个
        await (_click_text(form, "添加规格类型", exact=False)
               or _click_text(form, "添加定制规格"))
        await asyncio.sleep(1.0)
        # 没有任何已存规格类型可触发 = 本就干净,直接当成功
        has_type = await form.evaluate(r"""()=>[...document.querySelectorAll('input')].some(i=>/规格类型/.test(i.placeholder||''))""")
        if not has_type:
            print("[reset_specs] 页面无规格类型(本就干净)→ 视为已清空")
            return True
    print("[reset_specs] 6轮没清成 → 返回False")
    return False


async def set_dim_type(form, name="款式"):
    """规格类型下拉:点开 → 在【刚弹出的下拉浮层】里选「款式」。
    ★用 fill_product_type 那套已验证的"锚定 dropdownPanel/dropdownMain 浮层"法(§13.H),
    取代旧的"全局扫 + 文字完全相等 + 水平±150px"(净含量×款式这种下拉偏移就点不中→build-fail)。
    加:dump 真实选项 + scrollIntoView 后再取坐标 + 没中就关掉重开重试一次。"""
    # 找规格类型输入框时先 scrollIntoView 再取坐标(取消净含量后页面常滚在顶部,输入框在屏外点不中)
    _find_dt_input = r"""()=>{
      const directText=el=>Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
      let sY=null,pY=null;
      for(const el of document.querySelectorAll('*')){const t=directText(el);if(sY==null&&t==='商品规格')sY=el.getBoundingClientRect().top;if(pY==null&&t==='价格及库存')pY=el.getBoundingClientRect().top;}
      const visible=el=>{const r=el.getBoundingClientRect();return r.width>0&&r.height>0;};
      const inSpec=el=>{const r=el.getBoundingClientRect();return visible(el)&&(sY==null||r.top>sY-60)&&(pY==null||r.top<pY+10);};
      const inputs=[...document.querySelectorAll('input')].filter(i=>inSpec(i));
      const hit=inputs.find(i=>/规格类型\d*/.test((i.placeholder||'')+' '+(i.value||'')))
        || inputs.find(i=>/规格类型/.test(i.placeholder||''));
      if(hit){hit.scrollIntoView({block:'center'});const r=hit.getBoundingClientRect();if(r.width>0)return{x:Math.round(r.x+r.width/2),y:Math.round(r.top+r.height/2),value:hit.value||'',placeholder:hit.placeholder||''};}
      return null;
    }"""
    pos = await form.evaluate(_find_dt_input)
    if not pos:
        # 没有规格类型输入框(取消净含量后已无维度)→ 把「添加规格类型」按钮【滚进视口再点】造一个,再找。
        # ★关键:不滚进视口直接点会点空(探针实测就栽这);滚后点出现 规格类型1 输入框。
        print("[智能SKU][选款式] 无规格类型输入框 → 滚动并点「添加规格类型」新建")
        btn = await form.evaluate(r"""()=>{for(const el of document.querySelectorAll('span,div,a,button,i')){if(el.querySelector('*'))continue;const t=(el.innerText||'').trim();if(t==='添加规格类型'||t==='添加商品规格类型'||t==='添加定制规格'){el.scrollIntoView({block:'center'});const r=el.getBoundingClientRect();if(r.width>0)return{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};}}return null;}""")
        if btn:
            await form.mouse.click(btn["x"], btn["y"]); await asyncio.sleep(1.4)
        pos = await form.evaluate(_find_dt_input)
    if not pos:
        print("[智能SKU][选款式] 仍没找到「规格类型」输入框")
        return None
    DD = {"x": pos["x"], "y": pos["y"]}
    for attempt in range(2):
        await form.mouse.click(pos["x"], pos["y"]); await asyncio.sleep(1.1)
        # dump:锚定离字段最近的可见下拉浮层,读出真实选项(诊断为什么没匹配到款式)
        opts = await form.evaluate(r"""(dd)=>{
            const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"],[class*="optionList"]')]
              .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
            if(!ps.length) return [];
            ps.sort((a,b)=>{const ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
              return (Math.abs(ra.top-dd.y)+Math.abs(ra.left-dd.x))-(Math.abs(rb.top-dd.y)+Math.abs(rb.left-dd.x));});
            const out=[];
            for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"],[role="option"],div,span')){
                if(it.querySelector('*')) continue;
                const t=(it.innerText||'').trim();
                if(t && t.length<=8 && !/没有合适|点击反馈|反馈/.test(t)) out.push(t);
            }
            return [...new Set(out)];
        }""", DD)
        print(f"[智能SKU][选款式] 下拉选项(第{attempt+1}次): {opts}")
        for label in (name, "套餐", "组合", "型号", "材质", "口味", "规格", "类型"):
            coord = await form.evaluate(r"""(a)=>{
              const {label,dd}=a;
              const ps=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"],[class*="optionList"]')]
                .filter(p=>{const r=p.getBoundingClientRect();return r.width>0&&r.height>0;});
              if(!ps.length) return null;
              ps.sort((x,y)=>{const ra=x.getBoundingClientRect(),rb=y.getBoundingClientRect();
                return (Math.abs(ra.top-dd.y)+Math.abs(ra.left-dd.x))-(Math.abs(rb.top-dd.y)+Math.abs(rb.left-dd.x));});
              for(const it of ps[0].querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"],[role="option"],div,span')){
                if(it.querySelector('*')) continue;
                if((it.innerText||'').trim()!==label) continue;
                it.scrollIntoView({block:'center'});
                const r=it.getBoundingClientRect();
                if(r.width>0&&r.height>0) return {x:Math.round(r.x+r.width/2),y:Math.round(r.top+r.height/2)};
              }
              return null;
            }""", {"label": label, "dd": DD})
            if coord:
                await form.mouse.click(coord["x"], coord["y"]); await asyncio.sleep(1.0)
                print(f"[智能SKU][选款式] 已选「{label}」({coord['x']},{coord['y']})")
                return label
        # 没匹配到 → 关掉浮层、稍等,下一轮重开重试
        try: await form.keyboard.press("Escape")
        except Exception: pass
        await asyncio.sleep(0.6)
    print("[智能SKU][选款式] 两次都没在下拉里找到款式/型号等(看上面选项 dump)")
    return None


async def add_value(form, name):
    d = await form.evaluate(DIMS_JS)
    if not d["dims"]:
        return False
    ab = d["dims"][0].get("addBox")
    if not ab:
        return False
    await form.mouse.click(ab["x"], ab["y"]); await asyncio.sleep(0.3)
    await form.keyboard.type(name, delay=35); await asyncio.sleep(0.3)
    await form.keyboard.press("Tab"); await asyncio.sleep(1.2)
    return True

async def _fallback_dims(form):
    try:
        return await form.evaluate(FALLBACK_DIMS_JS)
    except Exception as e:
        print(f"[智能SKU][fallback] 读取新版规格区异常: {e}")
        return {"dims": [], "priceRows": 0}


async def _fallback_select_dim_type(form, name="款式"):
    """新版规格页兜底选择规格类型。旧 set_dim_type 失败后才进入。"""
    pos = await form.evaluate(r"""(label)=>{
      const visible=el=>{const r=el.getBoundingClientRect();const cs=getComputedStyle(el);return r.width>0&&r.height>0&&cs.display!=='none'&&cs.visibility!=='hidden';};
      const center=el=>{el.scrollIntoView({block:'center'});const r=el.getBoundingClientRect();return{x:Math.round(r.x+r.width/2),y:Math.round(r.top+r.height/2),value:el.value||'',placeholder:el.placeholder||''};};
      const inputs=[...document.querySelectorAll('input')].filter(i=>visible(i)&&/规格类型/.test((i.placeholder||'')+' '+(i.value||'')));
      if(inputs.length) return center(inputs[0]);
      const btns=[...document.querySelectorAll('button,span,div')].filter(el=>visible(el));
      const add=btns.find(el=>/(添加规格类型|添加商品规格类型|添加定制规格)/.test((el.innerText||'').replace(/\s+/g,'')));
      if(add) return {...center(add), add:true};
      return null;
    }""", name)
    if not pos:
        print("[智能SKU][fallback] 找不到规格类型输入框/添加规格类型按钮")
        return None
    await form.mouse.click(pos["x"], pos["y"])
    await asyncio.sleep(0.8)
    if pos.get("add"):
        pos = await form.evaluate(r"""()=>{
          const visible=el=>{const r=el.getBoundingClientRect();const cs=getComputedStyle(el);return r.width>0&&r.height>0&&cs.display!=='none'&&cs.visibility!=='hidden';};
          const hit=[...document.querySelectorAll('input')].find(i=>visible(i)&&/规格类型/.test((i.placeholder||'')+' '+(i.value||'')));
          if(!hit)return null;
          hit.scrollIntoView({block:'center'});const r=hit.getBoundingClientRect();return{x:Math.round(r.x+r.width/2),y:Math.round(r.top+r.height/2),value:hit.value||'',placeholder:hit.placeholder||''};
        }""")
        if not pos:
            print("[智能SKU][fallback] 点击添加规格类型后仍找不到输入框")
            return None
        await form.mouse.click(pos["x"], pos["y"])
        await asyncio.sleep(0.8)
    if (pos.get("value") or "").strip() and name in (pos.get("value") or ""):
        return pos.get("value")
    hit = await form.evaluate(r"""(label)=>{
      const visible=el=>{const r=el.getBoundingClientRect();const cs=getComputedStyle(el);return r.width>0&&r.height>0&&cs.display!=='none'&&cs.visibility!=='hidden';};
      const panels=[...document.querySelectorAll('[class*="dropdownPanel"],[class*="dropdownMain"],[role="listbox"],ul,div')]
        .filter(visible)
        .map(p=>{const r=p.getBoundingClientRect();return{p,x:r.x,y:r.y,w:r.width,h:r.height};})
        .filter(o=>o.w>80&&o.h>20)
        .sort((a,b)=>a.y-b.y);
      const labels = label === '款式' ? ['款式','型号','套餐'] : [label];
      for(const box of panels){
        for(const it of box.p.querySelectorAll('li,[class*="itemRendererLabel"],[class*="cIL_item"],[role="option"],div,span')){
          if(!visible(it)) continue;
          if(it.querySelector('input,textarea,select')) continue;
          const txt=(it.innerText||'').trim();
          if(!txt) continue;
          if(!labels.some(x=>txt===x || txt.startsWith(x))) continue;
          it.scrollIntoView({block:'center'});
          const r=it.getBoundingClientRect();
          return {x:Math.round(r.x+r.width/2), y:Math.round(r.top+r.height/2), text:txt};
        }
      }
      return null;
    }""", name)
    if not hit:
        print("[智能SKU][fallback] 下拉里没有可选规格类型")
        return None
    await form.mouse.click(hit["x"], hit["y"])
    await asyncio.sleep(1.0)
    return hit.get("text") or name


async def add_value_fallback(form, name):
    d = await _fallback_dims(form)
    dims = d.get("dims") or []
    if not dims:
        return False
    ab = dims[0].get("addBox")
    if not ab:
        return False
    await form.mouse.click(ab["x"], ab["y"])
    await asyncio.sleep(0.3)
    await form.keyboard.insert_text(name)
    await asyncio.sleep(0.3)
    await form.keyboard.press("Tab")
    await asyncio.sleep(1.2)
    return True


async def _build_skus_fallback(form, names, image_path, stock):
    """旧流程选规格类型失败/建成校验失败时，走新版规格页兜底分支。"""
    print("[智能SKU][fallback] 进入新版规格页兜底分支")
    picked = await _fallback_select_dim_type(form, "款式")
    print(f"[智能SKU][fallback] 规格类型选: {picked}")
    if not picked:
        d0 = await _fallback_dims(form)
        built0 = [v["v"] for x in (d0.get("dims") or []) for v in (x.get("values") or [])]
        return {"ok": False, "built": built0, "reason": "fallback-type-fail"}
    for nm in names:
        cur = await _fallback_dims(form)
        built = [v["v"] for x in (cur.get("dims") or []) for v in (x.get("values") or [])]
        if nm in built:
            continue
        if not await add_value_fallback(form, nm):
            print(f"[智能SKU][fallback] 输入规格值失败: {nm}")
            return {"ok": False, "built": built, "reason": "fallback-add-value-fail"}
        await asyncio.sleep(0.4)
    db = await _fallback_dims(form)
    built = [v["v"] for x in (db.get("dims") or []) for v in (x.get("values") or [])]
    ok = (set(built) == set(names)) and db.get("priceRows") == len(names)
    print(f"[智能SKU][fallback] 建成: {built}  rows={db.get('priceRows')}  ok={ok}")
    if not ok:
        return {"ok": False, "built": built, "reason": "fallback-verify-fail"}
    n_img = await batch_sku_image(form, image_path)
    print(f"[智能SKU][fallback] SKU图(批量): {n_img}")
    sres = await form.evaluate(STOCK_FILL_JS, int(stock))
    print(f"[智能SKU][fallback] 库存填{stock}: {sres}")
    return {"ok": True, "built": built}

async def batch_sku_image(form, image_path):
    """SKU预览图:批量把真实主图喂给游离SKU图口(逐色精确绑是后续,先批量)。"""
    try:
        idxs = await form.evaluate(r"""()=>[...document.querySelectorAll('input[type=file]')].map((f,i)=>{let ctx='?';let p=f;for(let k=0;k<12&&p;k++){const t=(p.innerText||'').replace(/\s+/g,'');if(/轮播|主图/.test(t)){ctx='轮播';break;}if(/包装标签/.test(t)){ctx='包装标签';break;}p=p.parentElement;}return{i,a:(f.accept||''),ctx};}).filter(o=>o.a.includes('image')&&o.ctx==='?').map(o=>o.i)""")
        hs = await form.query_selector_all("input[type=file]"); n = 0
        for i in idxs:
            if i < len(hs):
                try: await hs[i].set_input_files(image_path); await asyncio.sleep(1); n += 1
                except Exception: pass
        return n
    except Exception:
        return 0


async def uncheck_net_content(form):
    """重建前先取消勾选「净含量」属性。否则净含量(勾着,值"100g")会再生成一个净含量SKU维 →
    又变回 净含量×款式,且"100g"非纯数字 → PDD 报「需是数值类型」拒提交(实测候选不取消就栽这)。
    净含量勾选框是 beast-core 自定义控件(非真 input[type=checkbox]),按 input 找不到 →
    改:定位净含量【值框】(值=数字+单位),点它【左侧约22px】(勾选框的视觉位置)。dump 结构兜底。"""
    await asyncio.sleep(0.6)   # reset 后让页面稳一下
    try:
        # 探针实测的真实结构:净含量值框(input[value=100g])与勾选框 label[data-testid=beast-core-checkbox]
        # 同在一个容器里(checkbox 是值框的【兄弟】不是祖先)→ 从值框上溯到"含 checkbox 的容器",
        # 取里面已勾选(data-checked=true)的 checkbox 的 CBX_square 视觉框中心坐标。
        coords = await form.evaluate(r"""()=>{
            const UNIT=/^\s*\d+(?:\.\d+)?\s*(g|mg|kg|ml|mL|ML|l|L|片)\s*$/;
            const out=[];
            for(const inp of document.querySelectorAll('input[data-testid="beast-core-input-htmlInput"]')){
                if(!UNIT.test((inp.value||'').trim())) continue;     // 净含量值框 100g/50mL…
                let cont=inp, cb=null;
                for(let k=0;k<8&&cont.parentElement;k++){
                    cont=cont.parentElement;
                    cb=cont.querySelector('label[data-testid="beast-core-checkbox"]');
                    if(cb) break;
                }
                if(!cb) continue;
                if(cb.getAttribute('data-checked')!=='true') continue;  // 已没勾就不点
                const sq=cb.querySelector('[class*="CBX_square"]')||cb;
                sq.scrollIntoView({block:'center'});                    // ★先滚进视口,否则坐标在屏外点空
                const r=sq.getBoundingClientRect();
                if(r.width>0&&r.height>0) out.push({x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2),val:inp.value});
            }
            return out;
        }""")
        coords = coords or []
        if not coords:
            print("[智能SKU] 取消净含量:没找到已勾选的净含量(可能已取消)")
            return 0
        for c in coords:
            await form.mouse.click(c["x"], c["y"]); await asyncio.sleep(0.6)
            print(f"[智能SKU] 取消勾选净含量 {c['val']} @({c['x']},{c['y']})")
        return len(coords)
    except Exception as e:
        print(f"[智能SKU] 取消净含量异常(跳过): {e}")
        return 0


async def _build_skus(form, names, image_path, stock):
    """清空旧规格 → 建单维「款式」→ 填 names(已是最终SKU名)→ 批量传图 → 填库存。
    返回 {ok, built}。"""
    if not await reset_specs(form):
        print("[智能SKU] 清空旧规格失败 → 停止重建,避免残留两层规格")
        return {"ok": False, "built": [], "reason": "reset-fail"}
    after = await form.evaluate(DIMS_JS)
    if not after["dims"]:
        await (_click_text(form, "添加规格类型", exact=False) or _click_text(form, "添加定制规格"))
        await asyncio.sleep(1.2)
    picked = await set_dim_type(form, "款式")   # 净含量维还在时 set_dim_type 能工作(把维改成款式)
    print(f"[智能SKU] 规格类型选: {picked}")
    if not picked:
        fb = await _build_skus_fallback(form, names, image_path, stock)
        if fb.get("ok"):
            return fb
        return {"ok": False, "built": fb.get("built", []), "fallback": fb}
    for nm in names:
        await add_value(form, nm)
        await asyncio.sleep(0.4)
    # ★ 款式建好后【再】取消勾选净含量,去掉残留的净含量维(此时不影响 set_dim_type)→ 只剩干净款式
    await uncheck_net_content(form)
    await asyncio.sleep(0.8)
    db = await form.evaluate(DIMS_JS)
    built = [v["v"] for x in db["dims"] for v in x["values"]]
    ok = (set(built) == set(names)) and db["priceRows"] == len(names)
    print(f"[智能SKU] 建成: {built}  rows={db['priceRows']}  ok={ok}")
    if not ok:
        fb = await _build_skus_fallback(form, names, image_path, stock)
        if fb.get("ok"):
            return fb
        return {"ok": False, "built": built, "fallback": fb}
    n_img = await batch_sku_image(form, image_path)
    print(f"[智能SKU] SKU图(批量): {n_img}")
    sres = await form.evaluate(STOCK_FILL_JS, int(stock))   # 逐行按列x填库存(proven,不漏)
    print(f"[智能SKU] 库存填{stock}: {sres}")
    return {"ok": True, "built": built}


async def rebuild_from_form(form, title, image_path, stock, judged_rows=None, suffix=""):
    """读表单现有SKU → 大模型整理(剔防比价搭配/赠品、剔违禁词、留主产品、不重复加数量、给份数)→ 删掉重建。
    返回 {ok,names,units_map}。★含赠/送/买一送一(banned)与不含的,都走 cloud_rebuild_skus;云端没出才回落老正则。
    judged_rows 参数保留兼容,但不再单独走老 design 路(那条会强制加数量量词→'1瓶体验装1瓶'这种重复)。"""
    # ★主用大模型:从原始SKU名识别【主产品】、剔搭配/赠品/违禁词、不重复加数量、给份数(实测准;老正则会把"面膜"误当赠品)。
    names_raw = await read_current_specs(form)
    skus = []
    if names_raw:
        try:
            skus = cloud_rebuild_skus(names_raw, title)
        except Exception as e:
            print(f"[智能SKU] 云端重建提取异常→回落正则: {e}")
            skus = []
    # ★同名不同份的款各保留(治 970201123244:1支/2支被压成1个);seen 给下方正则回落路续用
    names, units_map = _dedupe_rebuilt_skus(skus)
    # 只保护明显真实变体序列:编号色号(01#...)或【香味/款名】列表被云端压少时回落。
    # 搭配赠品类(撕拉面膜+芦荟胶...)允许合并成真实SKU键,不能再用输入数量硬拦。
    _raws = [str(x or "") for x in (names_raw or [])]
    _coded = [x for x in _raws if re.match(r"^\s*\d+\s*#", x)]
    _bracketed = [x for x in _raws if re.match(r"^\s*[【\[][^】\]]+[】\]]", x)]
    _need_count_guard = (len(_coded) >= 2 and len(_coded) == len(_raws)) or (len(_bracketed) >= 2 and len(_bracketed) == len(_raws))
    if _need_count_guard and len(names) < len(_raws):
        print(f"[智能SKU] 云端输出 {len(names)} 条少于真实变体 {len(_raws)} 条 → 判定过度合并,回落逐项重建")
        names, units_map = [], {}
    seen = set(names)
    if names:
        print(f"[智能SKU] 云端重建(剔搭配/留主产品): 款式值={names} 份数={units_map}")
    else:
        # ── 回落:老正则抽款式 + design_custom_skus(大模型没出/异常时兜底) ──
        ext = await extract_variants_from_form(form)
        variants = ext["variants"]
        print(f"[智能SKU] 云端没出→回落正则抽款式({len(variants)}个): {variants}")
        if not variants:
            return {"ok": False, "names": [], "units_map": {}, "reason": "no-variants"}
        try:
            design = design_custom_skus(variants, title)
        except Exception as e:
            print(f"[智能SKU] 文案设计异常→回落: {e}")
            design = []
        for it in (design or []):
            _u = int(it.get("units") or 1)
            nm = clean_spec_value(it.get("name", ""))
            if nm and _has_banned(nm):           # 云端没躲开「赠/送」→ 兜底改写成干净「N量词装」
                nm = clean_spec_value(_clean_rebuilt_name(it.get("name", ""), _u))
            nm = _format_capacity_count_name(_dedupe_count_word(nm))  # 300g 2瓶→300g*2瓶
            if not nm or nm in seen:
                continue
            seen.add(nm); names.append(nm); units_map[nm] = _u
        if not names:   # design 也没出 → 多色用真色名各1份;单规格1/2/3份
            for v in (variants if len(variants) > 1 else ["1份", "2份", "3份"]):
                _u = _infer_units(v)
                nm = clean_spec_value(v)
                if nm and _has_banned(nm):
                    nm = clean_spec_value(_clean_rebuilt_name(v, _u))
                nm = _format_capacity_count_name(_dedupe_count_word(nm))
                if nm and nm not in seen:
                    seen.add(nm); names.append(nm); units_map[nm] = _u
    if suffix:   # ★重建时直接把防比价后缀拼进名字 → 二次编辑 append_spec_suffix 会自动跳过(幂等),省一轮编辑
        names = [n + suffix for n in names]
        units_map = {k + suffix: v for k, v in units_map.items()}
    print(f"[智能SKU] 重建: 款式值={names}  份数={units_map}")
    rb = await _build_skus(form, names, image_path, stock)
    return {"ok": rb["ok"], "names": names, "units_map": units_map, "built": rb.get("built")}


async def fill_stock(form, stock):
    return await form.evaluate(STOCK_FILL_JS, int(stock))
