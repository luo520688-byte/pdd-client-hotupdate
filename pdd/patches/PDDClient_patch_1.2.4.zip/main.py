"""
磁力金牛爆品数据抓取系统 v3
目标：美妆 / 美容护肤 / 个护清洁，过滤首次上架日期在5月的产品
固定筛选：载体类型=短视频，售卖渠道=货主自卖
"""

import sys
# GUI 进程(pythonw,无控制台)sys.stdout 为 None → 加保护,否则被 client 导入时崩
if sys.stdout is not None:
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

import asyncio
import json
import os
import random
import re
import traceback
from datetime import datetime
from pathlib import Path

from playwright.async_api import async_playwright

from report import generate_excel, generate_html_report

TARGET_URL = "https://jinfu.e.kuaishou.com/cyd-client/best-seller?__staffId__=80207551"
DATA_DIR = Path("D:/files/data")
DATA_DIR.mkdir(exist_ok=True)
LOGIN_CONFIG_PATH = DATA_DIR / "jinfu_login.json"
UPDATE_BACKUP_DIR = Path(__file__).resolve().parent / "updates" / "backups"


def _normalize_login_credentials(payload) -> tuple[str, str] | None:
    if not isinstance(payload, dict):
        return None
    phone = str(payload.get("phone") or "").strip()
    password = str(payload.get("password") or "").strip()
    return (phone, password) if phone and password else None


def _extract_legacy_login_credentials(source: str) -> tuple[str, str] | None:
    """从更新器保存的旧 main.py 中迁移凭据；不输出、不上传凭据。"""
    phone = re.search(r"(?m)^PHONE\s*=\s*(['\"])(.*?)\1\s*$", str(source or ""))
    password = re.search(r"(?m)^PASSWORD\s*=\s*(['\"])(.*?)\1\s*$", str(source or ""))
    if not phone or not password:
        return None
    values = (phone.group(2).strip(), password.group(2).strip())
    return values if all(values) else None


def _save_login_credentials(phone: str, password: str, path: Path = LOGIN_CONFIG_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"phone": phone, "password": password}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_login_credentials(
        config_path: Path = LOGIN_CONFIG_PATH,
        backup_root: Path = UPDATE_BACKUP_DIR) -> tuple[str, str]:
    """环境变量优先，其次受保护配置，最后从热更新备份自动迁移。"""
    env_values = _normalize_login_credentials({
        "phone": os.environ.get("JINFU_PHONE", ""),
        "password": os.environ.get("JINFU_PASSWORD", ""),
    })
    if env_values:
        return env_values
    try:
        saved = _normalize_login_credentials(
            json.loads(config_path.read_text(encoding="utf-8-sig")))
        if saved:
            return saved
    except Exception:
        pass
    try:
        backups = sorted(
            backup_root.glob("*/main.py"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
    except Exception:
        backups = []
    for backup in backups:
        try:
            migrated = _extract_legacy_login_credentials(
                backup.read_text(encoding="utf-8-sig", errors="ignore"))
        except Exception:
            migrated = None
        if migrated:
            _save_login_credentials(*migrated, path=config_path)
            print(f"  [登录配置] 已从本机更新备份迁移到 {config_path}")
            return migrated
    raise RuntimeError(
        f"磁力金牛登录配置缺失。请创建 {config_path}，填写 phone 和 password；"
        "或设置环境变量 JINFU_PHONE / JINFU_PASSWORD。")

_ALL_CATEGORIES = {
    "美妆": ("美妆",   "美妆"),
    "个护": ("个护",   "个护清洁"),
    "护肤": ("护肤",   "美容护肤"),
}

# 支持客户端通过环境变量传入参数
_env_cats = os.environ.get("SELECTED_CATS", "")
TARGET_CATEGORIES = (
    [_ALL_CATEGORIES[c] for c in _env_cats.split(",") if c in _ALL_CATEGORIES]
    if _env_cats else list(_ALL_CATEGORIES.values())
)
TEST_MODE   = os.environ.get("TEST_MODE", "0") == "1"
TEST_COMBOS = int(os.environ.get("TEST_COMBOS", "0"))  # 0=不限制
# 统计周期：今天/昨天/近7天/近14天/近30天（默认今天 = 平台默认值）
STATISTIC_PERIOD = os.environ.get("STATISTIC_PERIOD", "今天")

# 是否只扫描类目树（不抓数据）
DISCOVER_ONLY = "--discover-only" in sys.argv
# 恢复模式：从已有数据文件生成报表，不启动浏览器
RECOVER_MODE  = "--recover" in sys.argv

# 客户端直接传入指定的三级类目组合（格式: "美妆>彩妆>口红,美妆>香水>女士香水"）
def _parse_selected_combos(raw: str) -> list:
    """解析客户端类目任务；单段 L1 表示运行时自动发现其二/三级类目。"""
    parsed = []
    if raw:
        for _cs in raw.split(","):
            _cs = _cs.strip()
            if not _cs:
                continue
            _parts = [p.strip() for p in _cs.split(">") if p.strip()]
            if len(_parts) >= 3:
                parsed.append((_parts[0], _parts[1], _parts[2]))
            elif len(_parts) == 2:
                parsed.append((_parts[0], _parts[1], None))
            elif len(_parts) == 1:
                parsed.append((_parts[0], None, None))
    return parsed


_env_combos = os.environ.get("SELECTED_COMBOS", "")
SELECTED_COMBOS_LIST: list = _parse_selected_combos(_env_combos)

collected_products = []
# 本次 main.py 启动的固定时间戳,所有进度文件都用同一个 ts
# 这样中途崩溃也保住数据(products_<RUN_TS>.json 已经持续在写)
RUN_TS = datetime.now().strftime("%Y%m%d_%H%M%S")
seen_ids = set()


# ─── 人工模拟 ──────────────────────────────────────────────────────────────────

async def human_click(page, locator):
    box = await locator.bounding_box()
    if not box:
        return
    x = box["x"] + box["width"] / 2
    y = box["y"] + box["height"] / 2
    await page.mouse.move(x - 20, y - 10)
    await asyncio.sleep(0.2)
    await page.mouse.move(x, y)
    await asyncio.sleep(0.15)
    await page.mouse.click(x, y)


async def human_type(page, text):
    for ch in text:
        await page.keyboard.type(ch)
        await asyncio.sleep(random.uniform(0.08, 0.18))


# ─── 登录 ─────────────────────────────────────────────────────────────────────

async def auto_login(page):
    # 等待 JS 重定向完成（最多 5 秒），再判断是否需要登录
    for _ in range(10):
        await asyncio.sleep(0.5)
        if "/cyd-client/best-seller" not in page.url or "welcome" in page.url:
            break  # 已跳转到登录页，停止等待

    print(f"  当前页面: {page.url}")

    # 如果还在目标页面，说明 session 有效，无需登录
    if "/cyd-client/best-seller" in page.url and "welcome" not in page.url:
        print("  Session 有效，已在目标页面，跳过登录")
        return

    phone, password = load_login_credentials()

    # 点击"立即登录"
    try:
        btn = page.locator("text=立即登录").first
        await btn.wait_for(state="visible", timeout=8000)
        await human_click(page, btn)
        print("  已点击: 立即登录")
        await asyncio.sleep(3)
    except Exception as e:
        print(f"  [!] 未找到立即登录按钮: {e}")

    # 如果是 QR 码界面，尝试切换到密码登录
    for switch_text in ["密码登录", "账号密码登录", "手机号登录"]:
        try:
            sw = page.locator(f"text={switch_text}").first
            if await sw.is_visible(timeout=2000):
                await human_click(page, sw)
                print(f"  已切换到: {switch_text}")
                await asyncio.sleep(1.5)
                break
        except Exception:
            pass

    # 填入手机号
    try:
        phone_input = page.locator("input[placeholder='请输入手机号/邮箱']").first
        await phone_input.wait_for(state="visible", timeout=8000)
        await human_click(page, phone_input)
        await asyncio.sleep(0.3)
        await phone_input.fill("")
        await human_type(page, phone)
        await asyncio.sleep(0.5)
        print("  已填入登录账号")
    except Exception as e:
        print(f"  [!] 填入账号失败: {e}")

    # 填入密码
    try:
        pwd_input = page.locator("input[placeholder='请输入密码']").first
        await pwd_input.wait_for(state="visible", timeout=5000)
        await human_click(page, pwd_input)
        await asyncio.sleep(0.3)
        await pwd_input.fill("")
        await human_type(page, password)
        await asyncio.sleep(0.5)
        print("  已填入密码")
    except Exception as e:
        print(f"  [!] 填入密码失败: {e}")

    # 点击登录按钮（多种候选文字）
    clicked = False
    for btn_text in ["快手APP账号授权登录", "登录", "确认登录"]:
        try:
            lb = page.locator(f"button:has-text('{btn_text}')").first
            if await lb.is_visible(timeout=2000):
                await human_click(page, lb)
                print(f"  已点击登录按钮: {btn_text}")
                clicked = True
                break
        except Exception:
            pass
    if not clicked:
        print("  [!] 未找到登录按钮，尝试按回车")
        await page.keyboard.press("Enter")

    # 等待登录完成（最多 60 秒）。两种成功信号都认,别死等 best-seller 那一个网址:
    #   ① 已经在 best-seller 目标页 → 直接成功;
    #   ② 登录框(密码输入框)已消失 = 已登录但落在了别的子页 → 立刻导到目标页,不再傻等满 60 秒。
    print("  等待跳转到目标页面（最多60秒）...")
    for i in range(60):
        await asyncio.sleep(1)
        if "/cyd-client/best-seller" in page.url and "welcome" not in page.url:
            print(f"  登录成功！({i+1}s)")
            return
        if i >= 4 and "welcome" not in page.url:   # 给登录提交几秒处理,再看登录框在不在
            try:
                form_gone = not await page.locator("input[placeholder='请输入密码']").first.is_visible(timeout=400)
            except Exception:
                form_gone = True                    # 登录框已被销毁/页面已跳走 = 已登录
            if form_gone:
                print(f"  已登录(登录框消失,{i+1}s)→ 导到目标页…")
                await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(2)
                print(f"  导航后页面: {page.url}")
                return
        if i % 15 == 14:
            print(f"  仍在等待... ({i+1}s) url={page.url[:80]}")

    # 超时后强制导航
    print("  登录超时，强制导航到目标页面...")
    await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
    await asyncio.sleep(5)
    print(f"  导航后页面: {page.url}")


# ─── 关闭弹窗 ─────────────────────────────────────────────────────────────────

async def close_popup(page, max_rounds: int = 3):
    """
    扫描并关闭所有可见弹窗/公告，最多尝试 max_rounds 轮。
    每轮遍历候选按钮文字，成功关闭一个后再循环检测是否还有弹窗。
    """
    # 优先精确匹配按钮，避免误点页面正文里的同名文字
    btn_selectors = [
        "button:has-text('知道了')",
        "button:has-text('我知道了')",
        "button:has-text('关闭')",
        "[role='button']:has-text('知道了')",
        "[role='button']:has-text('关闭')",
        ".agent-modal button",          # modal 内任意按钮（兜底）
        ".agent-modal-close",           # 右上角 × 按钮
        "button:has-text('×')",
        "button:has-text('✕')",
        "text=知道了",                  # 纯文字兜底
        "text=关闭",
        "text=×",
        "text=Close",
    ]
    for _ in range(max_rounds):
        closed = False
        for sel in btn_selectors:
            try:
                el = page.locator(sel).first
                if await el.is_visible(timeout=800):
                    txt = (await el.inner_text(timeout=500)).strip()[:10]
                    await human_click(page, el)
                    await asyncio.sleep(0.8)
                    print(f"  已关闭弹窗: {txt or sel}")
                    closed = True
                    break
            except Exception:
                pass
        if not closed:
            break   # 本轮没关到，说明已没有弹窗
        await asyncio.sleep(0.3)


# ─── 设置下拉筛选 ─────────────────────────────────────────────────────────────

async def set_statistic_period(page, period_text: str = "今天") -> bool:
    """设置统计周期（今天/昨天/近7天/近14天/近30天）。
    流程：找「统计周期」label → 点右侧日期框打开 picker → 点对应快捷按钮。
    """
    await close_popup(page)
    print(f"  [统计周期] 设置为「{period_text}」")
    # 1) 找 label，点其右侧打开 picker
    label_info = await page.evaluate("""() => {
        for (const el of document.querySelectorAll('*')) {
            if (el.children.length === 0 && el.innerText && el.innerText.trim() === '统计周期') {
                const r = el.getBoundingClientRect();
                if (r.width > 0)
                    return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height)};
            }
        }
        return null;
    }""")
    if not label_info:
        print(f"  [!] 未找到「统计周期」label")
        return False
    # 点 label 右侧 ~40px 处（日期输入框中心）
    await page.mouse.click(label_info['x'] + label_info['w'] + 40,
                           label_info['y'] + label_info['h']//2)
    await asyncio.sleep(1.5)
    # 2) 找快捷按钮坐标（不直接 .click()——很多自定义 picker 不响应 JS click）
    pos = await page.evaluate(f"""() => {{
        // 优先找 li.agent-picker-preset 里的 span
        for (const li of document.querySelectorAll('li.agent-picker-preset')) {{
            if ((li.innerText || '').trim() === {period_text!r}) {{
                const r = li.getBoundingClientRect();
                if (r.width > 0 && r.height > 0)
                    return {{x: Math.round(r.x + r.width/2), y: Math.round(r.y + r.height/2)}};
            }}
        }}
        return null;
    }}""")
    if not pos:
        print(f"  [!] 未找到「{period_text}」快捷按钮"); return False
    # 用真实鼠标点击触发 picker 选择
    await page.mouse.click(pos['x'], pos['y'])
    print(f"  [统计周期] 鼠标点击 ({pos['x']},{pos['y']})")
    await asyncio.sleep(2)
    return True


async def set_dropdown(page, label_text, option_text):
    """通用筛选设置：兼容 radio 单选组（新版）/ select 下拉框（旧版）。
    策略：
      1. 找 label 文字元素（叶节点，innerText === label_text）
      2. 在其右侧+下方 450px、宽 ≤ 800px 范围内搜索 option_text 元素
      3. 优先匹配 input[type=radio][value=option_text]（最稳）
      4. 否则匹配文字精确等于 option_text 的 LABEL/SPAN/DIV
      5. 兜底走老下拉框流程（.agent-select-selector + .agent-select-item）
    """
    await close_popup(page)
    # 策略 1+2+3+4：直接找 option 元素并点击
    try:
        target = await page.evaluate(f"""() => {{
            const labelText = {label_text!r};
            const optionText = {option_text!r};
            // 找 label
            let labelEl = null;
            for (const el of document.querySelectorAll('*')) {{
                if (el.children.length === 0 && el.innerText && el.innerText.trim() === labelText) {{
                    labelEl = el; break;
                }}
            }}
            if (!labelEl) return null;
            const lr = labelEl.getBoundingClientRect();
            // 区域：label 右侧/下方 450px
            const minX = lr.left, maxX = lr.left + 850;
            const minY = lr.top - 20, maxY = lr.top + 450;
            // 3.1 优先：input[type=radio][value=optionText]
            for (const inp of document.querySelectorAll('input[type=radio]')) {{
                if (inp.value === optionText) {{
                    let p = inp.closest('label') || inp.parentElement;
                    if (!p) continue;
                    const r = p.getBoundingClientRect();
                    if (r.left >= minX - 10 && r.left <= maxX && r.top >= minY && r.top <= maxY) {{
                        p.scrollIntoView({{block:'center'}});
                        const rr = p.getBoundingClientRect();
                        return {{x: Math.round(rr.left + rr.width/2), y: Math.round(rr.top + rr.height/2), via: 'radio[value]'}};
                    }}
                }}
            }}
            // 3.2 文字精确等于的 LABEL/SPAN/DIV/A/BUTTON（叶节点优先）
            const candidates = [];
            for (const el of document.querySelectorAll('label, span, div, a, button, li')) {{
                if (el.innerText && el.innerText.trim() === optionText) {{
                    const r = el.getBoundingClientRect();
                    if (r.width < 30 || r.width > 250 || r.height < 16 || r.height > 80) continue;
                    if (r.left < minX - 10 || r.left > maxX || r.top < minY || r.top > maxY) continue;
                    // label 优先（包含 input）
                    const score = el.tagName === 'LABEL' ? 0 : (el.tagName === 'SPAN' ? 1 : 2);
                    candidates.push({{el, score, r}});
                }}
            }}
            candidates.sort((a,b) => a.score - b.score);
            if (candidates.length > 0) {{
                const {{el, r}} = candidates[0];
                // 如果是 span，向上找 label 父级
                let p = el;
                if (el.tagName === 'SPAN') {{
                    const lb = el.closest('label');
                    if (lb) p = lb;
                }}
                p.scrollIntoView({{block:'center'}});
                const rr = p.getBoundingClientRect();
                return {{x: Math.round(rr.left + rr.width/2), y: Math.round(rr.top + rr.height/2), via: 'text-match'}};
            }}
            return null;
        }}""")

        if target:
            await page.mouse.click(target['x'], target['y'])
            await asyncio.sleep(1.0)
            print(f"  已设置 {label_text} = {option_text}  (via {target['via']})")
            return True
    except Exception as e:
        print(f"  [!] 通用匹配异常: {e}")

    # 策略 5：兜底走老版下拉框流程
    print(f"  [兜底] 尝试老版下拉框路径")
    try:
        coords = await page.evaluate(f"""() => {{
            const all = Array.from(document.querySelectorAll('*'));
            let labelRect = null;
            for (const el of all) {{
                if (el.children.length === 0 && el.innerText && el.innerText.trim() === '{label_text}') {{
                    labelRect = el.getBoundingClientRect();
                    break;
                }}
            }}
            if (!labelRect) return null;
            const selectors = document.querySelectorAll('.agent-select-selector');
            let best = null, bestDist = Infinity;
            for (const sel of selectors) {{
                const r = sel.getBoundingClientRect();
                if (Math.abs(r.top - labelRect.top) < 30 && r.left >= labelRect.right - 5) {{
                    const dist = r.left - labelRect.right;
                    if (dist < bestDist) {{ bestDist = dist; best = sel; }}
                }}
            }}
            if (!best) return null;
            best.scrollIntoView({{block:'center', behavior:'instant'}});
            const r = best.getBoundingClientRect();
            return {{ x: r.left + r.width / 2, y: r.top + r.height / 2 }};
        }}""")
        if not coords:
            print(f"  [!] 未找到 {label_text} 对应的元素")
            return False
        await page.mouse.click(coords["x"], coords["y"])
        await asyncio.sleep(2.5)
        opt = page.locator(f".agent-select-item:has-text('{option_text}')").first
        if await opt.is_visible(timeout=6000):
            await human_click(page, opt)
            await asyncio.sleep(1.0)
            print(f"  已设置 {label_text} = {option_text}  (via 老下拉)")
            return True
        await page.keyboard.press("Escape")
        return False
    except Exception as e:
        print(f"  设置 {label_text} 失败: {e}")
        return False


# ─── 发现类目树 ───────────────────────────────────────────────────────────────

async def click_cascader_item_exact(page, menu_nth, text):
    """在第 menu_nth 个 cascader 面板中，用 JS 精确点击文字为 text 的项"""
    clicked = await page.evaluate(f"""(nth) => {{
        const menus = document.querySelectorAll('.agent-cascader-menu');
        if (!menus[nth]) return false;
        const items = menus[nth].querySelectorAll(
            '.agent-cascader-menu-item-content, .agent-cascader-menu-item'
        );
        for (const item of items) {{
            if (item.innerText.trim() === '{text}') {{
                item.scrollIntoView({{block:'center', behavior:'instant'}});
                item.click();
                return true;
            }}
        }}
        // 模糊兜底：contains
        for (const item of items) {{
            if (item.innerText.includes('{text}')) {{
                item.scrollIntoView({{block:'center', behavior:'instant'}});
                item.click();
                return true;
            }}
        }}
        return false;
    }}""", menu_nth)
    if not clicked:
        print(f"  [!] JS未找到cascader第{menu_nth}级菜单项: {text!r}")
    await asyncio.sleep(0.4)


async def discover_category_tree(page, l1_text) -> list:
    """
    打开 cascader，点击 L1，遍历每个 L2（点击后读 L3），Escape 关闭不提交。
    返回 [(l1, l2, l3), ...] 列表，l3 为 None 表示该 L2 无三级。
    """
    tree = []

    await human_click(page, page.locator(".agent-cascader .agent-select-selector").first)
    await asyncio.sleep(1.5)

    # 精确点击一级
    await click_cascader_item_exact(page, 0, l1_text)
    await asyncio.sleep(1.5)

    # 检查 L2 菜单是否出现
    try:
        await page.locator(".agent-cascader-menu").nth(1).wait_for(
            state="visible", timeout=6000
        )
    except Exception:
        print(f"  [!] L2菜单未出现，cascader可能未展开，跳过")
        await page.keyboard.press("Escape")
        return tree

    # 验证 L2 内容是否合理
    try:
        l2_sample = await page.locator(".agent-cascader-menu").nth(1).locator(
            ".agent-cascader-menu-item-content").first.inner_text(timeout=5000)
        print(f"  L2第一项: {l2_sample.strip()!r}")
    except Exception as e:
        print(f"  [!] 读取L2第一项失败: {e}")
        await page.keyboard.press("Escape")
        return tree

    # 读所有二级项（不含"全部"）
    l2_menu = page.locator(".agent-cascader-menu").nth(1)
    l2_els = await l2_menu.locator(".agent-cascader-menu-item-content").all()
    l2_texts = []
    for el in l2_els:
        try:
            t = (await el.inner_text(timeout=3000)).strip()
            if t and t != "全部":
                l2_texts.append(t)
        except Exception:
            pass

    print(f"  L2 发现 {len(l2_texts)} 个: {l2_texts}")

    # 对每个二级，点击后读三级
    for l2_text in l2_texts:
        await click_cascader_item_exact(page, 1, l2_text)
        await asyncio.sleep(0.8)

        menus = page.locator(".agent-cascader-menu")
        count = await menus.count()
        if count >= 3:
            l3_els = await menus.nth(2).locator(".agent-cascader-menu-item-content").all()
            l3_texts = []
            for el in l3_els:
                try:
                    t = (await el.inner_text(timeout=3000)).strip()
                    if t and t != "全部":
                        l3_texts.append(t)
                except Exception:
                    pass
            if l3_texts:
                for l3_text in l3_texts:
                    tree.append((l1_text, l2_text, l3_text))
            else:
                tree.append((l1_text, l2_text, None))
        else:
            tree.append((l1_text, l2_text, None))

    # Escape 关闭，不提交选择
    await page.keyboard.press("Escape")
    await asyncio.sleep(0.5)
    return tree


async def discover_category_tree_retry(page, l1_text, attempts=3, retry_delay=1.0) -> list:
    """类目弹层偶发不展开时重试，避免一次空结果让整个一级类目永久不可选。"""
    for attempt in range(1, max(1, attempts) + 1):
        combos = await discover_category_tree(page, l1_text)
        if combos:
            if attempt > 1:
                print(f"  [OK] {l1_text} 第{attempt}次扫描成功")
            return combos
        if attempt < attempts:
            print(f"  [!] {l1_text} 第{attempt}次扫描为空，准备重试")
            try:
                await page.keyboard.press("Escape")
            except Exception:
                pass
            await asyncio.sleep(max(0, retry_delay))
    return []


# ─── 三级类目选择 ─────────────────────────────────────────────────────────────

async def clear_cascader_selection(page) -> bool:
    """清除 cascader 当前选中,让显示回到「请选择」。
    若已是空态直接返回 True。失败不抛错,带状态继续。

    实现:用键盘 Backspace 逐个删除已选 tag。这是 antd 多选组件的原生交互,
    比点击 × 清除按钮更稳 —— 之前测试发现点 × 会让 cascader 内部 React state
    损坏,虽然 DOM 显示「请选择」但后续 L1/L2/L3 click 全部失效。
    Backspace 走原生键盘事件,不破坏状态机。
    """
    sel = page.locator(".agent-cascader .agent-select-selector").first
    try:
        shown_before = (await sel.inner_text(timeout=1500)).strip()
    except Exception:
        shown_before = ""
    if "请选择" in shown_before or not shown_before:
        return True

    # 点 cascader selector 让它聚焦(antd 多选会弹出下拉,后续按键操作有效)
    try:
        box = await sel.bounding_box()
        if box:
            await page.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
        await asyncio.sleep(0.6)
    except Exception:
        pass

    # 逐个 Backspace 删除已选 tag(每次删最后一个,直到显示「请选择」)
    deleted = 0
    for _ in range(20):  # 最多删 20 个,够用了
        try:
            await page.keyboard.press("Backspace")
            await asyncio.sleep(0.25)
        except Exception:
            break
        deleted += 1
        try:
            shown = (await sel.inner_text(timeout=800)).strip()
            if "请选择" in shown or not shown:
                break
        except Exception:
            pass

    # 关闭可能仍打开的下拉
    try:
        await page.keyboard.press("Escape")
        await asyncio.sleep(0.3)
        await page.mouse.move(10, 10)
        await asyncio.sleep(0.2)
    except Exception:
        pass

    # 等弹层真正消失
    try:
        for _ in range(6):
            menu_cnt = await page.locator('.agent-cascader-menu').count()
            if menu_cnt == 0:
                break
            try:
                visible = await page.locator('.agent-cascader-menu').first.is_visible(timeout=300)
                if not visible:
                    break
            except Exception:
                pass
            await asyncio.sleep(0.25)
    except Exception:
        pass

    # 验证
    try:
        shown_after = (await sel.inner_text(timeout=1500)).strip()
        if "请选择" in shown_after or not shown_after:
            print(f"  [清除] 上轮选择已清空(Backspace x{deleted}): {shown_before[:30]!r} → 请选择")
            return True
        print(f"  [!] Backspace x{deleted} 后仍有残留: {shown_after[:40]!r}")
    except Exception:
        pass
    print(f"  [!] 未能清除上轮选择(当前: {shown_before[:30]!r}),将带状态继续")
    return False


async def commit_cascader_selection(page, expected: str) -> bool:
    """多选 cascader 点击 L3 叶子不会自动 commit,需要显式触发。
    按 3 种方式逐个尝试,任一让 cascader 显示文本包含 expected 即成功。
    每次尝试都打日志,方便后续删减无效分支。
    """
    sel = page.locator(".agent-cascader .agent-select-selector").first

    async def verify() -> bool:
        try:
            shown = (await sel.inner_text(timeout=1500)).strip()
            ok = expected in shown
            print(f"  [commit-verify] cascader={shown[:40]!r}  含「{expected}」={ok}")
            return ok
        except Exception:
            return False

    # 方式1:找弹层底部「确定」按钮(antd cascader 多选版常有)
    clicked = await page.evaluate("""() => {
        const buttons = Array.from(document.querySelectorAll('button, [role="button"]'));
        const candidates = buttons.filter(b => {
            const t = (b.innerText || '').trim();
            if (t !== '确定' && t !== '确认' && t !== 'OK') return false;
            const r = b.getBoundingClientRect();
            return r.width > 0 && r.height > 0 && r.y > 100;
        });
        if (!candidates.length) return false;
        // 取 y 最大的(弹层底部),避免误点页面其它「确定」按钮
        candidates.sort((a, b) => b.getBoundingClientRect().y - a.getBoundingClientRect().y);
        candidates[0].click();
        return true;
    }""")
    if clicked:
        print(f"  [commit] 方式1:点击底部「确定」按钮")
        await asyncio.sleep(1.0)
        if await verify():
            return True

    # 方式2:再次点击 cascader 选择器自身(关闭弹层 + commit 多选)
    try:
        box = await sel.bounding_box()
        if box:
            await page.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
            print(f"  [commit] 方式2:再次点击 cascader 自身关闭弹层")
            await asyncio.sleep(1.0)
            if await verify():
                return True
    except Exception:
        pass

    # 方式3:Tab 键让焦点离开
    try:
        await page.keyboard.press("Tab")
        print(f"  [commit] 方式3:Tab 键离开焦点")
        await asyncio.sleep(0.8)
        if await verify():
            return True
    except Exception:
        pass

    # 兜底:Escape 关弹层,避免遮挡后续筛选
    try:
        await page.keyboard.press("Escape")
    except Exception:
        pass
    return False


async def select_category_3level(page, l1_text, l2_text, l3_text):
    """用 cascader 搜索输入选择三级类目,绕开 L1→L2→L3 菜单导航的复杂性。

    根因:三级菜单点击路径有 render race condition —— JS item.click() 能写入
    selection(L3 active class 出现)但 cascader 不重渲染完整 tag,显示成 "+ 0 ..."
    而非「防晒霜 ×」。且对窗口尺寸/弹层位置敏感(窗口太小弹层超视口)。

    实测可靠路径(已在用户浏览器中端到端验证):
    1. click cascader selector → 进入输入态(input 获得焦点)
    2. Backspace × N → 清空之前所有已选 tag(每按一次删一个 tag)
    3. keyboard.type 三级类目名 → 触发搜索,下拉显示精确匹配项
    4. click 下拉结果项("L1 / L2 / L3" 格式文本) → 加入 selection
    5. 真实外部点击(5,5) → 关闭弹层 + 触发完整 tag 渲染
    """
    await close_popup(page)   # 切类目前先扫弹窗
    expected = l3_text or l2_text
    search_text = l3_text or l2_text
    expected_path = (f"{l1_text} / {l2_text} / {l3_text}" if l3_text
                     else f"{l1_text} / {l2_text}")

    sel = page.locator(".agent-cascader .agent-select-selector").first
    search_input = page.locator(".agent-cascader .agent-select-selection-search-input").first

    for attempt in range(2):
        # 1) 直接 click 内部 search input 让它获得焦点
        #    (不点 selector 中心,避免命中已选 tag 上的 × 删除按钮)
        try:
            await search_input.click(timeout=3000, force=True)
            await asyncio.sleep(0.6)
        except Exception as e:
            print(f"  [!] click search input 失败,fallback 到 selector: {e}")
            try:
                box = await sel.bounding_box()
                if box:
                    # 点 selector 最右侧空白处(避开 tag 区)
                    await page.mouse.click(box["x"] + box["width"] - 15, box["y"] + box["height"] / 2)
                await asyncio.sleep(0.6)
            except Exception:
                pass

        # 2) Backspace 清空已选 tag。每按一次删一个 tag,空态下继续无副作用
        #    通过 Playwright locator 直接发到 input,确保焦点正确
        #    ⚠ 先清掉输入框里可能残留的搜索文字,否则 Backspace 会先逐字删文字、
        #    把删 tag 的次数吃掉 → 上一轮的类目 tag 没清干净就会"多输入/选错"
        try:
            await search_input.fill("")
            await asyncio.sleep(0.15)
        except Exception:
            pass
        for _ in range(15):
            try:
                await search_input.press("Backspace", timeout=1500)
            except Exception:
                # 兜底:全局 keyboard
                try:
                    await page.keyboard.press("Backspace")
                except Exception:
                    break
            await asyncio.sleep(0.1)
        await asyncio.sleep(0.5)
        # 验证已清空
        try:
            shown_after_clear = (await sel.inner_text(timeout=1000)).strip()
            print(f"  [清空] cascader 状态: {shown_after_clear[:40]!r}")
        except Exception:
            pass

        # 3) 输入三级类目名触发搜索(通过 input locator 直接发,确保焦点)
        try:
            await search_input.type(search_text, delay=40, timeout=3000)
        except Exception as e:
            print(f"  [!] input.type 失败,fallback 到全局 keyboard: {e}")
            try:
                await page.keyboard.type(search_text, delay=40)
            except Exception:
                pass
        await asyncio.sleep(1.2)  # 等下拉出现 + 防抖

        # 4) 在下拉里精确选中目标类目。
        #    ⚠ 绝不用 get_by_text(search_text).first 子串兜底 —— 它会把
        #    "发际线粉"误命中到任意含该词的相近类目/父级,导致选错。
        #    改为 JS:按"规范化整路径"或"叶子名精确相等"匹配;命中多个就放弃
        #    (宁可这次重试,也不点错)。
        clicked = False
        match_info = await page.evaluate(
            """([expectedPath, leaf]) => {
                const norm = s => (s || '').replace(/\\s*\\/\\s*/g, '/').replace(/\\s+/g, ' ').trim();
                const wantPath = norm(expectedPath);
                const root = document.querySelector('.agent-cascader-dropdown');
                if (!root) return {status: 'no-dropdown'};
                let opts = Array.from(root.querySelectorAll(
                    '.agent-cascader-menu-item, [role="menuitemcheckbox"], [role="option"]'));
                if (!opts.length)
                    opts = Array.from(root.querySelectorAll('*')).filter(
                        e => e.children.length === 0 && (e.innerText || '').includes('/'));
                const rows = opts.map(e => ({el: e, text: norm(e.innerText)}))
                                 .filter(o => o.text);
                // 1) 整路径精确匹配
                let hit = rows.filter(o => o.text === wantPath);
                // 2) 退到"叶子名精确相等"(路径最后一段 === leaf)
                if (!hit.length && leaf) hit = rows.filter(o => o.text.split('/').pop() === leaf);
                if (hit.length === 1) { hit[0].el.click(); return {status: 'ok', text: hit[0].text}; }
                if (hit.length > 1)
                    return {status: 'ambiguous', texts: hit.map(o => o.text).slice(0, 8)};
                return {status: 'none', sample: rows.slice(0, 8).map(o => o.text)};
            }""",
            [expected_path, expected],
        )
        status = (match_info or {}).get("status")
        if status == "ok":
            clicked = True
            print(f"  [下拉] 精确选中: {match_info.get('text')!r}")
        elif status == "ambiguous":
            print(f"  [!] 第{attempt+1}次下拉多个匹配,放弃避免选错: {match_info.get('texts')}")
        else:
            sample = (match_info or {}).get("sample") or (match_info or {}).get("texts")
            print(f"  [!] 第{attempt+1}次下拉未精确匹配 {expected_path!r} (status={status}); 样例={sample}")
        if not clicked:
            await asyncio.sleep(1.0)
            continue
        await asyncio.sleep(0.8)

        # 5) 真实外部点击(5,5)关闭弹层 + 触发 tag 完整渲染
        #    这一步关键 —— 不关弹层 tag 会显示 "+ N ..." 而非具体类目名
        await page.mouse.click(5, 5)
        await asyncio.sleep(0.6)

        # 6) 严格验证:读真实 tag 列表,必须"正好一个 tag 且等于叶子名"。
        #    旧的 `expected in shown` 太松:tag 里混进残留搜索文字/别的类目也算过,
        #    脏数据被放过(这正是"选错/多输入"没被拦下的原因)。
        try:
            tags = await page.evaluate(
                """() => {
                    const root = document.querySelector(
                        '.agent-cascader .agent-select-selector');
                    if (!root) return null;
                    return Array.from(root.querySelectorAll('.agent-select-selection-item'))
                        .map(e => (e.getAttribute('title') || e.innerText || '')
                            .replace(/\\s*×\\s*$/, '').trim())
                        .filter(Boolean)
                        // 排除 antd 多选的溢出占位元素「+ N ...」(纯渲染产物,非真类目)
                        .filter(t => !/^\\+\\s*\\d/.test(t));
                }"""
            )
            shown = (await sel.inner_text(timeout=3000)).strip()
            print(f"  cascader显示: {shown!r}  tags={tags!r}  期望叶子: {expected!r}")
            if tags is not None:
                ok = (len(tags) == 1 and tags[0] == expected)
            else:
                # 读不到 tag 元素时退回旧的包含判断,避免误判失败
                ok = (expected in shown)
            if ok:
                print(f"  已选: {l1_text} > {l2_text} > {l3_text or '全部'}")
                return
            print(f"  [!] 第{attempt+1}次验证失败(tags={tags!r} ≠ [{expected!r}]),清空重试...")
            await clear_cascader_selection(page)
            await asyncio.sleep(1.0)
        except Exception:
            print(f"  已选: {l1_text} > {l2_text} > {l3_text or '全部'}")
            return

    print(f"  [!] 两次重试后仍未选中 {l3_text},继续执行")


# ─── 等待表格刷新 ─────────────────────────────────────────────────────────────

async def wait_for_table_refresh(page, timeout=25000):
    """等待表格加载：先等转圈出现，再等转圈消失，最少等5秒"""
    await asyncio.sleep(3)  # 平台响应慢，先等页面开始请求
    try:
        await page.wait_for_selector(
            ".agent-spin-spinning, .agent-table-loading",
            timeout=5000
        )
    except Exception:
        pass  # 加载太快，转圈已消失
    try:
        await page.wait_for_selector(
            ".agent-spin-spinning, .agent-table-loading",
            state="hidden",
            timeout=timeout
        )
        await asyncio.sleep(2)  # 数据渲染完成再等一下
    except Exception:
        await asyncio.sleep(4)


# ─── DOM 表格抓取 ─────────────────────────────────────────────────────────────

async def scrape_table_dom(page, category_label) -> list:
    """从 DOM 提取商品行，对齐模版20列格式"""
    products = []
    await asyncio.sleep(1.5)

    result = await page.evaluate("""() => {
        // 优先找滚动区域的行（包含所有列），避免固定列overlay只有部分列
        const rowSelectors = [
            '.agent-table-scroll-body .agent-table-row:not(.agent-table-row-level-1)',
            '.agent-table-body .agent-table-row:not(.agent-table-row-level-1)',
            '.agent-table-row:not(.agent-table-row-level-1)',
            '.agent-table-row',
        ];
        let rows = [], usedSel = '';
        for (const sel of rowSelectors) {
            const found = document.querySelectorAll(sel);
            if (found.length > 0) { rows = Array.from(found); usedSel = sel; break; }
        }
        if (rows.length === 0) {
            const allC = new Set();
            document.querySelectorAll('[class]').forEach(el => {
                const cls = el.getAttribute('class') || '';
                cls.split(' ').forEach(c => { if (c.includes('table') || c.includes('row')) allC.add(c); })
            });
            return { error: true, tableClasses: Array.from(allC).slice(0, 30) };
        }

        // 找最全的表头（选列数最多的那组）
        const hSels = [
            '.agent-table-scroll .agent-table-thead .agent-table-cell',
            '.agent-table-thead .agent-table-cell',
            '.agent-table-thead th',
        ];
        let headers = [];
        for (const sel of hSels) {
            const found = document.querySelectorAll(sel);
            if (found.length > headers.length)
                headers = Array.from(found).map(c => c.innerText.trim());
        }

        // 每行提取所有单元格文字、图片URL、单品洞察链接
        const rowData = rows.map(row => {
            const cells = Array.from(row.querySelectorAll('.agent-table-cell, td'));

            // 文字内容
            const texts = cells.map(c => c.innerText.trim());

            // 商品图片（第2列 index=1 的 img）
            let imgSrc = '';
            if (cells[1]) {
                const img = cells[1].querySelector('img');
                if (img) imgSrc = img.src || img.getAttribute('data-src') || '';
            }

            // 单品洞察链接（第3列 index=2 的 a 标签，或含"洞察"文字的 a）
            let insightHref = '';
            if (cells[2]) {
                const links = cells[2].querySelectorAll('a');
                for (const a of links) {
                    if (a.innerText.includes('洞察') || a.href.includes('insight') || a.href.includes('goods')) {
                        insightHref = a.href;
                        break;
                    }
                }
                // 如果没找到 a，找 span/div 的 onclick 或 data 属性
                if (!insightHref) {
                    const spans = cells[2].querySelectorAll('[data-href],[data-url]');
                    if (spans.length) insightHref = spans[0].dataset.href || spans[0].dataset.url || '';
                }
            }

            return { texts, imgSrc, insightHref };
        });

        // 调试：第一行前26格
        const debugRow = rowData.length > 0
            ? rowData[0].texts.slice(0, 26).map((t, i) => i + ': ' + t.slice(0, 60).replace(/\\n/g, '|'))
            : [];

        return { error: false, usedSel, headers, rowData, debugRow };
    }""")

    if result.get("error"):
        print(f"    [!] 未找到表格行: {result.get('tableClasses', [])[:15]}")
        return products

    headers   = result["headers"]
    rows_data = result["rowData"]
    print(f"    选择器: {result['usedSel']}  行数: {len(rows_data)}  表头列数: {len(headers)}")
    for line in result.get("debugRow", []):
        print(f"    调试: {line}")

    # 按表头关键词找列索引，找不到用硬编码fallback
    def hi(keywords, fallback=-1):
        for i, h in enumerate(headers):
            if any(k in h for k in keywords):
                return i
        return fallback

    def gc(texts, idx):
        return texts[idx].strip() if 0 <= idx < len(texts) else ""

    IX = {
        "rank":        hi(["排名"],          0),
        "prod_info":   hi(["商品信息","商品名"], 1),
        "store_info":  hi(["货主信息","货主名"], 3),
        "first_online":hi(["上架","日期"],    6),
        "price":       hi(["价格"],           8),
        "gmv":         hi(["支付GMV"],        9),
        "orders":      hi(["订单量"],        10),
        "sales":       hi(["销量"],          11),
        "ad_spend":    hi(["广告花费"],       12),
        "gmv_mom":     hi(["GMV环比"],        15),
        "order_mom":   hi(["订单量环比"],     16),
        "site_cum_orders": hi(["当日累计订单"], 22),
        "site_cum_gmv":    hi(["当日累计.*GMV","当日累计 GMV"], 23),
        "site_direct_roi": hi(["直接.*ROI","直接 ROI"], 24),
        "site_cum_roi":    hi(["累计.*ROI","累计 ROI"], 25),
    }

    for row in rows_data:
        texts       = row["texts"]
        img_src     = row.get("imgSrc", "")
        insight_url = row.get("insightHref", "")

        if len(texts) < 4:
            continue

        # 解析商品名称 + ID（格式："名称|ID：123456"）
        prod_raw  = gc(texts, IX["prod_info"])
        name      = prod_raw.split("|ID")[0].split("\n")[0].strip()[:80]
        if not name or name == "快捷分享单品洞察":
            continue
        id_m      = re.search(r'ID[：:]\s*(\d+)', prod_raw)
        prod_id   = id_m.group(1) if id_m else ""
        link      = f"https://app.kwaixiaodian.com/merchant/shop/detail?id={prod_id}&hyId=kwaishop&layoutType=4" if prod_id else ""

        # 解析货主店铺名（格式："店铺名|ID: 123456"，ID不采集）
        store_raw  = gc(texts, IX["store_info"])
        store_name = store_raw.split("|ID")[0].strip()

        # 单品洞察链接：如果DOM没抓到，用商品ID构造
        if not insight_url and prod_id:
            insight_url = f"https://jinfu.e.kuaishou.com/cyd-client/product-insight?productId={prod_id}&__staffId__=80207551"

        # 1688以图搜图链接（用户在自己浏览器点击，无需验证码）
        from urllib.parse import quote as _quote
        img_search_url = f"https://s.1688.com/youyuantu/youyuantusearch.htm?imageAddress={_quote(img_src, safe='')}" if img_src else ""

        products.append({
            "rank":               gc(texts, IX["rank"]),
            "prod_id":            prod_id,
            "name":               name,
            "link":               link,
            "insight_url":        insight_url,
            "image":              img_src,
            "img_search_url":     img_search_url,
            "store_name":         store_name,
            "first_online":       gc(texts, IX["first_online"]),
            "price_range":        gc(texts, IX["price"]),
            "gmv_range":          gc(texts, IX["gmv"]),
            "order_range":        gc(texts, IX["orders"]),
            "sales_range":        gc(texts, IX["sales"]),
            "gmv_mom":            gc(texts, IX["gmv_mom"]),
            "order_mom":          gc(texts, IX["order_mom"]),
            "site_cumulative_gmv":    gc(texts, IX["site_cum_gmv"]),
            "site_cumulative_orders": gc(texts, IX["site_cum_orders"]),
            "site_direct_roi":    gc(texts, IX["site_direct_roi"]),
            "site_cumulative_roi":gc(texts, IX["site_cum_roi"]),
            "ad_spend":           gc(texts, IX["ad_spend"]),
            "category_label":     category_label,
        })

    return products


# ─── 设置每页条数 ─────────────────────────────────────────────────────────────

_PAGER_JS = """() => {
    // 找 document Y 坐标最大的 agent-select-selector（分页器条/页选择器）
    const sels = Array.from(document.querySelectorAll('.agent-select-selector'));
    let best = null, bestDocY = -1;
    for (const s of sels) {
        const r = s.getBoundingClientRect();
        const docY = r.bottom + window.scrollY;
        if (docY > bestDocY) { bestDocY = docY; best = s; }
    }
    if (!best) return null;
    best.scrollIntoView({ block: 'center', behavior: 'instant' });
    const r = best.getBoundingClientRect();
    return { x: r.left + r.width/2, y: r.top + r.height/2,
             text: best.innerText.trim() };
}"""


async def set_page_size(page, size=100):
    """将分页器每页条数设为 size，最多重试 3 次，每次都验证是否生效。"""
    for attempt in range(3):
        try:
            await close_popup(page)
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await asyncio.sleep(1.0)

            coords = await page.evaluate(_PAGER_JS)
            if not coords:
                print(f"  [!] 未找到分页选择器 (尝试 {attempt+1}/3)")
                await asyncio.sleep(1.5)
                continue

            cur = coords.get("text", "")
            if str(size) in cur:
                print(f"  每页已是 {size} 条，无需修改")
                await page.evaluate("window.scrollTo(0, 0)")
                return True

            print(f"  [分页] 当前 {cur!r} → 设为 {size} 条/页 (尝试 {attempt+1}/3)")

            # 点击打开下拉
            await asyncio.sleep(0.3)
            await page.mouse.move(coords["x"] - 8, coords["y"])
            await asyncio.sleep(0.15)
            await page.mouse.click(coords["x"], coords["y"])
            await asyncio.sleep(2.0)   # 等下拉渲染

            # 找并点击目标选项
            found = False
            for label in [f"{size} 条/页", f"{size}条/页"]:
                opt = page.locator(f".agent-select-item:has-text('{label}')").first
                if await opt.is_visible(timeout=2000):
                    await human_click(page, opt)
                    await asyncio.sleep(3.5)   # 等表格用新条数重新加载
                    print(f"  已点击 {size} 条/页")
                    found = True
                    break

            if not found:
                items = page.locator(".agent-select-item")
                cnt   = await items.count()
                opts  = [(await items.nth(i).inner_text()).strip()
                         for i in range(min(cnt, 10))]
                print(f"  [!] 可见选项: {opts}")
                await page.keyboard.press("Escape")
                await asyncio.sleep(0.5)
                continue   # 重试

            # 验证是否生效
            coords2 = await page.evaluate(_PAGER_JS)
            verified = (coords2 or {}).get("text", "")
            if str(size) in verified:
                print(f"  [分页] 验证成功: {verified!r}")
                await page.evaluate("window.scrollTo(0, 0)")
                await asyncio.sleep(0.5)
                return True
            else:
                print(f"  [!] 验证失败，当前 {verified!r}，重试...")

        except Exception as e:
            print(f"  [!] set_page_size 错误 (尝试 {attempt+1}/3): {e}")

        await asyncio.sleep(1.5)

    print(f"  [!] 设置每页 {size} 条失败，保持默认")
    try:
        await page.evaluate("window.scrollTo(0, 0)")
    except Exception:
        pass
    return False


# ─── 翻页抓取 ─────────────────────────────────────────────────────────────────

async def get_first_row_rank(page) -> str:
    """读取第一行排名数字，用于检测翻页（排名唯一且变化明确）"""
    return await page.evaluate("""() => {
        // 优先从 scrollable body 取行（与抓取用同一选择器）
        const selectors = [
            '.agent-table-body .agent-table-row:not(.agent-table-row-level-1)',
            '.agent-table-row:not(.agent-table-row-level-1)',
        ];
        let rows = [];
        for (const sel of selectors) {
            rows = document.querySelectorAll(sel);
            if (rows.length) break;
        }
        if (!rows.length) return '';
        const cells = rows[0].querySelectorAll('.agent-table-cell, td');
        // col 0 = 排名（纯数字），col 1 = 商品信息（文字）
        const rank = cells.length > 0 ? cells[0].innerText.trim() : '';
        const name = cells.length > 1 ? cells[1].innerText.trim().slice(0, 20) : '';
        return rank + '|' + name;
    }""")


async def paginate_and_scrape(page, category_label) -> list:
    """翻页并用 DOM 抓取，返回所有商品"""
    all_products = []

    for page_num in range(1, 20):  # 最多20页（100条/页时约2000条）
        batch = await scrape_table_dom(page, category_label)
        all_products.extend(batch)
        print(f"    第{page_num}页 {len(batch)} 条")

        # 记录当前首行，用于检测翻页后数据是否真正更新
        first_before = await get_first_row_rank(page)

        try:
            # 用 scrollIntoView 让分页器进入视窗
            nxt_info = await page.evaluate("""() => {
                const btn = document.querySelector('.agent-pagination-next');
                if (!btn) return { found: false };
                btn.scrollIntoView({ block: 'center', behavior: 'instant' });
                const r = btn.getBoundingClientRect();
                const disabled = btn.classList.contains('agent-pagination-disabled');
                return { found: true, disabled, x: r.left + r.width/2, y: r.top + r.height/2 };
            }""")
            await asyncio.sleep(0.3)

            if not nxt_info.get("found"):
                print(f"    [!] 未找到分页下一页按钮，停止")
                break
            if nxt_info.get("disabled"):
                print(f"    第{page_num}页已是最后一页")
                break

            print(f"    翻到第{page_num+1}页 (next btn @ {nxt_info['x']:.0f},{nxt_info['y']:.0f})")
            await page.mouse.move(nxt_info["x"] - 5, nxt_info["y"])
            await asyncio.sleep(0.2)
            await page.mouse.click(nxt_info["x"], nxt_info["y"])

            # 轮询等待第一行排名变化（最多20秒）
            changed = False
            for _ in range(40):
                await asyncio.sleep(0.5)
                first_after = await get_first_row_rank(page)
                if first_after and first_after != first_before:
                    changed = True
                    break

            await page.evaluate("window.scrollTo(0, 0)")
            await asyncio.sleep(0.3)

            if not changed:
                print(f"    [!] 第{page_num+1}页数据未更新，停止翻页")
                break

        except Exception:
            break

    return all_products


# ─── 5月过滤 ──────────────────────────────────────────────────────────────────

def _get_filter():
    """从环境变量读取年月筛选，默认2026年5月"""
    try:
        y = int(os.environ.get("FILTER_YEAR", "2026"))
    except Exception:
        y = 2026
    try:
        m = int(os.environ.get("FILTER_MONTH", "5"))
    except Exception:
        m = 5
    return y, m


def is_target_month(first_online_str):
    """按 FILTER_YEAR / FILTER_MONTH 过滤首次上架日期"""
    if not first_online_str:
        return False
    year, month = _get_filter()
    s = str(first_online_str).strip()
    # 时间戳格式
    if s.isdigit() and len(s) >= 10:
        try:
            dt = datetime.fromtimestamp(int(s[:10]))
            if month == 0:
                return dt.year == year
            return dt.year == year and dt.month == month
        except Exception:
            pass
    # 字符串格式：2026-05-xx
    if month == 0:
        return bool(re.search(rf'{year}[-/]', s))
    mm = str(month).zfill(2)
    return bool(re.search(rf'{year}[-/]{mm}', s))


# ─── 数据保存（可在正常结束和异常退出时复用）────────────────────────────────────

def _save_checkpoint(tag: str = "checkpoint"):
    """保存当前已收集数据到 checkpoint 文件(crash-safe)。
    2026-05-27 改:用固定 RUN_TS + 固定 cp_latest 名,覆盖式写,不再每 10 类目累积新文件。
    主要的批次报表由 _save_progress 写 products_<RUN_TS>.json,这里只是冷备份。
    """
    if not collected_products:
        return
    fy, fm = _get_filter()
    may_prods = [p for p in collected_products if is_target_month(p["first_online"])]
    all_prods = collected_products
    try:
        cp_path = DATA_DIR / f"products_{RUN_TS}_cp_latest.json"
        with open(cp_path, "w", encoding="utf-8") as f:
            json.dump(may_prods if may_prods else all_prods, f, ensure_ascii=False, indent=2)
        print(f"[checkpoint] {tag} → {cp_path.name}  ({len(may_prods or all_prods)} 条,覆盖式)")
    except Exception as e:
        print(f"[!] checkpoint 写入失败: {e}")

    # 同步更新 live 文件
    try:
        live_path = DATA_DIR / "products_live.json"
        with open(live_path, "w", encoding="utf-8") as f:
            json.dump(may_prods if may_prods else all_prods, f, ensure_ascii=False)
    except Exception:
        pass


def _update_progress(target_combos=None, completed_combos=None, current_combo=None):
    """更新 data/scrape_progress.json — 记录本次抓取进度,用于崩溃后续抓。
    target_combos: 第一次调用时传(全列表),后续传 None 不覆盖
    completed_combos: 已完成的类目列表(每次类目完成后传新列表)
    current_combo: 当前正在抓的类目(每个类目开始前传)
    """
    prog_path = DATA_DIR / "scrape_progress.json"
    data = {}
    if prog_path.exists():
        try:
            with open(prog_path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
    data.setdefault("run_ts", RUN_TS)
    data.setdefault("started_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    if target_combos is not None:
        # target 用元组列表,转为 list of [l1,l2,l3] 便于 JSON
        data["target_combos"] = [list(c) for c in target_combos]
    if completed_combos is not None:
        data["completed_combos"] = [list(c) for c in completed_combos]
    if current_combo is not None:
        data["current_combo"] = list(current_combo)
    data["last_update"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(prog_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[progress-file] 写入失败: {e}")


def _clear_progress():
    """全部抓完后删 scrape_progress.json,表示无未完成任务。
    崩溃时不调用,客户端启动时检测有这个文件就提示「上次未完成,是否继续」。
    """
    prog_path = DATA_DIR / "scrape_progress.json"
    try:
        if prog_path.exists():
            prog_path.unlink()
            print(f"[progress-file] 已删除 {prog_path.name}(全部完成)")
    except Exception as e:
        print(f"[progress-file] 删除失败: {e}")


def _save_progress():
    """每完成 1 个类目调用:写 products_<RUN_TS>.json + 更新 live + scrape_history 单条目。
    不写 Excel/HTML(慢,留到 _finalize 跑一次)。
    crash-safe:即使后续崩溃,客户端也能从 products_<RUN_TS>.json 加载已完成的类目数据。
    """
    if not collected_products:
        return
    fy, fm = _get_filter()
    label = f"{fy}年{fm}月" if fm else f"{fy}年全年"
    may_prods = [p for p in collected_products if is_target_month(p["first_online"])]
    final_products = may_prods if may_prods else collected_products

    # 1) 用固定 RUN_TS 写 products_<RUN_TS>.json (本次批次唯一,持续更新)
    json_path = DATA_DIR / f"products_{RUN_TS}.json"
    try:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(final_products, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[progress] 写 {json_path.name} 失败: {e}")
        return

    # 2) 同步 live.json
    try:
        live_path = DATA_DIR / "products_live.json"
        with open(live_path, "w", encoding="utf-8") as f:
            json.dump(final_products, f, ensure_ascii=False)
    except Exception:
        pass

    # 3) 更新 scrape_history(本次启动 = 一条记录,同 RUN_TS 就更新 count,不存在就新增)
    try:
        hist_path = DATA_DIR / "scrape_history.json"
        history = []
        if hist_path.exists():
            try:
                with open(hist_path, encoding="utf-8") as f:
                    history = json.load(f)
                if not isinstance(history, list): history = []
            except Exception:
                history = []
        found = False
        for entry in history:
            if entry.get("timestamp") == RUN_TS or entry.get("time") == RUN_TS:
                entry["count"] = len(final_products)
                entry["total"] = len(final_products)
                entry["filter_label"] = label
                found = True
                break
        if not found:
            history.append({
                "timestamp": RUN_TS, "filename": f"products_{RUN_TS}.json",
                "count": len(final_products),
                "time": RUN_TS, "tag": "in_progress",
                "total": len(final_products), "filter_label": label,
                "json": str(json_path),
            })
        with open(hist_path, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[progress] 更新 scrape_history 失败: {e}")
    print(f"[progress] 已固化 {len(final_products)} 条到 products_{RUN_TS}.json")


def _finalize(tag: str = "final"):
    """正常/异常结束时都执行：过滤、写 JSON/Excel/HTML/scrape_history"""
    print(f"\n共抓取 {len(collected_products)} 条商品，开始过滤...")

    fy, fm = _get_filter()
    label = f"{fy}年{fm}月" if fm else f"{fy}年全年"
    may_products = [p for p in collected_products if is_target_month(p["first_online"])]
    print(f"  {label}上架: {len(may_products)} 条")

    if may_products:
        final_products = may_products
    elif collected_products:
        # 日期过滤后为空（字段格式不匹配），改用全部原始数据，避免报表丢失
        print(f"  [!] 日期过滤后为空，改用全部 {len(collected_products)} 条原始数据")
        print("   样本首次上架字段:")
        for p in collected_products[:5]:
            print(f"     {p['name'][:20]}  first_online={p['first_online']!r}")
        final_products = collected_products
    else:
        print("[!] 未获取到任何商品数据，跳过报表生成")
        return

    # 用本次启动的固定 RUN_TS,跟 _save_progress 写同一个 products_<RUN_TS>.json
    # 确保 scrape_history 里同一批次只有一条记录(进度多次更新),Excel/HTML 在最后跑一次
    ts = RUN_TS

    json_path = DATA_DIR / f"products_{ts}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(final_products, f, ensure_ascii=False, indent=2)
    print(f"[OK] JSON: {json_path}")

    excel_path = DATA_DIR / f"选品报表_{ts}.xlsx"
    html_path  = DATA_DIR / f"选品报表_{ts}.html"

    try:
        generate_excel(final_products, excel_path)
        print(f"[OK] Excel: {excel_path}")
    except Exception as e:
        print(f"[!] Excel 生成失败: {e}")
        excel_path = None

    try:
        generate_html_report(final_products, html_path)
        print(f"[OK] HTML: {html_path}")
    except Exception as e:
        print(f"[!] HTML 生成失败: {e}")
        html_path = None

    # 更新抓取历史记录
    try:
        hist_path = DATA_DIR / "scrape_history.json"
        history = []
        if hist_path.exists():
            try:
                with open(hist_path, encoding="utf-8") as f:
                    history = json.load(f)
                if not isinstance(history, list):
                    history = []
            except Exception:
                history = []
        import os as _os
        _json_fn = _os.path.basename(str(json_path)) if json_path else ""
        # 去重:同 RUN_TS 就 update,不存在就 append(跟 _save_progress 同款逻辑)
        # 避免 _save_progress(in_progress) + _finalize(final) 各 append 一条 → 重复
        new_entry = {
            "timestamp": ts,                       # client.py 规范字段
            "filename":  _json_fn,
            "count":     len(final_products),
            "time":      ts,                       # 兼容旧字段
            "tag":       tag,
            "total":     len(final_products),
            "filter_label": label,
            "json":      str(json_path),
            "excel":     str(excel_path) if excel_path else "",
            "html":      str(html_path) if html_path else "",
        }
        found = False
        for i, entry in enumerate(history):
            if entry.get("timestamp") == ts or entry.get("time") == ts:
                history[i] = new_entry   # 整条覆盖,带上 excel/html 路径
                found = True
                break
        if not found:
            history.append(new_entry)
        with open(hist_path, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
        print(f"[OK] 历史记录: {hist_path}")
    except Exception as e:
        print(f"[!] 历史记录写入失败: {e}")

    print()
    print("=" * 55)
    print(f"  完成！共 {len(final_products)} 条商品，数据在 data/ 目录")
    print("=" * 55)


# ─── 主流程 ───────────────────────────────────────────────────────────────────

async def run():
    print("=" * 55)
    print("  磁力金牛爆品数据抓取系统 v3")
    if DISCOVER_ONLY:
        print("  模式: 类目扫描（仅发现类目树，不抓数据）")
    else:
        fy, fm = _get_filter()
        _flabel = f"{fy}年{fm}月" if fm else f"{fy}年全年"
        _cnames = " / ".join(c[0] for c in TARGET_CATEGORIES)
        print(f"  目标: {_cnames} | 筛选: {_flabel}首次上架")
    print("=" * 55)
    print()

    _browser = None  # 保留引用，供 finally 块关闭

    try:
        async with async_playwright() as p:
            # 视口 1920x1080:原 1440x900 太小,cascader 多级菜单超出视口,
            # JS item.click() 命中的是被裁切/滚出的元素 → 选择不生效。
            # 用固定大视口而非 no_viewport,避开 Playwright on Windows 在
            # no_viewport 模式下偶发的 chromium 进程崩溃。
            _browser = await p.chromium.launch(
                headless=False,
                args=["--start-maximized"]
            )
            context = await _browser.new_context(
                viewport=None,
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            page = await context.new_page()

            # 登录
            await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
            await auto_login(page)
            await close_popup(page)
            await asyncio.sleep(2)

            # 确认已在目标页面
            if "/cyd-client/best-seller" not in page.url or "welcome" in page.url:
                print(f"  [!] 当前页不是目标页，重新导航... ({page.url[:60]})")
                await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(4)
            if "/cyd-client/best-seller" not in page.url or "welcome" in page.url:
                print(f"  [!] 无法到达目标页面，退出。当前: {page.url}")
                await _browser.close()
                _browser = None
                return

            # ── 发现模式：只扫描类目树，保存 JSON 后退出 ──────────────────────
            if DISCOVER_ONLY:
                old_tree = {}
                try:
                    if TREE_PATH.exists():
                        with open(TREE_PATH, encoding="utf-8") as _oldf:
                            old_tree = json.load(_oldf)
                except Exception:
                    old_tree = {}
                tree_data: dict = {}
                for cat_label, cat_text in TARGET_CATEGORIES:
                    print(f"\n{'='*40}")
                    print(f"  扫描: {cat_text}")
                    combos = await discover_category_tree_retry(page, cat_text)
                    print(f"  发现 {len(combos)} 个三级类目")
                    l2_dict: dict = {}
                    for _, l2, l3 in combos:
                        if l2 not in l2_dict:
                            l2_dict[l2] = []
                        if l3 and l3 not in l2_dict[l2]:
                            l2_dict[l2].append(l3)
                    if l2_dict:
                        tree_data[cat_text] = l2_dict
                    elif old_tree.get(cat_text):
                        tree_data[cat_text] = old_tree[cat_text]
                        print(f"  [!] 本次扫描为空，保留本地已有的 {cat_text} 类目")
                    else:
                        tree_data[cat_text] = {}

                tree_path = DATA_DIR / "category_tree.json"
                with open(tree_path, "w", encoding="utf-8") as _tf:
                    json.dump(tree_data, _tf, ensure_ascii=False, indent=2)
                print(f"\n[OK] 类目树已保存: {tree_path}")
                await _browser.close()
                _browser = None
                return

            # ── 正常抓取模式 ───────────────────────────────────────────────────
            # 固定筛选（先关弹窗再设置）
            await close_popup(page)
            await asyncio.sleep(1)
            print("设置固定筛选条件...")
            # 统计周期（默认今天，可改为 近7天/近14天/近30天）
            global STATISTIC_PERIOD
            if STATISTIC_PERIOD and STATISTIC_PERIOD != "今天":
                await set_statistic_period(page, STATISTIC_PERIOD)
                await asyncio.sleep(1)
            await set_dropdown(page, "载体类型", "短视频")
            await asyncio.sleep(1)
            await set_dropdown(page, "售卖渠道", "货主自卖")
            await asyncio.sleep(1)

            # 确定要抓取的三级类目组合
            if SELECTED_COMBOS_LIST:
                # 客户端直传。若只有一级类目(L2=None)，运行时发现其完整子类目。
                all_combos = []
                for l1, l2, l3 in SELECTED_COMBOS_LIST:
                    if l2 is None:
                        print(f"\n  本地「{l1}」子类目为空，运行时自动发现...")
                        found = await discover_category_tree_retry(page, l1)
                        if not found:
                            print(f"  [!] {l1} 连续扫描为空，无法生成抓取任务")
                        all_combos.extend(found)
                    else:
                        all_combos.append((l1, l2, l3))
                # 去重并保留原顺序
                all_combos = list(dict.fromkeys(all_combos))
                if not all_combos:
                    print("  [!] 选中的类目没有发现可抓取的二/三级类目，本次停止")
                    return
                print(f"使用指定类目: {len(all_combos)} 个三级类目")
                for l1, l2, l3 in all_combos[:6]:
                    print(f"    {l1} > {l2} > {l3 or '全部'}")
                if len(all_combos) > 6:
                    print(f"    ... 还有 {len(all_combos)-6} 个")
            else:
                # 自动发现所有类目
                all_combos = []
                for cat_label, cat_text in TARGET_CATEGORIES[:1] if TEST_MODE else TARGET_CATEGORIES:
                    print(f"\n{'='*40}")
                    print(f"  发现子类目: {cat_label} ({cat_text})")
                    combos = await discover_category_tree(page, cat_text)
                    print(f"  发现 {len(combos)} 个三级类目组合")
                    for combo in combos:
                        l1, l2, l3 = combo
                        print(f"    {l1} > {l2} > {l3 or '全部'}")
                    all_combos.extend(combos)

            # 逐三级类目抓取（loop 内异常不终止整体，转为 checkpoint 保存）
            limit = TEST_COMBOS if TEST_COMBOS > 0 else (1 if TEST_MODE else len(all_combos))
            # 初始化进度文件:记录全列表 + 已完成空列表
            target_list = list(all_combos[:limit])
            _update_progress(target_combos=target_list, completed_combos=[])
            completed = []
            combo_count = 0
            for l1, l2, l3 in target_list:
                label = f"{l1}>{l2}>{l3 or '全部'}"
                print(f"\n  抓取: {label}")
                _update_progress(current_combo=(l1, l2, l3))
                try:
                    await select_category_3level(page, l1, l2, l3)

                    # 验证 cascader 显示值
                    try:
                        shown = await page.locator(".agent-cascader .agent-select-selector").first.inner_text(timeout=3000)
                        print(f"  cascader当前显示: {shown.strip()!r}")
                    except Exception:
                        pass

                    # 每次查询前重新设置固定筛选（防止类目切换后被重置）
                    await set_dropdown(page, "载体类型", "短视频")
                    await set_dropdown(page, "售卖渠道", "货主自卖")

                    # 点击查询，等待表格用新类目数据刷新
                    await human_click(page, page.locator("text=查询").first)
                    print("  已点击查询，等待数据加载完成...")
                    await wait_for_table_refresh(page)

                    await set_page_size(page, 100)
                    await wait_for_table_refresh(page)

                    batch = await paginate_and_scrape(page, label)

                    added = 0
                    for prod in batch:
                        pid = prod["prod_id"] or prod["name"]
                        if pid not in seen_ids:
                            seen_ids.add(pid)
                            collected_products.append(prod)
                            added += 1
                    print(f"  [{label}] 新增 {added} 条（本次抓取 {len(batch)} 条）")

                except Exception as combo_err:
                    print(f"  [!] 类目 {label} 抓取异常: {combo_err}")
                    traceback.print_exc()
                    # 单个类目失败不影响后续，继续下一个

                finally:
                    # 每个类目结束后更新 live 文件（无论成功/失败）
                    try:
                        live_path = DATA_DIR / "products_live.json"
                        live_prods = [p for p in collected_products if is_target_month(p["first_online"])]
                        with open(live_path, "w", encoding="utf-8") as _lf:
                            json.dump(live_prods, _lf, ensure_ascii=False)
                    except Exception:
                        pass

                combo_count += 1
                # 类目完成,更新进度文件(已完成列表 + 清空 current_combo)
                completed.append((l1, l2, l3))
                _update_progress(completed_combos=completed, current_combo=None)
                # 2026-05-27 改:每完成 1 个类目就 _save_progress(写 products_<RUN_TS>.json
                # + 更新 scrape_history,不写 Excel/HTML)。即使 main.py 后续崩溃,
                # 已完成类目的数据已固化,客户端能从 products_<RUN_TS>.json 读到。
                _save_progress()
                # 每 10 个类目额外写一次带 cp 标签的 checkpoint(冷备份)
                if combo_count % 10 == 0:
                    _save_checkpoint(f"cp{combo_count:03d}")

            # 所有类目正常抓完 → 删 progress 文件(标记"无未完成任务")
            _clear_progress()
            await _browser.close()
            _browser = None

    except Exception as fatal_err:
        print(f"\n[!!!] 致命异常，尝试保存已收集数据: {fatal_err}")
        traceback.print_exc()

    finally:
        # 确保浏览器一定被关闭
        if _browser is not None:
            try:
                await _browser.close()
            except Exception:
                pass

    # 无论正常结束还是异常退出，都执行最终保存
    _finalize()


def _recover():
    """
    从已有数据文件生成报表（不启动浏览器）。
    优先用 products_live.json，其次用最新 checkpoint。
    """
    global collected_products

    live = DATA_DIR / "products_live.json"
    candidates = sorted(DATA_DIR.glob("products_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    src = live if live.exists() else (candidates[0] if candidates else None)

    if not src:
        print("[recover] 未找到任何数据文件，放弃")
        return

    print(f"[recover] 读取: {src}  ({src.stat().st_size // 1024} KB)")
    with open(src, encoding="utf-8") as f:
        collected_products = json.load(f)
    print(f"[recover] 共 {len(collected_products)} 条商品")
    _finalize(tag="recover")


def _auto_recover_if_needed():
    """
    启动时自动检测：如果上次运行有数据但没出报表（闪退），自动恢复。
    判断依据：products_live.json 的修改时间 > scrape_history.json 最后一条记录时间。
    """
    live = DATA_DIR / "products_live.json"
    if not live.exists():
        return  # 第一次运行，无需恢复

    live_mtime = live.stat().st_mtime
    live_kb    = live.stat().st_size // 1024
    if live_kb < 10:
        return  # 文件太小，不是有效数据

    # 读取最后一次成功出报表的时间
    # 兼容两种时间字段（time/timestamp）和两种格式（%Y%m%d_%H%M%S / %Y-%m-%d %H:%M:%S）
    last_report_time = 0.0
    hist = DATA_DIR / "scrape_history.json"
    if hist.exists():
        try:
            with open(hist, encoding="utf-8") as f:
                history = json.load(f)
            if isinstance(history, list):
                for entry in history:
                    ts_str = entry.get("time") or entry.get("timestamp") or ""
                    if not ts_str:
                        continue
                    for fmt in ("%Y%m%d_%H%M%S", "%Y-%m-%d %H:%M:%S"):
                        try:
                            t = datetime.strptime(ts_str, fmt).timestamp()
                            if t > last_report_time:
                                last_report_time = t
                            break
                        except Exception:
                            continue
        except Exception:
            pass

    # live 文件比最后一次报表新超过 2 分钟 → 上次闪退了
    # 2026-05-27 改为「只警告不自动恢复」:
    # 之前 _recover 会把 live 数据生成新 products_<ts>.json + 写 scrape_history,
    # 导致用户删历史后再启动,live 残留数据被"复活"为新历史(用户报的 bug)
    if live_mtime > last_report_time + 120:
        live_dt  = datetime.fromtimestamp(live_mtime).strftime("%m-%d %H:%M")
        hist_dt  = datetime.fromtimestamp(last_report_time).strftime("%m-%d %H:%M") if last_report_time else "无"
        print("=" * 55)
        print(f"  [警告] 检测到 products_live.json 有未出报表的旧数据 ({live_kb} KB)")
        print(f"  数据时间: {live_dt}    最近报表: {hist_dt}")
        print(f"  - 不会自动恢复(防止已删历史被复活)")
        print(f"  - 如需恢复: python main.py --recover")
        print(f"  - 如不需要: 删除 data/products_live.json 再启动")
        print("=" * 55)
        print()


if __name__ == "__main__":
    if RECOVER_MODE:
        _recover()
    else:
        # 每次启动先检测上次是否闪退，有数据就自动恢复
        _auto_recover_if_needed()
        try:
            asyncio.run(run())
        except KeyboardInterrupt:
            print("\n[!] 用户中断，尝试保存已收集数据...")
            _finalize(tag="interrupted")
        except Exception as top_err:
            print(f"\n[!!!] 顶层异常: {top_err}")
            traceback.print_exc()
            _finalize(tag="crashed")
