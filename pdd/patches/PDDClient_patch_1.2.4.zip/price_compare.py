"""
1688 以图搜图比价模块
用法: python price_compare.py --image-url URL [--name NAME]
输出: JSON 到 stdout
"""
import asyncio
import sys
import json
import socket
import random
import argparse
import subprocess
import os
import urllib.request
from pathlib import Path


# 下图 opener:走 clash(★实测直连国内CDN极慢:214KB图直连210秒/走clash 0秒)。
# 坑:进程继承系统 all_proxy 环境变量,urllib 不认 all_proxy → 默认走直连=慢死。
# 故直接读注册表系统代理(clash),并把 all 补成 http/https。clash没开=注册表空=直连(唯一选择)。
def _make_dl_opener():
    try:
        _px = dict(urllib.request.getproxies_registry())
    except Exception:
        _px = {}
    if not _px.get("http") and not _px.get("https"):
        _px = dict(urllib.request.getproxies())
    _all = _px.get("all")
    if _all:
        _px.setdefault("http", _all)
        _px.setdefault("https", _all)
    return urllib.request.build_opener(urllib.request.ProxyHandler(_px))


_DL_OPENER = _make_dl_opener()


BAT_PATH = str(Path(__file__).parent / "start_chrome_debug.bat")
SEARCH_URL = "https://s.1688.com/youyuan/index.htm?tab=imageSearch"


def _cdp_available(host="127.0.0.1", port=9222, timeout=1.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _find_chrome() -> str | None:
    """通过注册表 + 常见路径查找Chrome/Edge可执行文件"""
    import winreg, shutil

    # 1. 注册表查找 Chrome
    reg_paths = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
        (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
    ]
    for hive, reg_path in reg_paths:
        try:
            key = winreg.OpenKey(hive, reg_path)
            val, _ = winreg.QueryValueEx(key, "")
            winreg.CloseKey(key)
            if val and os.path.exists(val):
                print(f"[Chrome] 注册表找到: {val}", file=sys.stderr, flush=True)
                return val
        except Exception:
            pass

    # 2. 常见路径
    candidates = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        # Edge 也支持 CDP，作为备用
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    for c in candidates:
        if os.path.exists(c):
            print(f"[Chrome] 路径找到: {c}", file=sys.stderr, flush=True)
            return c

    # 3. PATH 环境变量
    for name in ("chrome", "google-chrome", "msedge"):
        found = shutil.which(name)
        if found:
            print(f"[Chrome] PATH找到: {found}", file=sys.stderr, flush=True)
            return found

    print("[Chrome] 未找到任何浏览器", file=sys.stderr, flush=True)
    return None


DEBUG_PROFILE = str(Path(__file__).parent / "chrome_debug_profile")


def _launch_debug_chrome(show_browser: bool = False) -> bool:
    """强制关闭Chrome并以调试端口重启，等待端口就绪，返回是否成功。

    show_browser=False(默认,客户用):窗口挪到屏幕外 + 固定大尺寸 1920x1080
      → 不挡桌面、自动跑,且页面按大视口渲染,「搜同款」按钮一定在界内不会找不到。
    show_browser=True(调试用):正常最大化显示,方便盯着看有没有出错。
    """
    import time

    chrome_exe = _find_chrome()
    if not chrome_exe:
        return False

    # 不再 taskkill 全部 chrome.exe!比价用的是独立 profile(DEBUG_PROFILE),
    # 与用户日常 Chrome 互不干扰,杀全部会误关用户正在用的浏览器。
    # 只清"比价独立 profile"自己的单实例锁(上次比价异常退出可能残留),
    # 让本次能干净拉起带调试端口的实例。绝不碰用户日常 Chrome 的 profile。
    os.makedirs(DEBUG_PROFILE, exist_ok=True)
    for lock in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        lock_path = os.path.join(DEBUG_PROFILE, lock)
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
    mode_desc = "显示(调试)" if show_browser else "屏幕外静默"
    print(f"[Chrome] 以调试端口启动（{mode_desc}, profile: {DEBUG_PROFILE}）", file=sys.stderr, flush=True)
    chrome_args = [
        chrome_exe,
        "--remote-debugging-port=9222",
        "--remote-allow-origins=*",
        f"--user-data-dir={DEBUG_PROFILE}",
        "--no-first-run",
        "--no-default-browser-check",
    ]
    if show_browser:
        # 调试:最大化显示
        chrome_args.append("--start-maximized")
    else:
        # 客户:窗口挪到屏幕外 + 固定大尺寸(不挡桌面,页面仍按大视口渲染,按钮不出界)
        chrome_args += ["--window-position=-32000,-32000", "--window-size=1920,1080"]
    subprocess.Popen(
        chrome_args,
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )

    # 等待端口就绪（最多20秒）
    for i in range(40):
        time.sleep(0.5)
        if _cdp_available():
            print(f"[Chrome] 端口9222就绪（{(i+1)*0.5:.1f}s）", file=sys.stderr, flush=True)
            return True

    print("[Chrome] 等待超时，端口仍未就绪", file=sys.stderr, flush=True)
    return False


async def human_delay(min_ms=300, max_ms=900):
    """随机停顿，模拟人类反应时间"""
    await asyncio.sleep(random.uniform(min_ms / 1000, max_ms / 1000))


async def human_move_and_click(page, locator):
    """
    模拟人类鼠标移动后点击：
    先移到元素附近随机偏移处，停顿，再移到元素中心，再点击
    """
    box = await locator.bounding_box()
    if not box:
        await locator.click()
        return

    # 元素中心
    cx = box["x"] + box["width"] / 2
    cy = box["y"] + box["height"] / 2

    # 中途随机路过点（相对元素偏移 ±150px）
    mid_x = cx + random.randint(-150, 150)
    mid_y = cy + random.randint(-80, 80)
    mid_x = max(10, min(mid_x, 1260))
    mid_y = max(10, min(mid_y, 800))

    # 移动到中途点
    await page.mouse.move(mid_x, mid_y, steps=random.randint(8, 16))
    await human_delay(80, 200)

    # 移动到元素中心（轻微随机偏移，不要总是正中心）
    tx = cx + random.uniform(-3, 3)
    ty = cy + random.uniform(-3, 3)
    await page.mouse.move(tx, ty, steps=random.randint(5, 12))
    await human_delay(60, 180)

    # 点击
    await page.mouse.click(tx, ty)
    await human_delay(150, 400)


async def human_scroll(page, direction="down", times=None):
    """随机滚动几次，模拟浏览页面"""
    n = times or random.randint(2, 5)
    for _ in range(n):
        dy = random.randint(200, 500) * (1 if direction == "down" else -1)
        await page.mouse.wheel(0, dy)
        await human_delay(200, 600)


def _select_and_build(items: list, my_img: str, search_url: str) -> dict:
    """对候选 items 做「判对 + 物美价廉选货」并组装成统一返回结构。

    爬网页路径与万邦 API 路径共用本函数:match_rank 只吃候选 list
    (每项需含 name/shopName/price/shipping/total/fulfillment/speed/years/link/image),
    与候选来源无关。改动选货逻辑只需改这一处,两条路径同步生效。
    """
    if not items:
        return {"error": "未获取到搜索结果（可能页面结构变更或图片无匹配）"}

    # 调试：打印前3条的链接情况
    for i, it in enumerate(items[:3]):
        print(f"[调试] [{i}] price={it['price']} fulfillment={it['fulfillment']} "
              f"link={it['link'][:80] if it['link'] else '无链接'}",
              file=sys.stderr, flush=True)

    # 软过滤:价格>0 必要;揽收率>=95% 优先但允许兜底。
    valid = [s for s in items if s["price"] > 0]
    qualified = [s for s in valid if s["fulfillment"] >= 95]

    if not valid:
        return {"error": f"未找到有效候选(共{len(items)}条均无价格)"}

    # ── 选链接:match_rank(DINOv2 图像 embedding「判对簇 + 物美价廉排序」)──────
    # 判对:DINOv2 相似度 → 绝对地板剔垃圾 + 相对断层取顶部「对版簇」
    #       (实测能区分聊天大模型区分不了的"同品类换牌冒充货")。
    # 排序:对版簇内按 价格 + 揽收率/发货/年限 价值分挑「物美价廉」那条。
    # 无对版簇 → 不乱选,退相似度首条 + 🚨 强提醒人工。
    # match_rank 不可用(缺 torch/transformers/模型)→ 自动回退老逻辑:相似度首条。
    CAP = 10
    pool = valid[:CAP]
    best = None
    auto_note = ""
    ss_verdict = ""
    ss_reason = ""
    mr = None
    try:
        import match_rank as _mr
        mr = _mr if (my_img and _mr.available()) else None
    except Exception as e:
        print(f"[货品核对] match_rank 加载失败,回退老逻辑: {e}", file=sys.stderr, flush=True)

    if mr:
        res = mr.select_best(my_img, pool)
        for r in res.get("ranked", []):
            si = r.get("sim")
            print(f"[货品核对] #{r['index']} 总价¥{r['total']} 揽收{r['fulfillment']}% "
                  f"sim={('%.3f' % si) if si is not None else '—'}"
                  f"{' [簇]' if r.get('in_cluster') else ''}", file=sys.stderr, flush=True)
        bi = res.get("best_index")
        conf = res.get("confidence")
        if bi is not None:
            best = pool[bi]
            # 商品库「货品核对」列:high/medium→一致,low→不确定
            ss_verdict = "一致" if conf in ("high", "medium") else "不确定"
            ss_reason = res.get("note", "")
            icon = "✅" if conf in ("high", "medium") else "⚠"
            auto_note = f"{icon} 视觉判对(置信度{conf}):{res.get('note', '')}"
        else:
            # 无对版候选 → 不乱选,退相似度首条但强提醒人工
            best = qualified[0] if qualified else valid[0]
            ss_verdict = "不一致"
            ss_reason = res.get("note", "")
            auto_note = f"🚨 未找到对版候选(暂选相似度首条),务必人工核对再上架:{res.get('note', '')}"
        print(f"[货品核对] match_rank → {auto_note}", file=sys.stderr, flush=True)
    else:
        # match_rank 不可用(视觉模型没加载成)→ 【不静默放行】:
        #   挑相似度首条仅供参考,但明确标「核对未执行」让闸门拦下留人工
        #   (无人值守铁律:绝不蒙着发没视觉核对过的货;区别于真判"不一致")。
        best = qualified[0] if qualified else valid[0]
        ss_verdict = "核对未执行"
        ss_reason = "视觉模型(DINOv2)未加载,本次未做同款核对,请重试比价或人工核对"
        auto_note = (f"⚠ 视觉模型未加载,未做核对(暂选相似度首条 揽收率{best['fulfillment']}%),"
                     f"务必人工核对再上架")
        print("[货品核对] match_rank 不可用 → 标『核对未执行』拦下留人工", file=sys.stderr, flush=True)

    top3 = qualified[:3] if qualified else valid[:3]
    # 候选列表:保留原序的前 10 条,供手动模式 GUI 弹窗勾选
    candidates = valid[:10]

    return {
        "ok":            True,
        "total_found":   len(items),
        "qualified":     len(qualified),
        "top3":          top3,
        "candidates":    candidates,   # 含 image 字段,GUI 缩略图列 + 手动比价弹窗使用
        "cost_ref":      f"¥{best['price']}",
        "cost_supplier": best["shopName"],
        "cost_top3_str": " | ".join(
            f"{s['shopName']} ¥{s['total']}({s['fulfillment']}%)" for s in top3
        ),
        "supplier_link": best["link"],
        "img_search_url": search_url,
        "auto_note":     auto_note,
        "same_style":        ss_verdict,   # 品类核对结论(相符/不符/不确定/""),带回写进商品库
        "same_style_reason": ss_reason,
    }


# ───────────────────────── 万邦(onebound)拍立淘 API ─────────────────────────
# 第三方全站以图搜货接口,替代「爬网页比价」(根治 1688 风控)。
# key/secret 放配置文件 data/pdd/wanbang_api.json,不写死、不进交付版。
WANBANG_CONFIG_PATH = str(Path(__file__).parent / "data" / "pdd" / "wanbang_api.json")
WANBANG_API_URL = "https://api-gw.onebound.cn/1688/item_search_img"


def _load_wanbang_config() -> dict | None:
    """读万邦 key/secret 配置。无文件 / 无 key → 返回 None(调用方回退爬网页)。"""
    try:
        if not os.path.exists(WANBANG_CONFIG_PATH):
            return None
        with open(WANBANG_CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        key = (cfg.get("key") or "").strip()
        secret = (cfg.get("secret") or "").strip()
        if not key:
            return None
        return {"key": key, "secret": secret,
                "enabled": cfg.get("enabled", True),
                "sort": (cfg.get("sort") or "").strip()}
    except Exception as e:
        print(f"[万邦] 读配置失败,回退爬网页: {e}", file=sys.stderr, flush=True)
        return None


def _wb_num(v) -> float:
    """把 '12.50'、'¥12.5'、'30%' 之类杂字符串安全转成 float,失败给 0。"""
    if v is None:
        return 0.0
    try:
        import re
        m = re.search(r"[\d]+(?:\.[\d]+)?", str(v))
        return float(m.group(0)) if m else 0.0
    except Exception:
        return 0.0


def _wb_url(u: str) -> str:
    """补全 //xxx 这种省略协议的链接为 https。"""
    u = (u or "").strip()
    if u.startswith("//"):
        return "https:" + u
    return u


def _wanbang_items_to_candidates(api_items: list) -> list:
    """把万邦 items.item[] 映射成本模块统一的候选格式(与爬网页字段对齐)。

    ⚠ 万邦此接口不返运费 → total 只用货价(忽略运费,1688 运费普遍很低)。
    ⚠ fulfillment 暂用 turn_head(回头率);语义和爬网页的「24H揽收率」不同,
       仅作排序参考,真实校准等实测后再调。
    """
    out = []
    for it in api_items:
        # 价格:优先促销价,无则原价
        price = _wb_num(it.get("promotion_price")) or _wb_num(it.get("price"))
        out.append({
            "name":     str(it.get("title") or "").strip()[:40],
            "shopName": str(it.get("seller_nick") or it.get("shop_name")
                            or it.get("nick") or "").strip()[:30],
            "price":    price,
            "shipping": 0.0,                 # 万邦不返运费
            "total":    price,               # 忽略运费,total=货价
            "fulfillment": int(_wb_num(it.get("turn_head"))),   # 暂用回头率
            "speed":    "",
            "years":    0,
            "link":     _wb_url(it.get("detail_url") or ""),
            "image":    _wb_url(it.get("pic_url") or ""),
            # 额外字段(GUI/调试可用,不影响 match_rank)
            "num_iid":  str(it.get("num_iid") or ""),
            "sales":    int(_wb_num(it.get("sales"))),
            "one_psale": it.get("one_psale") or "",
        })
    return out


def search_via_wanbang(cfg: dict, image_url: str, image_path: str = "", name: str = "") -> dict:
    """走万邦 API 以图搜货,再用共用的 _select_and_build 选货。同步函数,无需浏览器。"""
    import urllib.parse
    import urllib.request

    imgid = (image_url or "").strip()
    if not imgid or not imgid.startswith("http"):
        # 万邦此接口要图片 URL(快手图 URL 实测可用);本地路径无法直接搜。
        return {"error": "万邦API需要网络图片URL(image-url),当前未提供有效URL"}

    params = {
        "key":      cfg["key"],
        "secret":   cfg["secret"],
        "api_name": "item_search_img",
        "imgid":    imgid,
        "lang":     "zh-CN",
        "cache":    "no",
    }
    if cfg.get("sort"):
        params["sort"] = cfg["sort"]   # bid2=总价升 / sale=销量;留空=按相关度(最利判对)
    url = WANBANG_API_URL + "?" + urllib.parse.urlencode(params)

    print(f"[万邦] 调用 item_search_img imgid={imgid[:70]}...", file=sys.stderr, flush=True)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"万邦API请求失败: {e}"}

    try:
        data = json.loads(raw)
    except Exception as e:
        return {"error": f"万邦API返回非JSON: {e} | {raw[:200]}"}

    # 错误判定:onebound 正常 error_code=0000;异常给 error/reason
    err_code = str(data.get("error_code", "")).strip()
    err_msg = str(data.get("error", "")).strip()
    if (err_code and err_code not in ("0", "0000")) or (err_msg and err_msg.lower() != "0"):
        reason = data.get("reason") or err_msg or err_code
        return {"error": f"万邦API错误: {reason}"}

    api_items = (data.get("items") or {}).get("item") or []
    if isinstance(api_items, dict):       # 单条时可能不是数组
        api_items = [api_items]
    print(f"[万邦] 返回货源 {len(api_items)} 条", file=sys.stderr, flush=True)

    candidates = _wanbang_items_to_candidates(api_items)
    my_img = image_path if (image_path and os.path.exists(image_path)) else image_url
    # ⚠ 不能把含 key/secret 的接口 URL 当 img_search_url 传出去(会泄密、会被存进商品库)。
    # 万邦无用户可见的结果页,img_search_url 留空即可。
    result = _select_and_build(candidates, my_img, "")
    if isinstance(result, dict) and result.get("ok"):
        result["source"] = "wanbang"     # 标记本次走的是万邦API(GUI/日志可辨)
    return result


async def do_image_search(image_url: str, image_path: str = "", name: str = "",
                          show_browser: bool = False) -> dict:
    if not _cdp_available():
        print("端口9222未开放，尝试自动以调试模式启动Chrome...", file=sys.stderr, flush=True)
        chrome_found = _find_chrome()
        if not chrome_found:
            return {"error": "未找到Chrome或Edge浏览器，请确认已安装Chrome。"}
        ok = _launch_debug_chrome(show_browser=show_browser)
        if not ok:
            return {
                "error": (
                    f"找到浏览器但调试端口未就绪。\n"
                    f"路径: {chrome_found}\n"
                    "请手动双击运行 D:\\files\\start_chrome_debug.bat 后重试。"
                )
            }
        print("Chrome调试模式已启动，请在弹出的浏览器中登录1688后继续...", file=sys.stderr, flush=True)
        # 给用户10秒简单看一眼浏览器（首次使用时可能需要登录）
        import time
        time.sleep(8)

    from playwright.async_api import async_playwright

    async with async_playwright() as p:
        browser = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = browser.contexts[0] if browser.contexts else await browser.new_context()
        # 记下"开工前已存在的标签",收尾时只关本次新开的,保留它们(debug 模式常驻的初始空白页等)
        pre_existing = set(ctx.pages)
        page = await ctx.new_page()
        # 固定大视口:无论窗口是否最大化(尤其静默/屏幕外时),页面都按 1920x1080 渲染,
        # 「搜同款」等按钮一定在界内,不会因窗口小而找不到。
        try:
            await page.set_viewport_size({"width": 1920, "height": 1080})
        except Exception:
            pass

        # 每次比价主动控制窗口位置(不依赖启动参数——浏览器常驻 debug 模式时启动参数不会重跑)。
        #   静默(默认/客户用):窗口挪到屏幕外,不挡桌面、不打扰,但仍正常渲染。
        #   显示(调试用):窗口最大化,方便盯着看有没有出错。
        try:
            cdp = await ctx.new_cdp_session(page)
            win = await cdp.send("Browser.getWindowForTarget")
            wid = win["windowId"]
            if show_browser:
                await cdp.send("Browser.setWindowBounds",
                               {"windowId": wid, "bounds": {"windowState": "maximized"}})
            else:
                # 先恢复 normal 再挪走(maximized/minimized 状态下不能设坐标)
                await cdp.send("Browser.setWindowBounds",
                               {"windowId": wid, "bounds": {"windowState": "normal"}})
                await cdp.send("Browser.setWindowBounds",
                               {"windowId": wid,
                                "bounds": {"left": -32000, "top": -32000,
                                           "width": 1920, "height": 1080}})
        except Exception as e:
            print(f"[窗口] 调整窗口位置失败(不影响比价): {e}", file=sys.stderr, flush=True)

        try:
            # 抹掉 webdriver 特征
            await page.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                window.chrome = {runtime: {}};
                Object.defineProperty(navigator, 'languages', {get: () => ['zh-CN', 'zh', 'en']});
                Object.defineProperty(navigator, 'platform',  {get: () => 'Win32'});
            """)

            def is_blocked(url):
                return any(k in url for k in ["login", "passport", "punish", "verify", "captcha"])

            # 先访问1688主站，像普通用户一样停留一下
            await page.goto("https://www.1688.com/", wait_until="domcontentloaded", timeout=20000)
            await human_delay(1500, 3000)

            # 随机滚动，模拟浏览
            await human_scroll(page, "down", random.randint(1, 3))
            await human_delay(800, 1800)

            if is_blocked(page.url):
                print("【请在弹出的Chrome中登录1688，登录完成后程序自动继续（最多等3分钟）】",
                      file=sys.stderr, flush=True)
                for _ in range(36):
                    await asyncio.sleep(5)
                    if not is_blocked(page.url):
                        break
                else:
                    return {"error": "登录超时，请登录1688后重试"}

            await human_delay(600, 1200)

            # 跳转到图搜页（模拟正常导航）
            await page.goto(SEARCH_URL, wait_until="domcontentloaded", timeout=20000)
            await human_delay(2000, 3500)

            if is_blocked(page.url):
                print("图搜页面触发验证，请在浏览器中完成...", file=sys.stderr, flush=True)
                for _ in range(24):
                    await asyncio.sleep(5)
                    if not is_blocked(page.url):
                        break
                else:
                    return {"error": "图搜页验证超时"}

            # 等待图搜 file input
            try:
                await page.wait_for_selector('input[type="file"]', timeout=12000)
            except Exception:
                return {"error": "图搜页面未加载（当前URL: " + page.url[:80] + "）"}

            # 页面加载后先随机移动鼠标，再滚一下，像在看页面
            await page.mouse.move(
                random.randint(300, 900),
                random.randint(200, 500),
                steps=random.randint(10, 20)
            )
            await human_delay(400, 800)
            await human_scroll(page, "down", random.randint(1, 2))
            await human_delay(600, 1200)

            # 上传图片到 1688 file input。
            # 优先 set_input_files 本地路径(Playwright 原生,不依赖浏览器 fetch);
            # 无 image_path 才回退到 JS fetch URL 路径(老逻辑兼容)。
            if image_path and os.path.exists(image_path):
                try:
                    await page.set_input_files('input[type="file"]', image_path)
                    upload = {"ok": True, "size": os.path.getsize(image_path), "via": "set_input_files"}
                    print(f"[upload] 使用 set_input_files: {image_path}", file=sys.stderr, flush=True)
                except Exception as e:
                    upload = {"ok": False, "error": f"set_input_files: {e}"}
            else:
                upload = await page.evaluate("""
                async (url) => {
                    try {
                        const resp = await fetch(url, {mode: 'cors'});
                        if (!resp.ok) return {ok: false, error: 'fetch ' + resp.status};
                        const blob = await resp.blob();
                        const file = new File([blob], 'product.jpg', {type: 'image/jpeg'});
                        const input = document.querySelector('input[type="file"]');
                        if (!input) return {ok: false, error: 'no file input'};
                        const dt = new DataTransfer();
                        dt.items.add(file);
                        input.files = dt.files;
                        input.dispatchEvent(new Event('change', {bubbles: true}));
                        return {ok: true, size: blob.size, via: 'fetch'};
                    } catch(e) {
                        return {ok: false, error: String(e)};
                    }
                }
                """, image_url)

            if not upload.get("ok"):
                return {"error": f"图片上传失败: {upload.get('error')}"}

            # 注入后等一下，再找按钮点击
            await human_delay(1500, 2500)

            # 找搜索按钮，模拟人类点击
            btn = page.locator(".search-btn").first
            try:
                await btn.wait_for(state="visible", timeout=5000)
            except Exception:
                return {"error": "找不到搜索按钮"}

            await human_move_and_click(page, btn)

            # 等待结果加载（随机等待，像人在等结果）
            await human_delay(5000, 8000)

            # 结果页随机滚动一下，像在浏览
            await human_scroll(page, "down", random.randint(2, 4))
            await human_delay(1000, 2000)

            search_url = page.url

            # 先抓第一张卡片的完整链接调试信息
            debug_links = await page.evaluate("""
            () => {
                let cards = document.querySelectorAll('[class*="searchOfferItem"]');
                if (cards.length === 0) cards = document.querySelectorAll('[class*="offerItem"]');
                if (cards.length === 0) cards = document.querySelectorAll('[data-offer-id]');
                if (cards.length === 0) return {cardCount: 0, links: []};
                const card = cards[0];
                const links = Array.from(card.querySelectorAll('a')).map(a => ({
                    href:      a.href,
                    dataHref:  a.getAttribute('data-href') || '',
                    dataUrl:   a.getAttribute('data-url') || '',
                    text:      (a.innerText || '').trim().slice(0, 20),
                    onclick:   (a.getAttribute('onclick') || '').slice(0, 60),
                }));
                const offerId = card.getAttribute('data-offer-id') || '';
                return {cardCount: cards.length, offerId, links};
            }
            """)
            print(f"[调试] 卡片总数={debug_links.get('cardCount')} offerId={debug_links.get('offerId')}",
                  file=sys.stderr, flush=True)
            for lk in debug_links.get("links", [])[:6]:
                print(f"  a: href={lk['href'][:80]}  dataHref={lk['dataHref'][:60]}"
                      f"  text={lk['text']}", file=sys.stderr, flush=True)

            # 提取商品卡片数据
            items = await page.evaluate("""
            () => {
                // 多选择器兜底
                let cards = document.querySelectorAll('[class*="searchOfferItem"]');
                if (cards.length === 0)
                    cards = document.querySelectorAll('[class*="offerItem"]');
                if (cards.length === 0)
                    cards = document.querySelectorAll('[class*="offer-item"]');
                if (cards.length === 0)
                    cards = document.querySelectorAll('[data-offer-id]');

                // 从卡片或任意子元素的 data-offer-id 构造详情链接（最可靠）
                const offerIdToUrl = id => 'https://detail.1688.com/offer/' + id + '.html';

                const getOfferLink = (card) => {
                    // 1. 卡片本身或任意子元素上的 data-offer-id
                    let el = card.querySelector('[data-offer-id]') ||
                             (card.hasAttribute('data-offer-id') ? card : null);
                    if (el) return offerIdToUrl(el.getAttribute('data-offer-id'));

                    const allA = Array.from(card.querySelectorAll('a'));

                    // 2. href 直接含 detail.1688.com（最标准格式）
                    let a = allA.find(a => (a.href || '').includes('detail.1688.com'));
                    if (a) return a.href;

                    // 3. 从 air.1688.com 的 IM 链接里解析 offerId（关键兜底！）
                    //    示例: air.1688.com/...?offerId=1045614379826
                    for (const a of allA) {
                        const h = a.href || '';
                        if (h.includes('air.1688.com') || h.includes('offerId=')) {
                            const m = h.match(/offerId=(\\d+)/);
                            if (m) return offerIdToUrl(m[1]);
                        }
                    }

                    // 4. href 含 1688.com/offer（排除 air/shop/message）
                    a = allA.find(a => {
                        const h = a.href || '';
                        return h.includes('1688.com') && h.includes('offer') &&
                               !h.includes('air.1688.com') &&
                               !h.includes('/shop/') &&
                               !h.includes('/message/');
                    });
                    if (a) return a.href;

                    return '';
                };

                // 卡片封面图(供 GUI 缩略图列 + 手动比价弹窗使用);处理 1688 多种 lazy 属性
                const getCoverImage = (card) => {
                    const imgs = card.querySelectorAll('img');
                    for (const img of imgs) {
                        const srcs = [
                            img.src,
                            img.getAttribute('data-src'),
                            img.getAttribute('data-lazy-src'),
                            img.getAttribute('data-ks-lazyload'),
                            img.getAttribute('data-original'),
                        ];
                        for (const s of srcs) {
                            if (s && !s.startsWith('data:') && (s.startsWith('http') || s.startsWith('//'))) {
                                return s.startsWith('//') ? 'https:' + s : s;
                            }
                        }
                    }
                    return '';
                };

                const all = [];
                cards.forEach(card => {
                    const txt = card.innerText || '';
                    const pm  = txt.match(/¥\\s*([\\d]+)\\s*\\.\\s*([\\d]+)/);
                    const price = pm ? parseFloat(pm[1] + '.' + pm[2]) : 0;
                    const sm  = txt.match(/运费([\\d.]+)元/);
                    const shipping = sm ? parseFloat(sm[1]) : 0;
                    const r24 = txt.match(/24H揽收(\\d+)%/);
                    const fulfillment = r24 ? parseInt(r24[1]) : 0;
                    const sp  = txt.match(/(明天达|后天达)/);
                    const shopM = txt.match(/入驻\\d+年\\s*([^\\n]+)/);
                    const yearsM = txt.match(/入驻(\\d+)年/);

                    const link = getOfferLink(card);
                    const image = getCoverImage(card);

                    all.push({
                        name:        txt.split('\\n')[0].trim().slice(0, 40),
                        shopName:    shopM ? shopM[1].trim().slice(0, 30) : '',
                        price, shipping,
                        total:       Math.round((price + shipping) * 100) / 100,
                        fulfillment,
                        speed:       sp ? sp[1] : '',
                        years:       yearsM ? parseInt(yearsM[1]) : 0,
                        link,
                        image,
                    });
                });
                return all;
            }
            """)

            my_img = image_path if (image_path and os.path.exists(image_path)) else image_url
            return _select_and_build(items, my_img, search_url)

        except Exception as e:
            return {"error": str(e)}
        finally:
            # 关掉本次比价新开的所有标签(主标签 + 点"搜同款"时 1688 弹出的新标签),
            # 避免跑完遗留空白页。保留"开工前已存在"的标签,确保浏览器不会因无标签而退出。
            try:
                for pg in list(ctx.pages):
                    if pg not in pre_existing:
                        try:
                            await pg.close()
                        except Exception:
                            pass
            except Exception:
                pass


# ───────────────── 1688 采购助手插件·官方图搜(系统级模拟人工) ─────────────────
# 用插件触发 1688 官方图搜(最准,花图靠"框选主体"也能搜),再读结果面板。
# ⚠ 依赖:Windows + 屏幕100%缩放 + 固定窗口 + 插件已装 + 1688已登录;跑时占用鼠标键盘。
# 经验值(坐标/时序/坑)见 handoff.md。
import time as _time

PLUGIN_ID = "kphldkppgfpjadpabfkghmjbhpcmgpdg"
_PLUGIN_ICON_XY = (1138, 103)     # 工具栏图标动态识别失败时的兜底坐标
_PLUGIN_CARD_XY = (1190, 257)     # 新版侧栏右侧「上传找同款」中心：窗口内(1130,217)+窗口偏移(60,40)
_PLUGIN_WIN = (60, 40, 1280, 860)
_PLUGIN_RESTORE_BLUE_RECT = (1220, 200, 1305, 255)  # 「恢复」蓝色按钮所在屏幕区域
_PLUGIN_RESTORE_CLOSE_XY = (1288, 151)              # 恢复气泡右上角 ×
_PLUGIN_PANEL_LOGO_RECT = (955, 160, 995, 205)       # 已打开侧栏左上角的橙色1688标识
_PLUGIN_TOOLBAR_SCAN_RECT = (1100, 85, 1220, 125)   # Chrome工具栏扩展图标扫描区域
_PLUGIN_UPLOAD_READY_RECT = (1160, 225, 1245, 285)  # 右侧上传卡片的图标+文字区域


def _find_plugin_dir():
    """在本机 Chrome 扩展目录里找采购助手插件(取最新版本目录)。"""
    import glob
    base = os.path.expandvars(r"%LocalAppData%\Google\Chrome\User Data")
    cands = [c for c in glob.glob(os.path.join(base, "*", "Extensions", PLUGIN_ID, "*"))
             if os.path.isfile(os.path.join(c, "manifest.json"))]
    cands.sort()
    return cands[-1] if cands else None


async def _plugin_prepare_window():
    """Resize the current CDP Chrome window to the fixed plugin-click geometry."""
    from playwright.async_api import async_playwright
    x, y, w, h = _PLUGIN_WIN
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        cdp = await ctx.new_cdp_session(page)
        win = await cdp.send("Browser.getWindowForTarget")
        await cdp.send("Browser.setWindowBounds", {"windowId": win["windowId"], "bounds": {"windowState": "normal"}})
        await cdp.send("Browser.setWindowBounds", {"windowId": win["windowId"], "bounds": {"left": x, "top": y, "width": w, "height": h}})
        await page.bring_to_front()
        await page.wait_for_timeout(500)


def _ensure_plugin_chrome():
    """确保 9222 调试Chrome 带插件运行;没开则按固定窗口拉起(可见,坐标才准)。"""
    if _cdp_available():
        try:
            asyncio.run(_plugin_prepare_window())
        except Exception as e:
            print(f"[plugin] failed to resize Chrome window: {e}", file=sys.stderr, flush=True)
        return True
    chrome = _find_chrome()
    pdir = _find_plugin_dir()
    if not chrome or not pdir:
        print("[插件] 找不到 Chrome 或插件目录", file=sys.stderr, flush=True)
        return False
    os.makedirs(DEBUG_PROFILE, exist_ok=True)
    for lk in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        try:
            os.remove(os.path.join(DEBUG_PROFILE, lk))
        except Exception:
            pass
    x, y, w, h = _PLUGIN_WIN
    args = [chrome, "--remote-debugging-port=9222", "--remote-allow-origins=*",
            f"--user-data-dir={DEBUG_PROFILE}", f"--load-extension={pdir}",
            "--no-first-run", "--no-default-browser-check",
            "--hide-crash-restore-bubble",
            "--disable-blink-features=AutomationControlled", "--lang=zh-CN",
            f"--window-position={x},{y}", f"--window-size={w},{h}"]
    subprocess.Popen(args, creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        _time.sleep(0.5)
        if _cdp_available():
            _time.sleep(2.0)
            return True
    return False


def _os_click(x, y):
    import ctypes
    u = ctypes.windll.user32
    u.SetCursorPos(int(x), int(y)); _time.sleep(0.2)
    u.mouse_event(0x0002, 0, 0, 0, 0); _time.sleep(0.06); u.mouse_event(0x0004, 0, 0, 0, 0)
    _time.sleep(0.2)


def _os_press_escape():
    """关闭 Chrome 工具栏菜单等临时浮层，不改变已打开的插件侧栏。"""
    import ctypes
    u = ctypes.windll.user32
    u.keybd_event(0x1B, 0, 0, 0)
    _time.sleep(0.05)
    u.keybd_event(0x1B, 0, 0x0002, 0)
    _time.sleep(0.25)


def _plugin_is_orange(rgb) -> bool:
    r, g, b = rgb
    return r > 180 and 30 < g < 170 and b < 100 and r > g * 1.35


def _plugin_restore_prompt_detect(pixel_reader) -> bool:
    """按恢复按钮的整块蓝色识别 Chrome 原生恢复气泡，避免无气泡时误点页面。"""
    left, top, right, bottom = _PLUGIN_RESTORE_BLUE_RECT
    blue = 0
    for y in range(top, bottom, 4):
        for x in range(left, right, 4):
            r, g, b = pixel_reader(x, y)
            if b > 145 and b > g * 1.45 and g > 40 and r < 90:
                blue += 1
    return blue >= 60


def _plugin_panel_open_detect(pixel_reader) -> bool:
    """识别侧栏左上角的橙色1688标识；避免每个商品都重复点工具栏。"""
    left, top, right, bottom = _PLUGIN_PANEL_LOGO_RECT
    orange = sum(
        1 for y in range(top, bottom, 2) for x in range(left, right, 2)
        if _plugin_is_orange(pixel_reader(x, y))
    )
    return orange >= 20


def _plugin_find_toolbar_icon(pixel_reader):
    """在固定工具栏范围内找橙色1688图标中心；图标位移时不再点到拼图按钮。"""
    left, top, right, bottom = _PLUGIN_TOOLBAR_SCAN_RECT
    points = [
        (x, y) for y in range(top, bottom) for x in range(left, right)
        if _plugin_is_orange(pixel_reader(x, y))
    ]
    if len(points) < 25:
        return None
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return ((min(xs) + max(xs)) // 2, (min(ys) + max(ys)) // 2)


def _plugin_upload_card_ready_detect(pixel_reader) -> bool:
    """上传卡片的黑色图标/文字已渲染后才算可点击，避免侧栏空壳阶段点空。"""
    left, top, right, bottom = _PLUGIN_UPLOAD_READY_RECT
    dark = sum(
        1 for y in range(top, bottom, 2) for x in range(left, right, 2)
        if max(pixel_reader(x, y)) < 125
    )
    return dark >= 20


def _plugin_read_screen(callback):
    """一次截图后在内存读取像素；避免逐点 GetPixel 导致插件点击前卡几十秒。"""
    left, top, width, height = _PLUGIN_WIN
    try:
        from PIL import ImageGrab
        image = ImageGrab.grab(
            bbox=(left, top, left + width, top + height), all_screens=True).convert("RGB")

        def _read_captured_pixel(x, y):
            rx, ry = int(x) - left, int(y) - top
            if 0 <= rx < image.width and 0 <= ry < image.height:
                return image.getpixel((rx, ry))
            return (0, 0, 0)

        return callback(_read_captured_pixel)
    except Exception as e:
        print(f"[插件] 快速截图识别不可用，回退GDI: {e}", file=sys.stderr, flush=True)

    # Pillow/ImageGrab 异常时保留原 GDI 兜底；正常客户环境不会走这条慢路径。
    import ctypes
    u = ctypes.windll.user32
    gdi = ctypes.windll.gdi32
    u.GetDC.argtypes = [ctypes.c_void_p]
    u.GetDC.restype = ctypes.c_void_p
    u.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    gdi.GetPixel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    gdi.GetPixel.restype = ctypes.c_uint32
    dc = u.GetDC(0)
    if not dc:
        return None
    try:
        def _read_pixel(x, y):
            color = gdi.GetPixel(dc, int(x), int(y))
            if color == 0xFFFFFFFF:
                return (0, 0, 0)
            return (color & 0xFF, (color >> 8) & 0xFF, (color >> 16) & 0xFF)

        return callback(_read_pixel)
    finally:
        u.ReleaseDC(0, dc)


def _plugin_close_restore_prompt() -> bool:
    """检测并关闭会挡住「上传找同款」的 Chrome「要恢复页面吗？」气泡。"""
    visible = bool(_plugin_read_screen(_plugin_restore_prompt_detect))
    if not visible:
        return False
    print("[插件] 检测到 Chrome 恢复页面气泡，先关闭", file=sys.stderr, flush=True)
    _os_click(*_PLUGIN_RESTORE_CLOSE_XY)
    _time.sleep(0.5)
    return True


def _plugin_open_panel_if_needed() -> bool:
    """侧栏已开则复用；未开时动态定位工具栏1688图标并验证打开结果。"""
    _os_press_escape()
    if _plugin_read_screen(_plugin_panel_open_detect):
        print("[插件] 1688侧栏已打开，跳过工具栏点击", file=sys.stderr, flush=True)
        return True
    icon_xy = _plugin_read_screen(_plugin_find_toolbar_icon) or _PLUGIN_ICON_XY
    print(f"[插件] 打开侧栏，工具栏坐标={icon_xy}", file=sys.stderr, flush=True)
    _os_click(*icon_xy)
    for _ in range(8):
        _time.sleep(0.25)
        if _plugin_read_screen(_plugin_panel_open_detect):
            return True
    return False


def _plugin_wait_upload_card(timeout=8.0) -> bool:
    """等待侧栏内部「上传找同款」卡片真正渲染完成，而不只等待侧栏外壳。"""
    end = _time.time() + max(0.1, float(timeout))
    while _time.time() < end:
        if _plugin_read_screen(_plugin_upload_card_ready_detect):
            return True
        _time.sleep(0.2)
    return False


def _os_raise_chrome():
    """把固定尺寸(1280x860)的调试Chrome 提到前台,OS点击才打得准。"""
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    res = []
    P = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, lp):
        if u.IsWindowVisible(hwnd):
            n = u.GetWindowTextLengthW(hwnd); b = ctypes.create_unicode_buffer(n + 1)
            u.GetWindowTextW(hwnd, b, n + 1)
            r = wintypes.RECT(); u.GetWindowRect(hwnd, ctypes.byref(r))
            if "Google Chrome" in b.value and (r.right - r.left) == _PLUGIN_WIN[2] and (r.bottom - r.top) == _PLUGIN_WIN[3]:
                res.append(hwnd)
        return True
    u.EnumWindows(P(cb), 0)
    if not res:
        return False
    hwnd = res[0]
    u.ShowWindow(hwnd, 9)
    try:
        fg = u.GetForegroundWindow()
        t1 = u.GetWindowThreadProcessId(fg, 0); t2 = u.GetWindowThreadProcessId(hwnd, 0)
        u.AttachThreadInput(t1, t2, True)
        u.SetForegroundWindow(hwnd); u.BringWindowToTop(hwnd)
        u.AttachThreadInput(t1, t2, False)
    except Exception:
        u.SetForegroundWindow(hwnd)
    _time.sleep(0.5)
    return True


def _os_fill_file_dialog(path, timeout=8):
    """Win32 直接给系统文件框写路径 + 点'打开'(枚举 #32770,不靠焦点/剪贴板)。"""
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    u.FindWindowExW.restype = ctypes.c_void_p
    u.FindWindowExW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.LPCWSTR, wintypes.LPCWSTR]

    def find_dlg():
        found = []
        P = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def cb(hwnd, lp):
            if u.IsWindowVisible(hwnd):
                cls = ctypes.create_unicode_buffer(64); u.GetClassNameW(hwnd, cls, 64)
                if cls.value == "#32770":
                    n = u.GetWindowTextLengthW(hwnd); b = ctypes.create_unicode_buffer(n + 1)
                    u.GetWindowTextW(hwnd, b, n + 1)
                    found.append((hwnd, b.value))
            return True
        u.EnumWindows(P(cb), 0)
        return found

    dlg = None; end = _time.time() + timeout
    while _time.time() < end and not dlg:
        fnd = find_dlg()
        for hwnd, t in fnd:
            if any(kw in (t or "") for kw in ("打开", "上传", "Open", "选择")):
                dlg = hwnd; break
        if not dlg and fnd:
            dlg = fnd[0][0]
        if not dlg:
            _time.sleep(0.3)
    if not dlg:
        return False
    edit = None
    cbex = u.FindWindowExW(dlg, None, "ComboBoxEx32", None)
    if cbex:
        cb2 = u.FindWindowExW(cbex, None, "ComboBox", None)
        if cb2:
            edit = u.FindWindowExW(cb2, None, "Edit", None)
    if not edit:
        edit = u.FindWindowExW(dlg, None, "Edit", None)
    if not edit:
        return False
    u.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, wintypes.LPCWSTR]
    u.SendMessageW(edit, 0x000C, 0, path)        # WM_SETTEXT 写路径
    _time.sleep(0.3)
    u.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p]
    u.SendMessageW(dlg, 0x0111, 1, 0)            # WM_COMMAND IDOK 点"打开"
    return True


def _plugin_cards_to_candidates(rows):
    """插件面板卡片 → 统一候选格式。插件给真·运费/真·48h揽收/店铺名,字段最全。"""
    import re
    out = []
    for r in rows:
        t = r.get("text", ""); oid = r.get("oid", ""); img = r.get("img", "")
        pm = re.search(r"[￥¥]\s*([\d]+)\s*\.?\s*([\d]*)", t)
        price = float(pm.group(1) + "." + (pm.group(2) or "0")) if pm else 0.0
        if "包邮" in t.split("年销量")[0]:
            ship = 0.0
        else:
            sm = re.search(r"运费([\d.]+)", t); ship = float(sm.group(1)) if sm else 0.0
        lm = re.search(r"48h揽收(\d+)%", t); ful = int(lm.group(1)) if lm else 0
        sm2 = re.search(r"年销量([\d.]+\w*)", t); sale = sm2.group(1) if sm2 else ""
        title = re.sub(r"^\d+\s*", "", t).split("￥")[0].strip()[:40]
        # 店铺名 = 末尾的公司/厂/商行(代发模式末尾有"面单支持:",普通模式直接是店名)
        mshop = re.search(r"([一-龥A-Za-z()（）]{2,}(?:公司|厂|商行|经营部|中心|工厂|商贸|个体户|合作社|店))\s*$", t)
        shop = mshop.group(1).strip()[:30] if mshop else ""
        if img.startswith("//"):
            img = "https:" + img
        out.append({
            "name": title, "shopName": shop, "price": price, "shipping": ship,
            "total": round(price + ship, 2), "fulfillment": ful, "speed": "", "years": 0,
            "link": ("https://detail.1688.com/offer/%s.html" % oid) if oid else "",
            "image": img, "sales": sale,
        })
    return out


async def _plugin_set_active_1688():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        page = None
        for pg in ctx.pages:
            if pg.url.startswith("https://www.1688.com"):
                page = pg
        if page is None:
            page = await ctx.new_page()
        await page.goto("https://www.1688.com/", wait_until="domcontentloaded", timeout=25000)
        await page.bring_to_front()
        await page.wait_for_timeout(800)


_PLUGIN_CARD_SEL = '[class*="batch_distribute_item"],[class*="offer-list-item-box"]'


async def _plugin_read_panel(timeout=30):
    """读图搜面板。兼容 普通模式(offer-list-item-box)/代发模式(batch_distribute_item),
    并自动切到代发模式(代发价才是 PDD 真实进货成本,普通模式包邮优惠乱价)。"""
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        viewer = None; end = _time.time() + timeout
        while _time.time() < end:
            for pg in ctx.pages:
                for fr in pg.frames:
                    if "imageSearch/offer-viewer" in fr.url:
                        viewer = fr
            if viewer:
                try:
                    cnt = await viewer.evaluate(
                        "(sel)=>document.querySelectorAll(sel).length", _PLUGIN_CARD_SEL)
                except Exception:
                    cnt = 0
                if cnt:
                    break
            await asyncio.sleep(1.0)
        if not viewer:
            return None
        # 确保代发模式(取代发价)。新搜索默认是普通模式,必须主动切;重试2次并确认成功。
        async def _active_tab():
            try:
                return await viewer.evaluate(
                    "()=>{const a=document.querySelector('[class*=\"tab_active\"]');return a?a.innerText.trim():''}")
            except Exception:
                return ""
        for _ in range(2):
            if "代发" in (await _active_tab() or ""):
                break
            print("[插件] 当前普通模式,切换到代发模式(取代发价)", file=sys.stderr, flush=True)
            try:
                await viewer.get_by_text("代发模式", exact=True).first.click()
            except Exception as e:
                print(f"[插件] 点代发模式失败:{e}", file=sys.stderr, flush=True)
            await viewer.wait_for_timeout(3500)
        final_tab = await _active_tab()
        print(f"[插件] 读取模式 = {final_tab or '未知'}", file=sys.stderr, flush=True)
        return await viewer.evaluate(r'''(sel)=>{const c=[...document.querySelectorAll(sel)];return c.map(card=>{const r=card.querySelector('[data-aplus-report]');const rep=r?r.getAttribute('data-aplus-report'):'';const m=/object_id@(\d+)/.exec(rep||'');
        let img='',best=0;
        card.querySelectorAll('img').forEach(im=>{let s=im.currentSrc||im.src||im.getAttribute('data-src')||'';if(!s||s.startsWith('data:')||s.indexOf('tps-16-16')>=0)return;const a=(im.naturalWidth||im.width||0)*(im.naturalHeight||im.height||0);if(a>=best){best=a;img=s;}});
        if(!img){const el=[...card.querySelectorAll('*')].find(e=>/url\(/.test(getComputedStyle(e).backgroundImage||''));if(el){const mm=/url\("?(.*?)"?\)/.exec(getComputedStyle(el).backgroundImage);if(mm)img=mm[1];}}
        return {oid:m?m[1]:'',text:(card.innerText||'').replace(/\n+/g,' '),img:img};});}''', _PLUGIN_CARD_SEL)


def search_via_plugin(image_url, image_path="", name=""):
    """1688 插件官方图搜(系统级模拟人工)。返回结构与万邦/爬网页一致。"""
    # 1) 备本地图(文件框上传需本地路径)
    local = image_path if (image_path and os.path.exists(image_path)) else ""
    if not local and image_url:
        import tempfile, uuid
        local = os.path.join(tempfile.gettempdir(), "pdd_plugin_%s.jpg" % uuid.uuid4().hex[:10])
        try:
            _rq = urllib.request.Request(image_url, headers={"User-Agent": "Mozilla/5.0"})
            with _DL_OPENER.open(_rq, timeout=30) as _r, open(local, "wb") as _f:
                _f.write(_r.read())
        except Exception as e:
            return {"error": "插件模式:下载图片失败 %s" % e}
    if not local or not os.path.exists(local):
        return {"error": "插件模式:无可用本地图片"}
    # 路径规范成 Windows 反斜杠绝对路径:系统文件框只认 \,正斜杠会报"文件名无效"。
    local = os.path.abspath(local).replace("/", "\\")
    # 2) 确保带插件调试Chrome
    if not _ensure_plugin_chrome():
        return {"error": "插件模式:调试Chrome未就绪(插件未装?)"}
    # 3) 活动页设为 1688 普通页(否则插件报"当前页面不支持上传")
    try:
        asyncio.run(_plugin_set_active_1688())
    except Exception as e:
        print("[插件] 设活动页失败:%s" % e, file=sys.stderr, flush=True)
    # 4) 系统级模拟人工:点图标→点上传卡片→填文件框
    if not _os_raise_chrome():
        return {"error": "插件模式:没找到固定窗口(1280x860)的调试Chrome"}
    _plugin_close_restore_prompt()
    if not _plugin_open_panel_if_needed():
        return {"error": "插件模式:未能打开1688采购助手侧栏(工具栏图标位置可能变化)"}
    if not _plugin_wait_upload_card():
        return {"error": "插件模式:侧栏已打开，但『上传找同款』卡片8秒内未加载完成"}
    _os_click(*_PLUGIN_CARD_XY); _time.sleep(1.5)
    if not _os_fill_file_dialog(local):
        return {"error": "插件模式:系统文件框未出现/填充失败"}
    # 5) 读结果面板(1688.com 内的 air.1688 iframe)
    rows = asyncio.run(_plugin_read_panel())
    if not rows:
        return {"error": "插件模式:未读到图搜面板(可能未登录1688/滑块/坐标失效)"}
    candidates = _plugin_cards_to_candidates(rows)
    result = _select_and_build(candidates, local, "")
    if isinstance(result, dict) and result.get("ok"):
        result["source"] = "plugin"
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-url", default="", help="网络图片 URL(走浏览器 fetch 上传)")
    parser.add_argument("--image-path", default="", help="本地图片路径(走 Playwright set_input_files,推荐)")
    parser.add_argument("--name", default="")
    parser.add_argument("--show-browser", action="store_true",
                        help="显示比价浏览器(调试用)；默认屏幕外静默不打扰")
    parser.add_argument("--mode", default="auto",
                        choices=["auto", "wanbang", "web", "plugin"],
                        help="比价引擎:auto(默认,有key走万邦否则爬网页)/wanbang/web/plugin(1688插件官方图搜)")
    args = parser.parse_args()
    if args.image_url and not args.image_path and os.path.exists(args.image_url):
        args.image_path = os.path.abspath(args.image_url)
        args.image_url = ""
    if args.image_path:
        args.image_path = os.path.abspath(args.image_path)
    if not args.image_url and not args.image_path:
        print("ERROR: 必须提供 --image-url 或 --image-path", file=sys.stderr)
        sys.exit(2)

    real_stdout = sys.stdout
    sys.stdout = sys.stderr

    def _run_web():
        return asyncio.run(do_image_search(args.image_url, args.image_path, args.name,
                                           show_browser=args.show_browser))

    def _run_wanbang(cfg):
        return search_via_wanbang(cfg, args.image_url, args.image_path, args.name)

    try:
        wb_cfg = _load_wanbang_config()
        has_url = bool(args.image_url and args.image_url.strip().lower().startswith("http"))
        mode = args.mode

        if mode == "plugin":
            # 1688 插件官方图搜(最准)。用户明确选择插件时，失败就直接提示；
            # 不再静默切到旧网页或万邦，避免界面看似“没反应”但实际跑了另一条链路。
            print("[比价] 使用 1688 插件官方图搜", file=sys.stderr, flush=True)
            result = search_via_plugin(args.image_url, args.image_path, args.name)
            if isinstance(result, dict) and result.get("error"):
                print(f"[比价] 插件失败: {result.get('error')}", file=sys.stderr, flush=True)

        elif mode == "wanbang":
            if wb_cfg and has_url:
                print("[比价] 使用万邦 API", file=sys.stderr, flush=True)
                result = _run_wanbang(wb_cfg)
            else:
                print("[比价] 指定万邦但无key/无URL → 回退爬网页", file=sys.stderr, flush=True)
                result = _run_web()

        elif mode == "web":
            print("[比价] 使用爬网页", file=sys.stderr, flush=True)
            result = _run_web()

        else:  # auto:有万邦 key 且有 URL → 万邦;否则爬网页。
            if wb_cfg and wb_cfg.get("enabled", True) and has_url:
                print("[比价] (auto)使用万邦 API", file=sys.stderr, flush=True)
                result = _run_wanbang(wb_cfg)
            else:
                print("[比价] (auto)使用爬网页", file=sys.stderr, flush=True)
                result = _run_web()
    except Exception as e:
        result = {"error": str(e)}
    finally:
        sys.stdout = real_stdout

    encoded = (json.dumps(result, ensure_ascii=False) + "\n").encode("utf-8")
    real_stdout.buffer.write(encoded)
    real_stdout.buffer.flush()


if __name__ == "__main__":
    main()
