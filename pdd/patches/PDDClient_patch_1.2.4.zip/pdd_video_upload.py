# -*- coding: utf-8 -*-
"""把视频文件发到 PDD 创作者中心「多多视频」(逐条上传+发布)。机制见 handoff §16(已实测发成功)。

流程(每条):进发布页 → setInputFiles 喂 mp4 → 等上传完成(出现「一键发布」)→ 填视频描述 →
内容声明下拉固定选「内容无需标注」→ 点底部红色「一键发布」→ 成功=发布后页面离开表单(不再有「一键发布」)。
★ 文件名命名成 `<PDD goods_id>.mp4`,平台按文件名自动匹配商品(见 handoff §16)。

要 PDD 创作者中心登录态(`pdd_profiles/live_creator`,手动扫码登一次存进去,以后复用)。
未登录时返回 reason=creator-login-required；安全验证页返回 creator-checker-required。
调用方显示浏览器时可选择等待人工完成登录/验证后继续。

接口:
- async upload_one_video_on_page(page, video_path, description) -> dict   # 复用页,循环用
- async upload_videos(video_paths, description=, profile=) -> [dict]      # 独立:开浏览器循环上传
CLI:  python pdd_video_upload.py <video.mp4> [<video2.mp4> ...]
"""
import asyncio, os, sys
from urllib.parse import urlsplit
sys.path.insert(0, r"D:/files")
from playwright.async_api import async_playwright
from pdd_publish import find_chrome

PROFILE = r"D:/files/pdd_profiles/live_creator"
VIDEO_HOME = "https://live.pinduoduo.com/n-creator/video/home?from=mms&msfrom=mms_sidenav"
DECL_PREFIX = "内容无需标注"   # 内容声明固定选这项(用户拍板)
DEFAULT_DESC = ""             # 标题/描述非必填(用户:可不输入)→ 默认不填


def classify_creator_access_url(url: str) -> str:
    """区分真正掉登录与平台安全验证；只检查地址主体，不被 query 文本误导。"""
    try:
        parsed = urlsplit(str(url or ""))
        path = (parsed.path or "").lower()
        host = (parsed.netloc or "").lower()
    except Exception:
        return "creator-login-required"
    if "checker" in path:
        return "creator-checker-required"
    if any(marker in path for marker in ("/login", "/passport", "/sso")):
        return "creator-login-required"
    if host and "pinduoduo.com" not in host:
        return "creator-login-required"
    return ""


def creator_access_message(reason: str) -> str:
    return {
        "creator-login-required": "多多视频需要重新登录",
        "creator-checker-required": "多多视频需要完成安全验证",
        "creator-network-error": "多多视频网络连接失败，请稍后重试",
    }.get(str(reason or ""), "多多视频登录态不可用")


def _safe_creator_url(url: str) -> str:
    """日志只保留域名和路径，避免把跳转 query 中的敏感参数带回界面。"""
    try:
        parsed = urlsplit(str(url or ""))
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}" if parsed.netloc else parsed.path
    except Exception:
        return ""


_TRANSIENT_NAV_ERRORS = (
    "err_connection_closed",
    "err_connection_reset",
    "err_connection_aborted",
    "err_network_changed",
    "err_timed_out",
    "err_internet_disconnected",
    "timeout",
)


def _is_transient_navigation_error(exc: Exception) -> bool:
    text = str(exc or "").lower()
    return any(marker in text for marker in _TRANSIENT_NAV_ERRORS)


async def _goto_creator_home_with_retry(page, attempts=3, timeout_ms=25000) -> None:
    """创作者中心偶发断连时重试；非瞬时导航错误立即抛出。"""
    last_error = None
    total = max(1, int(attempts))
    for attempt in range(1, total + 1):
        try:
            await page.goto(VIDEO_HOME, wait_until="domcontentloaded", timeout=timeout_ms)
            return
        except Exception as exc:
            last_error = exc
            if not _is_transient_navigation_error(exc) or attempt >= total:
                raise
            print(f"[多多视频] 首页连接中断，第{attempt}/{total}次重试: {exc}",
                  file=sys.stderr, flush=True)
            await asyncio.sleep(1.2 * attempt)
    if last_error:
        raise last_error


async def ensure_creator_access(page, wait_for_user=False, timeout_seconds=300, on_wait=None) -> dict:
    """进入多多视频；显示浏览器时允许人工完成登录/验证后自动继续。"""
    try:
        await _goto_creator_home_with_retry(page)
    except Exception as exc:
        if on_wait:
            try:
                on_wait("creator-network-error")
            except Exception:
                pass
        return {"ok": False, "reason": "creator-network-error",
                "after_url": _safe_creator_url(page.url), "detail": str(exc)[:180]}
    await asyncio.sleep(5)
    reason = classify_creator_access_url(page.url)
    if not reason:
        return {"ok": True, "reason": "", "after_url": _safe_creator_url(page.url)}
    if on_wait:
        try:
            on_wait(reason)
        except Exception:
            pass
    if wait_for_user:
        deadline = asyncio.get_running_loop().time() + max(1, int(timeout_seconds))
        last_reason = reason
        while asyncio.get_running_loop().time() < deadline:
            await asyncio.sleep(1)
            reason = classify_creator_access_url(page.url)
            if reason:
                if reason != last_reason and on_wait:
                    try:
                        on_wait(reason)
                    except Exception:
                        pass
                last_reason = reason
                continue
            # 登录/验证完成后重新进入目标页，防止停在登录成功首页却没有上传控件。
            try:
                await _goto_creator_home_with_retry(page)
            except Exception as exc:
                return {"ok": False, "reason": "creator-network-error",
                        "after_url": _safe_creator_url(page.url), "detail": str(exc)[:180]}
            await asyncio.sleep(5)
            reason = classify_creator_access_url(page.url)
            if not reason:
                return {"ok": True, "reason": "", "after_url": _safe_creator_url(page.url)}
            last_reason = reason
    return {"ok": False, "reason": reason, "after_url": _safe_creator_url(page.url)}


# 关闭弹窗的检测+点击逻辑(已用 video_popup_probe.py 的 dry-run 在正常页验证零误伤)。
# ① 老逻辑:点纯文本 × / ✕(关别的简单弹窗,保留)。
# ② 新增:针对「审满40条领流量卡/去审核」这类随机促销弹窗 —— 它右上角是【图标式圆形 ×】(非文本),
#    老逻辑匹配不到。改用:锚点专属文字「视频待审/审满N/去审核」判定确有弹窗 → 只在那张弹层卡片
#    【右上角附近】找小尺寸可点元素(× 文本 / svg图标 / class含close / aria=close)去点;
#    ★绝不点文字含「去审核/发布/一键发布/确定/提交」的元素(免误触发布/花钱)。关掉则写日志坐实。
_CLOSE_PROMO_JS = r"""
() => {
  const AVOID = /去审核|查看数据详情|去查看|发布|一键发布|确定|提交|确认|删除|同步|取消发布/;
  const ANCHOR = /视频待审|审满\s*\d|去审核|带货周报|周报|发布视频数据|审核视频数据|流量卡/;

  function visibleRect(el){
    const r = el.getBoundingClientRect();
    if(r.width<=0 || r.height<=0) return null;
    const st = window.getComputedStyle(el);
    if(st.visibility==='hidden' || st.display==='none' || Number(st.opacity)===0) return null;
    return r;
  }
  function isCloseLike(el){
    const t=(el.innerText||el.textContent||'').trim();
    if(AVOID.test(t)) return false;
    const cls=(el.getAttribute('class')||'');
    const aria=(el.getAttribute('aria-label')||'');
    const title=(el.getAttribute('title')||'');
    return (t==='×'||t==='✕'||t==='✖') || /close|Close|关闭/.test(cls)
        || /close|关闭/i.test(aria) || /close|关闭/i.test(title);
  }
  function centerOf(r, how){
    return {x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2), how};
  }
  function topRightPoint(card, how){
    const cr = card.getBoundingClientRect();
    const cands=[];
    for(const el of document.querySelectorAll('button,a,[role=button],i,svg,use,div,span')){
      const r=visibleRect(el); if(!r) continue;
      if(r.width>80 || r.height>80) continue;
      if(!isCloseLike(el)) continue;
      const cx=r.x+r.width/2, cy=r.y+r.height/2;
      if(cx>=cr.right-90 && cx<=cr.right+80 && cy>=cr.top-70 && cy<=cr.top+95) cands.push({el,r});
    }
    cands.sort((a,b)=>Math.hypot((a.r.x+a.r.width/2)-cr.right,(a.r.y+a.r.height/2)-cr.top)
                         -Math.hypot((b.r.x+b.r.width/2)-cr.right,(b.r.y+b.r.height/2)-cr.top));
    if(cands.length) return centerOf(cands[0].r, how + '-coord');

    // PDD sometimes draws the close circle as an overlay with little useful DOM metadata.
    // Probe only the modal's top-right close zone and let Playwright perform a real mouse click.
    const points = [
      [cr.right - 20, cr.top + 20],
      [cr.right - 8, cr.top + 18],
      [cr.right + 2, cr.top + 2],
      [cr.right - 36, cr.top + 36],
      [cr.right - 1, cr.top + 52],
      [cr.right + 20, cr.top + 20]
    ];
    for(const [x,y] of points){
      const el = document.elementFromPoint(x, y);
      if(!el) continue;
      const t=(el.innerText||el.textContent||'').trim();
      if(AVOID.test(t)) continue;
      const r=visibleRect(el);
      if(r && (r.width>240 || r.height>200) && !isCloseLike(el)) continue;
      return {x: Math.round(x), y: Math.round(y), how: how + '-point'};
    }
    return null;
  }

  // ① Text close marks.
  for(const el of document.querySelectorAll('*')){
    const r=visibleRect(el); if(!r) continue;
    const t=(el.innerText||el.textContent||'').trim();
    if((t==='×'||t==='✕'||t==='✖') && r.width<70 && r.height<70) return centerOf(r, 'text-x');
  }

  // ② Text-anchored campaign/report dialogs.
  let anchor=null;
  for(const el of document.querySelectorAll('*')){
    if(el.children.length>0) continue;
    const r=visibleRect(el); if(!r) continue;
    const t=(el.innerText||el.textContent||'').trim();
    if(t.length<80 && ANCHOR.test(t)){ anchor=el; break; }
  }
  if(anchor){
    let card=anchor, bestScore=0;
    for(let p=anchor.parentElement,i=0; p&&i<14; p=p.parentElement,i++){
      const r=visibleRect(p); if(!r) continue;
      if(r.width>=200&&r.width<=980&&r.height>=100&&r.height<=820){
        const score = r.width * r.height;
        if(score > bestScore){ card=p; bestScore=score; }
      }
    }
    const hit = topRightPoint(card, 'anchored');
    if(hit) return hit;
  }

  // ③ Generic centered dialog fallback.
  const vw=window.innerWidth, vh=window.innerHeight;
  const cards=[];
  for(const el of document.querySelectorAll('div,[role=dialog],[class*=modal],[class*=Modal],[class*=dialog],[class*=Dialog]')){
    const r=visibleRect(el); if(!r) continue;
    if(r.width<220||r.width>980||r.height<100||r.height>820) continue;
    const st=window.getComputedStyle(el);
    const z=parseInt(st.zIndex||'0',10)||0;
    const centered = Math.abs((r.x+r.width/2)-vw/2)<vw*0.35 && Math.abs((r.y+r.height/2)-vh/2)<vh*0.4;
    const text=(el.innerText||'').trim();
    if(!centered && !ANCHOR.test(text)) continue;
    if(text.includes('一键发布') && text.length<120) continue;
    cards.push({el,r,z,score:z + (ANCHOR.test(text)?10000:0) + r.width*r.height/1000});
  }
  cards.sort((a,b)=>b.score-a.score);
  for(const c of cards.slice(0,5)){
    const hit = topRightPoint(c.el, 'generic');
    if(hit) return hit;
  }
  return null;
}
"""

def _clog(msg):
    try:
        import time as _t
        with open(r"D:/files/data/video_debug.log", "a", encoding="utf-8") as f:
            f.write(_t.strftime("%H:%M:%S ") + msg + "\n")
    except Exception:
        pass


async def _close_promo(page):
    """关「去审核/领流量卡/带货周报」等遮挡弹窗。JS 只算安全坐标,用真实鼠标点击关闭。"""
    for _ in range(3):
        try:
            await page.keyboard.press("Escape")
        except Exception:
            pass
        try:
            hit = await page.evaluate(_CLOSE_PROMO_JS)
        except Exception:
            hit = None
        if not hit:
            break
        try:
            await page.mouse.click(float(hit.get("x")), float(hit.get("y")))
            _clog(f"[关弹窗] 点击弹窗关闭坐标 (方式={hit.get('how')} x={hit.get('x')} y={hit.get('y')})")
        except Exception as e:
            _clog(f"[关弹窗] 点击关闭坐标失败: {e!r}")
            break
        await asyncio.sleep(0.5)

async def _has_publish_btn(page) -> bool:
    return await page.evaluate(
        """()=>{for(const el of document.querySelectorAll('button,a,[role=button],div,span')){if((el.innerText||'').trim()==='一键发布'){const r=el.getBoundingClientRect();if(r.width>40&&r.top>300)return true;}}return false;}""")


def publish_state_is_success(url_before: str, url_after: str,
                             publish_button_visible: bool, success_signal: bool) -> bool:
    if success_signal or not publish_button_visible:
        return True
    return bool(url_after != url_before and "video/home" not in str(url_after or ""))


async def _read_publish_feedback(page) -> dict:
    """提交后只读成功/失败提示；不点击确认按钮、不关闭任何弹层。"""
    return await page.evaluate(r"""() => {
      const visible = el => {
        const r = el.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) return false;
        const st = getComputedStyle(el);
        return st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity) !== 0;
      };
      let publishButton = false;
      for (const el of document.querySelectorAll('button,a,[role=button],div,span')) {
        if ((el.innerText || '').trim() !== '一键发布' || !visible(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width > 40 && r.top > 300) { publishButton = true; break; }
      }
      const texts = [];
      const sels = '[class*=toast],[class*=Toast],[class*=message],[class*=Message],'
                 + '[class*=notify],[class*=Notify],[class*=alert],[class*=Alert],'
                 + '[role=dialog],[class*=modal],[class*=Modal],[class*=dialog],[class*=Dialog]';
      for (const el of document.querySelectorAll(sels)) {
        if (!visible(el)) continue;
        const t = (el.innerText || '').trim().replace(/\s+/g, ' ');
        if (t && t.length <= 180 && !texts.includes(t)) texts.push(t);
      }
      const feedbackText = texts.join(' ');
      let successSignal = /发布成功|提交成功|已提交审核/.test(feedbackText);
      let failureSignal = /发布失败|提交失败|操作失败|请稍后重试|发布频繁|系统繁忙/.test(feedbackText);
      // 某些版本把结果写成普通短文本而不是 toast；只认叶子节点短句，避免把导航里的“审核中”误判成功。
      for (const el of document.querySelectorAll('span,div,p')) {
        if (el.children.length || !visible(el)) continue;
        const t = (el.innerText || '').trim().replace(/\s+/g, ' ');
        if (!t || t.length > 80) continue;
        if (/发布成功|提交成功|已提交审核/.test(t)) successSignal = true;
        if (/发布失败|提交失败|操作失败|请稍后重试|发布频繁|系统繁忙/.test(t)) failureSignal = true;
      }
      return {publishButton, successSignal, failureSignal, texts: texts.slice(0, 6)};
    }""")


async def _select_declaration(page) -> bool:
    """内容声明下拉:滚到它 → 点「请选择」→ 精确选「内容无需标注…」(避开点到下拉容器)。"""
    await page.evaluate(
        """()=>{for(const el of document.querySelectorAll('*')){const t=(el.innerText||'').trim();if(/内容声明/.test(t)&&t.length<12){el.scrollIntoView({block:'center'});return;}}}""")
    await asyncio.sleep(1)
    sel = await page.evaluate(
        """()=>{let label=null;for(const el of document.querySelectorAll('*')){const t=(el.innerText||'').trim();if(/内容声明/.test(t)&&t.length<12){label=el;break;}}
        if(!label)return null;const lr=label.getBoundingClientRect();
        for(const el of document.querySelectorAll('div,span,input')){const t=(el.innerText||el.placeholder||'').trim();const r=el.getBoundingClientRect();
        if(t==='请选择'&&r.top>=lr.top-20&&r.top<lr.top+70&&r.width>60)return{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};}return null;}""")
    if not sel:
        return False
    await page.mouse.click(sel["x"], sel["y"])
    await asyncio.sleep(1.2)
    # 选单个选项:text 以「内容无需标注」开头且 length<40(排除把所有选项拼一起的容器)
    picked = await page.evaluate(
        """(prefix)=>{let best=null;
        for(const el of document.querySelectorAll('li,[role=option],div,span')){const t=(el.innerText||'').trim();
        if(!t.startsWith(prefix)||t.length>40)continue;const r=el.getBoundingClientRect();
        if(r.width>40&&r.height>10&&r.top>0){if(!best||r.top<best.top)best={x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2),top:r.top};}}
        return best;}""", DECL_PREFIX)
    if not picked:
        return False
    await page.mouse.click(picked["x"], picked["y"])
    await asyncio.sleep(0.6)
    return True


async def _set_sync_off(page) -> bool:
    """「同步视频至店铺动态」默认开启 → 点「取消同步」(用户要求不同步到店铺动态)。"""
    return await page.evaluate(
        """()=>{let cands=[];
        for(const el of document.querySelectorAll('*')){if(el.children.length>0)continue;
        const t=(el.innerText||'').trim();if(t==='取消同步'){const r=el.getBoundingClientRect();if(r.width>0&&r.height>0)cands.push(el);}}
        if(!cands.length)return false;
        const el=cands[0];(el.closest('label')||el).click();
        const inp=(el.closest('label')||el).querySelector?(el.closest('label')||el).querySelector('input[type=radio]'):null;
        if(inp&&!inp.checked)inp.click&&inp.click();
        return true;}""")


async def upload_one_video_on_page(page, video_path, description=DEFAULT_DESC, preclose_popups=True,
                                   wait_for_access=False, access_status=None) -> dict:
    """在已登录创作者中心的 page 上发一条视频。返回 {video, ok, reason?, after_url?, toast?}。"""
    res = {"video": video_path, "ok": False}
    if not os.path.exists(video_path):
        res["reason"] = "file-not-found"
        return res
    access = await ensure_creator_access(
        page, wait_for_user=wait_for_access, on_wait=access_status)
    if not access.get("ok"):
        res.update(access)
        return res
    if preclose_popups:
        await _close_promo(page)
        await asyncio.sleep(0.3)
        await _close_promo(page)
    await asyncio.sleep(1)

    fi = await page.query_selector('input[type=file]')
    if not fi:
        res["reason"] = "no-file-input"
        return res
    await fi.set_input_files(video_path)

    # ★ 明确等「视频上传成功」那个元素出现才算传完(不靠时间;预览会提前渲染,不能用 video 元素判定)。
    # 大视频久一点也等(上限纯兜底防卡死),只要还没出「视频上传成功」就继续等。
    ready = False
    for _ in range(150):   # 上限 ~600s 兜底,正常一出现就 break
        await asyncio.sleep(4)
        await _close_promo(page)
        seen = await page.evaluate(
            """()=>{const t=document.body.innerText||'';
            return {ok:t.includes('视频上传成功'), fail:t.includes('上传失败')};}""")
        if seen.get("ok"):
            ready = True
            break
        if seen.get("fail"):
            res["reason"] = "upload-failed"
            return res
    if not ready:
        res["reason"] = "upload-timeout"
        return res
    await asyncio.sleep(2)   # 上传成功后稍等,让「推荐商品」自动匹配落定

    # 视频描述(可选,标题非必填;description 为空就跳过不填)
    if description:
        try:
            await page.evaluate(
                """()=>{for(const el of document.querySelectorAll('*')){const t=(el.innerText||'').trim();if(t==='添加视频描述'){el.click&&el.click();el.focus&&el.focus();return;}}}""")
            await asyncio.sleep(0.4)
            ta = await page.query_selector('textarea, [contenteditable="true"], input[placeholder*="描述"]')
            if ta:
                await ta.click()
                await ta.type(description, delay=15)
            else:
                await page.keyboard.type(description, delay=15)
            await asyncio.sleep(0.4)
        except Exception as e:
            res["desc_err"] = repr(e)

    # 同步视频至店铺动态 → 取消同步(用户要求)
    res["sync_off"] = await _set_sync_off(page)

    # 内容声明 = 内容无需标注(必选,否则发布被拦)
    res["decl_ok"] = await _select_declaration(page)

    # 点底部红色「一键发布」(top>300,避开左侧导航的「发布视频」)
    pub = await page.evaluate(
        """()=>{let b=null;for(const el of document.querySelectorAll('button,a,[role=button],div,span')){if((el.innerText||'').trim()==='一键发布'){const r=el.getBoundingClientRect();if(r.width>40&&r.height>16&&r.top>300)b={x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};}}return b;}""")
    if not pub:
        res["reason"] = "no-publish-btn"
        return res
    url_before = page.url
    await page.mouse.click(pub["x"], pub["y"])
    # 最多等60秒。提交后不再调用通用“关弹窗”，避免把成功提示关掉后误判失败。
    ok = False
    feedback = {}
    for _ in range(30):
        await asyncio.sleep(2)
        feedback = await _read_publish_feedback(page)
        if publish_state_is_success(
                url_before, page.url, bool(feedback.get("publishButton")),
                bool(feedback.get("successSignal"))):
            ok = True
            break
        if feedback.get("failureSignal"):
            break
    res["after_url"] = page.url
    if ok:
        res["ok"] = True
    else:
        res["reason"] = "publish-blocked"
        res["toast"] = list(feedback.get("texts") or [])[:4]
        _clog(f"[发布受阻] file={os.path.basename(video_path)} url={_safe_creator_url(page.url)} "
              f"feedback={res['toast']}")
    return res


async def upload_videos(video_paths, description=DEFAULT_DESC, profile=PROFILE) -> list:
    """独立版:开浏览器(live_creator 登录态)循环上传多条视频。返回每条结果。"""
    results = []
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            user_data_dir=profile, executable_path=find_chrome(), headless=False,
            args=["--start-maximized", "--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"], viewport=None)
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        try:
            for i, vp in enumerate(video_paths):
                r = await upload_one_video_on_page(page, vp, description)
                results.append(r)
                tag = "✓发布" if r["ok"] else ("✗ " + str(r.get("reason")))
                print("[%d/%d] %s  %s  %s" % (i + 1, len(video_paths), os.path.basename(vp), tag,
                                              r.get("toast") or r.get("after_url") or ""))
        finally:
            try:
                await ctx.close()
            except Exception:
                pass
    return results


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python pdd_video_upload.py <video.mp4> [<video2.mp4> ...]")
        sys.exit(1)
    paths = sys.argv[1:]
    res = asyncio.run(upload_videos(paths))
    ok = sum(1 for r in res if r["ok"])
    print(f"\n完成: {ok}/{len(res)} 条发布成功")
